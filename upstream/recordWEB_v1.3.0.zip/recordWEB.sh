#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $(uname -s) != Linux || ! -f module/recordWEB.py ]]; then
    echo '[recordWEB] Linux에서 프로젝트 폴더의 recordWEB.sh를 실행하세요.' >&2
    exit 20
fi
if (( $# )) && [[ $# != 1 || $1 != --check ]]; then
    echo '사용법: ./recordWEB.sh [--check]' >&2
    exit 20
fi
source module/install/linux_bootstrap.sh
(( EUID != 0 )) || fail '일반 사용자로 실행하세요. 시스템 패키지가 필요한 경우에만 sudo를 요청합니다.'
unset PYTHONHOME PYTHONPATH
export PYTHONNOUSERSITE=1 PYTHONUTF8=1
export PATH="$PATH:${HOME:-/nonexistent}/.local/bin"
umask 077
prepare_linux
unset RWEB_LINUX_GUI
if .venv-linux/bin/python -c 'from module.data_manager import loadConfig; from module.run_mode import resolve_run_mode; raise SystemExit(resolve_run_mode(loadConfig()) == "headless")'; then
    if [[ -z ${DISPLAY:-} && -z ${WAYLAND_DISPLAY:-} ]]; then
        echo '[recordWEB] 그래픽 세션이 없어 Headless로 실행합니다. 저장된 실행 모드는 유지합니다.'
    elif (set -e; prepare_linux_gui); then
        export RWEB_LINUX_GUI="$PWD/.venv-linux-gui/bin/python"
    else
        echo '[recordWEB] 그래픽 환경을 준비하지 못해 Headless로 실행합니다. 저장된 실행 모드는 유지합니다.' >&2
    fi
fi
[[ ${1:-} != --check ]] || exit 0
exec "$PWD/.venv-linux/bin/python" -u "$PWD/module/recordWEB.py" --backend
