@echo off
setlocal
chcp 65001 >nul
set PYTHONUTF8=1
set "PYTHONHOME="
set "PYTHONPATH="
set "PYTHONNOUSERSITE=1"
cd /d "%~dp0"

if /I "%~1"=="--help" goto help
if /I "%~1"=="/?" goto help
if /I "%~1"=="--repair" goto repair
if /I "%~1"=="--check" goto check
if /I "%~1"=="--startup" goto startup

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0module\install\install_windows.ps1" -RecordWeb
if errorlevel 1 exit /b 1

".venv\Scripts\python.exe" "%~dp0module\recordWEB_launcher.py" %*
exit /b %errorlevel%

:check
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0module\install\install_windows.ps1" -CheckOnly -RecordWeb
exit /b %errorlevel%

:startup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0module\install\install_windows.ps1" -CheckReady -LogStartupCheck -RecordWeb
if errorlevel 1 exit /b 20
if not exist ".venv\Scripts\pythonw.exe" exit /b 20
start "" /b ".venv\Scripts\pythonw.exe" "%~dp0module\recordWEB_launcher.py" --startup
exit /b 0

:repair
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0module\install\install_windows.ps1" -Repair -RecordWeb
exit /b %errorlevel%

:help
echo Usage: recordWEB.bat [--startup ^| --repair ^| --check ^| --help]
echo Run this BAT directly from cmd.exe. Do not prefix it with python.
exit /b 0
