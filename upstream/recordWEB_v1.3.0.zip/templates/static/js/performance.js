// Passive local diagnostics for the actual rendered recording page.
document.addEventListener('DOMContentLoaded', async () => {
  const cards = [...document.querySelectorAll('.channel')];
  if (!cards.length) return;
  try {
    if (window.recordWebReady) await window.recordWebReady;
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    const firstCards = performance.now();
    const pictures = cards.map(card => card.querySelector('img')).filter(Boolean);
    await Promise.all(pictures.map(image => new Promise(resolve => {
      if (image.complete) return resolve();
      image.addEventListener('load',resolve,{once:true});
      image.addEventListener('error',resolve,{once:true});
      setTimeout(resolve,10000);
    })));
    const data = {cards:cards.length,first_cards_ms:firstCards,
      first_contentful_paint_ms:performance.getEntriesByName('first-contentful-paint')[0]?.startTime || 0,
      initial_thumbnails_ms:performance.now(),thumbnail_count:pictures.length,
      thumbnails_loaded:pictures.filter(image=>image.complete&&image.naturalWidth>0).length};
    console.debug('[PERF][RECORDING-PAGE]',data);
    await fetch('/api/performance/client',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  } catch(error) { console.debug('[PERF] measurement unavailable',error); }
});
