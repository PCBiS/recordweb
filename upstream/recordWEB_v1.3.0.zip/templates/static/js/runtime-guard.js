(() => {
  const expectedVersion = 'v1.3.0';
  const expectedBuild = document.querySelector('meta[name="recordweb-build"]')?.content;
  const version = document.querySelector('meta[name="recordweb-version"]')?.content;
  const nativeFetch = window.fetch.bind(window);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  window.recordWebReady = (async () => {
    try {
      const response = await nativeFetch('/api/runtime/identity', {cache:'no-store', signal:controller.signal});
      if (!response.ok) throw new Error('실행 중인 서버가 새 UI의 식별 API를 지원하지 않습니다.');
      const identity = await response.json();
      if (!/^[0-9a-f]{64}$/.test(expectedBuild || '') || version !== expectedVersion ||
          identity.product !== 'recordWEB' || identity.version !== expectedVersion || identity.build !== expectedBuild) {
        throw new Error('실행 중인 백엔드와 UI의 버전 또는 빌드가 다릅니다.');
      }
      document.getElementById('runtime-pending-style')?.remove();
      return identity;
    } catch (error) {
      const show = () => {
        document.getElementById('runtime-pending-style')?.remove();
        document.body.replaceChildren();
        const message = document.createElement('p');
        message.style.cssText='padding:40px;white-space:pre-line;font:18px sans-serif';
        message.textContent='recordWEB 연결을 중단했습니다.\n'+error.message+'\n기존 앱에서 작업을 확인하고 완전 종료한 뒤 recordWEB.bat으로 다시 실행하세요.';
        document.body.append(message);
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', show, {once:true}); else show();
      throw error;
    } finally { clearTimeout(timer); }
  })();
  // Every page, including inline form scripts, waits for the same identity check.
  window.fetch = async (...args) => { await window.recordWebReady; return nativeFetch(...args); };
  window.recordWebReady.catch(() => {});
})();
