document.addEventListener('recordweb:page-ready', setupCookieFormListeners);

// 쿠키 관리 폼 리스너
function setupCookieFormListeners() {
  const updateCookiesForm = document.getElementById("updateCookiesForm");

  if (updateCookiesForm) {
    updateCookiesForm.addEventListener("submit", async function (event) {
      event.preventDefault();

      // key:value 수집
      const newCookies = {
        chzzk: {
          NID_AUT: "",
          NID_SES: "",
        },
        cime: {
          "mauth-authorization-code": "",
          "session-id": "",
        },
      };

      const inputs = document.querySelectorAll("#updateCookiesForm input");
      inputs.forEach((input) => {
        if (input.type === "submit" || !input.name.trim()) return;

        const name = input.name.trim();
        const value = input.value.trim();

        if (name.includes(".")) {
          const [platform, key] = name.split(".", 2);
          if (!newCookies[platform]) newCookies[platform] = {};
          newCookies[platform][key] = value;
        }
      });

      try {
        const response = await fetch("/cookies", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newCookies),
        });

        if (!response.ok) throw new Error(`HTTP 오류: ${response.status}`);

        const data = await response.json();

        if (data.status === "success") {
          await recordWebDialog.notice("쿠키를 저장했습니다.");
          setTimeout(() => (window.location.href = "/cookies"), 1500);
        } else {
          recordWebDialog.notice(`쿠키 업데이트에 실패했습니다: ${data.message || "알 수 없는 오류"}`);
        }
      } catch (error) {
        console.error("쿠키 업데이트 중 오류 발생:", error);
        recordWebDialog.notice("쿠키 업데이트 중 문제가 발생했습니다.");
      }
    });
  }

  const checkChzzkCookieBtn = document.getElementById("checkChzzkCookieBtn");

  if (checkChzzkCookieBtn) {
    checkChzzkCookieBtn.addEventListener("click", async function () {
      const resultEl = document.getElementById("chzzkCookieCheckResult");
      if (resultEl) resultEl.textContent = "치지직 쿠키 확인 중...";

      try {
        const response = await fetch("/api/check_chzzk_cookie", {
          method: "GET",
          cache: "no-store",
        });

        const data = await response.json();

        if (resultEl) {
          resultEl.textContent = data.ok
            ? `정상: ${data.message}`
            : `확인 필요: ${data.message}`;
        }

        recordWebDialog.notice(data.ok ? `정상: ${data.message}` : `확인 필요: ${data.message}`);
      } catch (error) {
        if (resultEl) resultEl.textContent = `확인 실패: ${error}`;
        recordWebDialog.notice(`치지직 쿠키 확인 중 오류가 발생했습니다: ${error}`);
      }
    });
  }

  const checkCimeCookieBtn = document.getElementById("checkCimeCookieBtn");

  if (checkCimeCookieBtn) {
    checkCimeCookieBtn.addEventListener("click", async function () {
      const resultEl = document.getElementById("cimeCookieCheckResult");
      if (resultEl) resultEl.textContent = "씨미 쿠키 확인 중...";

      try {
        const response = await fetch("/api/check_cime_cookie", {
          method: "GET",
          cache: "no-store",
        });

        const data = await response.json();

        if (resultEl) {
          resultEl.textContent = data.ok
            ? `정상: ${data.message}`
            : `확인 필요: ${data.message}`;
        }

        recordWebDialog.notice(data.ok ? `정상: ${data.message}` : `확인 필요: ${data.message}`);
      } catch (error) {
        if (resultEl) resultEl.textContent = `확인 실패: ${error}`;
        recordWebDialog.notice(`씨미 쿠키 확인 중 오류가 발생했습니다: ${error}`);
      }
    });
  }
}
