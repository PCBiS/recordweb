let filesCurrentPath = null;
let filesRoots = [];
let filesAllItems = [];           // 파일 검색 필터용 캐시
let selectedPaths = new Set();    // 모바일 선택 상태(경로 Set)
let selectMode = false;           // 모바일: 선택모드 여부
let movePickerPath = null;		  // 폴더 선택 모달의 현재 경로

// 길게 누르기 판정 시간
const LONG_PRESS_MS = 380;         

// 파일관리에서 숨김으로 간주할 후보 이름(Windows/일반 공통)
const HIDDEN_NAME_SET = new Set([
  'system volume information',
  '$recycle.bin',
  'recycler',
  'pagefile.sys',
  'hiberfil.sys',
  'swapfile.sys',
  'config.msi',
  'msocache',
  'recovery',
  'desktop.ini',
  'thumbs.db'
]);

// 숨김 판단 헬퍼(리눅스 dot 숨김 + 세트)
function isHiddenItem(nameOrItem){
  const n = (typeof nameOrItem === 'string' ? nameOrItem : (nameOrItem?.name || '')).trim();
  if (!n) return false;
  if (n.startsWith('.')) return true;                  // dot hidden
  return HIDDEN_NAME_SET.has(n.toLowerCase());         // set 매칭
}

// escape 함수
function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

document.addEventListener('recordweb:page-ready', setupFilesPage);

// 파일 관리 크기/퍼센트 포맷
function bytesToHuman(n) {
  if (n == null || isNaN(n)) return "-";
  const units = ["B", "KB", "MB", "GB", "TB", "PB"];
  let i = 0,
    v = Number(n);
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v >= 10 ? 0 : 1)} ${units[i]}`;
}

function percent(num, den) {
  if (!den || den <= 0) return 0;
  return Math.min(100, Math.max(0, Math.round((num / den) * 100)));
}


// API 래퍼 (same-origin + 오류처리)
async function apiGet(url) {
  const res = await safeFetch(url, { method: "GET" });
  return res.json();
}

async function apiPost(url, body) {
  const res = await safeFetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body || {}),
  });
  return res.json();
}


// 파일매니저 비활성 모달 표시
function showFMDisabledModal() {
  const app = document.getElementById("files-app");
  if (app) app.style.display = "none";

  const modal = document.getElementById("fm-disabled-modal");
  if (!modal) return;

  modal.classList.remove("hidden");

  // 설정으로 이동
  document.getElementById("go-config")?.addEventListener(
    "click",
    () => { window.location.href = "/config"; },
    { once: true }
  );

  const closeBtn =
    document.getElementById("close-fm-modal") ||
    document.getElementById("close-modal");

  closeBtn?.addEventListener(
    "click",
    () => { window.location.href = "/"; },
    { once: true }
  );
}



//fetch 공통 방어 래퍼
async function safeFetch(url, opts) {
  const res = await fetchWithTimeout(url, { ...(opts || {}) }, 10000);
  if (res.ok) return res;

  const isFilesApi = url.startsWith("/api/files/");
  let detail = "";
  try {
    const j = await res.clone().json();
    detail = j?.detail || "";
  } catch {}

  const fmDisabledByMsg = /file\s*manager.*disabled/i.test(detail);
  const forbiddenByStatus = res.status === 401 || res.status === 403;
  const forbiddenByMsg = /outside.*allowed\s*roots|not\s*allowed|forbidden|permission\s*denied|access\s*denied|restricted/i.test(detail);

  if (isFilesApi && fmDisabledByMsg) {
    showFMDisabledModal();
    const err = new Error("File manager is disabled");
    err.fmDisabled = true;
    err.status = res.status;
    throw err;
  }

  if (isFilesApi && (forbiddenByStatus || forbiddenByMsg)) {
    const err = new Error(detail || "보안 정책상 접근이 제한된 경로입니다.");
    err.status = res.status;
    err.pathDenied = true;
    throw err;
  }

  const msg = detail || `Request failed: ${res.status}`;
  const err = new Error(msg);
  err.status = res.status;
  throw err;
}


// 파일 API 에러 → 사용자 친화 메시지
function formatFileApiError(e, action = "열람", path = "") {
  const t = String(e.message || "");
  const s = e.status || 0;

  if (e.fmDisabled) {
    return "파일 관리 기능이 비활성화되어 있어 작업을 진행할 수 없습니다.\n설정에서 파일관리 기능을 활성화해 주세요.";
  }

  const securityHit =
    e.pathDenied ||
    s === 401 || s === 403 ||
    /outside.*allowed\s*roots|not\s*allowed|forbidden|permission\s*denied|access\s*denied|restricted/i.test(t);

  if (securityHit) {
    return `보안 정책상 접근이 제한된 경로입니다.\n허용된 루트 내부에서만 ${action}할 수 있습니다.` +
           (path ? `\n요청 경로: ${path}` : "");
  }

  if (s === 404 || /not\s*found|no\s*such|invalid\s*path/i.test(t)) {
    return `대상 경로를 찾을 수 없습니다.` + (path ? `\n요청 경로: ${path}` : "");
  }

  if (s >= 500) {
    return `요청 처리 중 서버 오류가 발생했습니다.` +
           (path ? `\n요청 경로: ${path}` : "") +
           `\n허용되지 않은 경로 접근일 가능성이 있습니다.`;
  }

  return `요청 실패: ${t || s || "알 수 없는 오류"}`;
}


// 파일루트/용량 불러와 초기화
async function fetchRootsAndInit() {
  let data;
  try {
    data = await apiGet("/api/files/roots");
  } catch (e) {
    if (e.status === 404 || /not\s*found/i.test(String(e.message || ""))) {
      const ui = await apiGet("/user_info");
      const conf = ui?.config || {};
      const enabled = !!(conf.loginMode && conf.fileManagerEnabled);
      const rootsArr = Array.isArray(conf.fileManagerRoots) ? conf.fileManagerRoots : [];
      const roots = rootsArr.map((p) => ({ path: p, label: p }));

      if (!enabled || roots.length === 0) {
        showFMDisabledModal();
        const err2 = new Error("File manager is disabled or no allowed roots");
        err2.fmDisabled = true;
        throw err2;
      }

      data = { roots, default: roots[0]?.path };
    } else {
      throw e;
    }
  }

  filesRoots = (data.roots || []).map((r) => (typeof r === "string" ? { path: r, label: r } : r));

  const select = document.getElementById("rootSelect");
  select.innerHTML = "";
  filesRoots.forEach((r, idx) => {
    const opt = document.createElement("option");
    opt.value = r.path;
    opt.textContent = r.label || r.path;
    if (idx === 0) opt.selected = true;
    select.appendChild(opt);
  });

  filesCurrentPath = data.default || filesRoots[0]?.path || null;
  if (!filesCurrentPath) {
    recordWebDialog.notice("허용된 루트가 없습니다. 설정에서 허용 경로를 추가해 주세요.");
    return;
  }
  document.getElementById("pathInput").value = filesCurrentPath;

  try {
    await Promise.all([refreshDiskUsage(), listAndRender(filesCurrentPath)]);
  } catch (e) {
    if (
      /not\s*found|no\s*such|invalid\s*path|not\s*allowed/i.test(String(e.message || "")) &&
      filesRoots[0]?.path &&
      filesRoots[0].path !== filesCurrentPath
    ) {
      await listAndRender(filesRoots[0].path);
      await refreshDiskUsage();
    } else {
      throw e;
    }
  }
}


// 디스크 사용량 갱신
async function refreshDiskUsage() {
  if (!filesRoots.length) return;
  const query = filesRoots.map((r) => `paths=${encodeURIComponent(r.path)}`).join("&");
  const data = await apiGet(`/api/files/disk-usage?${query}`);
  renderDiskCards(data.usages || []);
}


// 디스크 요약(한 줄 칩 형태) 렌더
function renderDiskCards(usages) {
  const wrap = document.getElementById('storage-summary');
  wrap.classList.add('disk-chips');
  wrap.innerHTML = '';

  usages.forEach(u => {
    const used = (u.total || 0) - (u.free || 0);
    const p = percent(used, u.total || 0);

    const chip = document.createElement('div');
    chip.className = 'disk-chip';
	chip.innerHTML = `
	  <span class="disk-ico">💽</span>
	  <strong>${escapeHtml(u.label || u.path)}</strong>
	  <span>${escapeHtml(bytesToHuman(used))} / ${escapeHtml(bytesToHuman(u.total))} (${p}%)</span>
	  <span class="bar"><i style="width:${p}%;"></i></span>
	`;
    wrap.appendChild(chip);
  });
}


// 경로 → 브레드크럼 빌드
function buildBreadcrumbs(pathStr) {
  const bc = document.getElementById("breadcrumbs");
  bc.innerHTML = "";

  const parts = pathStr.split(/[\\/]/).filter(Boolean);
  const seps = pathStr.includes("\\") ? "\\" : "/";

  let accum = "";
  if (pathStr.includes(":")) {
    accum = parts.shift() + seps; // "D:"
  } else if (pathStr.startsWith("/")) {
    accum = seps; // "/"
  }

  const addCrumb = (label, full) => {
    const a = document.createElement("a");
    a.href = "javascript:void(0)";
    a.textContent = label || full || "/";
    a.addEventListener("click", () => changePath(full || seps));
    bc.appendChild(a);
    const sepNode = document.createElement("span");
    sepNode.textContent = " / ";
    bc.appendChild(sepNode);
  };

  if (accum) addCrumb(accum.replace(/[\\\/]$/, ""), accum);

  parts.forEach((p) => {
    accum = accum ? (accum.endsWith(seps) ? accum + p : accum + seps + p) : p;
    addCrumb(p, accum);
  });

  if (bc.lastChild) bc.removeChild(bc.lastChild);
}


// 디렉터리 목록 로드 + 렌더
async function listAndRender(pathStr) {
  try {
    const data = await apiGet(`/api/files/ls?path=${encodeURIComponent(pathStr)}`);
    filesCurrentPath = data.path || pathStr;
    const raw = data.items || [];
	filesAllItems = raw.filter(it => !isHiddenItem(it));

    document.getElementById('pathInput').value = filesCurrentPath;
    buildBreadcrumbs(filesCurrentPath);
    renderFileTable(filesAllItems);

    // 경로 바뀔 때 모바일 선택 초기화
    clearSelection();
  } catch (e) { throw e; }
}


// 수정일 포맷
function fmtMtime(m) {
  if (m == null) return '-';
  if (typeof m === 'number') {
    const d = new Date(m * 1000);
    return isNaN(d) ? '-' : d.toLocaleString();
  }
  return String(m);
}


// 파일/폴더 리스트형 렌더
function renderFileTable(items) {
  // 모바일이면 테이블 대신 모바일 렌더러
  if (window.matchMedia('(max-width: 900px)').matches) {
    renderFileListMobile(items);
    return;
  }

  const tbody = document.getElementById('fileTableBody');
  const filterText = (document.getElementById('fileSearch').value || '').toLowerCase();
  tbody.innerHTML = '';

  const filtered = items.filter(it => !filterText || (it.name || '').toLowerCase().includes(filterText));

  if (!filtered.length) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.colSpan = 6; // 체크박스 열 추가로 6열
    td.textContent = '표시할 항목이 없습니다.';
    tr.appendChild(td);
    tbody.appendChild(tr);
    return;
  }

  // 헤더의 전체선택 체크박스(#chkAll)와 동기화
  const chkAll = document.getElementById('chkAll');
  if (chkAll) {
    // 현재 화면에 보이는 항목 기준으로 체크 상태 반영
    const totalCount    = filtered.length;
    const selectedCount = filtered.filter(it => selectedPaths.has(it.path)).length;
    chkAll.indeterminate = selectedCount > 0 && selectedCount < totalCount;
    chkAll.checked       = totalCount > 0 && selectedCount === totalCount;

    chkAll.onchange = () => {
      filtered.forEach(it => {
        // 폴더도 선택 허용(필요시 제한하려면 it.is_dir은 건너뛰기)
        if (chkAll.checked) selectedPaths.add(it.path);
        else selectedPaths.delete(it.path);
      });
      // 다시 렌더해 UI 반영
      renderFileTable(items);
    };
  }

  filtered.forEach(it => {
    const tr = document.createElement('tr');

	// 선택 체크박스
	const tdCheck = document.createElement('td');
	tdCheck.className = 'col-check';
	const cb = document.createElement('input');
	cb.type = 'checkbox';
	cb.className = 'row-check';
	cb.value = it.path;
	cb.checked = selectedPaths.has(it.path);
	cb.addEventListener('change', () => {
	  if (cb.checked) selectedPaths.add(it.path);
	  else selectedPaths.delete(it.path);

	  // 헤더 전체선택 상태 즉시 갱신
	  const allRowChecks = tbody.querySelectorAll('input.row-check');
	  const total = allRowChecks.length;
	  const sel   = Array.from(allRowChecks).filter(x => x.checked).length;
	  const hdr   = document.getElementById('chkAll');
	  if (hdr) {
		hdr.indeterminate = sel > 0 && sel < total;
		hdr.checked       = sel > 0 && sel === total;
	  }

	  // 모바일 액션바 쓰면 상태 갱신
	  if (typeof updateMobileActionBar === 'function') updateMobileActionBar();
	});
	tdCheck.appendChild(cb);


    // 유형
    const tdType = document.createElement('td');
    tdType.className = 'col-type';
    tdType.textContent = it.is_dir ? '폴더' : (it.ext || '파일');

    // 이름
    const tdName = document.createElement('td');
    tdName.className = 'col-name';
    const nameBtn = document.createElement('button');
    nameBtn.className = 'linklike';
    nameBtn.textContent = it.name || '(이름없음)';
    if (it.is_dir) {
      nameBtn.title = '이 폴더 열기';
      nameBtn.addEventListener('click', () => changePath(it.path));
    } else {
      nameBtn.title = '미리보기 (미디어 파일)';
      nameBtn.addEventListener('click', () => openPreview(it.path));
    }
    tdName.appendChild(nameBtn);

    // 크기
    const tdSize = document.createElement('td');
    tdSize.className = 'col-size';
    tdSize.textContent = it.is_dir ? '-' : bytesToHuman(it.size);

    // 수정일
    const tdMtime = document.createElement('td');
    tdMtime.className = 'col-mtime';
    tdMtime.textContent = it.mtime || '-';

    // 작업(1×4)
    const tdAct = document.createElement('td');
    tdAct.className = 'actions';

    const btnMove   = document.createElement('button');  btnMove.textContent   = '이동';   btnMove.disabled   = !!it.locked;
    const btnDelete = document.createElement('button');  btnDelete.textContent = it.locked ? '잠김' : '삭제'; btnDelete.disabled = !!it.locked;
    const btnRename = document.createElement('button');  btnRename.textContent = '수정';   btnRename.disabled = !!it.locked;
    const btnDetail = document.createElement('button');  btnDetail.textContent = '상세';

    btnRename.addEventListener('click', () => onRename(it));
    btnMove  .addEventListener('click', () => onMove(it));
    btnDelete.addEventListener('click', () => onDelete(it));
    btnDetail.addEventListener('click', () => {
      const lines = [
        `이름 : ${it.name}`,
        `종류 : ${it.is_dir ? '폴더' : (it.ext || '파일')}`,
        `크기 : ${it.is_dir ? '-' : bytesToHuman(it.size)}`,
        `수정 : ${it.mtime || '-'}`,
        `경로 : ${it.path}`
      ];
      recordWebDialog.notice(lines.join('\n'));
    });

    [btnMove, btnDelete, btnRename, btnDetail].forEach(b => tdAct.appendChild(b));

    // 행 조립 (체크박스 열이 맨 앞)
    tr.appendChild(tdCheck);
    tr.appendChild(tdType);
    tr.appendChild(tdName);
    tr.appendChild(tdSize);
    tr.appendChild(tdMtime);
    tr.appendChild(tdAct);
    tbody.appendChild(tr);
  });
}


// 경로 변경
async function changePath(nextPath) {
  try {
    await listAndRender(nextPath);
  } catch (e) {
    recordWebDialog.notice(formatFileApiError(e, "열람", nextPath));  
  }
}


// 상세 모달: 크기/수정일/전체 경로 등 표시
function showDetailModal(it){
  const modal = document.getElementById('file-detail-modal');
  const body  = document.getElementById('detail-body');
  if (!modal || !body) return;

  const isDir = !!it.is_dir;
  const iconEmoji = isDir ? '📁' : '📄';
  const size = isDir ? '-' : bytesToHuman(it.size);
  const mtime = it.mtime || '-';

  body.innerHTML = `
    <div class="detail-icon">${escapeHtml(iconEmoji)}</div>
    <div class="detail-grid">
      <div class="detail-row"><b>이름</b> <span>${escapeHtml(it.name || '')}</span></div>
      <div class="detail-row"><b>유형</b> <span>${escapeHtml(isDir ? '폴더' : (it.ext || '파일'))}</span></div>
      <div class="detail-row"><b>크기</b> <span>${escapeHtml(size)}</span></div>
      <div class="detail-row"><b>수정일</b> <span>${escapeHtml(fmtMtime(it.mtime))}</span></div>
      <div class="detail-row"><b>경로</b> <span style="word-break:break-all">${escapeHtml(it.path || '')}</span></div>
    </div>
  `;

  modal.classList.remove('hidden');
  document.getElementById('detail-close')?.addEventListener('click', () => {
    modal.classList.add('hidden');
  }, { once:true });

  // 바깥 클릭 닫기
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.add('hidden');
  }, { once:true });
}


// 파일 다운로드/미리보기
function openPreview(fullPath) {
  const a = document.createElement("a");
  a.href = `/api/files/download?path=${encodeURIComponent(fullPath)}`;
  a.target = "_blank";
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
}


// 파일 이름 변경
async function onRename(item) {
  const newName = await recordWebDialog.prompt("새 이름을 입력하세요", item.name);
  if (!newName || newName === item.name) return;
  try {
    await apiPost("/api/files/rename", { path: item.path, new_name: newName });
    await listAndRender(filesCurrentPath);
  } catch (e) {
    recordWebDialog.notice(`이름 변경 실패: ${e.message}`);
  }
}


// 파일 삭제(완전삭제/휴지통)
async function onDelete(item) {
  const hard = await recordWebDialog.confirm("완전 삭제하시겠습니까?\n(확인=완전삭제 / 취소=휴지통으로 이동)");
  const msg = hard ? "완전 삭제" : "휴지통 이동";
  if (!await recordWebDialog.confirm(`${item.name}\n정말 ${msg} 하시겠습니까?`)) return;

  try {
    await apiPost("/api/files/delete", { paths: [item.path], hard: !!hard });
    await listAndRender(filesCurrentPath);
  } catch (e) {
    recordWebDialog.notice(`${msg} 실패: ${e.message}`);
  }
}


// 스트림복사 공통 핸들러
async function onStreamCopySelected() {
  const items = getSelectedItems().filter(it => !it.is_dir);
  if (!items.length) { recordWebDialog.notice("스트림복사할 파일을 선택하세요."); return; }

  try {
    const res = await apiPost('/api/files/streamcopy', { paths: items.map(i => i.path) });
    const failed = (res.results || []).filter(r => !r.ok);
    if (failed.length) {
      const msg = failed.map(f => `- ${f.src}\n  → ${f.error || '실패'}`).join('\n');
      await recordWebDialog.notice(`일부 실패:\n${msg}`);
    } else {
      await recordWebDialog.notice('스트림복사가 완료되었습니다.');
    }
    // 복사본도 보이도록 새로고침
    await listAndRender(filesCurrentPath);
  } catch (e) {
    recordWebDialog.notice(formatFileApiError(e, "스트림복사"));
  }
}

// 파일매니저 페이지 초기 세팅
function setupFilesPage() {
  const ml = document.getElementById('fileListMobile');
  if (ml) {
    ml.style.webkitTouchCallout = 'none';
    ml.style.webkitUserSelect = 'none';
    ml.style.userSelect = 'none';
  }

  // 루트 변경
  document.getElementById("rootSelect")?.addEventListener("change", async (e) => {
    const p = e.target.value;
    if (p) await changePath(p);
    await refreshDiskUsage();
  });

  // 상위 폴더
  document.getElementById("btnUp")?.addEventListener("click", async () => {
    const sep = (filesCurrentPath || "").includes("\\") ? "\\" : "/";
    let p = filesCurrentPath || "";
    if (!p) return;

    p = p.replace(/[\\\/]+$/, ""); // 끝 구분자 제거
    const parts = p.split(/[\\/]/).filter(Boolean);

    if (p.includes(":")) {
      // Windows
      if (parts.length > 1) {
        parts.pop();
        p = parts[0] + sep + parts.slice(1).join(sep);
      } else {
        p = parts[0] + sep; // D:\
      }
    } else if (p.startsWith("/")) {
      // Unix
      if (parts.length > 0) parts.pop();
      p = "/" + parts.join(sep);
      if (p === "") p = "/";
    }
    await changePath(p);
  });

  // 새로고침
  document.getElementById("btnRefresh")?.addEventListener("click", async () => {
    await Promise.all([refreshDiskUsage(), listAndRender(filesCurrentPath)]);
  });

  // 새 폴더
  document.getElementById("btnMkdir")?.addEventListener("click", async () => {
    const name = await recordWebDialog.prompt("새 폴더 이름을 입력하세요", "새 폴더");
    if (!name) return;
    try {
      await apiPost("/api/files/mkdir", { path: filesCurrentPath, new_name: name });
      await listAndRender(filesCurrentPath);
    } catch (e) {
      recordWebDialog.notice(`폴더 생성 실패: ${e.message}`);
    }
  });

  // 경로 입력 후 Enter 이동
  document.getElementById("pathInput")?.addEventListener("keydown", async (e) => {
    if (e.key === "Enter") {
      const p = e.target.value.trim();
      if (p) await changePath(p);
    }
  });

  // 클라이언트 사이드 필터
  document.getElementById("fileSearch")?.addEventListener("input", () => {
    renderFileTable(filesAllItems);
  });

  // 모바일 액션바 바인딩 (setupFilesPage() 안쪽)
  function setupMobileActionBar() {
    // 이동/삭제/수정/상세
    document.getElementById('mobMove')  ?.addEventListener('click', onMoveSelected);
    document.getElementById('mobDelete')?.addEventListener('click', onDeleteSelected);
    document.getElementById('mobRename')?.addEventListener('click', onRenameSelected);
    document.getElementById('mobDetail')?.addEventListener('click', onDetailSelected);

    // 선택모드 진입
    document.getElementById('mobSelect')?.addEventListener('click', () => {
  	  enterSelectMode();        // 선택모드 on
	  updateMobileActionBar();  // 버튼 상태 즉시 반영
    });

    // 취소 버튼: 선택 해제 + 선택모드 종료
    document.getElementById('mobCancel')?.addEventListener('click', () => {
 	  clearSelection();                     // 선택 모두 해제
	  selectMode = false;                   // 선택모드 종료
	  document.body.classList.remove('select-mode');
	  updateMobileActionBar();              // 버튼 상태 반영
    });
}

  setupMobileActionBar();
  updateMobileActionBar(); // 초기 상태 반영(취소 버튼 숨김 등)


  // 스트림복사 버튼 바인딩
  (function bindStreamCopyButton() {
    const btn = document.getElementById('btnStreamCopy');
    if (!btn || btn.dataset.bound === '1') return;
    btn.dataset.bound = '1';

    let scLock = false;

    const handler = async (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (scLock) return;
      scLock = true;
      btn.disabled = true;

      try {
        await onStreamCopySelected();
      } finally {
        btn.disabled = false;
        scLock = false;
      }
    };

    if (window.PointerEvent) {
      btn.addEventListener('pointerup', handler, { passive: false });

      btn.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') handler(e);
      });
    } else if ('ontouchend' in window) {
      btn.addEventListener('touchend', handler, { passive: false });
    } else {
      btn.addEventListener('click', handler, { passive: false });
    }
  })();

  // 초기화
  fetchRootsAndInit().catch((err) => {
    console.error("파일관리 초기화 실패:", err);
    if (!err?.fmDisabled) {
      recordWebDialog.notice("파일관리 초기화 실패: " + (err?.message || "Unknown error"));
    }
  });
}

// 모바일 목록 렌더러(버튼 없음, 선택용 체크박스 + 썸/이름)
function renderFileListMobile(items) {
  const wrap = document.getElementById('fileListMobile');
  const filterText = (document.getElementById('fileSearch')?.value || '').toLowerCase();
  wrap.innerHTML = '';

  const filtered = items.filter(it => !filterText || (it.name || '').toLowerCase().includes(filterText));
  if (!filtered.length) {
    const empty = document.createElement('div');
    empty.textContent = '표시할 항목이 없습니다.';
    empty.style.cssText = 'padding:10px;color:#666;';
    wrap.appendChild(empty);
    updateMobileActionBar();
    return;
  }

  filtered.forEach(it => {
    const row = document.createElement('div');
    row.className = 'fm-item ' + (it.is_dir ? 'kind-folder' : 'kind-file');
    row.dataset.path = it.path;

    // 체크박스(선택모드에서만 CSS로 보임)
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'fm-select';
    cb.checked = selectedPaths.has(it.path);
    cb.addEventListener('change', () => {
      if (cb.checked) enterSelectMode();
      toggleSelect(it.path, row, cb.checked);
      exitSelectModeIfNone();
      updateMobileActionBar();
    });
    row.appendChild(cb);

    // 썸
    const thumb = document.createElement('div');
    thumb.className = 'fm-thumb';
    row.appendChild(thumb);

    // 텍스트 묶음
    const textBox = document.createElement('div');
    textBox.className = 'fm-text';

    const nameEl = document.createElement('div');
    nameEl.className = 'fm-name';
    nameEl.title = it.name || '';
    nameEl.textContent = it.name || '(이름없음)';

    const metaEl = document.createElement('div');
    metaEl.className = 'fm-meta';
    metaEl.textContent = it.is_dir ? '폴더' : (it.ext || '파일');

    textBox.appendChild(nameEl);
    textBox.appendChild(metaEl);
    row.appendChild(textBox);

    // 길게 눌러 선택모드 / 짧게 탭은 열기
    let pressTimer = null;
    let longPressed = false;
    const clearTimer = () => { if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; } };

    row.addEventListener('pointerdown', (event) => {
      if (event.target === cb) return;
      longPressed = false;
      pressTimer = setTimeout(() => {
        longPressed = true;
        enterSelectMode();
        toggleSelect(it.path, row, true);
        const c = row.querySelector('.fm-select'); if (c) c.checked = true;
        updateMobileActionBar();
      }, LONG_PRESS_MS);
    });

    row.addEventListener('pointerup', (event) => {
      clearTimer();
      if (event.target === cb || longPressed) return;
      if (!selectMode) {
        if (it.is_dir) changePath(it.path);
        else openPreview(it.path);
      } else {
        const nowChecked = !selectedPaths.has(it.path);
        toggleSelect(it.path, row, nowChecked);
        const c = row.querySelector('.fm-select'); if (c) c.checked = nowChecked;
        exitSelectModeIfNone();
        updateMobileActionBar();
      }
    });

    row.addEventListener('pointerleave', clearTimer);
    row.addEventListener('pointercancel', clearTimer);

    if (it.locked) {
      const lock = document.createElement('div');
      lock.className = 'fm-meta';
      lock.textContent = '잠김(녹화중)';
      textBox.appendChild(lock);
    }

    if (selectedPaths.has(it.path)) row.classList.add('is-selected');
    wrap.appendChild(row);
  });

  updateMobileActionBar();
}


// 선택 상태 초기화
function clearSelection() {
  // 내부 상태 비우기
  selectedPaths.clear();

  // (데스크탑) 행 체크박스 전부 원복
  document.querySelectorAll('input.row-check').forEach(cb => { cb.checked = false; });

  // (데스크탑) 헤더 전체선택도 해제
  const hdr = document.getElementById('chkAll');
  if (hdr) { hdr.checked = false; hdr.indeterminate = false; }

  // (모바일) UI 원복
  document.querySelectorAll('#fileListMobile .fm-item').forEach(el => {
    el.classList.remove('is-selected');
    const cb = el.querySelector('.fm-select');
    if (cb) cb.checked = false;
  });

  // 선택모드 종료
  selectMode = false;
  document.body.classList.remove('select-mode');

  // 스트림복사 버튼 상태 원복
  const scBtn = document.getElementById('btnStreamCopy');
  if (scBtn) {
    scBtn.disabled = false;
    scBtn.classList.remove('is-busy');   // 진행중 클래스 쓰는 경우
    // scBtn.textContent = '스트림복사'; // 텍스트를 바꿨다면 주석 해제
  }

  // 액션바 버튼 상태 갱신
  updateMobileActionBar();
}


// 현재 선택된 항목들 반환 
function getSelectedItems() {
  const map = new Map(filesAllItems.map(it => [it.path, it]));

  // PC(테이블)에서 직접 체크한 값
  const fromPc = Array.from(document.querySelectorAll('input.row-check:checked'))
    .map(cb => cb.value);

  // 모바일 선택모드(길게 눌러서 담긴 Set)
  const fromMobile = Array.from(selectedPaths);

  // 합집합 → filesAllItems에 실제 있는 항목만 반환
  const uniq = Array.from(new Set([...fromPc, ...fromMobile]));
  return uniq.map(p => map.get(p)).filter(Boolean);
}


// 버튼 활성/비활성 업데이트 (Select/Cancel 교대 표시 포함)
function updateMobileActionBar() {
  const cnt = selectedPaths.size;
  const any = cnt > 0;
  const one = cnt === 1;

  const $mv  = document.getElementById('mobMove');
  const $del = document.getElementById('mobDelete');
  const $ren = document.getElementById('mobRename');
  const $det = document.getElementById('mobDetail');
  const $can = document.getElementById('mobCancel');
  const $sel = document.getElementById('mobSelect');

  // 개수에 따라 enable/disable
  [$mv, $del].forEach(b => b && (b.disabled = !any));
  [$ren, $det].forEach(b => b && (b.disabled = !one));

  if ($can) { $can.classList.toggle('hidden', !any); $can.disabled = !any; }
  if ($sel) { $sel.classList.toggle('hidden',  any); $sel.disabled =  any; }
}


// 폴더 선택(이동) 모달
async function openMovePicker(initialPath, onChoose) {
  const modal    = document.getElementById('move-picker-modal');
  const rootSel  = document.getElementById('mp-rootSelect');
  const listBox  = document.getElementById('mp-list');
  const crumbsEl = document.getElementById('mp-breadcrumbs');
  const btnOk    = document.getElementById('mp-choose');
  const btnCancel= document.getElementById('mp-cancel');

  modal.classList.remove('hidden');
  listBox.innerHTML = '<div style="padding:10px;">불러오는 중…</div>';

  try {
    if (!rootSel.dataset.filled) {
      let rootsArr = [];
      if (Array.isArray(filesRoots) && filesRoots.length) {
        rootsArr = filesRoots;
      } else {
        const rootsData = await apiGet('/api/files/roots');
        rootsArr = rootsData.roots || [];
      }
      rootSel.innerHTML = '';
      rootsArr.forEach(r => {
        const path = typeof r === 'string' ? r : (r.path || '');
        const label = typeof r === 'string' ? r : (r.label || path);
        if (!path) return;
        const o = document.createElement('option');
        o.value = path; o.textContent = label;
        rootSel.appendChild(o);
      });
      rootSel.dataset.filled = '1';
    }
  } catch (e) {
    // 루트 불러오기 실패 → 현재 경로로라도 동작
    rootSel.innerHTML = '';
    const o = document.createElement('option');
    o.value = filesCurrentPath || '/';
    o.textContent = o.value;
    rootSel.appendChild(o);
    rootSel.dataset.filled = '1';
  }

  // 3) 시작 경로 설정
  movePickerPath = initialPath || rootSel.value || filesCurrentPath || '/';

  rootSel.onchange = async () => {
    movePickerPath = rootSel.value;
    await renderMovePickerList(movePickerPath, listBox, crumbsEl);
  };

  // 4) 폴더 목록 렌더 (실패해도 안내 문구 표시)
  try {
    await renderMovePickerList(movePickerPath, listBox, crumbsEl);

  } catch (e) {
    const msg = formatFileApiError(e, "탐색", movePickerPath).replace(/\n/g, "<br>");
    listBox.innerHTML = `<div style="padding:10px;color:#b91c1c;">${msg}</div>`;
  }

  // 5) OK/취소
  const close = () => {
    modal.classList.add('hidden');
    btnOk.onclick = btnCancel.onclick = rootSel.onchange = null;
  };
  btnCancel.onclick = close;
  btnOk.onclick = async () => {
    try { await onChoose(movePickerPath); } finally { close(); }
  };

  // 바깥 클릭 닫기
  const outsideHandler = (e) => { if (e.target === modal) close(); };
  modal.addEventListener('click', outsideHandler, { once:true });
}


async function renderMovePickerList(path, box, crumbsEl) {
  try {
    const data = await apiGet(`/api/files/ls?path=${encodeURIComponent(path)}`);
    movePickerPath = data.path || path;

    // 브레드크럼 다시 그림
    mpBuildBreadcrumbs(movePickerPath, crumbsEl);

    // 디렉터리만 필터
    const dirs = (data.items || []).filter(it => it.is_dir);

    box.innerHTML = '';
    if (!dirs.length) {
      const empty = document.createElement('div');
      empty.textContent = '하위 폴더가 없습니다.';
      empty.style.cssText = 'padding:10px;color:#666;';
      box.appendChild(empty);
      return;
    }

    dirs.forEach(d => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:10px;padding:10px 12px;cursor:pointer;';
      row.innerHTML = `<span>📁</span><div style="flex:1;min-width:0;">${escapeHtml(d.name)}</div>`;
      row.addEventListener('click', async () => {
        await renderMovePickerList(d.path, box, crumbsEl);
      });
      box.appendChild(row);
    });
  } catch (e) {
    const msg = formatFileApiError(e, "탐색", path).replace(/\n/g, "<br>");
    box.innerHTML = `<div style="padding:10px;color:#b91c1c;">${msg}</div>`;
  }
}

function mpBuildBreadcrumbs(fullPath, el) {
  el.innerHTML = '';
  const sep = fullPath.includes('\\') ? '\\' : '/';
  const parts = fullPath.split(/[\\/]/).filter(Boolean);

  let accum = '';
  if (fullPath.includes(':')) { accum = parts.shift() + sep; }
  else if (fullPath.startsWith('/')) { accum = sep; }

  const add = (label, target) => {
    const a = document.createElement('a');
    a.href = 'javascript:void(0)';
    a.textContent = label || target || '/';
    a.addEventListener('click', async () => {
      await renderMovePickerList(target || sep, document.getElementById('mp-list'), el);
    });
    el.appendChild(a);
    const s = document.createElement('span'); s.textContent = ' / '; el.appendChild(s);
  };

  if (accum) add(accum.replace(/[\\\/]$/, ''), accum);

  parts.forEach(p => {
    accum = accum ? (accum.endsWith(sep) ? accum + p : accum + sep + p) : p;
    add(p, accum);
  });

  if (el.lastChild) el.removeChild(el.lastChild);
}


async function onMoveSelected() {
  const items = getSelectedItems();
  if (!items.length) return;
  try {
    await openMovePicker(filesCurrentPath, async (dst) => {
      await apiPost('/api/files/move', { srcs: items.map(i => i.path), dst_dir: dst });
      await listAndRender(filesCurrentPath);
      clearSelection();
    });
  } catch (e) {
    recordWebDialog.notice('이동 창을 여는 데 실패했습니다: ' + (e.message || e));
  }
}


async function onMove(item) {
  try {
    await openMovePicker(filesCurrentPath, async (dst) => {
      await apiPost('/api/files/move', { srcs: [item.path], dst_dir: dst });
      await listAndRender(filesCurrentPath);
    });
  } catch (e) {
    recordWebDialog.notice('이동 창을 여는 데 실패했습니다: ' + (e.message || e));
  }
}


async function onDeleteSelected() {
  const items = getSelectedItems();
  if (!items.length) return;
  const hard = await recordWebDialog.confirm('완전 삭제하시겠습니까?\n(확인=완전삭제 / 취소=휴지통)');
  if (!await recordWebDialog.confirm(`${items.length}개 항목을 ${hard?'완전 삭제':'휴지통 이동'} 하시겠습니까?`)) return;
  try {
    await apiPost('/api/files/delete', { paths: items.map(i => i.path), hard: !!hard });
    await listAndRender(filesCurrentPath);
    clearSelection();
  } catch (e) { recordWebDialog.notice('삭제 실패: ' + e.message); }
}


async function onRenameSelected() {
  const items = getSelectedItems();
  if (items.length !== 1) return;
  const it = items[0];
  const newName = await recordWebDialog.prompt('새 이름을 입력하세요', it.name);
  if (!newName || newName === it.name) return;
  try {
    await apiPost('/api/files/rename', { path: it.path, new_name: newName });
    await listAndRender(filesCurrentPath);
    clearSelection();
  } catch (e) { recordWebDialog.notice('이름 변경 실패: ' + e.message); }
}


function onDetailSelected() {
  const items = getSelectedItems();
  if (items.length !== 1) return;
  const it = items[0];
  const lines = [
    `이름 : ${it.name}`,
    `종류 : ${it.is_dir ? '폴더' : (it.ext || '파일')}`,
    `크기 : ${it.is_dir ? '-' : bytesToHuman(it.size)}`,
    `수정 : ${it.mtime || '-'}`,
    `경로 : ${it.path}`
  ];
  recordWebDialog.notice(lines.join('\n'));
}


// 선택모드 진입/해제
function enterSelectMode() {
  if (selectMode) return;
  selectMode = true;
  document.body.classList.add('select-mode');

  // ↑ 선택모드에서도 툴바 클릭 보장
  const tb = document.querySelector('.file-toolbar');
  if (tb) {
    tb.style.pointerEvents = 'auto';
    tb.style.position = 'relative';
    tb.style.zIndex = '1001';
  }

  updateMobileActionBar();
}


function exitSelectModeIfNone() {
  if (!selectMode) return;
  if (selectedPaths.size === 0) {
    selectMode = false;
    document.body.classList.remove('select-mode');

    // 원복
    const tb = document.querySelector('.file-toolbar');
    if (tb) {
      tb.style.pointerEvents = '';
      tb.style.position = '';
      tb.style.zIndex = '';
    }

    updateMobileActionBar();
  }
}


// 선택 토글
function toggleSelect(path, card, forceChecked = null) {
  const wantCheck = forceChecked === null ? !selectedPaths.has(path) : !!forceChecked;
  if (wantCheck) {
    selectedPaths.add(path);
    card?.classList.add('is-selected');
  } else {
    selectedPaths.delete(path);
    card?.classList.remove('is-selected');
  }
}
