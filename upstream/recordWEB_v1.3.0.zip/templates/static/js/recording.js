let isStartingRecordings = false; // 중복 녹화 시작 방지
let isStoppingRecordings = false; // 중복 녹화 중지 방지
let isPollingSys = false;
let isThumbJobRunning = false;    // 썸네일/메타 갱신 중복 방지
let isRefreshingStatus = false;
let __sys_poll_tm  = null;
let __sys_disk_signature = "";
let sysDisks = new Map();
let __sys_dashboard_expanded = true;

const pendingChannelActions = new Set();

function setThumbnail(image, url) {
  if (image.getAttribute('src') !== url) image.setAttribute('src', url);
}

// 안전하게 키 고르는 헬퍼
const pick = (obj, keys, dflt) => {
  for (const k of keys) if (obj && obj[k] != null && obj[k] !== '') return obj[k];
  return dflt;
};

// Debounce: 지정 시간 이후에 실행
function debounce(func, wait) {
  let timeout;
  return function (...args) {
    const context = this;
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(context, args), wait);
  };
}

document.addEventListener('recordweb:page-ready', () => {
  setupFilterListeners();
  setupRecordingButtons();
  setupRecordingView();

  // 화면을 보고 있을 때만 상태와 썸네일 갱신
  function refreshRecordingPage() {
    if (document.hidden) return;
    refreshAllStatus();
    updateAllThumbnails();
  }

  refreshRecordingPage();
  setInterval(() => { if (!document.hidden) refreshAllStatus(); }, 2000);
  setInterval(() => { if (!document.hidden) updateAllThumbnails(); }, 20000);
  document.addEventListener('visibilitychange', refreshRecordingPage);
  setupRecordingToggles();
});

function setupRecordingView() {
  const options = document.getElementById('recording-view-options');
  const list = document.getElementById('channel-list');
  if (!options || !list) return;

  const storageKey = 'recordingViewMode';
  const buttons = options.querySelectorAll('button[data-view-mode]');
  // Keep the existing browser cutoff for the recording list.
  const wideViewport = window.matchMedia('(min-width: 980px) and (min-height: 600px)');
  let isRecordWebView = false;
  let preferredViewMode = 'card';
  try {
    if (localStorage.getItem(storageKey) === 'list') preferredViewMode = 'list';
  } catch { /* use the default view */ }

  function renderView() {
    const canUseListView = isRecordWebView || wideViewport.matches;
    const effectiveViewMode = canUseListView ? preferredViewMode : 'card';
    const isList = effectiveViewMode === 'list';
    const layoutChanged = list.classList.contains('recording-list-view') !== isList;
    options.hidden = !canUseListView;
    list.classList.toggle('recording-list-view', isList);
    list.parentElement.classList.toggle('recording-list-layout', isList);
    buttons.forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset.viewMode === effectiveViewMode));
    });
    if (layoutChanged) applyFilters();
  }

  async function detectRecordWebView() {
    const api = window.pywebview?.api;
    if (isRecordWebView || typeof api?.desktop_info !== 'function') return;
    try {
      const info = await api.desktop_info();
      if (info?.desktop !== true) return;
    } catch {
      return;
    }
    isRecordWebView = true;
    renderView();
  }

  options.addEventListener('click', event => {
    const button = event.target.closest('button[data-view-mode]');
    if (!button || options.hidden) return;
    preferredViewMode = button.dataset.viewMode;
    try { localStorage.setItem(storageKey, preferredViewMode); } catch { /* keep the current view */ }
    renderView();
  });
  wideViewport.addEventListener('change', renderView);
  window.addEventListener('pywebviewready', detectRecordWebView);
  renderView();
  detectRecordWebView();
}

// 예약녹화 토글
function setupRecordingToggles() {
  document.querySelectorAll('.toggle-record-enabled').forEach(checkbox => {
    checkbox.addEventListener('change', async (e) => {
      // 1) 채널 ID 회수
      let channelId = e.target.dataset.channelId;
      if (!channelId) {
        const host = e.target.closest('.channel');
        channelId = host && host.dataset.channelId;
      }
      if (!channelId) {
        console.error('[toggle] 채널 ID를 찾을 수 없습니다.');
        e.target.checked = !e.target.checked; // 롤백
        return;
      }

      const prev = e.target.checked; // 사용자가 건드린 값
      try {
		const res = await fetchWithTimeout(`/api/toggle_record_enabled/${channelId}`, {
		  method: 'POST',
		  headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		  }
		}, 8000);

        if (!res.ok) {
          console.error('[toggle] 응답 오류', res.status);
          e.target.checked = !prev;
          return;
        }

        let data;
        try { data = await res.json(); }
        catch (err) {
          console.error('[toggle] JSON 파싱 오류(리다이렉트 응답 가능성)', err);
          e.target.checked = !prev;
          return;
        }

        if (data.status !== 'success') {
          console.error('[toggle] API 실패', data);
          e.target.checked = !prev;
          return;
        }

        // 2) 서버 상태 동기화
        const enabled = !!data.record_enabled;
        e.target.checked = enabled;

        // 3) 카드 스타일
		const card = document.querySelector(`.channel[data-channel-id="${cssEsc(channelId)}"]`);
		if (card) card.classList.toggle('channel-disabled', !enabled);
      } catch (err) {
        console.error('[toggle] 호출 중 오류', err);
        e.target.checked = !prev;
      }
    });
  });
}

// status 집계 폴링 
async function refreshAllStatus() {
  if (isRefreshingStatus) return;
  isRefreshingStatus = true;

  try {
    const res = await fetchWithTimeout('/status', {
      cache: 'no-store',
      credentials: 'same-origin'
    }, 8000);

    if (!res.ok) throw new Error('status fetch failed');
    const raw = await res.json();

    const entries = Array.isArray(raw)
      ? raw.map(x => [String(x.id || x.channel_id || x.channelId), x])
      : Object.entries(raw);

    for (const [cid, st] of entries) {
      if (!cid) continue;

      const recording = !!(st.recording ?? st.is_recording ?? (st.state === 'recording'));
      const reserved  = !!(st.reserved  ?? st.is_reserved  ?? (st.state === 'reserved'));
      const stopReq   = !!(st.stop_requested ?? st.stopRequested);
      const name      = st.name || st.channel_name || st.channelName || null;

      let state;
      if (recording) state = '녹화 중';
      else if (reserved) state = '예약녹화 중';
      else state = '대기 중';

      const duration = st.duration || st.recording_duration || '00:00:00';
      const filename = st.filename || st.recording_filename
        || (st.output_path ? String(st.output_path).split(/[\\/]/).pop() : '')
        || (recording ? '(임시 파일명)' : '녹화 파일이 없습니다.');

      try {
        updateChannelStatus(cid, state, filename, duration, stopReq, name);
        updatePostprocessStatus(cid, st.postprocess);
      } catch (error) {
        console.error('[WEB] 채널 상태 표시 실패:', cid, error);
      }
    }
  } catch (e) {
    console.warn('[WEB] refreshAllStatus error:', e);
  } finally {
    isRefreshingStatus = false;
  }
}


// 특정 채널 상태 확인
async function checkStatus(channelId) {
  try {
    const response = await fetchWithTimeout(`/api/check_status/${channelId}`, {
      method: 'GET'
    }, 8000);

    if (response.status === 404) {
      document.querySelector(`.channel[data-channel-id="${cssEsc(channelId)}"]`)?.remove();
      return;
    }

    if (!response.ok) throw new Error(`[DEBUG] status HTTP: ${response.status}`);

    const data = await response.json();
    if (data.status === 'success') {
      // 파일명 키 호환 보정
      if (!data.filename) {
        data.filename = data.recording_filename || (data.output_path ? String(data.output_path).split(/[\\/]/).pop() : '');
      }

      updateChannelStatus(channelId, data.state, data.filename, data.recording_duration, data.stop_requested, null, 1);
      updatePostprocessStatus(channelId, data.postprocess);
    } else {
      console.error(`[DEBUG] Failed to check status for channel: ${channelId}`, data);
    }
  } catch (error) {
    console.error(`[DEBUG] Error checking status for channel: ${channelId}`, error);
  }
}


function updatePostprocessStatus(channelId, post) {
  const node=document.getElementById('postprocess-'+channelId);
  if (!node) return;
  post = post || {active_count: 0, last_result: null};
  node.hidden=!post.active_count&&!post.last_result;
  const text = post.active_count ? '후처리: 진행 중 ('+post.active_count+'개)' :
    post.last_result==='success' ? '후처리: 완료' : post.last_result ? '후처리: 실패 · 진단로그에서 확인하세요.' : '';
  if (node.textContent !== text) node.textContent = text;
}


function recordingCardLabel(text, tag = 'span') {
  const node = document.createElement(tag);
  node.className = 'recording-card-label';
  node.textContent = text;
  return node;
}

// 두 보기에서 공유하는 채널 상태 표시
function updateChannelStatus(channelId, state, filename, recordingDuration, stopRequested, channelNameFromServer = null) {
  const channelElement = document.querySelector(`.channel[data-channel-id="${cssEsc(channelId)}"]`);
  if (!channelElement) return;

  const statusElement = channelElement.querySelector('.channel-name');
  const filenameElement = document.getElementById(`filename-${channelId}`);
  const timingElement = document.getElementById(`timing-${channelId}`);

  const channelName = channelNameFromServer || (statusElement ? statusElement.dataset.channelName : 'Unknown Channel');

  const statusText = `${channelName} (${state})`;
  const displayedFilename = filename || '녹화 파일이 없습니다.';
  const filenameText = `녹화 파일명: ${displayedFilename}`;
  const statusChanged = channelElement.dataset.recordingState !== state || statusElement?.textContent.trim() !== statusText;
  if (statusChanged) {
    channelElement.dataset.recordingState = state;
    if (statusElement) {
      const label = statusElement.querySelector('.recording-channel-label');
      const cardState = statusElement.querySelector('.recording-card-state');
      if (label && cardState) {
        label.textContent = channelName;
        cardState.textContent = ` (${state})`;
      } else {
        statusElement.textContent = statusText;
      }
    }
    const listState = channelElement.querySelector('.recording-list-state');
    if (listState) listState.textContent = state;
    if (document.getElementById('channel-filter')) applyChannelFilter(channelElement, getChannelFilters());
  }
  if (filenameElement && filenameElement.textContent !== filenameText) {
    filenameElement.replaceChildren(recordingCardLabel('녹화 파일명: '), displayedFilename);
    filenameElement.title = displayedFilename;
  }

  if (timingElement) {
    const label = state === "녹화 중" ? "녹화 시간" : state === "예약녹화 중" ? "예약녹화 중" : "녹화 상태";
    const duration = state === "녹화 중" ? (recordingDuration || '00:00:00') : '';
    const detail = duration ? ': ' : state === "예약녹화 중" ? "" : ": 대기 중";
    if (timingElement.textContent !== label + detail + duration) {
      timingElement.replaceChildren(recordingCardLabel(label, 'strong'), recordingCardLabel(detail), duration);
    }
  }

  const startBtn = document.getElementById(`button-start-${channelId}`);
  const stopBtn = document.getElementById(`button-stop-${channelId}`);
  if (startBtn) startBtn.disabled = pendingChannelActions.has(channelId);
  if (stopBtn) stopBtn.disabled = pendingChannelActions.has(channelId);

  if (state === "녹화 중" || state === "예약녹화 중") {
    if (startBtn) startBtn.style.display = 'none';
    if (stopBtn) {
      stopBtn.style.display = 'inline-block';
    } else {
      const newStopBtn = document.createElement('button');
      newStopBtn.id = `button-stop-${channelId}`;
      newStopBtn.classList.add('stop-recording');
      newStopBtn.dataset.channelId = channelId;
      newStopBtn.innerText = '녹화 중지';
      channelElement.appendChild(newStopBtn);
    }
  } else {
    if (startBtn) {
      startBtn.style.display = 'inline-block';
    } else {
      const newStartBtn = document.createElement('button');
      newStartBtn.id = `button-start-${channelId}`;
      newStartBtn.classList.add('start-recording');
      newStartBtn.dataset.channelId = channelId;
      newStartBtn.innerText = '녹화 시작';
      channelElement.appendChild(newStartBtn);
    }
    if (stopBtn) stopBtn.style.display = 'none';
  }
}




// 모든 썸네일/메타 갱신
async function updateAllThumbnails() {
  if (isThumbJobRunning) return;
  isThumbJobRunning = true;

  try {
    const nowTs = Date.now();
    const cards = Array.from(document.querySelectorAll('.channel'));
    const cardById = new Map(cards.map(c => [String(c.dataset.channelId), c]));

    // 카드에 메타 적용 
    function applyMeta(id, platform, meta, root) {
      const card = cardById.get(id);
      if (!card) return;

      const sel  = (q) => card.querySelector(q);
      const byId = (domId) => document.getElementById(domId) || sel(`#${domId}`);

      const thumbEl  = byId(`thumbnail-${id}`) || sel('img.thumbnail, .thumb img');
      const titleEl  = byId(`title-${id}`)     || sel('.channel-title, .title');
      const catEl    = byId(`category-${id}`)  || sel('.channel-category, .category');

      // 썸네일
      const thumbUrl = pick(meta, ['thumbnail_url','thumbnailUrl','thumbnail'])
                    ?? pick(root, ['thumbnail_url','thumbnailUrl','thumbnail']);
      // 텍스트 메타
      const title    = pick(meta, ['live_title','liveTitle','title','video_title','name']);
      const category = pick(meta, ['category','category_name','game','game_name','genre','tag']);
      const isLive   = pick(meta, ['is_live','isLive','live','online']) === true || pick(meta, ['status']) === 'OPEN';

      if (thumbEl) {
        const pf = (platform || card.dataset.platform || '').toLowerCase();
        const fallback = pf === 'cime'
          ? (isLive ? `/static/img/cime_thumbnail.png` : `/static/img/cimeclosed_thumbnail.png`)
          : `/static/img/default_thumbnail.png`;
        setThumbnail(thumbEl, thumbUrl || fallback);
      }
      const adult    = !!meta.adult;

      if (titleEl && title) {
        titleEl.textContent = adult ? `${title} (연령제한)` : title;
        titleEl.title = titleEl.textContent;
      }
      if (catEl && category) {
        const value = catEl.querySelector('.recording-category-value');
        if (value) value.textContent = category;
        else catEl.replaceChildren(recordingCardLabel('카테고리', 'strong'), recordingCardLabel(': '), category);
        catEl.title = category;
      }

    }

    // (A) 벌크 상태 수집 & 1차 DOM 반영 
    let bulkItems = [];
    try {
  	  const res = await fetchWithTimeout('/api/thumbnail_status', {
	    headers: { 'Accept': 'application/json' },
	    cache: 'no-store'
	  }, 10000);
      if (res.ok) {
        const raw  = await res.json();
        const list = Array.isArray(raw) ? raw
                  : Array.isArray(raw?.channels) ? raw.channels
                  : Array.isArray(raw?.items)    ? raw.items
                  : Array.isArray(raw?.data)     ? raw.data
                  : [];
        bulkItems = list.map(x => {
          const id = x.channel_id ?? x.id ?? x.channelId ?? x.channel?.id ?? x.meta?.id ?? '';
          const pf = x.platform ?? x.pf ?? x.meta?.platform ?? x.metadata?.platform ?? '';
          const meta = (x.metadata && typeof x.metadata === 'object') ? x.metadata
                    : (x.meta && typeof x.meta === 'object') ? x.meta
                    : x;
          return { id: String(id || ''), platform: String(pf || ''), meta, root: x };
        }).filter(v => v.id);
      }
    } catch {/* 벌크 실패는 조용히 무시 */}

    // 벌크 1차 반영
    const bulkMap = new Map();
    for (const it of bulkItems) {
      bulkMap.set(it.id, it);
      applyMeta(it.id, it.platform, it.meta, it.root);
    }


  } catch (e) {
    console.error('updateAllThumbnails error', e);
  } finally {
    isThumbJobRunning = false;
  }
}



// 필터링 드롭다운/검색 리스너
function setupFilterListeners() {
  document.getElementById('recording-group-tabs')?.addEventListener('click', event => {
    const button = event.target.closest('button[data-group-id]');
    if (!button) return;
    document.querySelectorAll('#recording-group-tabs button').forEach(item => {
      item.classList.toggle('active', item === button);
      item.setAttribute('aria-pressed', item === button ? 'true' : 'false');
    });
    applyFilters();
  });
  const filterDropdown = document.getElementById('channel-filter');
  const searchInput = document.getElementById('channel-search');

  if (filterDropdown) filterDropdown.addEventListener('change', applyFilters);
  if (searchInput) searchInput.addEventListener('input', debounce(applyFilters, 300));
}


const channelFilterStates = {
  recording: '녹화 중',
  reserved: '예약녹화 중',
  idle: '대기 중',
};

function getChannelFilters() {
  return {
    state: channelFilterStates[document.getElementById('channel-filter').value],
    search: document.getElementById('channel-search').value.toLowerCase(),
    group: document.querySelector('#recording-group-tabs button.active')?.dataset.groupId || '',
  };
}

function applyChannelFilter(channel, {state, search, group}) {
  const name = channel.querySelector('.channel-name').textContent.toLowerCase();
  const visible = (!state || channel.dataset.recordingState === state) &&
    name.includes(search) && (!group || channel.dataset.recordingGroup === group);
  const listView = channel.parentElement.classList.contains('recording-list-view');
  const display = visible ? (listView ? 'grid' : 'block') : 'none';
  if (channel.style.display !== display) channel.style.display = display;
}

// 상태, 검색어, 그룹 동시 적용
function applyFilters() {
  const filters = getChannelFilters();
  document.querySelectorAll('.channel').forEach(channel => applyChannelFilter(channel, filters));
}


// 녹화 버튼 바인딩
function setupRecordingButtons() {
  const channelList = document.getElementById('channel-list');
  if (channelList) {
    channelList.addEventListener('click', function (event) {
      const startButton = event.target.closest('.start-recording');
      const stopButton = event.target.closest('.stop-recording');

      if (startButton) startRecording(startButton.dataset.channelId);
      if (stopButton)  stopRecording(stopButton.dataset.channelId);
    });
  }

  const startAllBtn = document.getElementById('start-all-recording');
  if (startAllBtn) {
    startAllBtn.addEventListener('click', function () {
      const channelIds = Array.from(document.querySelectorAll('.channel')).map(c => c.dataset.channelId);
      if (channelIds.length > 0) startAllRecordings(channelIds);
    });
  }

  const stopAllBtn = document.getElementById('stop-all-recording');
  if (stopAllBtn) {
    stopAllBtn.addEventListener('click', function () {
      const channelIds = Array.from(document.querySelectorAll('.channel')).map(c => c.dataset.channelId);
      if (channelIds.length > 0) stopAllRecordings(channelIds);
    });
  }
}


// 개별 채널 녹화 시작
async function startRecording(channelId) {
  if (pendingChannelActions.has(channelId)) return;
  pendingChannelActions.add(channelId);
  const button = document.getElementById('button-start-'+channelId);
  if (button) { button.disabled=true; button.textContent='시작 요청 중…'; }
  const apiUrl = `/api/start_recording/${channelId}`;
  try {
    const response = await fetchWithTimeout(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_user_request: true })
    }, 12000);

    // 에러 응답 처리
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || '녹화 시작 요청에 실패했습니다.');
    }

    // 성공 응답 처리
    const data = await response.json().catch(() => ({}));
    if (data.status === 'success') {
      const st   = data.state || '녹화 중';
  	  const file = data.filename || data.recording_filename
			    || (data.output_path ? String(data.output_path).split(/[\\/]/).pop() : '')
			    || (st === '녹화 중' ? '(임시 파일명)' : '녹화 파일이 없습니다.');
      const dur  = st === '녹화 중' ? (data.recording_duration || '00:00:00') : '00:00:00';

      updateChannelStatus(channelId, st, file, dur, false, null, 1);

      // 최신 서버 상태로 한 번 더 동기화
      await checkStatus(channelId);
    } else {
      console.error('녹화 시작 실패:', data);
    }
  } catch (error) {
    console.error(`녹화 시작 오류 - 채널 ID: ${channelId}:`, error);
    recordWebDialog.notice(error.message);
  } finally {
    pendingChannelActions.delete(channelId);
    if (button) button.textContent='녹화 시작';
    await checkStatus(channelId);
  }
}


// 개별 채널 녹화 중지
async function stopRecording(channelId) {
  if (pendingChannelActions.has(channelId)) return;
  pendingChannelActions.add(channelId);
  const button = document.getElementById('button-stop-'+channelId);
  if (button) { button.disabled=true; button.textContent='중지 요청 중…'; }
  const apiUrl = `/api/stop_recording/${channelId}`;
  try {
    const response = await fetchWithTimeout(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, 12000);

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.detail || '녹화 중지 요청에 실패했습니다.');
    }

    const data = await response.json();
    if (data.status === 'success') {
      // Re-query the authoritative snapshot; do not invent an idle state.
      await checkStatus(channelId);
    } else {
      console.error('녹화 중지 실패:', data);
    }
  } catch (error) {
    console.error(`녹화 중지 오류 - 채널 ID: ${channelId}:`, error);
    recordWebDialog.notice(error.message);
  } finally {
    pendingChannelActions.delete(channelId);
    if (button) button.textContent='녹화 중지';
    await checkStatus(channelId);
  }
}


// 모든 채널 녹화 시작
async function startAllRecordings(channelIds, platforms) {
  if (isStartingRecordings) { console.log("이미 녹화 시작 중입니다."); return; }
  isStartingRecordings = true;
  try {
    if (!channelIds || channelIds.length === 0) throw new Error("녹화를 시작할 채널이 없습니다.");
    const response = await fetchWithTimeout(`/api/start_all_recording`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channelIds, platforms, is_user_request: true })
    }, 15000);
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || '모두 녹화 시작 요청 실패');
    }
    const data = await response.json();
    if (data.status === 'success') {
      Object.keys(data.channels_status).forEach(channelId => {
        const channelElement = document.querySelector(`.channel[data-channel-id="${cssEsc(channelId)}"]`);
        if (channelElement) {
          updateChannelStatus(
            channelId,
            data.channels_status[channelId].state,
            data.channels_status[channelId].filename,
            data.channels_status[channelId].recording_duration || '00:00:00'
          );
        }
      });
    } else {
      console.error('모두 녹화 시작 실패:', data);
    }
  } catch (error) {
    console.error(`모두 녹화 시작 오류: ${error.message}`);
  } finally {
    isStartingRecordings = false;
  }
}


// 모든 채널 녹화 중지
async function stopAllRecordings(channelIds, platforms) {
  if (isStoppingRecordings) { console.log("이미 녹화 중지 중입니다."); return; }
  isStoppingRecordings = true;
  try {
    if (!channelIds || channelIds.length === 0) throw new Error("녹화를 중지할 채널이 없습니다.");
    const response = await fetchWithTimeout(`/api/stop_all_recording`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channelIds, platforms, is_user_request: true })
    }, 15000);
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.detail || '모두 녹화 중지 요청 실패');
    }
    const data = await response.json();
    if (data.status === 'success') {
      Object.keys(data.channels_status).forEach(channelId => {
        const channelElement = document.querySelector(`.channel[data-channel-id="${cssEsc(channelId)}"]`);
        if (channelElement) {
          updateChannelStatus(
            channelId,
            data.channels_status[channelId].state,
            data.channels_status[channelId].filename,
            data.channels_status[channelId].recording_duration
          );
        }
      });
    } else {
      console.error('모두 녹화 중지 실패:', data);
    }
  } catch (error) {
    console.error(`모두 녹화 중지 오류: ${error.message}`);
  } finally {
    isStoppingRecordings = false;
  }
}


// 시스템 상태
function _fmtBytes(n) {
  if (!Number.isFinite(n)) return "-";
  const u = ["B","KB","MB","GB","TB","PB"];
  let i = 0, x = n;
  while (x >= 1024 && i < u.length - 1) { x /= 1024; i++; }
  return `${x.toFixed(2)} ${u[i]}`;
}


function _setMetricText(node, value) {
  if (node && node.textContent !== value) node.textContent = value;
}

function _renderUsage(metric, percent, warning = 70) {
  const reading = typeof percent === 'number' && Number.isFinite(percent);
  const value = reading ? Math.max(0, Math.min(100, percent)) : 0;
  _setMetricText(metric.querySelector('.sys-value'), reading ? Math.round(value) + '%' : '—');
  const meter = metric.querySelector('progress');
  if (meter.value !== value) meter.value = value;
  metric.dataset.level = value >= 90 ? 'danger' : value >= warning ? 'warning' : 'normal';
}


async function _fetchSys() {
  const r = await fetchWithTimeout('/api/sys_metrics', { cache: 'no-store' }, 5000);
  if (!r.ok) throw new Error('sys_metrics 요청 실패');
  return r.json();
}


function _renderMainTiles({cpu, memory}) {
  _renderUsage(document.getElementById('tile-cpu'), cpu?.percent);
  _setMetricText(document.getElementById('cpu-name'), cpu?.name || '—');
  _renderUsage(document.getElementById('tile-mem'), memory?.percent);
  _setMetricText(document.getElementById('mem-brief'), _usageBytes(memory));
}

function _usageBytes(metric) {
  if (!Number.isFinite(metric?.used) || !Number.isFinite(metric?.total)) return '—';
  return _fmtBytes(metric.used) + ' / ' + _fmtBytes(metric.total);
}

function _renderSelectedDisk(select) {
  const row = document.getElementById('sys-disk');
  const disk = sysDisks.get(select.value);
  row.hidden = !disk;
  if (!disk) return;

  _renderUsage(row, disk.percent, 75);
  _setMetricText(row.querySelector('.sys-disk-format'), disk.fstype?.toUpperCase() || '');
  _setMetricText(row.querySelector('.sys-disk-usage'), _usageBytes(disk));
  row.querySelector('progress').setAttribute('aria-label', disk.label + ' 저장공간 사용률');
}

function _renderDisks({disks, disk_pending, disk_failed}) {
  const select = document.getElementById('sys-disk-select');
  const entries = (disks || []).map((disk, i) => {
    const label = disk.label || disk.mountpoint || disk.device || ('드라이브 ' + (i + 1));
    const key = disk.mountpoint || disk.device || label;
    return [key, {...disk, label}];
  });
  sysDisks = new Map(entries);
  const signature = JSON.stringify([...sysDisks].map(([key, {label}]) => [key, label]));
  if (signature !== __sys_disk_signature) {
    __sys_disk_signature = signature;
    const selected = select.value || localStorage.getItem('recordweb.systemMonitorDrive');
    const options = [...sysDisks].map(([key, {label}]) => new Option(label, key));
    select.replaceChildren(...(options.length ? options : [new Option('—', '')]));
    if (sysDisks.has(selected)) select.value = selected;
  }

  select.disabled = !sysDisks.size;
  _renderSelectedDisk(select);

  const empty = document.getElementById('sys-disks-empty');
  empty.hidden = sysDisks.size > 0;
  if (!empty.hidden) {
    _setMetricText(empty, disk_pending ? '확인 중' : disk_failed ? '확인 실패' : '표시할 드라이브가 없습니다.');
  }
}


async function _pollSys() {
  if (isPollingSys) return;
  isPollingSys = true;

  try {
    const m = await _fetchSys();
    _renderMainTiles(m);
    _renderDisks(m);
    const updated = new Date((m.sampled_at || Date.now() / 1000) * 1000);
    document.getElementById('sys-updated')?.replaceChildren(
      document.createTextNode(`${updated.toLocaleTimeString('ko-KR')} 갱신` +
        (m.disk_pending ? ' · 저장공간 확인 중' : m.disk_failed ? ' · 저장공간 확인 실패 (이전 수치 유지)' : ''))
    );
  } catch (e) {
    document.getElementById('sys-updated')?.replaceChildren(
      document.createTextNode('측정값을 가져오지 못했습니다')
    );
  } finally {
    isPollingSys = false;
  }
}

function _scheduleSysPoll(delay = 3000) {
  if (__sys_poll_tm) clearTimeout(__sys_poll_tm);
  if (document.hidden || !__sys_dashboard_expanded) {
    __sys_poll_tm = null;
    return;
  }
  __sys_poll_tm = setTimeout(async () => {
    await _pollSys();
    _scheduleSysPoll(3000);
  }, delay);
}

function _setSysDashboardExpanded(expanded) {
  const dashboard = document.getElementById('sys-dashboard');
  const body = document.getElementById('sys-dashboard-body');
  const button = document.getElementById('sys-dashboard-toggle');
  if (!dashboard || !body || !button) return;

  __sys_dashboard_expanded = expanded;
  body.hidden = !expanded;
  button.textContent = expanded ? '접기' : '펼치기';
  button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
  localStorage.setItem('recordweb.systemMonitorExpanded', expanded ? '1' : '0');

  if (expanded) {
    _pollSys();
    _scheduleSysPoll(3000);
  } else if (__sys_poll_tm) {
    clearTimeout(__sys_poll_tm);
    __sys_poll_tm = null;
  }
}


function setupSysDashboard() {
  const button = document.getElementById('sys-dashboard-toggle');
  if (!button) return;

  const select = document.getElementById('sys-disk-select');
  select.addEventListener('change', () => {
    localStorage.setItem('recordweb.systemMonitorDrive', select.value);
    _renderSelectedDisk(select);
  });

  const saved = localStorage.getItem('recordweb.systemMonitorExpanded');
  _setSysDashboardExpanded(saved !== '0');
  button.addEventListener('click', () => {
    _setSysDashboardExpanded(!__sys_dashboard_expanded);
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (__sys_poll_tm) clearTimeout(__sys_poll_tm);
      __sys_poll_tm = null;
      return;
    }
    if (__sys_dashboard_expanded) {
      _pollSys();
      _scheduleSysPoll(3000);
    }
  });
}


// 페이지 진입 시 자동 초기화 (녹화현황)
document.addEventListener('DOMContentLoaded', () => {
  if (location.pathname.includes('/recording') && document.getElementById('sys-dashboard')) {
    setupSysDashboard();
  }
});
