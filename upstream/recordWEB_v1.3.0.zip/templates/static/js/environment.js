(() => {
  const button = document.getElementById('refresh-environment');
  if (!button) return;
  const time = document.getElementById('environment-checked-at');
  const compact = detail => {
    if (!detail || ['없음','미설치'].includes(detail.status)) return '미설치';
    if (detail.status !== '정상') return '오류';
    const first = (detail.version || '').split('\n')[0];
    return first.match(/\d+(?:\.\d+)+/)?.[0] || first || '버전 확인 불가';
  };
  function render(data) {
    const deps = {...data.dependencies, python: data.recordweb_python};
    document.querySelectorAll('[data-env]').forEach(node => {
      const name = node.dataset.env;
      node.textContent = compact(deps[name]);
    });
    time.textContent = `마지막 확인: ${new Date(data.checked_at).toLocaleString('ko-KR')}`;
    const details = document.getElementById('environment-details');
    if (details) {
      details.replaceChildren();
      Object.entries(deps).forEach(([name, detail]) => {
        if (name === 'ffprobe') return;
        const row = document.createElement('details');
        const title = document.createElement('summary'); title.textContent = `${name} · ${compact(detail)}`;
        const text = document.createElement('pre'); text.className = 'detail-output';
        text.textContent = `경로: ${detail.path || '미설치'}\n${detail.version || detail.error || detail.guide || ''}`;
        row.append(title, text); details.append(row);
      });
    }
  }
  async function load(force=false) {
    button.disabled = true;
    if (force) time.textContent = '확인 중 · 기존 결과는 유지됩니다';
    try {
      const response = await fetch('/api/environment' + (force ? '?force=true' : ''));
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || '환경 검사 실패');
      render(data);
    } catch (error) { time.textContent = error.message; }
    finally { button.disabled = false; }
  }
  button.addEventListener('click', () => load(true));
  load();
})();
