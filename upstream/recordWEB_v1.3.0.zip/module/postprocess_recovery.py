"""기록된 실패 작업만 식별자로 다시 실행합니다."""
import asyncio
from fastapi import HTTPException
from module import data_manager as dm
from module.diagnostics import redact


def failures():
    from module.postprocess_store import records
    return records()


def list_failures():
    from module.postprocess_store import is_failure_record
    jobs = [job for job in failures() if is_failure_record(job)]
    return [{"job_id": job.get("job_id"), "file": redact(job.get("input_file", "")),
             "reason": redact((job.get("reason") or "").replace("검증 성공 후 파일 정리 실패", "후처리 파일 정리 실패")), "finished_at": job.get("finished_at"),
             "status": job.get("status", "failed"), "retry_count": job.get("retry_count", 0),
             "first_failure_at": job.get("first_failure_at", job.get("finished_at")),
             "first_reason": redact(job.get("first_reason", job.get("reason", ""))),
             "last_retry_at": job.get("last_retry_at"), "retry_profile": job.get("retry_profile"),
             "output_file": redact(job.get("output_file", ""))}
            for job in jobs[-30:]]


def list_history():
    return [{"job_id": job.get("job_id"), "file": redact(job.get("input_file", "")),
             "status": job.get("status"), "recovered_at": job.get("recovered_at"),
             "output_file": redact(job.get("output_file", "")),
             "retry_count": job.get("retry_count", 0)}
            for job in failures()[-100:] if isinstance(job, dict) and job.get("status") == "recovered"]


async def retry(request, job_id):
    from module.live_recorder import handlePostProcessing, buildPostCfgForChannel
    job = next((job for job in failures() if isinstance(job, dict) and job.get("job_id") == job_id), None)
    if job is None:
        raise HTTPException(404, "실패 작업을 찾을 수 없습니다.")
    from module.postprocess_store import begin_retry, is_failure_record
    if not is_failure_record(job):
        raise HTTPException(404, "실패 작업을 찾을 수 없습니다.")
    path = job.get("input_path")
    channel_id = job.get("channel_id")
    channel = next((c for c in request.app.state.channels if c.get("id") == channel_id), {})
    cfg = buildPostCfgForChannel(channel)
    manager = dm.RecorderManager()
    if not manager.recording_add_postproc(channel_id):
        raise HTTPException(409, "해당 채널의 후처리가 이미 실행 중입니다.")
    try:
        await asyncio.to_thread(begin_retry, job_id, {key: cfg.get(key) for key in ("_profile", "gpu_index", "video_codec", "preset", "stream_copy")})
    except BaseException:
        manager.recording_remove_postproc(channel_id)
        raise
    task = asyncio.create_task(handlePostProcessing(path, channel_id, job.get("channel_name", ""), cfg, recovery_job_id=job_id))
    request.app.state.bg_tasks.add(task)
    task.add_done_callback(request.app.state.bg_tasks.discard)
    return {"status": "success", "message": "현재 후처리 설정으로 재시도를 시작했습니다."}

