"""Check pinned Core packages and verify that their imports work."""
from importlib import import_module, metadata
from pathlib import Path


def main():
    requirements = Path(__file__).resolve().with_name('requirements-linux.txt')
    for line in requirements.read_text(encoding='utf-8').splitlines():
        line = line.split('#', 1)[0].strip()
        if not line:
            continue
        name, version = line.split('==')
        try:
            if metadata.version(name) != version:
                raise ValueError('version mismatch')
            import_module({'py-cpuinfo': 'cpuinfo', 'python-multipart': 'python_multipart'}.get(name, name.lower()))
        except (metadata.PackageNotFoundError, ImportError, OSError, ValueError) as exc:
            print(f'[recordWEB] {name} {version}: {type(exc).__name__}')
            return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
