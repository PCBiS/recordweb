"""Linux 전용 창에 필요한 그래픽 환경을 확인합니다."""
from importlib import metadata
from pathlib import Path
import sys


def main():
    import gi
    import cairo
    gi.require_version('Gtk', '3.0')
    gi.require_version('WebKit2', '4.1')
    gi.require_version('AyatanaAppIndicator3', '0.1')
    from gi.repository import AyatanaAppIndicator3
    from gi.repository import Gtk, WebKit2
    if '--system' in sys.argv:
        import ensurepip
    else:
        requirements = Path(__file__).resolve().with_name('requirements-linux-gui.txt')
        for line in requirements.read_text(encoding='utf-8').splitlines():
            name, version = line.split('==')
            if metadata.version(name) != version:
                raise RuntimeError(f'{name} {version} 필요')
        import webview
        from webview.platforms import gtk
        import psutil
        from Xlib import X
        from PIL import Image
    if '--imports-only' not in sys.argv and not Gtk.init_check()[0]:
        raise RuntimeError('현재 그래픽 세션에 연결할 수 없습니다.')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        sys.exit(f'[recordWEB] Linux GUI 검사: {error}')
