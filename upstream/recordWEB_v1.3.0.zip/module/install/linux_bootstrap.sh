# recordWEB.sh에서 호출합니다.
fail() {
    printf '[recordWEB] 오류: %s\n' "$*" >&2
    exit 20
}

install_system() {
    local -a elevate=()
    if (( EUID != 0 )); then
        command -v sudo >/dev/null || fail "관리자가 설치해야 하는 패키지: $* (sudo 없음)"
        elevate=(sudo)
        [[ -t 0 && -t 2 ]] || elevate+=(-n)
    fi
    printf '[recordWEB] 시스템 패키지 설치: %s\n' "$*"
    if [[ $manager == apt-get ]]; then
        "${elevate[@]}" apt-get update || fail "패키지 목록 갱신 실패. 관리자에게 설치를 요청하세요: $*"
        "${elevate[@]}" apt-get install -y --no-install-recommends "$@" ||
            fail "설치 실패. sudo 권한 및 배포판 저장소를 확인하세요. 필요한 패키지: $*"
    else
        "${elevate[@]}" "$manager" install -y --setopt=install_weak_deps=False "$@" ||
            fail "설치 실패. sudo 권한 및 배포판 저장소를 확인하세요. 필요한 패키지: $*"
    fi
}

python_supported() {
    "$1" -c 'import sys; raise SystemExit(not ((3, 11) <= sys.version_info[:2] <= (3, 14)))' >/dev/null 2>&1
}

select_python() {
    local candidate base_python
    for candidate in python3 python3.14 python3.13 python3.12 python3.11; do
        if command -v "$candidate" >/dev/null && python_supported "$candidate" &&
            base_python=$("$candidate" -c 'import sys; print(sys._base_executable)' 2>/dev/null) &&
            base_python=$(realpath -- "$base_python") &&
            [[ $base_python != "$PWD/.venv-linux/"* ]] &&
            python_supported "$base_python" &&
            "$base_python" -c 'import venv, ensurepip' >/dev/null 2>&1; then
            python_bin=$base_python
            return 0
        fi
    done
    return 1
}

prepare_linux() {
    local manager python_bin architecture tool package name
    [[ -r /etc/os-release ]] || fail '/etc/os-release를 읽을 수 없습니다.'
    local ID= ID_LIKE= PRETTY_NAME=
    source /etc/os-release
    architecture=$(uname -m)
    case "$architecture" in x86_64|aarch64) ;; *) fail "지원 대상 CPU: x86_64, aarch64. 현재: $architecture" ;; esac
    case " $ID $ID_LIKE " in
        *" debian "*|*" ubuntu "*) manager=apt-get ;;
        *" fedora "*|*" rhel "*|*" rocky "*|*" almalinux "*) manager=dnf ;;
        *) fail "지원 대상 배포판을 확인하세요: $ID" ;;
    esac
    command -v "$manager" >/dev/null || fail "$manager 명령이 필요합니다."
    command -v flock >/dev/null || fail '관리자가 util-linux 패키지(flock)를 설치해야 합니다.'
    printf '[recordWEB] %s (%s) 확인\n' "${PRETTY_NAME:-$ID}" "$architecture"
    mkdir -p .runtime || fail '프로젝트 폴더에 쓰기 권한이 필요합니다.'
    (
        flock -x 9 || fail '설치 잠금을 얻을 수 없습니다.'
        local -a packages=()
        if ! linux_venv_usable && ! select_python; then
            case "$manager:$ID" in
                apt-get:*) packages+=(python3 python3-venv) ;;
                dnf:fedora) packages+=(python3 python3-pip) ;;
                dnf:*) packages+=(python3.12 python3.12-pip) ;;
            esac
        fi
        if ! ffmpeg -version >/dev/null 2>&1 || ! ffprobe -version >/dev/null 2>&1; then
            case "$manager:$ID" in
                apt-get:*) packages+=(ffmpeg) ;;
                dnf:fedora) packages+=(ffmpeg-free) ;;
                dnf:*)
                    for package in ffmpeg-free ffmpeg; do
                        if dnf -q list "$package" >/dev/null 2>&1; then
                            packages+=("$package")
                            break
                        fi
                    done
                    [[ ${packages[*]} == *ffmpeg* ]] ||
                        fail '현재 저장소에 FFmpeg 패키지가 없습니다. 관리자가 ffmpeg와 ffprobe를 제공하는 저장소 또는 실행 파일을 준비해야 합니다.'
                    ;;
            esac
        fi
        if (( ${#packages[@]} )); then install_system "${packages[@]}"; fi
        printf '[recordWEB] Python 가상환경과 패키지 확인 중...\n'
        if ! linux_venv_usable; then
            select_python || fail 'Python 3.11~3.14와 venv 지원이 필요합니다.'
            if [[ -e .venv-linux || -L .venv-linux ]]; then
                local backup
                backup=$(mktemp -d .runtime/venv-backup.XXXXXX) || fail '가상환경 백업 폴더를 만들지 못했습니다.'
                mv -- .venv-linux "$backup/venv" ||
                    fail '손상된 가상환경을 보관하지 못했습니다.'
            fi
            printf '[recordWEB] 프로젝트 전용 Python 환경을 만드는 중...\n'
            "$python_bin" -m venv .venv-linux || fail '가상환경 생성에 실패했습니다. 다음 실행에서 다시 준비합니다.'
        fi
        if ! .venv-linux/bin/python module/install/check_linux_deps.py ||
            ! .venv-linux/bin/python -m pip check >/dev/null ||
            [[ ! -x .venv-linux/bin/streamlink ]]; then
            printf '[recordWEB] Python 패키지를 설치하거나 복구하는 중...\n'
            .venv-linux/bin/python -m pip install --disable-pip-version-check --force-reinstall -r module/install/requirements-linux.txt ||
                fail 'Python 패키지 설치 실패. 위의 pip 오류를 확인하세요.'
            .venv-linux/bin/python module/install/check_linux_deps.py ||
                fail 'Python 패키지 검사에 실패했습니다.'
            .venv-linux/bin/python -m pip check ||
                fail 'Python 패키지의 의존성이 맞지 않습니다.'
        fi
        if [[ ! -e json && ! -L json ]]; then
            local seed
            seed=$(mktemp -d .runtime/json-defaults.XXXXXX) || fail '기본 설정 폴더를 만들 수 없습니다.'
            for name in config.json channels.json channel_groups.json cookie.json notification.json; do
                cp -- "defaults/json/$name" "$seed/$name" || fail "기본 설정 준비 실패: $name"
            done
            mv -nT -- "$seed" json || fail '기본 설정을 적용하지 못했습니다.'
        fi
    ) 9>.runtime/linux-bootstrap.lock
    export PATH="$PWD/.venv-linux/bin:$PATH"
    for tool in ffmpeg ffprobe; do
        "$tool" -version >/dev/null 2>&1 || fail "$tool 실행 실패. 설치 상태와 PATH를 확인하세요."
    done
    .venv-linux/bin/streamlink --version >/dev/null 2>&1 || fail 'Streamlink 실행에 실패했습니다.'
    printf '[recordWEB] Linux 실행 환경 준비 완료\n'
}

linux_venv_usable() {
    [[ ! -L .venv-linux && -f .venv-linux/pyvenv.cfg ]] &&
        python_supported .venv-linux/bin/python &&
        .venv-linux/bin/python -c 'import sys, pip; assert sys.prefix != sys.base_prefix' >/dev/null 2>&1
}

prepare_linux_gui() {
    local ID= ID_LIKE= manager
    source /etc/os-release
    local -a packages
    case " $ID $ID_LIKE " in
        *" debian "*|*" ubuntu "*)
            manager=apt-get
            packages=(python3-venv python3-gi python3-gi-cairo gir1.2-gtk-3.0
                      gir1.2-webkit2-4.1 gir1.2-ayatanaappindicator3-0.1)
            ;;
        *)
            manager=dnf
            packages=(python3 python3-pip python3-gobject python3-cairo gtk3
                      webkit2gtk4.1 libayatana-appindicator-gtk3)
            ;;
    esac
    printf '[recordWEB] GTK 및 WebKitGTK 환경 확인 중...\n'
    (
        flock -x 9 || fail 'GUI 설치 잠금을 얻을 수 없습니다.'
        if ! /usr/bin/python3 module/install/check_linux_gui.py --system; then
            /usr/bin/python3 module/install/check_linux_gui.py --system --imports-only &&
                fail '현재 그래픽 세션에 연결할 수 없습니다.'
            install_system "${packages[@]}"
            /usr/bin/python3 module/install/check_linux_gui.py --system ||
                fail 'GTK·WebKitGTK 또는 그래픽 세션을 확인하세요.'
        fi
        if [[ -L .venv-linux-gui || ! -f .venv-linux-gui/pyvenv.cfg ]] ||
            ! .venv-linux-gui/bin/python -c 'import sys, pip; assert sys.prefix != sys.base_prefix' >/dev/null 2>&1; then
            if [[ -e .venv-linux-gui || -L .venv-linux-gui ]]; then
                local backup
                backup=$(mktemp -d .runtime/gui-venv-backup.XXXXXX) || fail 'GUI 가상환경 백업 실패'
                mv -- .venv-linux-gui "$backup/venv" || fail 'GUI 가상환경 백업 실패'
            fi
            /usr/bin/python3 -m venv --system-site-packages .venv-linux-gui ||
                fail 'GUI 가상환경 생성 실패'
        fi
        if ! .venv-linux-gui/bin/python module/install/check_linux_gui.py --imports-only; then
            .venv-linux-gui/bin/python -m pip install --disable-pip-version-check --ignore-installed -r module/install/requirements-linux-gui.txt ||
                fail 'GUI 패키지 설치 실패'
            .venv-linux-gui/bin/python module/install/check_linux_gui.py --imports-only ||
                fail 'GUI 패키지 실행 검사 실패'
        fi
    ) 9>.runtime/linux-gui-bootstrap.lock
}
