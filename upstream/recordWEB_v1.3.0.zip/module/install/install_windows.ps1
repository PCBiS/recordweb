﻿param([switch]$Repair, [string]$PythonExe = '', [switch]$CheckPython, [switch]$CheckOnly, [switch]$BootstrapOnly, [switch]$CheckReady, [switch]$LogStartupCheck, [switch]$RecordWeb)
$env:PYTHONUTF8 = '1'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$venvPath = Join-Path $projectRoot '.venv'
$lockFile = Join-Path $PSScriptRoot 'requirements-windows-lock.txt'
$headless = $false
if ($RecordWeb) {
    try {
        $config = Get-Content -LiteralPath (Join-Path $projectRoot 'json\config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        $headless = $config.runMode -is [string] -and $config.runMode -ceq 'headless'
    } catch { }
}
$requiredImports = 'fastapi,uvicorn,aiohttp,jinja2,requests,cryptography,httpx,psutil,itsdangerous,werkzeug,python_multipart'
if (-not $headless) { $requiredImports += ',webview,pystray,PIL,PyQt6.QtWidgets' }
$guiLockPattern = '^(bottle|clr_loader|pillow|proxy_tools|pythonnet|pystray|pywebview|PyQt6(?:-Qt6|-sip)?)=='
. (Join-Path $PSScriptRoot 'runtime_bootstrap.ps1')
# 전용 Python 환경 사용
Remove-Item Env:PYTHONHOME -ErrorAction SilentlyContinue
Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
$env:PYTHONNOUSERSITE = '1'
$env:PIP_CACHE_DIR = Join-Path $projectRoot 'runtime\pip-cache'

function Test-RecordWebVenv([string]$Path) {
    $python = Join-Path $Path 'Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $python)) { return $false }
    & $python -I -c "import platform, $requiredImports; raise SystemExit(0 if platform.python_version() == '3.14.10' else 1)"
    return $LASTEXITCODE -eq 0
}

function Remove-BestEffort([string]$Path) {
    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return }
    try { Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop }
    catch { Write-Warning "정리 실패(정상 설치 결과는 유지): $Path - $($_.Exception.Message)" }
}

$runtimePath = Join-Path $projectRoot 'runtime\python'
if ($CheckPython -or $CheckOnly -or $CheckReady) {
    $runtimeOk = Test-OwnedPython $runtimePath
    $venvOk = Test-OwnedVenv $projectRoot -Headless:$headless
    $checkSummary = @(
        "recordWEB Python: $runtimePath (required: 3.14.10; healthy: $runtimeOk)"
        "recordWEB venv: $venvPath (owned base required; healthy: $venvOk)"
    )
    $checkSummary | ForEach-Object { Write-Host $_ }
    if ($CheckReady -and $LogStartupCheck) {
        $diagnosticDays = '3'
        try {
            $startupConfig = Get-Content -LiteralPath (Join-Path $projectRoot 'json\config.json') -Raw | ConvertFrom-Json
            if ($null -ne $startupConfig.diagnosticLogDays) { $diagnosticDays = [string]$startupConfig.diagnosticLogDays }
        } catch { }
        if ($diagnosticDays -notmatch '^(0|1|3|7|14|unlimited)$') { $diagnosticDays = '3' }
        if ($diagnosticDays -ne '0') {
            try {
                $startupLogDir = Join-Path $projectRoot 'logs'
                New-Item -ItemType Directory -Path $startupLogDir -Force | Out-Null
                $now = [DateTimeOffset]::UtcNow
                $hour = [long][Math]::Floor($now.ToUnixTimeSeconds() / 3600)
                $startupLog = Join-Path $startupLogDir ('recordWEB_startup.log.{0:D10}' -f $hour)
                $stamp = $now.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'")
                $lines = @($checkSummary | ForEach-Object { "[$stamp] $_" })
                [IO.File]::AppendAllLines($startupLog, [string[]]$lines, [Text.UTF8Encoding]::new($false))
                if ($diagnosticDays -match '^(1|3|7|14)$') {
                    $cutoff = $now.UtcDateTime.AddDays(-[int]$diagnosticDays)
                    Get-ChildItem -LiteralPath $startupLogDir -Filter 'recordWEB_startup.log*' -File |
                        Where-Object { $_.Name -match '^recordWEB_startup\.log(\.\d+)?$' -and $_.LastWriteTimeUtc -lt $cutoff } |
                        ForEach-Object { Remove-Item -LiteralPath $_.FullName }
                }
            } catch { Write-Warning $_.Exception.Message }
        }
    }
    if (-not $runtimeOk -or (($CheckOnly -or $CheckReady) -and -not $venvOk)) { exit 20 }
    if ($CheckOnly) {
        & (Join-Path $venvPath 'Scripts\python.exe') (Join-Path $projectRoot 'module\recordWEB_launcher.py') --check
        exit $LASTEXITCODE
    }
    exit 0
}
$lockDirectory = Join-Path $projectRoot '.runtime'
if (-not (Test-OwnedPython (Join-Path $projectRoot 'runtime\python'))) {
    $entryPaths = @('recordWEB.py','replayDownloader_GUI.py','module\recordWEB.py','module\replayDownloader_GUI.py') |
        ForEach-Object { Join-Path $projectRoot $_ }
    $projectProcesses = Get-CimInstance Win32_Process | Where-Object {
        $commandLine = $_.CommandLine
        $_.ProcessId -ne $PID -and $commandLine -and
        ($entryPaths | Where-Object { $commandLine.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0 })
    }
    if ($projectProcesses) { throw 'Python 업그레이드 전 recordWEB과 replayDownloader를 완전히 종료하세요. 실행 중인 환경은 변경하지 않았습니다.' }
}
New-Item -ItemType Directory -Path $lockDirectory -Force | Out-Null
try {
    $installLock = [IO.File]::Open((Join-Path $lockDirectory 'install.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
} catch { throw 'Another recordWEB installation is running. Retry after it finishes.' }
# The process owns this handle until exit, including on an unhandled failure.
try {
$ownedPython = Get-OwnedPython $projectRoot -PreserveBackup
if ($BootstrapOnly) { Write-Host "Owned Python ready: $ownedPython"; exit 0 }
if ($PythonExe) {
    # Explicit developer override only; never an automatic fallback.
    if (-not (Test-OwnedPython (Split-Path -Parent $PythonExe))) { throw 'Explicit override must be Python 3.14.10 with venv/ensurepip.' }
} else { $PythonExe = $ownedPython }
$healthyExisting = Test-OwnedVenv $projectRoot -Headless:$headless
if (-not $headless -and -not $healthyExisting -and -not $Repair -and (Test-OwnedVenv $projectRoot -Headless)) {
    # 실행 중인 공용 가상환경에 GUI 패키지만 추가합니다.
    $guiRequirements = @(Get-Content -LiteralPath $lockFile | Where-Object { $_ -match $guiLockPattern })
    if (-not $guiRequirements) { throw 'GUI 고정 의존성 목록이 비어 있습니다.' }
    & (Join-Path $venvPath 'Scripts\python.exe') -m pip install @guiRequirements
    if ($LASTEXITCODE -ne 0 -or -not (Test-OwnedVenv $projectRoot)) { throw 'GUI 의존성 복구 실패. 기존 가상환경은 교체하지 않았습니다.' }
    $healthyExisting = $true
}
if ($healthyExisting -and -not $Repair) {
    Write-Host '기존 .venv가 정상입니다. Python 패키지 재설치를 건너뜁니다.'
    $activePython = Join-Path $venvPath 'Scripts\python.exe'
} else {
    Write-Host "Python 3.14.10 selected: $PythonExe"
    $transactionId = [Guid]::NewGuid().ToString('N')
    $newPath = Join-Path $projectRoot ('.venv.new-' + $transactionId)
    $backupPath = Join-Path $projectRoot ('.venv.backup-' + $transactionId)
    $hadExisting = Test-Path -LiteralPath $venvPath
    try {
        & $PythonExe -I -m venv $newPath
        if ($LASTEXITCODE -ne 0) { throw '임시 가상환경 생성 실패' }
        $newPython = Join-Path $newPath 'Scripts\python.exe'
        if ($headless) {
            $coreRequirements = @(Get-Content -LiteralPath $lockFile | Where-Object { $_ -and $_ -notmatch '^#' -and $_ -notmatch $guiLockPattern })
            & $newPython -m pip install @coreRequirements
        } else {
            & $newPython -m pip install -r $lockFile
        }
        if ($LASTEXITCODE -ne 0) { throw '새 가상환경 의존성 설치 실패. 기존 .venv는 유지됩니다.' }
        if (-not (Test-RecordWebVenv $newPath)) { throw '새 가상환경 Python 버전 또는 필수 import 검사 실패' }

        if ($hadExisting) { Move-Item -LiteralPath $venvPath -Destination $backupPath }
        try {
            Move-Item -LiteralPath $newPath -Destination $venvPath
            if (-not (Test-RecordWebVenv $venvPath)) { throw '교체 후 가상환경 최종 검사 실패' }
        } catch {
            Remove-BestEffort $venvPath
            if ($hadExisting -and (Test-Path -LiteralPath $backupPath)) {
                try { Move-Item -LiteralPath $backupPath -Destination $venvPath -ErrorAction Stop }
                catch {
                    throw "가상환경 자동 복원 실패. 백업 위치: $backupPath`n수동 복구: Move-Item -LiteralPath '$backupPath' -Destination '$venvPath'"
                }
            }
            throw
        }
        $venvCommitted = $true
        $activePython = Join-Path $venvPath 'Scripts\python.exe'
    } finally {
        Remove-BestEffort $newPath
    }
}

& $activePython (Join-Path $projectRoot 'module/install_tools.py') --root $projectRoot
if ($LASTEXITCODE -ne 0) { throw '외부 도구 설치/검사 미완료. 기존 정상 도구와 사용자 데이터는 유지됩니다.' }
& $activePython (Join-Path $projectRoot 'module/install_tools.py') --root $projectRoot --check
if ($LASTEXITCODE -ne 0) { throw '최종 환경 검사 실패' }
& $activePython (Join-Path $projectRoot 'module\user_data.py') $projectRoot
if ($LASTEXITCODE -ne 0) { throw '기본 사용자 파일 초기화 실패' }
Write-Host '설치 완료. Python 3.14.10과 모든 필수 실행 파일 검사를 통과했습니다.'
if ($backupPath) { Remove-BestEffort $backupPath }
if ($script:OwnedRuntimeBackup) { Remove-BootstrapTemporary $script:OwnedRuntimeBackup }
} catch {
    if ($venvCommitted -and $script:OwnedRuntimeBackup) {
        if (Test-Path -LiteralPath $venvPath) {
            Move-Item -LiteralPath $venvPath -Destination ($venvPath + '.failed-' + [Guid]::NewGuid().ToString('N'))
        }
        if ($backupPath -and (Test-Path -LiteralPath $backupPath)) { Move-Item -LiteralPath $backupPath -Destination $venvPath }
    }
    if ($script:OwnedRuntimeBackup -and (Test-Path -LiteralPath $script:OwnedRuntimeBackup)) {
        if (Test-Path -LiteralPath $script:OwnedRuntimeActive) {
            Move-Item -LiteralPath $script:OwnedRuntimeActive -Destination ($script:OwnedRuntimeActive + '.failed-' + [Guid]::NewGuid().ToString('N'))
        }
        Move-Item -LiteralPath $script:OwnedRuntimeBackup -Destination $script:OwnedRuntimeActive
    }
    throw
}
