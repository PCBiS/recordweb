"""런처와 Worker가 공유하는 시작 검사 및 종료 분류."""
import json
from pathlib import Path

EXIT_OK = 0
EXIT_TOOLS = 20
EXIT_CONFIG = 21
EXIT_CRASH = 70


def preflight(root, *, tools=True):
    root = Path(root)
    try:
        for name, kind in (("config.json", dict), ("channels.json", list)):
            path = root / "json" / name
            if path.exists():
                value = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(value, kind):
                    raise ValueError(name + " 형식 오류")
                if name == "config.json" and not 1 <= int(value.get("port", 5000)) <= 65535:
                    raise ValueError("port 범위 오류")
    except (OSError, ValueError, TypeError) as exc:
        return EXIT_CONFIG, "설정 오류: " + str(exc)
    if tools:
        from module.tool_install import check_tools
        failed = [name for name, result in check_tools(root).items() if not result["ok"]]
        if failed:
            return EXIT_TOOLS, "필수 도구 누락/손상: " + ", ".join(failed) + ". recordWEB.bat --repair로 복구하세요."
    return EXIT_OK, "시작 검사 완료"


class RestartPolicy:
    def __init__(self, limit=2):
        self.limit, self.attempts = limit, 0

    def should_restart(self, code):
        if code in (EXIT_OK, EXIT_TOOLS, EXIT_CONFIG) or self.attempts >= self.limit:
            return False
        self.attempts += 1
        return True
