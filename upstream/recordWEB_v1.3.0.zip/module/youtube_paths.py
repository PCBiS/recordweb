"""영상 VOD 완성 컨테이너와 다운로드 보조 파일을 구분합니다."""
from pathlib import Path
from module.media_validation import has_video_stream

VIDEO_EXTENSIONS = {".mkv", ".mp4", ".webm", ".mov", ".flv", ".avi", ".m4v", ".ts"}
KNOWN_MEDIA_EXTENSIONS = VIDEO_EXTENSIONS | {".mka", ".m4a", ".mp3", ".opus", ".ogg", ".aac"}


def output_base(folder, filename):
    path = Path(folder, filename)
    return path.with_suffix("") if path.suffix.lower() in KNOWN_MEDIA_EXTENSIONS else path


def complete_files(base, ffprobe=None):
    base = Path(base)
    candidates = [base] if base.is_file() else []
    # glob 메타문자가 들어간 방송 제목도 문자열 기준으로 비교합니다.
    for path in base.parent.iterdir():
        if path.is_file() and path.name.startswith(base.name + ".") and path.suffix.lower() in VIDEO_EXTENSIONS:
            suffix = path.name[len(base.name):]
            if suffix.count(".") == 1:
                candidates.append(path)
    result = []
    for path in candidates:
        if path.suffix.lower() not in VIDEO_EXTENSIONS:
            continue
        # ffprobe가 제공된 실제 다운로드 경로에서는 확장자만 믿지 않습니다.
        if ffprobe and has_video_stream(path, ffprobe) is not True:
            continue
        result.append(path)
    preferred = Path(str(base) + ".mkv")
    return sorted(result, key=lambda path: (path != preferred, str(path)))
