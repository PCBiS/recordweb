"""배포 기본값은 사용자 데이터와 분리하고 없는 파일만 생성합니다."""
from pathlib import Path


def initialize(root):
    root = Path(root)
    target = root / "json"
    target.mkdir(exist_ok=True)
    for source in (root / "defaults/json").glob("*"):
        if not source.is_file():
            continue
        destination = target / source.name
        if source.name == "channels.json" and not destination.exists():
            (root / "output").mkdir(exist_ok=True)
        try:
            with destination.open("xb") as output:
                output.write(source.read_bytes())
        except FileExistsError:
            pass


if __name__ == "__main__":
    import sys
    initialize(sys.argv[1])
