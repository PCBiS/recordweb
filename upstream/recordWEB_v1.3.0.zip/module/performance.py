"""Bounded local timing diagnostics; no channel names, URLs, cookies or media paths."""
import asyncio
from collections import defaultdict, deque
import sys
import threading
import time
import traceback

requests = deque(maxlen=500)
pages = deque(maxlen=30)

def install(app):
    @app.middleware('http')
    async def timing(request, call_next):
        begin = time.perf_counter()
        response = await call_next(request)
        elapsed = (time.perf_counter()-begin)*1000
        route = request.scope.get('route')
        path = getattr(route, 'path', '<unmatched>')
        if path.startswith('/api/') or path == '/status':
            requests.append({'route':path,'ms':round(elapsed,3),'status':response.status_code})
        response.headers['Server-Timing'] = f'app;dur={elapsed:.3f}'
        if elapsed > 1000:
            print(f'[PERF][SLOW] route={path} ms={elapsed:.1f}',flush=True)
        return response

def summary():
    groups = defaultdict(list)
    for row in list(requests):groups[row['route']].append(row['ms'])
    def stats(values):
        values=sorted(values)
        return {'count':len(values),'p50_ms':values[len(values)//2],
                'p95_ms':values[min(len(values)-1,int(len(values)*.95))],'max_ms':values[-1]}
    return {'requests':{route:stats(values) for route,values in groups.items()},'pages':list(pages)}

def watch_loop(loop):
    """Record the actual blocking stack rather than guessing from a timeout."""
    stopped=threading.Event();heartbeat=[time.monotonic()];main_id=threading.get_ident()
    async def beat():
        while not stopped.is_set():
            heartbeat[0]=time.monotonic()
            await asyncio.sleep(.25)
    task=loop.create_task(beat())
    def watch():
        while not stopped.wait(2):
            lag=time.monotonic()-heartbeat[0]
            if lag>3:
                frame=sys._current_frames().get(main_id)
                stack=''.join(traceback.format_stack(frame,limit=14)) if frame else '<unavailable>'
                print(f'[PERF][EVENT-LOOP-LAG] seconds={lag:.2f}\n{stack}',flush=True)
    threading.Thread(target=watch,name='recordWEB-loop-watch',daemon=True).start()
    def stop():
        stopped.set();task.cancel()
    return stop
