"""서로 다른 WEB/Worker/다운로더 프로세스 사이의 도구 사용 상태 공유."""
import asyncio
import json
import os
from pathlib import Path
import time
import psutil
from module import data_manager as dm


def write_snapshot(root):
    rm = dm.RecorderManager()
    busy = any(rm.status_recording.values()) or any(rm.status_reserved.values()) or bool(rm.postprocess_active_jobs)
    dm.writeJsonSafe(str(Path(root) / "json/dependency_usage.json"), {"pid": os.getpid(), "time": time.time(), "busy": busy})


async def monitor(root):
    while True:
        await asyncio.to_thread(write_snapshot, root)
        await asyncio.sleep(2)


def remote_busy(root):
    try:
        value = json.loads((Path(root) / "json/dependency_usage.json").read_text(encoding="utf-8"))
        if value["pid"] == os.getpid() or not psutil.pid_exists(value["pid"]):
            return False
        return bool(value.get("busy")) or time.time() - value["time"] > 10
    except (OSError, ValueError, KeyError, TypeError):
        return False
