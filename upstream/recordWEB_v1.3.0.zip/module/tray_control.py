"""같은 프로세스 트레이에서만 사용하는 이벤트 루프 전달기."""
import asyncio
import threading


class TrayControl:
    def __init__(self):
        self._lock = threading.Lock()
        self._loop = None
        self._actions = {}
        self.notify = lambda message: print("[트레이]", message)

    def bind(self, loop, **actions):
        with self._lock:
            self._loop, self._actions = loop, actions

    def close(self):
        with self._lock:
            self._loop, self._actions = None, {}

    def submit(self, action):
        with self._lock:
            loop, handler = self._loop, self._actions.get(action)
            if loop is None or loop.is_closed() or handler is None:
                self.notify("서버가 준비되지 않았거나 종료 중입니다.")
                return None
            async def invoke():
                return await handler()
            coroutine = invoke()
            try:
                future = asyncio.run_coroutine_threadsafe(coroutine, loop)
            except RuntimeError:
                coroutine.close()
                self.notify("서버 종료 중 제어 요청을 전달하지 못했습니다.")
                return None
        def completed(result):
            try:
                result.result()
            except BaseException as exc:
                self.notify("제어 실패: " + type(exc).__name__)
        future.add_done_callback(completed)
        return future
