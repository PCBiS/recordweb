"""Read-only interpretation of old generic failures with explicit timeout logs."""
from functools import lru_cache
from itertools import chain
import json,re
from pathlib import Path

from module.runtime_log import LOG_STAMP, log_archives


def _legacy_lines(path):
    for item in [*reversed(log_archives(path)), path]:
        try:
            with item.open('rb') as source:
                first = source.readline()
                if not LOG_STAMP.match(first):
                    for line in chain((first,), source):
                        yield line.decode('utf-8', errors='replace')
        except OSError:
            continue


@lru_cache(maxsize=1)
def timeout_evidence(log_path):
    copies={};pending={};last_report=None
    for line in _legacy_lines(Path(log_path)):
        if '[POST][COPY-START]' in line:
            match=re.search(r'job=(\w+) input=(.*?) output=(.*?) stream_copy=',line)
            if match:
                copies[match[1]]=(match[2],match[3]);pending.pop(match[1],None)
            last_report=None
        elif '[POST][VALIDATION]' in line:
            try:last_report=json.loads(line.split('[POST][VALIDATION]',1)[1])
            except ValueError:last_report=None
        elif '[POST][FAIL]' in line:
            match=re.search(r'job=(\w+)',line)
            if not match or not last_report:continue
            jid=match[1];pair=copies.get(jid)
            error=last_report.get('error','')
            if pair and last_report.get('ffmpeg_returncode')==0 and error.startswith('TimeoutExpired:') and Path(pair[0]).name in error:
                pending[jid]={'input_path':pair[0],'output_path':pair[1]}
    return pending


def was_validation_timeout(job, root):
    evidence = timeout_evidence(str(Path(root) / 'logs/recordWEB_backend.log'))
    match = evidence.get(job.get('job_id'))
    return bool(match and match['input_path'] == job.get('input_path'))
