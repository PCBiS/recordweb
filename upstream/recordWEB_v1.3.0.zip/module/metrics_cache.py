"""Non-blocking, single-worker snapshots for potentially slow OS disk calls."""
import threading
import time
import json
import os
from pathlib import Path
import subprocess
import sys


def collect_disks():
    result = subprocess.run([sys.executable, '-B', '-m', 'module.disk_metrics'],
                            cwd=Path(__file__).resolve().parents[1],
                            capture_output=True, text=True, encoding='utf-8',
                            timeout=30, check=True,
                            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    return json.loads(result.stdout)


class MetricsCache:
    def __init__(self, collect, ttl=10):
        self.collect = collect
        self.ttl = ttl
        self.lock = threading.Lock()
        self.data = []
        self.sampled_at = 0
        self.attempt_at = 0
        self.busy = False
        self.failed = False

    def snapshot(self):
        with self.lock:
            now = time.monotonic()
            if not self.busy and (not self.attempt_at or now - self.attempt_at >= self.ttl):
                self.busy = True
                self.attempt_at = now
                threading.Thread(target=self._refresh, name='recordWEB-disk-metrics', daemon=True).start()
            return {'disks': list(self.data), 'disk_sampled_at': self.sampled_at,
                    'disk_pending': self.busy, 'disk_failed': self.failed}

    def _refresh(self):
        try:
            data = self.collect()
            with self.lock:
                self.data = data
                self.sampled_at = time.time()
                self.failed = False
        except Exception:
            with self.lock:
                self.failed = True
        finally:
            with self.lock:
                self.busy = False
