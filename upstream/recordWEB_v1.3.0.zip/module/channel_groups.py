"""Optional channel groups with stable IDs, independent of recording state."""
import asyncio
import uuid
from pathlib import Path
from fastapi import HTTPException
from module import data_manager as dm


def load_groups():
    path = Path(dm.CHANNELS_PATH).with_name('channel_groups.json')
    if not path.exists():
        return []
    import json
    groups = json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(groups, list) or any(not isinstance(g, dict) or not isinstance(g.get('id'), str) or not isinstance(g.get('name'), str) for g in groups):
        raise ValueError('녹화채널 그룹 파일 형식을 확인하세요. 기존 파일은 보존했습니다.')
    return groups


def effective_group(value, groups):
    return value if any(g['id'] == value for g in groups) else ''


def validate_assignment(value, current=''):
    if value is None:
        return ''
    if not isinstance(value, str):
        raise ValueError('녹화채널 그룹을 선택하세요.')
    value = value.strip()
    if value and not effective_group(value, load_groups()):
        if value == current:
            return ''  # Deleted group references behave as unassigned.
        raise ValueError('등록되지 않은 녹화채널 그룹입니다. 목록을 새로고침하세요.')
    return value


async def mutate_group(request, operation, group_id=None):
    task = asyncio.create_task(_mutate_group(request, operation, group_id))
    try:
        return await asyncio.shield(task)
    except asyncio.CancelledError:
        await task
        raise


async def _mutate_group(request, operation, group_id=None):
    body = await request.json() if operation != 'delete' else {}
    async with request.app.state.channels_lock:
        try:
            groups = load_groups()
            index = next((i for i,g in enumerate(groups) if g['id'] == group_id), None)
            if operation != 'add' and index is None:
                raise HTTPException(404, '녹화채널 그룹을 찾을 수 없습니다.')
            if operation == 'delete':
                groups.pop(index)
            else:
                name = body.get('name') if isinstance(body, dict) else None
                if not isinstance(name, str) or not name.strip() or len(name.strip()) > 60 or any(ord(c)<32 for c in name):
                    raise ValueError('그룹명은 1~60자의 한 줄로 입력하세요.')
                name = name.strip()
                if any(g['name'].casefold() == name.casefold() for i,g in enumerate(groups) if i != index):
                    raise HTTPException(409, '이미 등록된 그룹명입니다.')
                item = {'id': group_id or uuid.uuid4().hex, 'name': name}
                if operation == 'add': groups.append(item)
                else: groups[index] = item
            # IDs make rename a single-file operation. Removed IDs resolve to 없음,
            # including after restart; they are never reused for another group.
            await asyncio.to_thread(dm.writeJsonSafe, str(Path(dm.CHANNELS_PATH).with_name('channel_groups.json')), groups)
            return {'status':'success', 'groups':groups}
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        except OSError as exc:
            raise HTTPException(500, '그룹 저장에 실패했습니다. 기존 설정을 확인하세요.') from exc
