"""One backend-owned inspection result, shared by all pages."""
import asyncio
import copy
from pathlib import Path

class InspectionCache:
    def __init__(self):
        self.entries = {}
        self.locks = {}

    async def get(self, key, signature, factory, force=False):
        async with self.locks.setdefault(key, asyncio.Lock()):
            previous = self.entries.get(key)
            if not force and previous and previous[0] == signature:
                return copy.deepcopy(previous[1])
            value = await factory()
            self.entries[key] = (signature, copy.deepcopy(value))
            return value

    def invalidate(self, key=None):
        if key is None: self.entries.clear()
        else: self.entries.pop(key, None)

cache = InspectionCache()

def tool_signature(root):
    from module.data_manager import BUNDLED_TOOL_PATHS

    root = Path(root)
    names = ["runtime/python/python.exe", ".venv/Scripts/python.exe", *BUNDLED_TOOL_PATHS.values()]
    result = []
    for name in names:
        path = root/name
        try:
            info = path.stat()
            result.append((str(path.resolve()),info.st_mtime_ns,info.st_size))
        except OSError:
            result.append((str(path),None,None))
    return tuple(result)
