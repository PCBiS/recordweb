"""Own only a normal CMD's backend, allowing graceful shutdown before job cleanup."""
import ctypes
from ctypes import wintypes as w
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import psutil

ROOT = Path(__file__).resolve().parents[1]

def kernel():
    api = ctypes.WinDLL('kernel32', use_last_error=True)
    for name, args, result in [
        ('CreateJobObjectW', [ctypes.c_void_p,w.LPCWSTR],w.HANDLE),
        ('SetInformationJobObject',[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD],w.BOOL),
        ('AssignProcessToJobObject',[w.HANDLE,w.HANDLE],w.BOOL),
        ('CloseHandle',[w.HANDLE],w.BOOL),
        ('CreateEventW',[ctypes.c_void_p,w.BOOL,w.BOOL,w.LPCWSTR],w.HANDLE),
        ('OpenEventW',[w.DWORD,w.BOOL,w.LPCWSTR],w.HANDLE),
        ('SetEvent',[w.HANDLE],w.BOOL),
        ('WaitForSingleObject',[w.HANDLE,w.DWORD],w.DWORD)]:
        fn = getattr(api,name)
        fn.argtypes, fn.restype = args,result
    return api

def request_shutdown(name):
    api = kernel()
    event = api.OpenEventW(2,False,name)
    if not event:
        return False
    try:
        return bool(api.SetEvent(event))
    finally:
        api.CloseHandle(event)

def watch_shutdown(server):
    name = os.environ.get('RWEB_SHUTDOWN_EVENT')
    if not name:
        return
    api = kernel()
    event = api.OpenEventW(0x100000,False,name)
    if not event:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        while not server.should_exit:
            if api.WaitForSingleObject(event,500) == 0:
                print('[OWNER] 실행 CMD 종료 감지: 감시·녹화·후처리를 정리합니다.',flush=True)
                server.should_exit = True
                return
    finally:
        api.CloseHandle(event)

def supervise(owner_pid,owner_started,session):
    class Basic(ctypes.Structure):
        _fields_ = [('ProcessTime',ctypes.c_int64),('JobTime',ctypes.c_int64),
                    ('LimitFlags',w.DWORD),('MinWorkingSet',ctypes.c_size_t),
                    ('MaxWorkingSet',ctypes.c_size_t),('ActiveProcesses',w.DWORD),
                    ('Affinity',ctypes.c_size_t),('Priority',w.DWORD),('Scheduling',w.DWORD)]
    class IO(ctypes.Structure):
        _fields_ = [(n,ctypes.c_uint64) for n in ('ReadOps','WriteOps','OtherOps','ReadBytes','WriteBytes','OtherBytes')]
    class Limits(ctypes.Structure):
        _fields_ = [('Basic',Basic),('IO',IO),('ProcessMemory',ctypes.c_size_t),
                    ('JobMemory',ctypes.c_size_t),('PeakProcessMemory',ctypes.c_size_t),('PeakJobMemory',ctypes.c_size_t)]
    api = kernel()
    job = api.CreateJobObjectW(None,None)
    name = 'Local\\recordWEB-shutdown-'+session
    event = api.CreateEventW(None,True,False,name)
    child = None
    status_path = ROOT/'.runtime'/('session-'+session+'.json')
    try:
        if not job or not event:
            raise ctypes.WinError(ctypes.get_last_error())
        limits = Limits()
        limits.Basic.LimitFlags = 0x2000
        if not api.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits)):
            raise ctypes.WinError(ctypes.get_last_error())
        env = os.environ.copy()
        env['RWEB_SHUTDOWN_EVENT'] = name
        child = subprocess.Popen([sys.executable.replace('pythonw.exe','python.exe'),'-u',str(ROOT/'module/recordWEB.py'),'--backend'],
            cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW | 4)
        if not api.AssignProcessToJobObject(job,w.HANDLE(int(child._handle))):
            raise ctypes.WinError(ctypes.get_last_error())
        psutil.Process(child.pid).resume()
        status_path.write_text(json.dumps({'pid':child.pid,'event':name}),encoding='utf-8')
        owner = psutil.Process(owner_pid)
        while child.poll() is None:
            if not owner.is_running() or abs(owner.create_time()-owner_started)>.1:
                api.SetEvent(event)
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    print('[OWNER] Graceful shutdown timeout; closing owned process job.',flush=True)
                break
            time.sleep(.25)
    except psutil.NoSuchProcess:
        if event:
            api.SetEvent(event)
        if child:
            try:
                child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                pass
    finally:
        if child and child.poll() is None:
            child.kill()
        if job:
            api.CloseHandle(job)
        if event:
            api.CloseHandle(event)
        status_path.unlink(missing_ok=True)

if __name__ == '__main__':
    supervise(int(sys.argv[1]),float(sys.argv[2]),sys.argv[3])
