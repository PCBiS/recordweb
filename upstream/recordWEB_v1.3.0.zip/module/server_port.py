"""recordWEB 서버 포트 검사."""
import socket


MIN_USER_PORT = 1024
MAX_PORT = 65535
DEFAULT_PORT = 5000


def parse_port(value, *, allow_legacy=False):
    try:
        if isinstance(value, bool):
            raise ValueError
        port = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("서버 포트는 1024~65535 범위의 정수여야 합니다.") from exc

    minimum = 1 if allow_legacy else MIN_USER_PORT
    if not minimum <= port <= MAX_PORT:
        if allow_legacy:
            raise ValueError("서버 포트는 1~65535 범위여야 합니다.")
        raise ValueError("서버 포트는 1024~65535 범위여야 합니다.")
    return port


def legacy_port_warning(port):
    if 1 <= int(port) < MIN_USER_PORT:
        return "기존 서버 포트가 권장 범위(1024~65535)를 벗어났습니다. 설정에서 변경을 권장합니다."
    return ""


def ensure_port_available(port, host="127.0.0.1", *, current_port=None, previous_port=None):
    """새로 저장할 포트가 사용 가능한지 확인합니다."""
    port = parse_port(port, allow_legacy=(previous_port is not None and int(port) == int(previous_port)))
    if current_port is not None and port == int(current_port):
        return port

    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        probe.bind((host, port))
    except OSError as exc:
        raise ValueError(
            f"서버 포트 {port}번은 다른 프로그램이 사용 중이어서 저장할 수 없습니다. 다른 포트를 입력해 주세요."
        ) from exc
    finally:
        probe.close()
    return port

