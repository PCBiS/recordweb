"""후처리 실패와 재시도를 같은 작업 ID로 원자적으로 갱신합니다."""
from datetime import datetime, timezone
from module import data_manager as dm


def now():
    return datetime.now(timezone.utc).isoformat()


def records():
    jobs = dm.readJsonSafe(dm.POSTPROCESS_FAILED_PATH, [])
    return [job for job in jobs if isinstance(job, dict)] if isinstance(jobs, list) else []


def is_failure_record(job):
    if job.get("status", "failed") not in {"failed", "failed_again", "retrying", "원본 없음"}:
        return False
    reason = job.get("reason") or ""
    if job.get("retry_mode") == "validation" and reason != "검증 성공 후 파일 정리 실패":
        return False
    if reason.startswith(("후처리 결과 검증 실패:", "분할 후처리 출력 검증 실패.")):
        return False
    if reason == "copyStream returned False":
        from module.postprocess_legacy import was_validation_timeout
        return not was_validation_timeout(job, dm.base_directory)
    return True


def failed(job):
    with dm._json_write_lock:
        jobs = records()
        old = next((item for item in jobs if item.get("job_id") == job["job_id"]), {})
        merged = {**old, **job, "status": "failed_again" if old.get("retry_count", 0) else "failed",
                  "first_failure_at": old.get("first_failure_at", job.get("finished_at", now())),
                  "first_reason": old.get("first_reason", job.get("reason", "")),
                  "retry_count": old.get("retry_count", 0)}
        jobs = [item for item in jobs if item.get("job_id") != job["job_id"]]
        dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, [*jobs, merged][-300:])


def recovered(job):
    with dm._json_write_lock:
        jobs = records()
        for item in jobs:
            if item.get("job_id") == job["job_id"]:
                item.update(status="recovered", recovered_at=now(), output_file=job.get("output_path"), reason="")
                dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)
                break


def delete_record(job_id):
    from fastapi import HTTPException

    with dm._json_write_lock:
        jobs = dm.readJsonSafe(dm.POSTPROCESS_FAILED_PATH, [])
        matches = [
            job for job in jobs
            if isinstance(job, dict) and job.get("job_id") == job_id
        ] if isinstance(jobs, list) else []
        if not matches:
            raise HTTPException(404, "후처리 기록을 찾을 수 없습니다.")
        if any(job.get("status") in {"running", "retrying"} for job in matches):
            raise HTTPException(409, "후처리가 끝난 뒤 기록을 삭제할 수 있습니다.")
        remaining = [
            job for job in jobs
            if not isinstance(job, dict) or job.get("job_id") != job_id
        ]
        try:
            dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, remaining)
        except OSError as exc:
            raise HTTPException(500, "후처리 기록을 저장하지 못했습니다.") from exc


def begin_retry(job_id, profile):
    import os
    from fastapi import HTTPException
    with dm._json_write_lock:
        jobs = records()
        item = next((item for item in jobs if item.get("job_id") == job_id), None)
        if item is None:
            raise HTTPException(404, "실패 작업을 찾을 수 없습니다.")
        if item.get("status") in ("retrying", "recovered"):
            raise HTTPException(409, "이미 재시도 중이거나 복구 완료된 작업입니다.")
        if not is_failure_record(item):
            raise HTTPException(404, "실패 작업을 찾을 수 없습니다.")
        if not os.path.isfile(item.get("input_path", "")):
            item.update(status="원본 없음", reason="원본 파일 위치를 복구하세요.")
            dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)
            raise HTTPException(400, "원본 파일이 없습니다.")
        item.setdefault("first_failure_at", item.get("finished_at"))
        item.setdefault("first_reason", item.get("reason"))
        item.pop("retry_mode", None)
        item.update(status="retrying", retry_count=item.get("retry_count", 0) + 1,
                    last_retry_at=now(), retry_profile=profile)
        dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)
        return dict(item)


def recover_interrupted():
    with dm._json_write_lock:
        jobs = records()
        changed = False
        for item in jobs:
            if item.get("status") == "retrying" and item.get("retry_mode") != "validation":
                item.update(status="failed_again", reason="앱 종료로 이전 재시도가 중단되었습니다.")
                changed = True
        if changed:
            dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)
