"""접두사 및 개발/사전/정식 버전을 정규화해 비교합니다."""
import re
from packaging.version import Version, InvalidVersion


def normalized_version(value):
    text = str(value or "").strip().removeprefix("v")
    try:
        return Version(text)
    except InvalidVersion:
        dev = re.fullmatch(r'(\d+\.\d+\.\d+)-dev(\d+)(?:\.(\d+))?(?:-fix(\d+))?', text)
        if dev:
            core, generation, iteration, fix = dev.groups()
            return Version(f'{core}.dev{generation}+iteration.{iteration or 0}.fix.{fix or 0}')
        match = re.search(r"\d{4}\.\d{2}\.\d{2}(?:\.\d+)?", text)
        if match:
            return Version(match.group())
        return None


def compare_versions(current, latest):
    current, latest = normalized_version(current), normalized_version(latest)
    if current is None or latest is None:
        return None
    return (current > latest) - (current < latest)
