"""Platform cookie storage and guides for the standalone downloader.

Only aggregate status is returned. Saved credentials are never returned to UI.
"""
from pathlib import Path
from module import cookie_store, data_manager as dm
from module.cookie_store import FIELDS, REQUIRED_FIELDS

LABELS = {'chzzk':'치지직', 'cime':'씨미'}


def platform_guide(platform):
    if platform == 'chzzk':
        return ('공개 영상은 쿠키 없이 이용할 수 있습니다. 연령 제한·프라임·네이버 멤버십 등 계정 권한이 필요한 VOD는 해당 계정의 로그인 쿠키가 필요할 수 있습니다.\n\n'
                '1. Chrome/Edge에서 네이버 또는 치지직에 로그인합니다.\n'
                '2. F12 → Application(애플리케이션) → Storage → Cookies에서 https://www.naver.com 또는 https://chzzk.naver.com을 선택합니다.\n'
                '3. NID_AUT와 NID_SES 각각의 Value(값)를 복사합니다. 쿠키 이름이나 전체 Cookie 헤더를 복사하지 마세요.\n'
                '4. replayDownloader의 [쿠키 관리] → [치지직] 탭에 두 값을 붙여넣고 [쿠키 저장]을 누릅니다.\n'
                '5. [쿠키 검사]로 입력 상태를 확인한 뒤 영상을 다시 분석합니다. 재시작 없이 다음 분석·다운로드부터 적용됩니다.\n\n'
                '쿠키는 로그인 정보입니다. 외부 공유·로그 첨부를 하지 마세요. 쿠키가 있어도 계정에 없는 영상 권한은 추가되지 않습니다.')
    if platform == 'cime':
        return ('공개 영상은 쿠키 없이 이용할 수 있습니다. 로그인·연령 제한·구독·일부 고화질 등 계정 권한이 필요한 VOD는 해당 계정의 로그인 쿠키가 필요할 수 있습니다.\n\n'
                '1. Chrome/Edge에서 씨미 https://ci.me에 로그인합니다.\n'
                '2. F12 → Application(애플리케이션) → Storage → Cookies → https://ci.me를 선택합니다.\n'
                '3. mauth-authorization-code와 session-id의 Value(값)를 복사합니다.\n'
                '4. replayDownloader의 [쿠키 관리] → [씨미] 탭에 값을 붙여넣고 [쿠키 저장]을 누릅니다. session-id도 함께 등록하는 것을 권장합니다.\n'
                '5. [쿠키 검사]로 입력 상태를 확인한 뒤 영상을 다시 분석합니다. 재시작 없이 다음 분석·다운로드부터 적용됩니다.\n\n'
                '쿠키는 로그인 정보입니다. 외부 공유·로그 첨부를 하지 마세요. 구독·고화질 영상은 해당 계정에 실제 접근 권한이 있어야 합니다.')
    raise ValueError('지원하지 않는 쿠키 플랫폼입니다.')


def _summary(data, platform, path):
    values = data.get(platform, {})
    if not isinstance(values, dict):
        raise ValueError('플랫폼 쿠키 구조가 올바르지 않습니다.')
    present = {name:bool(str(values.get(name) or '').strip()) for name in FIELDS[platform]}
    usable = all(present[name] for name in REQUIRED_FIELDS[platform])
    try: stamp = path.stat().st_mtime
    except OSError: stamp = None
    return {'platform':platform, 'field_present':present, 'present_count':sum(present.values()),
            'usable':usable, 'verdict':'입력 완료' if usable and all(present.values()) else '확인 필요',
            'last_saved_at':stamp, 'message':'실제 로그인·만료·영상 권한은 영상 분석 결과로 확인하세요.'}


def platform_cookie_status(platform, path=None, changes=None):
    path = Path(path or dm.COOKIE_PATH)
    data = cookie_store.load_gui(path)
    if changes is not None:
        data = cookie_store.merge_gui(data, platform, changes)
    return _summary(data, platform, path)


def save_platform_cookies(platform, changes, path=None):
    path = Path(path or dm.COOKIE_PATH)
    data = cookie_store.save_gui(path, platform, changes)
    return _summary(data, platform, path)
