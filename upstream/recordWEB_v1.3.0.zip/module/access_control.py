"""One remote-access policy for form/API settings and server binding."""
from ipaddress import ip_address
import socket
from urllib.parse import urlsplit

import psutil

LOOPBACK = {'127.0.0.1', '::1', 'localhost'}


def interface_ipv4_addresses():
    return sorted({
        entry.address
        for entries in psutil.net_if_addrs().values()
        for entry in entries
        if entry.family == socket.AF_INET and not ip_address(entry.address).is_loopback
        and not ip_address(entry.address).is_unspecified
    })


def allowed_host(host, actual_port, bound_remote):
    try:
        parsed = urlsplit('http://' + host)
        name = parsed.hostname
        if not name or parsed.username or parsed.path or parsed.query or parsed.fragment:
            return False
        if (parsed.port or 80) != actual_port:
            return False
        if name in LOOPBACK:
            return True
        address = ip_address(name)
        if not bound_remote or address.version != 4 or address.is_unspecified:
            return False
        return name in interface_ipv4_addresses()
    except (OSError, ValueError):
        return False

def validate_network(config, account):
    from module.data_manager import toBool
    from module.server_port import parse_port
    result = dict(config)
    result['loginMode'] = toBool(result.get('loginMode', False))
    result['remoteAccessEnabled'] = toBool(result.get('remoteAccessEnabled', False))
    result['port'] = parse_port(result.get('port', 5000), allow_legacy=True)
    return result
