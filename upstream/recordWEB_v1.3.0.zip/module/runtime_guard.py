import atexit
import json
import os
import socket
import sys
import time
from datetime import datetime
from typing import Optional


class RuntimeAlreadyRunning(RuntimeError):
    pass


# 버전별 동시실행 방지
class RuntimeGuard:
    def __init__(self, mode: str, base_dir: Optional[str] = None, *, port=None, identity=None):
        self.mode = mode
        self.base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.runtime_dir = os.path.join(self.base_dir, "json")
        self.lock_path = os.path.join(self.runtime_dir, "recordfsm_runtime.lock")
        self.info_path = os.path.join(self.runtime_dir, "recordfsm_runtime.json")
        self._file = None
        self._locked = False
        self.port = int(port) if port is not None else None
        self.identity = dict(identity or {})

    def acquire(self):
        os.makedirs(self.runtime_dir, exist_ok=True)
        self._file = open(self.lock_path, "a+", encoding="utf-8")

        try:
            if os.name == "nt":
                import msvcrt
                self._file.seek(0)
                msvcrt.locking(self._file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (BlockingIOError, PermissionError) as error:
            self._file.close()
            self._file = None
            raise RuntimeAlreadyRunning(self._build_running_message()) from error
        except OSError as error:
            self._file.close()
            self._file = None
            if os.name == "nt" and error.errno == 13:
                raise RuntimeAlreadyRunning(self._build_running_message()) from error
            raise

        self._locked = True
        self._write_info()
        atexit.register(self.release)
        return self

    def release(self):
        if not self._file:
            return

        # 잠금을 가진 프로세스만 자신의 실행 정보를 지웁니다.
        try:
            info = self.read_info(self.base_dir)
            if info and info.get("pid") == os.getpid() and os.path.exists(self.info_path):
                os.remove(self.info_path)
        except Exception:
            pass

        try:
            if self._locked:
                if os.name == "nt":
                    import msvcrt
                    self._file.seek(0)
                    msvcrt.locking(self._file.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self._file.fileno(), fcntl.LOCK_UN)
        except Exception:
            pass

        try:
            self._file.close()
        except Exception:
            pass

        self._file = None
        self._locked = False

    def update_port(self, port):
        self.port = int(port)
        if self._locked:
            self._write_info()

    def _write_info(self):
        info = {
            "mode": self.mode,
            "pid": os.getpid(),
            "python": sys.executable,
            "host": socket.gethostname(),
            "started_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "time": time.time(),
            "port": self.port,
        }
        for key in ("product", "version", "pid_started", "project_root", "build"):
            if key in self.identity:
                info[key] = self.identity[key]
        try:
            temp_path = self.info_path + ".tmp"
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(info, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp_path, self.info_path)
        except Exception:
            pass

    @staticmethod
    def read_info(base_dir):
        path = os.path.join(base_dir, "json", "recordfsm_runtime.json")
        try:
            with open(path, "r", encoding="utf-8") as f:
                value = json.load(f)
            return value if isinstance(value, dict) else None
        except (OSError, ValueError):
            return None

    def _build_running_message(self):
        info = None
        try:
            with open(self.info_path, "r", encoding="utf-8") as f:
                info = json.load(f)
        except Exception:
            info = None

        if info:
            return (
                "이미 recordWEB이 실행 중입니다.\n"
                f"실행 모드: {info.get('mode')}\n"
                f"PID: {info.get('pid')}\n"
                f"시작 시간: {info.get('started_at')}\n"
                "기존 실행을 유지하고 recordWEB.bat을 다시 실행하면 데스크톱 창만 표시됩니다."
            )

        return (
            "이미 recordWEB이 실행 중이거나 이전 실행의 잠금이 남아 있습니다.\n"
            "recordWEB.bat을 사용해 기존 서버에 연결하세요."
        )
