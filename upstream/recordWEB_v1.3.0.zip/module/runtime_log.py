from __future__ import annotations

import json
import logging
import os
import re
import shutil
import sys
import time
import traceback
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_DIR = os.path.join(BASE_DIR, "logs")
REPORT_PATH = os.path.join(BASE_DIR, "json", "recent_errors.json")
MAX_ITEMS = 100
DEFAULT_DIAGNOSTIC_LOG_DAYS = "3"
DIAGNOSTIC_LOG_DAYS = {"0", "1", "3", "7", "14", "unlimited"}
_log_days = DEFAULT_DIAGNOSTIC_LOG_DAYS
_log_lock = threading.RLock()
_cleanup_wake = threading.Event()
_writers = {}
_LOG_NAMES = ('recordWEB_backend.log', 'recordWEB_web.log', 'recordWEB_startup.log')
LOG_STAMP = re.compile(rb'^\[\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ\] ')

_last_print_at: dict[str, float] = {}
_printed_once_keys: set[str] = set()


def normalize_diagnostic_log_days(value):
    value = str(value)
    return value if value in DIAGNOSTIC_LOG_DAYS else DEFAULT_DIAGNOSTIC_LOG_DAYS


def set_diagnostic_log_days(value):
    global _log_days
    days = normalize_diagnostic_log_days(value)
    with _log_lock:
        if days != _log_days:
            _log_days = days
            _cleanup_wake.set()


def diagnostic_logging_enabled():
    return _log_days != "0"


def log_hour(timestamp):
    return int(timestamp) // 3600


def log_archive(path, hour):
    target = path.with_name(f'{path.name}.{hour:010d}')
    if target.exists():
        target = target.with_name(f'{target.name}.{time.time_ns()}')
    return target


def log_archives(path):
    prefix = path.name + '.'
    archives = [item for item in path.parent.glob(prefix + '*')
                if item.name[len(prefix):].replace('.', '').isdigit()]
    return sorted(archives, key=lambda item: (len(item.name) >= len(prefix) + 10, item.name), reverse=True)


def _stamp(timestamp):
    return time.strftime('[%Y-%m-%dT%H:%M:%SZ] ', time.gmtime(timestamp)).encode('ascii')


class BackendLog:
    def __init__(self, path):
        self.path = Path(path)
        self.file = None
        self.hour = None
        self.line_end = True

    def _rotate(self, hour):
        if self.hour is None or self.hour >= hour:
            return
        if self.file is not None:
            self.file.close()
            self.file = None
        try:
            self.path.replace(log_archive(self.path, self.hour))
        except FileNotFoundError:
            pass
        self.hour = None
        self.line_end = True

    def write(self, text):
        if not text or not diagnostic_logging_enabled():
            return
        with _log_lock:
            try:
                now = time.time()
                hour = log_hour(now)
                if self.hour is None:
                    self.hour = log_hour(self.path.stat().st_mtime) if self.path.exists() else hour
                if self.line_end and self.hour < hour:
                    try:
                        self._rotate(hour)
                    except OSError:
                        # CMD에서 읽는 중이면 다음 줄에서 재시도
                        pass
                if self.file is None:
                    self.file = self.path.open("ab")
                    if self.hour is None:
                        self.hour = hour
                data = text.replace("\r\n", "\n").encode("utf-8", errors="replace")
                prefix = _stamp(now)
                parts = data.split(b'\n')
                for index, part in enumerate(parts):
                    if index == len(parts) - 1 and not part:
                        break
                    if self.line_end:
                        self.file.write(prefix)
                    self.file.write(part)
                    self.line_end = index < len(parts) - 1
                    if self.line_end:
                        self.file.write(b'\n')
            except OSError:
                pass

    def flush(self):
        with _log_lock:
            if self.file is not None:
                try:
                    self.file.flush()
                except OSError:
                    pass


class DiagnosticLogHandler(logging.Handler):
    def __init__(self, output):
        super().__init__()
        self.output = output

    def emit(self, record):
        self.output.write(self.format(record) + '\n')
        self.output.flush()


def _prune_log(path, cutoff, days):
    original = path.stat()
    if original.st_mtime < cutoff:
        with _log_lock:
            if _log_days == days and path.stat().st_mtime_ns == original.st_mtime_ns:
                path.unlink()
        return
    if log_hour(original.st_mtime) > log_hour(cutoff):
        # 회전한 파일의 이름에는 기록한 시간대가 들어감
        suffix = path.name.split('.log.', 1)[-1].split('.', 1)[0]
        if len(suffix) != 10 or int(suffix) > log_hour(cutoff):
            return

    limit = _stamp(cutoff)
    temporary = path.with_name(path.name + '.pruning')
    try:
        with path.open('rb') as source:
            first = source.readline()
            if not LOG_STAMP.match(first) or first[:23] >= limit:
                return
            while first and first[:23] < limit:
                first = source.readline()
            with temporary.open('wb') as output:
                output.write(first)
                shutil.copyfileobj(source, output)
        with _log_lock:
            if _log_days == days and path.stat().st_mtime_ns == original.st_mtime_ns:
                if first:
                    os.utime(temporary, ns=(original.st_atime_ns, original.st_mtime_ns))
                    temporary.replace(path)
                else:
                    path.unlink()
    finally:
        temporary.unlink(missing_ok=True)


def prune_diagnostic_logs():
    days = _log_days
    if days in ('0', 'unlimited'):
        return
    now = time.time()
    cutoff = now - int(days) * 86400
    with _log_lock:
        if _log_days != days:
            return
        managed = set(_writers)
        for writer in _writers.values():
            try:
                if writer.hour is None:
                    writer.hour = log_hour(writer.path.stat().st_mtime)
                if writer.hour <= log_hour(cutoff):
                    writer._rotate(log_hour(now))
            except OSError:
                pass
        items = _load_items()
        recent = _recent_items(items, cutoff)
        if recent != items:
            _save_items(recent)

    for name in _LOG_NAMES:
        path = Path(LOG_DIR) / name
        files = log_archives(path)
        if path not in managed:
            files.append(path)
        for item in files:
            try:
                _prune_log(item, cutoff, days)
            except OSError:
                pass


def start_diagnostic_log_cleanup():
    def cleanup():
        while True:
            _cleanup_wake.clear()
            prune_diagnostic_logs()
            _cleanup_wake.wait(300)

    threading.Thread(target=cleanup, name='diagnostic-log-cleanup', daemon=True).start()


class ConsoleTee:
    def __init__(self, stream, logfile, lock):
        self.stream, self.logfile, self.lock = stream, logfile, lock

    def write(self, text):
        with self.lock:
            if self.stream:
                try: self.stream.write(text)
                except (OSError, ValueError): pass
            self.logfile.write(text)
            self.logfile.flush()
        return len(text)

    def flush(self):
        with self.lock:
            if self.stream:
                try: self.stream.flush()
                except (OSError, ValueError): pass
            self.logfile.flush()

    def isatty(self):
        return bool(self.stream and self.stream.isatty())


class NotLiveError(Exception):
    pass


def getAppLogger(name: str | None = None) -> logging.Logger:
    if name:
        return logging.getLogger(f"recordWEB.{name}")

    return logging.getLogger("recordWEB")


def setupAppLogging(mode: str = "app") -> logging.Logger:
    os.makedirs(LOG_DIR, exist_ok=True)
    if mode == "web" and not isinstance(sys.stdout, ConsoleTee):
        # 시작 시 보관 기간 적용
        try:
            with open(os.path.join(BASE_DIR, "json", "config.json"), encoding="utf-8") as source:
                config = json.load(source)
        except (OSError, ValueError):
            config = {}
        set_diagnostic_log_days(config.get("diagnosticLogDays") if isinstance(config, dict) else None)
        path = Path(LOG_DIR) / "recordWEB_backend.log"
        output = _writers[path] = BackendLog(path)
        lock = threading.RLock()
        sys.stdout = ConsoleTee(sys.stdout, output, lock)
        sys.stderr = ConsoleTee(sys.stderr, output, lock)

    logger = logging.getLogger("recordWEB")
    logger.setLevel(logging.INFO)
    logger.propagate = False

    log_path = Path(LOG_DIR) / f"recordWEB_{mode}.log"
    if log_path not in _writers:
        output = _writers[log_path] = BackendLog(log_path)
        handler = DiagnosticLogHandler(output)
        handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
        logger.addHandler(handler)

    def _excepthook(exc_type, exc, tb):
        logger.error("Unhandled exception", exc_info=(exc_type, exc, tb))

        try:
            recordException(
                f"unhandled:{mode}",
                exc,
                exc_info=(exc_type, exc, tb),
            )
        except Exception:
            pass

        sys.__excepthook__(exc_type, exc, tb)

    sys.excepthook = _excepthook

    return logger


def debugThrottle(
    key: str,
    msg: str,
    min_secs: float = 30.0,
    print_fn=print,
):

    now = time.monotonic()
    prev = _last_print_at.get(key, 0.0)

    if now - prev >= min_secs:
        print_fn(msg)
        _last_print_at[key] = now


def printOnce(
    key: str,
    msg: str | None = None,
    print_fn=print,
):

    if key in _printed_once_keys:
        return

    _printed_once_keys.add(key)

    if msg is not None:
        print_fn(msg)


def _load_items() -> list[dict]:
    try:
        with open(REPORT_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)

        if isinstance(data, list):
            return data

    except Exception:
        pass

    return []


def _recent_items(items, cutoff=None):
    if cutoff is None:
        if _log_days in ('0', 'unlimited'):
            return items
        cutoff = time.time() - int(_log_days) * 86400
    limit = datetime.fromtimestamp(cutoff).strftime("%Y-%m-%d %H:%M:%S")
    return [item for item in items if isinstance(item, dict)
            and isinstance(item.get('time'), str) and item['time'] >= limit]


def _save_items(items: list[dict]):
    try:
        os.makedirs(os.path.dirname(REPORT_PATH), exist_ok=True)

        temporary = Path(REPORT_PATH).with_suffix(".tmp")
        with temporary.open("w", encoding="utf-8") as f:
            json.dump(
                items[-MAX_ITEMS:],
                f,
                ensure_ascii=False,
                indent=2,
            )
        temporary.replace(REPORT_PATH)

    except Exception:
        pass


def recordMessage(
    source: str,
    level: str,
    message: str,
    extra: Optional[Dict[str, Any]] = None,
):
    if not diagnostic_logging_enabled():
        return
    item = {
        "time": datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S"),
        "source": source,
        "level": level,
        "message": str(message),
        "extra": extra or {},
    }
    with _log_lock:
        _save_items([*_recent_items(_load_items()), item])


def recordException(
    source: str,
    exc: BaseException,
    extra: Optional[Dict[str, Any]] = None,
    exc_info=None,
):
    if not diagnostic_logging_enabled():
        return
    if exc_info:
        tb_text = "".join(traceback.format_exception(*exc_info))
    else:
        tb_text = traceback.format_exc()

    item = {
        "time": datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S"),
        "source": source,
        "level": "ERROR",
        "message": str(exc),
        "exception_type": exc.__class__.__name__,
        "traceback": tb_text,
        "extra": extra or {},
    }
    with _log_lock:
        _save_items([*_recent_items(_load_items()), item])


def loadRecentErrors() -> list[dict]:
    with _log_lock:
        return _recent_items(_load_items())


__all__ = [
    "NotLiveError",
    "getAppLogger",
    "setupAppLogging",
    "debugThrottle",
    "printOnce",
    "recordMessage",
    "recordException",
    "loadRecentErrors",
]
