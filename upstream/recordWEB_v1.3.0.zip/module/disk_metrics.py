"""Disk enumeration runs in a separate process: Windows volume calls can hold the GIL."""
import os
import json
import string
import shutil
import time
import psutil

# 대시보드 디스크 라벨 정리
def _shortDiskLabel(p):
    raw_mp = (p.mountpoint or "").strip()
    mp = raw_mp if raw_mp == os.sep else raw_mp.rstrip(os.sep)
    fs = (p.fstype or "").upper()

    if os.name == "nt":
        label = mp.upper() if (len(mp) >= 2 and mp[1] == ":") else (p.device or mp)
    else:
        if mp in ("/", "/home", "/boot"):
            label = mp
        elif mp.startswith("/sys/fs/cgroup/"):
            parts = [x for x in mp.split("/") if x]
            label = "cgroup/" + (parts[3] if len(parts) > 3 else "")
        elif len(mp) > 16:
            base = os.path.basename(mp)
            label = base if base else mp
        else:
            label = mp
    return label


def probe_disks():
    now = time.monotonic()
    parts = psutil.disk_partitions(all=True)

    disks = []
    seen = set()
    ephemeral = {"tmpfs", "proc", "sysfs", "cgroup", "cgroup2", "squashfs", "devpts", "overlay"}

    for part in parts:
        mountpoint = (part.mountpoint or "").strip()
        if not mountpoint or mountpoint in seen:
            continue
        if (part.fstype or "").lower() in ephemeral and mountpoint not in ("/", "/home", "/boot"):
            continue

        try:
            usage = psutil.disk_usage(mountpoint)
        except Exception:
            continue

        seen.add(mountpoint)
        disks.append({
            "device": part.device or mountpoint,
            "mountpoint": mountpoint,
            "label": _shortDiskLabel(part),
            "fstype": (part.fstype or "").lower(),
            "total": int(usage.total),
            "used": int(usage.used),
            "free": int(usage.free),
            "percent": float(usage.percent),
        })

    if not disks and os.name == "nt":
        for letter in string.ascii_uppercase:
            root = f"{letter}:\\"
            if not os.path.exists(root):
                continue
            try:
                usage = shutil.disk_usage(root)
            except Exception:
                continue
            disks.append({
                "device": root,
                "mountpoint": root,
                "label": root,
                "fstype": "",
                "total": int(usage.total),
                "used": int(usage.used),
                "free": int(usage.free),
                "percent": float((usage.used / usage.total * 100.0) if usage.total else 0.0),
            })
    return disks



if __name__ == "__main__":
    print(json.dumps(probe_disks()))
