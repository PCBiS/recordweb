import re

def parse_progress(line):
    result = {}
    percent = re.search(r'(\d+(?:\.\d+)?)\s*%', line)
    if percent: result['percent'] = min(100.0, float(percent.group(1)))
    speed = re.search(r'(?:at\s+|DL:)([\d.]+\s*[KMGTP]?i?B/s)', line, re.I)
    if speed: result['speed'] = speed.group(1)
    elif match := re.search(r'DL:([\d.]+\s*[KMGTP]?i?B)', line, re.I): result['speed'] = match.group(1)+'/s'
    elif match := re.search(r'speed=\s*([\d.]+x)', line): result['speed'] = '미디어 '+match.group(1)
    size = re.search(r'(?:of\s+~?|size=\s*)([\d.]+\s*[KMGTP]?i?B)', line, re.I)
    if size: result['size'] = size.group(1)
    if match := re.search(r'([\d.]+[KMGTP]?i?B)/([\d.]+[KMGTP]?i?B)', line,re.I): result['size'] = match.group(1)+' / '+match.group(2)
    eta = re.search(r'ETA[:\s]+([\dhms:]+)', line,re.I)
    if eta: result['eta'] = eta.group(1)
    position = re.search(r'time=\s*([\d:.]+)', line)
    if position: result['media_time'] = position.group(1)
    return result
