"""외부 도구 누락·손상만 공용 트랜잭션으로 복구하는 설치 진입점."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from module.tool_install import check_tools, repair_tools


def main(argv=None):
    parser = argparse.ArgumentParser(description="Windows 외부 실행 파일 검사·복구")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--only", nargs="+")
    args = parser.parse_args(argv)
    if not args.check:
        results = repair_tools(args.root, args.only)
        for name, result in results.items():
            print(name, "정상" if result["ok"] else "실패", result.get("error", ""))
    results = check_tools(args.root)
    print(json.dumps(results, ensure_ascii=False, indent=2))
    failed = [name for name, result in results.items() if not result["ok"]]
    if failed:
        print("설치 미완료:", ", ".join(failed), "· recordWEB.bat --repair로 복구하세요.")
        return 20
    print("FFmpeg·ffprobe·Streamlink·aria2c·SABR·Deno 실행 검사 완료")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
