"""Tabbed cookie manager used only by the standalone replayDownloader."""
from datetime import datetime
from html import escape
from pathlib import Path
from PyQt6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QPlainTextEdit,
    QPushButton,QFileDialog,QTabWidget,QWidget,QTextBrowser,QFormLayout,QLineEdit)
from module import data_manager as dm
from module.youtube_cookies import cookie_status,inspect_text,save_cookie_text,MAX_BYTES
from module.downloader_cookies import (FIELDS,LABELS,platform_guide,platform_cookie_status,save_platform_cookies)

YOUTUBE_GUIDE = """
<h3>유튜브 쿠키가 필요한 경우</h3>
<p>공개 영상은 쿠키 없이 이용할 수 있습니다. 로그인·연령 제한·멤버십 등 계정 권한이 필요한 영상에 유튜브 쿠키를 사용합니다.</p>
<p><b>권장: Chrome의 새 시크릿 창 / Edge의 새 InPrivate 창에서 새로 로그인하세요.</b><br>
Get cookies.txt LOCALLY를 미리 설치하고, 확장 프로그램 설정에서 시크릿/InPrivate 사용을 허용해 주세요.</p>
<h3>유튜브 쿠키 내보내기</h3>
<ol>
<li>Chrome의 <b>새 시크릿 창</b> 또는 Edge의 <b>새 InPrivate 창</b>을 엽니다.</li>
<li>그 창에서 YouTube에 로그인합니다.</li>
<li>로그인한 <b>같은 탭</b>의 주소창에 <code>https://www.youtube.com/robots.txt</code>를 입력합니다. 다른 시크릿/InPrivate 탭은 닫아 주세요.</li>
<li><b>Get cookies.txt LOCALLY</b> 확장 프로그램을 실행합니다.</li>
<li><b>Export Format = Netscape</b>를 선택합니다.</li>
<li><b>Export As</b>를 눌러 cookies.txt를 저장합니다. 또는 <b>Copy</b>로 전체 Netscape 내용을 복사합니다.</li>
<li>아래 <b>쿠키 파일 불러오기</b>로 파일을 열거나 입력칸에 붙여넣고 <b>쿠키 저장 → 쿠키 검사</b>를 누릅니다.</li>
<li><b>내보내기가 끝나면 사용했던 시크릿/InPrivate 창을 완전히 닫아 주세요.</b></li>
</ol>
<p><a href="https://github.com/yt-dlp/yt-dlp/wiki/Extractors#exporting-youtube-cookies">yt-dlp 공식 내보내기 안내</a> ·
<a href="https://github.com/yt-dlp/yt-dlp/wiki/FAQ#how-do-i-pass-cookies-to-yt-dlp">Netscape 형식 안내</a></p>
<p>쿠키는 로그인 정보와 동일하게 취급하세요. 외부 공유·로그 첨부·배포 ZIP 포함을 하지 마세요.
프로그램이 내부 저장을 관리하므로 파일 경로를 찾아 덮어쓸 필요가 없습니다. 저장은 다음 분석·다운로드부터 적용됩니다.</p>
"""


def _when(stamp):
    return datetime.fromtimestamp(stamp).strftime('%Y-%m-%d %H:%M:%S') if isinstance(stamp,(int,float)) else '저장 기록 없음'


def _guide(html,parent):
    view=QTextBrowser(parent)
    view.setOpenExternalLinks(True)
    view.setHtml(html)
    view.setMinimumHeight(185)
    view.setMaximumHeight(310)
    return view


def _status_box(parent):
    status=QPlainTextEdit(parent)
    status.setReadOnly(True)
    status.setMinimumHeight(145)
    status.setMaximumHeight(220)
    return status


class YoutubeCookiePanel(QWidget):
    def __init__(self,parent=None,cookie_path=None,close_callback=None):
        super().__init__(parent)
        self.path=Path(cookie_path or dm.yCOOKIE_PATH)
        layout=QVBoxLayout(self)
        self.guide=_guide(YOUTUBE_GUIDE,self)
        layout.addWidget(self.guide,3)
        close_notice=QLabel('내보내기가 끝나면 사용했던 시크릿/InPrivate 창을 완전히 닫아 주세요.',self)
        close_notice.setWordWrap(True)
        close_notice.setStyleSheet('font-weight:600; padding:6px; background:#fff4ce; color:#594400;')
        layout.addWidget(close_notice)
        layout.addWidget(QLabel('쿠키 입력 · 파일 불러오기 또는 전체 Netscape 내용 붙여넣기'))
        self.text=QPlainTextEdit(self)
        self.text.setObjectName('youtube-cookie-input')
        self.text.setPlaceholderText('# Netscape HTTP Cookie File\n기존 저장 쿠키 내용은 표시하지 않습니다.')
        self.text.setMinimumHeight(85)
        layout.addWidget(self.text,1)
        row=QHBoxLayout()
        self.buttons={}
        for label,handler in [('쿠키 파일 불러오기',self.load_file),('쿠키 저장',self.save),('쿠키 검사',self.refresh),('닫기',close_callback or (lambda:None))]:
            button=QPushButton(label,self);button.clicked.connect(handler);row.addWidget(button);self.buttons[label]=button
        layout.addLayout(row)
        self.status=_status_box(self)
        self.status.setObjectName('youtube-cookie-status')
        layout.addWidget(self.status,2)
        self.refresh()

    def render(self,result,prefix='',draft=False):
        kind='Netscape 정상' if result['format_valid'] else '미등록' if result['status']=='missing' else '확인 불가'
        rows=([prefix] if prefix else [])+[
            '검사 대상: '+('입력 내용 (아직 저장되지 않음)' if draft else '현재 저장된 쿠키'),
            '쿠키 형식: '+kind,
            'YouTube 도메인 쿠키: '+('확인됨' if result['youtube_count'] else '없음'),
            '로그인 관련 쿠키: '+('단서 확인됨' if result['login_cookie_count'] else '확인되지 않음'),
            f"쿠키 수: {result['cookie_count']}개 · 만료된 YouTube 쿠키: {result['expired_count']}개",
            f"사용 가능한 YouTube 쿠키: {result['usable_count']}개 · 세션 쿠키: {result['session_count']}개",
            '판정: '+result['verdict']]
        if result.get('reason'):rows.append('원인: '+result['reason'])
        rows += ['마지막 저장: '+_when(result.get('last_saved_at')),
                 '※ 형식·파일 만료 기준입니다. 실제 로그인·영상 접근 권한은 영상 분석으로 확인하세요.']
        self.status.setPlainText('\n'.join(rows))

    def load_file(self):
        name,_=QFileDialog.getOpenFileName(self,'쿠키 파일 불러오기','','쿠키 텍스트 파일 (*.txt);;모든 파일 (*)')
        if name:self.import_file(name)

    def import_file(self,name):
        try:
            path=Path(name)
            if path.stat().st_size>MAX_BYTES:
                raise ValueError()
            content=path.read_text(encoding='utf-8-sig')
            self.text.setPlainText(content)
            self.status.setPlainText('쿠키 파일을 불러왔습니다. 아직 저장되지 않았습니다.\n[쿠키 저장]을 눌러 등록하세요. [쿠키 검사]로 입력 내용을 먼저 검사할 수도 있습니다.')
            return True
        except (OSError,UnicodeError,ValueError):
            self.status.setPlainText('파일을 불러오지 못했습니다. UTF-8 텍스트 파일인지, 2MiB 이하인지 확인하세요.\n현재 저장된 쿠키는 변경하지 않았습니다.')
            return False

    def save(self):
        try:
            result=save_cookie_text(self.path,self.text.toPlainText())
        except ValueError as exc:
            self.status.setPlainText('저장할 수 없습니다.\n'+str(exc)+'\n현재 저장된 쿠키는 변경하지 않았습니다.')
        except OSError:
            self.status.setPlainText('쿠키를 저장하지 못했습니다. 폴더 쓰기 권한을 확인하세요.\n기존 쿠키 파일은 유지했습니다.')
        else:
            self.text.clear()
            self.render(result,'유튜브 쿠키 저장 완료\n상태: '+result['verdict'])

    def refresh(self):
        text=self.text.toPlainText()
        if text.strip():
            self.render(inspect_text(text),draft=True)
        else:
            self.render(cookie_status(self.path))


class PlatformCookiePanel(QWidget):
    def __init__(self,platform,parent=None,cookie_path=None,close_callback=None):
        super().__init__(parent)
        self.platform=platform;self.path=Path(cookie_path or dm.COOKIE_PATH)
        layout=QVBoxLayout(self)
        self.guide=_guide('<h3>'+LABELS[platform]+' 쿠키 등록 방법</h3><div style="white-space:pre-wrap">'+escape(platform_guide(platform)).replace('\n','<br>')+'</div>',self)
        layout.addWidget(self.guide,2)
        form=QFormLayout();form.setSpacing(14)
        self.fields={}
        for name in FIELDS[platform]:
            edit=QLineEdit(self);edit.setEchoMode(QLineEdit.EchoMode.Password)
            edit.setObjectName(platform+'-'+name)
            self.fields[name]=edit;form.addRow(name,edit)
        layout.addLayout(form)
        note=QLabel('기존 값은 표시하지 않습니다. 빈칸은 기존 값 유지입니다.\n쿠키 이름이 아닌 Value(값)만 붙여넣고 [쿠키 저장]을 누르세요.')
        note.setWordWrap(True);layout.addWidget(note)
        row=QHBoxLayout();self.buttons={}
        for label,handler in [('쿠키 저장',self.save),('쿠키 검사',self.refresh),('닫기',close_callback or (lambda:None))]:
            button=QPushButton(label,self);button.clicked.connect(handler);row.addWidget(button);self.buttons[label]=button
        layout.addLayout(row)
        self.status=_status_box(self);layout.addWidget(self.status,2)
        self.refresh()

    def changes(self):
        return {name:edit.text() for name,edit in self.fields.items()}

    def render(self,result,prefix='',draft=False):
        rows=([prefix] if prefix else [])+['검사 대상: '+('입력 내용 (미저장)' if draft else '현재 저장된 쿠키')]
        for name,present in result['field_present'].items():
            rows.append(name+': '+('등록됨' if present else '미등록'))
            self.fields[name].setPlaceholderText('등록됨 · 빈칸이면 기존 값 유지' if present else '쿠키의 Value(값)를 붙여넣으세요')
        rows += ['판정: '+result['verdict'],'마지막 쿠키 파일 저장: '+_when(result['last_saved_at']),result['message']]
        if not result['usable']:rows.append('위 안내대로 로그인 쿠키를 등록한 뒤 다시 검사하세요. 공개 영상은 쿠키 없이 시도할 수 있습니다.')
        self.status.setPlainText('\n'.join(rows))

    def save(self):
        try:result=save_platform_cookies(self.platform,self.changes(),self.path)
        except ValueError as exc:self.status.setPlainText('저장할 수 없습니다.\n'+str(exc))
        except OSError:self.status.setPlainText('쿠키를 저장하지 못했습니다. 폴더 쓰기 권한을 확인하세요. 기존 파일은 유지했습니다.')
        else:
            for edit in self.fields.values():edit.clear()
            self.render(result,LABELS[self.platform]+' 쿠키 저장 완료\n다음 영상 분석·다운로드부터 적용됩니다.')

    def refresh(self):
        draft=any(edit.text().strip() for edit in self.fields.values())
        try:result=platform_cookie_status(self.platform,self.path,self.changes() if draft else None)
        except ValueError as exc:self.status.setPlainText('쿠키 확인이 필요합니다.\n'+str(exc))
        else:self.render(result,draft=draft)


class CookieManagerDialog(QDialog):
    def __init__(self,parent=None,platform='chzzk',cookie_path=None,youtube_path=None):
        super().__init__(parent)
        self.setWindowTitle('쿠키 관리 · replayDownloader')
        self.resize(900,820);self.setMinimumSize(720,620)
        layout=QVBoxLayout(self)
        self.tabs=QTabWidget(self)
        self.pages={}
        for key in ('chzzk','cime'):
            self.pages[key]=PlatformCookiePanel(key,self,cookie_path,self.accept)
            self.tabs.addTab(self.pages[key],LABELS[key])
        self.youtube=YoutubeCookiePanel(self,youtube_path,self.accept)
        self.pages['youtube']=self.youtube;self.tabs.addTab(self.youtube,'유튜브')
        layout.addWidget(self.tabs)
        self.select_platform(platform)

    def select_platform(self,platform):
        self.tabs.setCurrentWidget(self.pages.get(platform,self.pages['chzzk']))
