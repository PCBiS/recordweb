"""Linux 트레이와 전용 창 실행."""
import os
from pathlib import Path
import subprocess
import sys
import threading
import webbrowser


def open_window(root):
    try:
        with (Path(root) / '.runtime/linux-window.log').open('a', encoding='utf-8') as log:
            process = subprocess.Popen(
                [os.environ['RWEB_LINUX_GUI'], str(Path(root) / 'module/recordWEB_launcher.py'), '--open-ui'],
                cwd=root, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
            )
    except (OSError, KeyError) as error:
        print(f'[recordWEB] 전용 창을 열 수 없습니다. {error}', flush=True)
        return
    def wait_for_window():
        if process.wait():
            print('[recordWEB] 전용 창이 종료됐습니다. 콘솔의 브라우저 접속 주소를 사용할 수 있습니다.',
                  file=sys.stderr, flush=True)

    threading.Thread(target=wait_for_window, daemon=True).start()


def run_tray(app, control, root):
    # GTK는 GUI 전용 가상환경에서 실행합니다.
    try:
        process = subprocess.Popen(
            [os.environ['RWEB_LINUX_GUI'], '-m', 'module.linux_desktop',
             str(app.state.actual_port), app.state.run_mode, str(os.getpid())],
            cwd=root, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, text=True,
        )
        app.state.linux_tray_process = process
        if app.state.server.should_exit:
            process.terminate()
        with process.stdout:
            for line in process.stdout:
                action = line.strip()
                if action in ('start', 'stop', 'quit'):
                    control.submit(action)
        process.wait()
    except (OSError, KeyError) as error:
        print(f'[recordWEB] 트레이를 시작할 수 없어 Headless로 실행합니다. {error}', flush=True)
    finally:
        if not app.state.server.should_exit:
            app.state.run_mode = 'headless'
            print('[recordWEB] 트레이가 종료되어 서버를 Headless로 유지합니다.', flush=True)


def tray_main(port, mode, parent):
    def report(message):
        print(f'[recordWEB] {message}', file=sys.stderr, flush=True)

    root = Path(__file__).resolve().parents[1]
    try:
        import gi
        from gi.repository import Gio, GLib

        try:
            bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
            watcher = bus.call_sync(
                'org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus',
                'NameHasOwner', GLib.Variant('(s)', ('org.kde.StatusNotifierWatcher',)),
                None, Gio.DBusCallFlags.NONE, 1000, None,
            ).unpack()[0]
        except GLib.Error:
            watcher = False
        if watcher:
            os.environ['PYSTRAY_BACKEND'] = 'appindicator'
        if not watcher:
            if os.environ.get('XDG_SESSION_TYPE') == 'wayland' or not os.environ.get('DISPLAY'):
                raise RuntimeError('시스템 트레이를 제공하는 데스크톱 확장이 없습니다.')
            os.environ['PYSTRAY_BACKEND'] = 'gtk'

        from PIL import Image
        import pystray

        def send(action):
            print(action, flush=True)

        menu = pystray.Menu(
            pystray.MenuItem('recordWEB 열기', lambda: open_window(root), default=True),
            pystray.MenuItem('브라우저에서 열기', lambda: webbrowser.open(f'http://127.0.0.1:{port}/')),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('모두 녹화 시작', lambda: send('start')),
            pystray.MenuItem('모두 녹화 중지', lambda: send('stop')),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('recordWEB 완전 종료', lambda: send('quit')),
        )
        with Image.open(root / 'templates/static/img/recordweb.ico') as image:
            icon = pystray.Icon('recordWEB', image.copy(), 'recordWEB', menu)

        def open_at_start():
            if mode == 'normal':
                open_window(root)
            return False

        if watcher:
            GLib.idle_add(open_at_start)
        else:
            # XEmbed 패널이 아이콘을 받아야 트레이 메뉴를 사용할 수 있습니다.
            def check_embedding():
                if not icon._status_icon.is_embedded():
                    report(f'패널에서 트레이를 찾지 못해 Headless로 전환합니다. http://127.0.0.1:{port}/')
                    icon.stop()
                else:
                    open_at_start()
                return False

            GLib.timeout_add_seconds(4, check_embedding)

        def keep_tray():
            if os.getppid() != parent:
                icon.stop()
                return False
            return True

        GLib.timeout_add_seconds(1, keep_tray)
        icon.run()
    except Exception as error:
        report(f'Linux 트레이를 시작할 수 없습니다. 브라우저 주소: http://127.0.0.1:{port}/ ({error})')


if __name__ == '__main__':
    tray_main(int(sys.argv[1]), sys.argv[2], int(sys.argv[3]))
