"""SABR 전용 버전 확인과 공용 설치 트랜잭션을 이용한 업데이트·복구."""
import os
from pathlib import Path
import re
import threading
import time
import psutil
import requests
import hashlib
from contextlib import contextmanager
from module import data_manager as dm
from module.tool_install import TOOLS, install_tool, release_info, run_executable, InstallTransactionError
from module.versioning import compare_versions

SOURCE = "https://github.com/bashonly/yt-dlp/releases/tag/sabr"
API = "https://api.github.com/repos/bashonly/yt-dlp/releases/tags/sabr"
CACHE = os.path.join(dm.base_directory, '.runtime', 'sabr_update_cache.json')
_lock = threading.Lock()
SPEC = next(spec for spec in TOOLS if spec.name == "yt-dlp")


def installation():
    expected = Path(dm.base_directory, "dependent", "yt-dlp", "yt-dlp.exe")
    try:
        path = dm.getYtDlp()
    except FileNotFoundError:
        path = str(expected)
    try:
        exists = Path(path).is_file()
        folder = Path(path).with_name("_internal").is_dir()
    except OSError:
        return {"path": str(path), "current_version": "", "status": "손상", "layout": "folder", "source": SOURCE}
    check = run_executable(path, ("--version",)) if exists else {"ok": False}
    works = check["ok"] and run_executable(path, ("--list-extractors",))["ok"]
    return {"path": str(path), "current_version": check.get("version", "").strip(),
            "status": "미설치" if not exists else "확인 전" if works else "손상",
            "layout": "folder" if folder else "single",
            "source": SOURCE}


def _status(current, latest):
    if current["status"] in ("미설치", "손상"):
        return current["status"]
    comparison = compare_versions(current["current_version"], latest)
    if comparison is None:
        return "버전 확인 실패"
    return "최신" if comparison == 0 else "업데이트 가능" if comparison < 0 else "개발판 또는 선행 버전"


def check_update(force=False):
    current = installation()
    cached = dm.readJsonSafe(CACHE, {})
    if not isinstance(cached, dict) or not isinstance(cached.get("checked_at", 0), (int, float)):
        cached = {}
    try:
        if force or cached.get("checked_at", 0) + 3600 <= time.time() or "release" not in cached:
            release = release_info(SPEC)
            match = re.search(r"\d{4}\.\d{2}\.\d{2}(?:\.\d+)?", release.get("name", ""))
            latest = match.group() if match else release.get("name", "")
            cached = {"checked_at": time.time(), "latest_version": latest, "release": release}
            try:
                Path(CACHE).parent.mkdir(parents=True, exist_ok=True)
                dm.writeJsonSafe(CACHE, cached)
            except OSError:
                pass  # A cache write failure must not discard a fresh response.
        release = cached['release']
        if release.get('tag_name') != 'sabr':
            raise ValueError('SABR 채널이 아닌 응답입니다.')
        asset = next((a for a in release.get('assets', []) if a.get('name') == SPEC.asset), None)
        if asset is None:
            raise ValueError('SABR Windows 패키지가 없습니다.')
        status = _status(current, cached['latest_version'])
        manifest = dm.readJsonSafe(str(Path(dm.base_directory)/'dependent/yt-dlp/.recordweb-sabr.json'), {})
        if not isinstance(manifest, dict):
            manifest = {}
        if status == '최신' and not manifest:
            status = '설치 검증 필요'
        if status == '최신' and manifest:
            identity = (asset.get('id'), asset.get('updated_at'))
            previous = (manifest.get('asset_id'), manifest.get('asset_updated_at'))
            if identity != previous:
                status = '업데이트 가능'
            elif manifest.get('binary_sha256'):
                if hashlib.sha256(Path(current['path']).read_bytes()).hexdigest() != manifest['binary_sha256']:
                    status = '손상'
        return {**current, 'latest_version': cached['latest_version'], 'checked_at': cached['checked_at'],
                'release': release, 'asset_updated_at': asset.get('updated_at'), 'status': status}
    except (requests.RequestException, ValueError, OSError, KeyError) as exc:
        return {**current, "status": current["status"] if current["status"] in ("미설치", "손상") else "확인 실패",
                "error": type(exc).__name__}


def is_busy():
    target = Path(dm.base_directory, 'dependent', 'yt-dlp').resolve()
    for process in psutil.process_iter(["name"]):
        if (process.info.get('name') or '').lower() not in ('yt-dlp.exe', 'deno.exe'):
            continue
        try:
            if Path(process.exe()).resolve().is_relative_to(target):
                return True
        except psutil.NoSuchProcess:
            continue
        except (psutil.AccessDenied, OSError):
            return True
    return False


def _ensure_idle():
    if is_busy():
        raise RuntimeError('이 폴더의 yt-dlp 또는 Deno가 사용 중입니다. 분석·다운로드를 마친 뒤 업데이트하세요.')


@contextmanager
def installation_lock():
    path = Path(dm.base_directory)/'.runtime/install.lock'
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        handle = path.open('a+b')
        if handle.tell() == 0:
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as exc:
        if 'handle' in locals(): handle.close()
        raise RuntimeError('공유 실행 환경의 다른 설치·업데이트가 진행 중이거나 설치 잠금을 열 수 없습니다.') from exc
    try:
        yield
    finally:
        handle.close()


def update_now(repair=False):
    if not _lock.acquire(blocking=False):
        raise RuntimeError("다른 업데이트/복구가 진행 중입니다.")
    try:
        with installation_lock():
            _ensure_idle()
            info = check_update(force=True)
            if 'release' not in info or info['status'] in ('확인 실패', '버전 확인 실패'):
                raise RuntimeError('SABR 릴리스 확인 실패. 기존 설치는 유지합니다.')
            if info['status'] == '최신' and not repair:
                return info
            if info['status'] == '개발판 또는 선행 버전' and not repair:
                raise RuntimeError('현재 설치가 배포본보다 새 버전입니다. 자동으로 다운그레이드하지 않습니다.')
            root = Path(dm.base_directory)
            target = (root/'dependent/yt-dlp/yt-dlp.exe').resolve()
            if Path(info['path']).resolve() != target:
                raise RuntimeError('외부 설치는 출처 링크에서 직접 업데이트하세요.')
            recovering = repair or info['status'] in ('미설치', '손상')
            try:
                result = install_tool(root, SPEC, release=info['release'], before_swap=_ensure_idle)
            except Exception as exc:
                return {**installation(), 'status':'업데이트 실패·복원 완료' if isinstance(exc, InstallTransactionError) and exc.restored else '업데이트 실패·기존 상태 유지', 'error':str(exc)}
            return {**installation(), 'status':'복구 완료' if recovering else '업데이트 완료', 'backup':result['backup']}
    finally:
        _lock.release()
