"""Netscape cookie validation for the standalone downloader.

Public results contain counts and states only, never cookie names or values.
"""
from pathlib import Path
import os
import tempfile
import time
import re

MAX_BYTES = 2 * 1024 * 1024


def inspect_text(text, now=None):
    now = time.time() if now is None else now
    text = str(text).lstrip('\ufeff')
    lines = text.splitlines()
    result = {'format_valid': False, 'usable': False, 'status': 'invalid',
              'youtube_count': 0, 'expired_count': 0, 'session_count': 0,
              'cookie_count': 0, 'usable_count': 0, 'login_cookie_count': 0,
              'verdict': '사용 불가', 'reason': '', 'last_saved_at': None}
    if not text.strip() or not any(line.strip() and not line.startswith('#') or line.startswith('#HttpOnly_') for line in lines):
        return {**result, 'status': 'missing', 'reason': '쿠키 내용이 없습니다.', 'message': '미등록 · 공개 영상은 쿠키 없이 이용할 수 있습니다.'}
    if len(text.encode('utf-8')) > MAX_BYTES or not lines or lines[0] not in ('# Netscape HTTP Cookie File', '# HTTP Cookie File'):
        return {**result, 'reason': 'Netscape cookies.txt 형식이 아닙니다.', 'message': 'Netscape cookies.txt 형식이 아닙니다. Get cookies.txt LOCALLY에서 Export Format을 Netscape로 선택해 주세요.'}
    for line in lines[1:]:
        if not line.strip() or (line.startswith('#') and not line.startswith('#HttpOnly_')):
            continue
        fields = line.removeprefix('#HttpOnly_').split('\t')
        if len(fields) != 7:
            return {**result, 'reason': '쿠키 행의 필드 구조가 올바르지 않습니다.', 'message': '각 쿠키 행에는 탭으로 구분된 7개 필드가 필요합니다. Netscape 형식으로 다시 내보내세요.'}
        domain, include, path, secure, expiry, name, value = fields
        if (include not in ('TRUE', 'FALSE') or secure not in ('TRUE', 'FALSE')
                or not path.startswith('/') or not domain or any(c.isspace() for c in domain) or not name
                or (include == 'TRUE') != domain.startswith('.')
                or any(ord(c) < 32 or ord(c) == 127 for c in name + value)):
            return {**result, 'reason': '쿠키 행의 도메인·경로·필드 값이 올바르지 않습니다.', 'message': '쿠키 행의 도메인·경로·필드 값을 확인하세요. Netscape 형식으로 다시 내보내세요.'}
        try:
            expiry = int(expiry or '0')
            if expiry < 0:
                raise ValueError()
        except ValueError:
            return {**result, 'reason': '쿠키 만료 시각이 올바르지 않습니다.', 'message': '쿠키 만료 시각이 올바르지 않습니다. Netscape 형식으로 다시 내보내세요.'}
        result['cookie_count'] += 1
        domain = domain.lstrip('.').lower()
        if domain == 'youtube.com' or domain.endswith('.youtube.com'):
            result['youtube_count'] += 1
            result['expired_count'] += bool(expiry and expiry <= now)
            result['session_count'] += expiry == 0
            active = not expiry or expiry > now
            result['usable_count'] += bool(active and value)
            # Advisory only: cookie families can change. Missing a particular
            # name never rejects a structurally valid cookie export.
            login_hint = name.upper() == 'LOGIN_INFO' or bool(re.search(r'(?:^|[-_])(?:[13]P)?(?:SID|HSID|SSID|APISID|SAPISID)$', name.upper()))
            result['login_cookie_count'] += bool(active and value and login_hint)
    result['format_valid'] = True
    if not result['youtube_count']:
        return {**result, 'reason': 'YouTube 도메인 쿠키가 없습니다.', 'message': 'YouTube 도메인 쿠키가 없습니다. 로그인한 youtube.com 탭에서 다시 내보내세요.'}
    result['usable'] = result['usable_count'] > 0
    result['status'] = 'ready' if result['usable'] else 'expired'
    result['verdict'] = '사용 가능' if result['usable'] else '사용 불가'
    if result['usable'] and not result['login_cookie_count']:
        result['status'] = 'review'
        result['verdict'] = '확인 필요'
        result['reason'] = 'YouTube 로그인 관련 쿠키를 확인하지 못했습니다. 공개 영상은 이용할 수 있으며, 계정 권한이 필요한 영상은 로그인 후 다시 내보내세요.'
    elif not result['usable']:
        result['reason'] = ('YouTube 쿠키가 모두 만료됐습니다.' if result['youtube_count'] == result['expired_count'] else '사용할 수 있는 YouTube 쿠키 값이 없습니다.')+' 새 시크릿/InPrivate 창에서 로그인한 뒤 다시 내보내세요.'
    result['message'] = ('형식 정상 · 만료되지 않은 유튜브 쿠키가 있습니다. 실제 로그인·영상 접근 권한은 별도 확인이 필요합니다.'
                         if result['usable'] else result['reason'])
    return result


def cookie_status(path):
    try:
        path = Path(path)
        stat = path.stat()
        if stat.st_size > MAX_BYTES:
            return {**inspect_text('invalid'), 'reason': '파일 크기가 2MiB를 초과합니다.', 'message': '2MiB 이하의 쿠키 파일을 선택하세요.'}
        return {**inspect_text(path.read_text(encoding='utf-8-sig')), 'last_saved_at': stat.st_mtime}
    except FileNotFoundError:
        return inspect_text('')
    except (OSError, UnicodeError):
        return {**inspect_text('invalid'), 'reason': '쿠키 파일을 읽지 못했습니다.', 'message': '쿠키 파일을 읽지 못했습니다. UTF-8 텍스트인지 확인하세요.'}


def save_cookie_text(path, text):
    text = str(text).lstrip('\ufeff').replace('\r\n', '\n').replace('\r', '\n')
    result = inspect_text(text)
    if not result['format_valid'] or not result['youtube_count']:
        raise ValueError(result['reason'] if result['status'] == 'missing' else result['message'])
    if not result['usable']:
        raise ValueError(result['reason'])
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', newline='', dir=path.parent, prefix='.youtube-cookies-', delete=False) as output:
            temporary = Path(output.name)
            output.write(text.rstrip('\n') + '\n')
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return cookie_status(path)
