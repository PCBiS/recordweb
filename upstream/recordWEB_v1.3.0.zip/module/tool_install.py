"""Windows 외부 도구의 검사와 검증 후 교체 트랜잭션."""
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tempfile
import time
import zipfile
import requests
from module.data_manager import BUNDLED_TOOL_LAYOUT, BUNDLED_TOOL_PATHS


def _cleanup_path(path):
    """Best-effort cleanup: a cleanup failure must not invalidate a good install."""
    try:
        path = Path(path)
        if path.is_dir():
            shutil.rmtree(path)
        elif path.exists():
            path.unlink()
        return None
    except OSError as exc:
        return f"{type(exc).__name__}: {exc}"


def _keep_latest_backup(target, latest):
    """Keep at most the newest known-good backup for one managed tool."""
    target = Path(target)
    backups = sorted(
        target.parent.glob(target.name + ".backup-*"),
        key=lambda path: path.stat().st_mtime_ns,
        reverse=True,
    )
    keep = Path(latest) if latest else (backups[0] if backups else None)
    warnings = []
    for path in backups:
        if keep is not None and path == keep:
            continue
        error = _cleanup_path(path)
        if error:
            warnings.append(f"{path}: {error}")
    return warnings


@dataclass(frozen=True)
class Tool:
    name: str
    repository: str
    tag: str
    asset: str
    directory: str
    executable: str
    args: tuple = ("--version",)
    extras: tuple = ()
    required_version: str = ''


TOOLS = (
    Tool("ffmpeg", "BtbN/FFmpeg-Builds", "autobuild-2026-11-10-12-39", "ffmpeg-n8.1.3-34-ga35157abb9-win64-gpl-8.1.zip",
         *BUNDLED_TOOL_LAYOUT["ffmpeg"], ("-version",), ((BUNDLED_TOOL_LAYOUT["ffprobe"][1], ("-version",)),),
         required_version='8.1.3-34-ga35157abb9'),
    Tool("streamlink", "streamlink/windows-builds", "8.6.3-1", "streamlink-8.6.3-1-py315-x86_64.zip",
         *BUNDLED_TOOL_LAYOUT["streamlink"], extras=((BUNDLED_TOOL_LAYOUT["streamlink"][1], ("--plugins",)),)),
    Tool("aria2c", "aria2/aria2", "release-1.37.0", "aria2-1.37.0-win-64bit-build1.zip",
         *BUNDLED_TOOL_LAYOUT["aria2c"]),
    Tool("yt-dlp", "bashonly/yt-dlp", "sabr", "yt-dlp_win.zip", *BUNDLED_TOOL_LAYOUT["yt-dlp"],
         extras=((BUNDLED_TOOL_LAYOUT["yt-dlp"][1], ("--list-extractors",)),)),
    Tool("deno", "denoland/deno", "latest", "deno-x86_64-pc-windows-msvc.zip", *BUNDLED_TOOL_LAYOUT["deno"]),
)


def run_executable(path, args, timeout=30):
    try:
        result = subprocess.run([str(path), *args], capture_output=True, text=True, errors="replace",
                                timeout=timeout, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return {"ok": result.returncode == 0, "version": (result.stdout or result.stderr)[:400].strip(), "code": result.returncode}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"ok": False, "error": type(exc).__name__}


def check_tool(root, spec):
    base = Path(root) / "dependent" / spec.directory
    result = run_executable(base / spec.executable, spec.args)
    if result['ok'] and spec.name in ('ffmpeg','streamlink'):
        expected = spec.required_version or spec.tag.split('-')[0]
        if not re.search(r'(?<![\d.])'+re.escape(expected)+r'(?![\d.])', result.get('version','')):
            return {**result, 'ok':False, 'error':'요구 버전 '+expected+'와 설치 버전이 다릅니다.'}
    if result["ok"]:
        for name, args in spec.extras:
            extra = run_executable(base / name, args)
            if not extra["ok"]:
                result = extra
                break
    return result


def check_tools(root):
    results = {spec.name: check_tool(root, spec) for spec in TOOLS}
    results["ffprobe"] = run_executable(Path(root) / BUNDLED_TOOL_PATHS["ffprobe"], ("-version",))
    return results


def release_info(spec):
    endpoint = "latest" if spec.tag == "latest" else "tags/" + spec.tag
    response = requests.get(f"https://api.github.com/repos/{spec.repository}/releases/{endpoint}", timeout=(10, 30))
    response.raise_for_status()
    release = response.json()
    if spec.name == "yt-dlp" and release.get("tag_name") != "sabr":
        raise ValueError("SABR 배포 채널이 아닙니다.")
    return release


def asset_digest(release, asset):
    digest = asset.get("digest") or ""
    if digest.startswith("sha256:"):
        return digest[7:].lower()
    # 오래된 GitHub 자산의 digest가 비어 있으면 배포자의 체크섬 파일을 사용합니다.
    names = {"SHA2-256SUMS", "SHA256SUMS", "sha256sums.txt", "sha256sum.txt", asset["name"] + ".sha256", asset["name"] + ".sha256sum"}
    for checksum in release.get("assets", []):
        if checksum["name"] not in names:
            continue
        response = requests.get(checksum["browser_download_url"], timeout=(10, 30))
        response.raise_for_status()
        for line in response.text.splitlines():
            fields = line.split()
            if fields and re.fullmatch(r"[a-fA-F0-9]{64}", fields[0]):
                if (len(fields) == 1 and checksum["name"].startswith(asset["name"])) or (len(fields) > 1 and fields[-1].lstrip("*") == asset["name"]):
                    return fields[0].lower()
    # 배포자가 올린 과거 고정 자산에 한정한 검증값입니다.
    pinned = {
        ("ffmpeg-8.0.1-full_build.zip", "8.0.1"): "467cde100a47ed4b03a897988aeb4a296890c1e2b2d2864204657d002bc5fb90",
        # 2026-11-08 공식 고정 릴리스 HTTPS 원본을 받아 기록한 검증 기준입니다.
        ("aria2-1.37.0-win-64bit-build1.zip", "release-1.37.0"): "67d015301eef0b612191212d564c5bb0a14b5b9c4796b76454276a4d28d9b288",
    }
    digest = pinned.get((asset["name"], release.get("tag_name")))
    if not digest:
        raise ValueError("배포자 SHA256을 확인하지 못했습니다. 기존 설치는 유지됩니다.")
    return digest


def download_verified(url, path, digest):
    hasher = hashlib.sha256()
    with requests.get(url, stream=True, timeout=(10, 90)) as response:
        response.raise_for_status()
        with Path(path).open("wb") as output:
            for chunk in response.iter_content(1024 * 1024):
                output.write(chunk)
                hasher.update(chunk)
    if hasher.hexdigest() != digest:
        raise ValueError("SHA256 불일치: 기존 설치는 변경하지 않았습니다.")


def extract_checked(package, destination):
    root = Path(destination).resolve()
    with zipfile.ZipFile(package) as archive:
        for member in archive.infolist():
            # Windows 경로·드라이브·심볼릭 링크와 경로 이탈을 모두 거절합니다.
            name = member.filename.replace("\\", "/")
            if ":" in name or PurePosixPath(name).is_absolute() or not (root / name).resolve().is_relative_to(root):
                raise ValueError("압축 파일에 잘못된 경로가 있습니다.")
            if (member.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("압축 파일의 링크 항목은 허용하지 않습니다.")
        archive.extractall(root)


class InstallTransactionError(RuntimeError):
    def __init__(self, message, restored=False):
        super().__init__(message)
        self.restored = restored


def _replace_with_retry(source, target):
    # Windows AV/executable image handles may outlive a finished version check.
    # Retry only access/sharing violations, with a bounded delay.
    for attempt in range(6):
        try:
            os.replace(source, target)
            return
        except OSError as exc:
            if getattr(exc, "winerror", None) not in (5, 32, 33) or attempt == 5:
                raise
            time.sleep(0.2 * (2 ** attempt))


def swap_install(staged, target, validate, before_replace=None):
    """임시 실행 검사 성공 전에는 기존 설치에 손대지 않습니다."""
    staged, target = Path(staged), Path(target)
    validate(staged)
    if before_replace:
        before_replace()
    backup = target.with_name(target.name + ".backup-" + str(time.time_ns()))
    existed = target.exists()
    if existed:
        _replace_with_retry(target, backup)
    try:
        _replace_with_retry(staged, target)
        validate(target)
    except BaseException as exc:
        try:
            if target.exists():
                _replace_with_retry(target, staged.with_name(staged.name + ".failed-" + str(time.time_ns())))
            if existed:
                _replace_with_retry(backup, target)
        except OSError as rollback_error:
            raise RuntimeError(f"자동 복원 실패. 백업 위치: {backup}") from rollback_error
        message = "업데이트 실패·복원 완료" if existed else "설치 실패·기존 상태 유지"
        raise InstallTransactionError(f"{message}: {type(exc).__name__}: {exc}", restored=existed) from exc
    return str(backup) if existed else None


def install_tool(root, spec, *, release=None, before_swap=None):
    root = Path(root).resolve()
    if before_swap is None and spec.name in ('ffmpeg','streamlink'):
        def before_swap():
            from module.tool_usage import remote_busy
            if remote_busy(root):
                raise RuntimeError('녹화·감시·후처리가 실행 중입니다. 작업을 마친 뒤 도구를 업데이트하세요.')
    parent = root / "dependent"
    parent.mkdir(exist_ok=True)
    release = release or release_info(spec)
    asset = next((a for a in release.get("assets", []) if a["name"] == spec.asset), None)
    if not asset:
        raise ValueError("현재 배포에 필요한 패키지가 없습니다: " + spec.asset)
    digest = asset_digest(release, asset)
    workspace = Path(tempfile.mkdtemp(prefix=".install-", dir=parent))
    cleanup_warning = None
    try:
        package = workspace / spec.asset
        download_verified(asset["browser_download_url"], package, digest)
        extracted = workspace / "extracted"
        extracted.mkdir()
        if spec.asset.endswith(".zip"):
            extract_checked(package, extracted)
        else:
            shutil.copy2(package, extracted / "yt-dlp.exe")
        matches = list(extracted.rglob(Path(spec.executable).name))
        if len(matches) != 1:
            raise ValueError("패키지 실행 파일을 식별하지 못했습니다.")
        executable = matches[0]
        if spec.name == "deno":
            staged, target = executable, parent / spec.directory / "deno.exe"
            target.parent.mkdir(exist_ok=True)
            def validate(path):
                if not run_executable(path, spec.args)["ok"]:
                    raise ValueError("Deno 실행 검사 실패")
        else:
            parts = Path(spec.executable).parts
            staged = executable.parents[len(parts) - 1]
            target = parent / spec.directory
            def validate(path):
                if spec.name == "yt-dlp" and spec.asset.endswith(".zip") and not (path / "_internal").is_dir():
                    raise ValueError("SABR 폴더형 패키지의 _internal이 없습니다.")
                for name, args in ((spec.executable, spec.args), *spec.extras):
                    if not run_executable(path / name, args)["ok"]:
                        raise ValueError("임시/최종 실행 검사 실패: " + name)
            # 같은 관리 폴더에 둔 보조 실행 파일은 별도 도구로 보존합니다.
            if spec.name == "yt-dlp" and target.exists():
                for name in ("deno.exe", "aria2c.exe"):
                    if (target / name).is_file():
                        shutil.copy2(target / name, staged / name)
        if spec.name == 'yt-dlp':
            manifest = {'repository': spec.repository, 'tag': spec.tag, 'asset': spec.asset,
                        'asset_id': asset.get('id'), 'asset_updated_at': asset.get('updated_at'),
                        'asset_sha256': digest, 'binary_sha256': hashlib.sha256(executable.read_bytes()).hexdigest()}
            (staged/'.recordweb-sabr.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
        backup = swap_install(staged, target, validate, before_replace=before_swap)
        warnings = _keep_latest_backup(target, backup)
        print(f"[설치] {spec.name} 실행 검사 완료. 백업: {backup or '최초 설치'}")
        return {"ok": True, "backup": backup, "path": str(target),
                "version": check_tool(root, spec).get("version", ""),
                "cleanup_warnings": warnings}
    finally:
        cleanup_warning = _cleanup_path(workspace)
        if cleanup_warning:
            print(f"[WARN] 설치 임시 폴더 정리 실패(설치 결과는 유지): {workspace}: {cleanup_warning}")


def repair_tools(root, names=None):
    results = {}
    for spec in TOOLS:
        if names and spec.name not in names:
            continue
        if check_tool(root, spec)["ok"]:
            results[spec.name] = {"ok": True, "status": "기존 정상 설치 유지"}
            continue
        try:
            results[spec.name] = install_tool(root, spec)
        except Exception as exc:
            results[spec.name] = {"ok": False, "error": str(exc), "guide": "recordWEB.bat --repair로 복구하세요. 기존 JSON/쿠키는 변경하지 않았습니다."}
    return results
