"""recordWEB가 소유한 Windows 시작프로그램 바로가기만 관리합니다."""
from pathlib import Path
import os
import subprocess


SHORTCUT_NAME = "recordWEB.lnk"


def shortcut_path():
    startup = Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs/Startup"
    return startup / SHORTCUT_NAME


def set_startup_enabled(root, enabled):
    if os.name != "nt":
        raise RuntimeError("Windows에서만 시작프로그램을 관리할 수 있습니다.")
    root = Path(root).resolve()
    launcher = root / "recordWEB.bat"
    link = shortcut_path()
    if enabled:
        if not launcher.is_file():
            raise FileNotFoundError("recordWEB.bat을 찾을 수 없습니다.")
        link.parent.mkdir(parents=True, exist_ok=True)
        link_ps = str(link).replace("'", "''")
        launcher_ps = str(launcher).replace("'", "''")
        root_ps = str(root).replace("'", "''")
        icon = root / 'templates/static/img/recordweb.ico'
        icon_ps = str(icon).replace("'", "''")
        icon_command = f"$s.IconLocation='{icon_ps},0';" if icon.is_file() else ""
        script = (
            "$w=New-Object -ComObject WScript.Shell;"
            f"$s=$w.CreateShortcut('{link_ps}');"
            f"$s.TargetPath='{launcher_ps}';"
            "$s.Arguments='--startup';"
            f"$s.WorkingDirectory='{root_ps}';"
            f"{icon_command}"
            "$s.WindowStyle=7;$s.Description='recordWEB background startup';$s.Save()"
        )
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True, text=True, errors="replace", timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode != 0 or not link.is_file():
            raise RuntimeError("시작프로그램 바로가기 생성 실패: " + (result.stderr or "결과 파일 없음")[:300])
    elif link.exists():
        link.unlink()
    return {"enabled": link.is_file(), "path": str(link)}
