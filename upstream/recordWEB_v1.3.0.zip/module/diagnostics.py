"""인증된 진단 API에서 사용하는 민감정보 제거와 환경 점검."""
import asyncio
import os
import platform
import re
import subprocess
import sys
import shutil
import tempfile
import time
import math
from datetime import datetime, timezone, timedelta
from module import cookie_store, data_manager as dm


def retry_schedule(deadline):
    if not deadline:
        return {"retry_after_seconds": None, "next_retry_at": None, "retry_summary": "재시도 예정 없음"}
    remaining = max(0, math.ceil(deadline - time.monotonic()))
    when = datetime.fromtimestamp(time.time() + remaining, timezone(timedelta(hours=9))).isoformat()
    return {"retry_after_seconds": remaining, "next_retry_at": when,
            "retry_summary": f"재시도까지 약 {remaining}초"}


def redact(value):
    text = str(value)
    home = os.path.expanduser("~")
    if home:
        text = text.replace(home, "<사용자폴더>")
    # Google 미디어 주소는 쿼리뿐 아니라 경로에도 서명·IP가 들어갑니다.
    text = re.sub(r"https?://[^\s\"'<>/]*googlevideo\.com[^\s\"'<>]*", "https://googlevideo.com/<숨김>", text, flags=re.IGNORECASE)
    text = re.sub(r"(?i)C:[/\\]Users[/\\][^/\\\s]+", "<사용자폴더>", text)
    text = re.sub(r"(?i)https?://[^\s\"'<>]+/(?:api/webhooks/|bot)[^\s\"'<>]+", "<숨김 URL>", text)
    text = re.sub(r"(?i)(https?://[^\s\"'<>?]+/)(?:hdntl|hdnts)=[^\s\"'<>?]+", r"\1<숨김>", text)
    text = re.sub(r"(?i)((?:password|token|NID_AUT|NID_SES|authorization|session-id|cookie)[\s\"':=]+)[^\s,;\"']+", r"\1<숨김>", text)
    text = re.sub(r"(https?://[^\s?]+)\?[^\s]+", r"\1?<숨김>", text)
    return text


def run_check(path, args):
    if not path:
        return {"status": "없음", "guide": "의존성 설치 또는 복구를 실행하세요."}
    try:
        p = subprocess.run([path, *args], capture_output=True, text=True, errors="replace", timeout=8,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return {"path": redact(path), "status": "정상" if p.returncode == 0 else "실행 실패",
                "version": redact((p.stdout or p.stderr)[:600])}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"path": redact(path), "status": "실행 실패", "error": type(exc).__name__}


async def environment_check(force=False):
    from module.inspection_cache import cache, tool_signature
    return await cache.get('environment', tool_signature(dm.base_directory), _inspect_environment, force)


async def _inspect_environment():
    def resolve(getter):
        try:
            return getter()
        except FileNotFoundError:
            return None
    checks = [("ffmpeg", resolve(dm.getFFmpeg), ["-version"]), ("ffprobe", resolve(dm.getFFprobe), ["-version"]),
              ("streamlink", resolve(dm.getStreamlink), ["--version"])]
    if sys.platform != 'linux':
        checks.append(("aria2c", resolve(dm.getAria2c), ["--version"]))
    results = await asyncio.gather(*(asyncio.to_thread(run_check, path, args) for _, path, args in checks))
    dependencies = {c[0]: r for c, r in zip(checks, results)}
    details = await asyncio.to_thread(storage_check)
    if sys.platform == 'linux':
        isolated = sys.prefix != sys.base_prefix
        return {"checked_at": datetime.now(timezone.utc).isoformat(),
                "python": sys.version.split()[0], "venv": isolated, "platform": platform.platform(),
                "recordweb_python": {"path": redact(sys.executable), "status": "정상",
                                     "version": sys.version.split()[0], "required_version": "3.11~3.14"},
                "recordweb_venv": {"path": redact(sys.prefix), "version": sys.version.split()[0],
                                   "status": "정상" if isolated else "확인 필요"},
                "dependencies": dependencies, "repair_command": "./recordWEB.sh --check", **details}
    owned_path = os.path.join(dm.base_directory, "runtime", "python", "python.exe")
    owned = await asyncio.to_thread(run_check, owned_path, ["-I", "--version"])
    owned["required_version"] = "3.14.10"
    owned["path"] = redact(owned_path)
    venv_base_owned = os.path.normcase(os.path.realpath(sys.base_prefix)) == os.path.normcase(os.path.realpath(os.path.dirname(owned_path)))
    return {"checked_at": datetime.now(timezone.utc).isoformat(),
            "python": sys.version.split()[0], "venv": sys.prefix != sys.base_prefix,
            "recordweb_python": owned,
            "recordweb_venv": {"path": redact(sys.prefix), "version": sys.version.split()[0], "owned_base": venv_base_owned,
                               "status": "정상" if venv_base_owned and sys.version_info[:3] == (3, 14, 10) and sys.prefix != sys.base_prefix else "확인 필요"},
            "windows": platform.platform(), "dependencies": dependencies,
            "install_cleanup_policy": "설치 임시 폴더는 성공·실패 후 자동 정리, 도구별 최신 정상 백업 최대 1개 보존",
            "repair_command": "recordWEB.bat --repair", **details}


def storage_check():
    result = {"cookies": {}, "output_directories": []}
    try:
        valid = cookie_store.stored_json_is_object(dm.COOKIE_PATH)
        result["cookies"]["cookie.json"] = "형식 확인됨" if valid else "형식 확인 필요"
    except (OSError, ValueError):
        result["cookies"]["cookie.json"] = "파일 없음 또는 파싱 실패"
    for path in {c.get("output_dir", "") for c in dm.loadChannels()}:
        try:
            dm.validateMediaDirectory(path)
        except ValueError:
            result["output_directories"].append({"path": redact(path), "status": "Linux에서 사용할 수 없는 Windows 경로"})
            continue
        full = os.path.abspath(os.path.join(dm.base_directory, path))
        try:
            with tempfile.TemporaryFile(dir=full) as output:
                output.write(b"test")
                output.flush()
            status = "쓰기 가능"
        except OSError:
            status = "폴더가 없거나 쓰기 실패"
        result["output_directories"].append({"path": redact(full), "status": status})
    return result


def channel_diagnostics(state):
    rm = dm.RecorderManager()
    rows = []
    for channel in state.channels:
        cid = channel.get("id", "")
        active = []
        if rm.get_status_recording(cid):
            active.append("녹화")
        elif rm.get_status_reserved(cid):
            active.append("감시")
        if any(job.get("channel_id") == cid for job in rm.postprocess_active_jobs.values()):
            active.append("후처리")
        rows.append({"platform": channel.get("platform"), "id": cid[:3] + "***" + cid[-2:],
                     "fsm": state.fsm.getState(cid), "active_tasks": active,
                     "record_enabled": channel.get("record_enabled"),
                     "retry_attempts": state.fsm.restartAttempts.get(cid, 0),
                     **retry_schedule(state.fsm.backoffUntil.get(cid)),
                     "diagnostics": {**rm.session_diagnostics.get(cid, {}), **state.fsm.diagnostics.get(cid, {})}})
    from module.runtime_log import loadRecentErrors
    def clean(value):
        if isinstance(value, dict):
            return {k: "<숨김>" if any(secret in k.lower() for secret in ("password", "cookie", "token", "authorization", "secret", "webhook", "playback_url")) else clean(v) for k, v in value.items()}
        if isinstance(value, list):
            return [clean(v) for v in value]
        if isinstance(value, str):
            value = redact(value)
            for channel in state.channels:
                cid = channel.get("id", "")
                if cid:
                    value = value.replace(cid, cid[:3] + "***" + cid[-2:])
        return value
    return {"app_version": dm.PROGRAM_VERSION, "time": datetime.now(timezone.utc).isoformat(),
            "python": sys.version.split()[0], "windows": platform.platform(), "channels": clean(rows),
            "recent_errors": clean(loadRecentErrors()[-30:]),
            "save_error": clean(getattr(state, "channel_save_error", None)),
            "cleanup_errors": [clean(value) for value in getattr(state, "pending_channel_cleanup", {}).values()]}
