"""Linux FFmpeg 장치 선택."""
from functools import lru_cache
import os
from pathlib import Path
import subprocess


class LinuxGpuError(RuntimeError):
    pass


QSV = {'h264_qsv', 'hevc_qsv'}
NVENC = {'h264_nvenc', 'hevc_nvenc'}
QSV_UPLOAD = 'format=nv12,hwupload'


def intel_render_nodes(sysfs=Path('/sys/class/drm'), dev=Path('/dev/dri')):
    devices = []
    for render in sysfs.glob('renderD*'):
        try:
            pci = (render / 'device').resolve(strict=True)
            node = dev / render.name
            if (pci / 'vendor').read_text().strip() == '0x8086' and node.exists():
                devices.append((pci.name, node))
        except OSError:
            continue
    return [node for _, node in sorted(devices)]


@lru_cache(maxsize=8)
def _encoders(ffmpeg, revision):
    try:
        output = subprocess.check_output(
            [ffmpeg, '-hide_banner', '-encoders'], stderr=subprocess.STDOUT,
            text=True, errors='replace', timeout=10,
        )
    except (OSError, subprocess.SubprocessError) as error:
        raise LinuxGpuError('FFmpeg의 GPU 인코더 목록을 확인할 수 없습니다.') from error
    return {parts[1] for line in output.splitlines()
            if len(parts := line.split()) >= 2 and len(parts[0]) == 6 and parts[0][0] == 'V'}


def linux_device_args(ffmpeg, codec, index):
    try:
        stat = Path(ffmpeg).stat()
        revision = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        revision = None
    if codec not in _encoders(ffmpeg, revision):
        raise LinuxGpuError(f'현재 FFmpeg에서 {codec} 인코더를 지원하지 않습니다. CPU 인코딩이나 스트림 복사를 선택할 수 있습니다.')
    if codec in NVENC:
        return []
    devices = intel_render_nodes()
    index = 0 if index is None else int(index)
    if not 0 <= index < len(devices):
        raise LinuxGpuError(f'Intel QSV GPU {index}에 해당하는 렌더 장치를 찾지 못했습니다.')
    node = devices[index]
    if not os.access(node, os.R_OK | os.W_OK):
        raise LinuxGpuError(f'Intel QSV 장치 {node}에 접근할 수 없습니다. render/video 그룹 권한을 확인하세요.')
    return ['-init_hw_device', f'qsv=qsv:hw,child_device={node}', '-filter_hw_device', 'qsv']


def gpu_failure(codec, stderr=''):
    detail = next((line.strip() for line in stderr.splitlines() if any(
        term in line.lower() for term in ('cannot load', 'device creation failed', 'no capable',
                                          'no device', 'permission denied', 'initializ')
    )), '')
    hint = ('Intel Media Driver·VAAPI/oneVPL과 렌더 장치 권한' if codec in QSV
            else 'NVIDIA 드라이버·NVENC 지원과 GPU 번호')
    return LinuxGpuError(f'{codec} 후처리에 실패했습니다. 다음 항목을 확인하세요. {hint}' + (f' ({detail[:240]})' if detail else ''))
