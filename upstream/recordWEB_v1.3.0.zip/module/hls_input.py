"""Naver HLS의 같은 호스트 상대 경로에 확인된 서명 쿼리를 전달합니다."""
from contextlib import contextmanager
from pathlib import Path
import re
import tempfile
from urllib.parse import urljoin, urlsplit, urlunsplit, parse_qsl, urlencode
import requests

AUTH_QUERY_KEYS = {"_lsu_sa_"}


def inherit_signature(parent, child):
    absolute = urljoin(parent, child)
    source, target = urlsplit(parent), urlsplit(absolute)
    if target.scheme not in ("http", "https"):
        raise ValueError("HLS에 지원하지 않는 미디어 경로가 있습니다.")
    if source.hostname != target.hostname:
        return absolute
    params = parse_qsl(target.query, keep_blank_values=True)
    existing = {key for key, _ in params}
    params += [(key, value) for key, value in parse_qsl(source.query, keep_blank_values=True)
               if key in AUTH_QUERY_KEYS and key not in existing]
    return urlunsplit((target.scheme, target.netloc, target.path, urlencode(params), target.fragment))


@contextmanager
def prepared_hls(url, headers, output_directory):
    if not urlsplit(url).path.lower().endswith(".m3u8") or not AUTH_QUERY_KEYS.intersection(dict(parse_qsl(urlsplit(url).query))):
        yield url
        return
    with tempfile.TemporaryDirectory(prefix=".recordfsm-hls-", dir=output_directory) as directory:
        root = Path(directory).resolve()
        known = {}
        def rewrite(source, depth=0):
            if depth > 3:
                raise ValueError("HLS 재생목록 중첩이 너무 깊습니다.")
            if source in known:
                return known[source]
            response = requests.get(source, headers=headers, timeout=(10, 15))
            response.raise_for_status()
            if len(response.content) > 8 * 1024 * 1024 or not response.text.lstrip().startswith("#EXTM3U"):
                raise ValueError("HLS 재생목록 형식을 확인하지 못했습니다.")
            path = root / f"playlist-{len(known)}.m3u8"
            # Windows FFmpeg는 file:///C:/... 대신 file:C:/... 형식을 사용합니다.
            known[source] = "file:" + path.as_posix()
            def reference(child):
                absolute = inherit_signature(source, child)
                return rewrite(absolute, depth + 1) if urlsplit(absolute).path.lower().endswith(".m3u8") else absolute
            lines = []
            for line in response.text.splitlines():
                if line.strip() and not line.startswith("#"):
                    line = reference(line.strip())
                elif "URI=" in line:
                    line = re.sub(r'URI="([^"]+)"', lambda match: 'URI="' + reference(match.group(1)) + '"', line)
                lines.append(line)
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            return "file:" + path.as_posix()
        yield rewrite(url)
