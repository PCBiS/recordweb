"""Lossless, idempotent legacy-channel migration shared by every entrypoint."""
import copy
import hashlib
import json
import re
from urllib.parse import urlparse

ALIASES = {
    'id': ('channelId', 'channel_id', 'uid'), 'name': ('channelName', 'channel_name'),
    'output_dir': ('outputDir', 'save_dir', 'output_path'),
    'record_enabled': ('auto_record', 'recordEnabled', 'enabled'),
    'recordWatchParty': ('record_watch_party',), 'watchPartyExcludeTags': ('watch_party_exclude_tags',),
}

def boolean(value, default=False):
    if value is None: return default
    if isinstance(value, str):
        if value.strip().lower() in ('true','1','yes','on','y','t'): return True
        if value.strip().lower() in ('false','0','no','off','n','f',''): return False
        return default
    return bool(value)

def channel_rows(raw):
    if isinstance(raw, list): return raw
    if isinstance(raw, dict):
        if 'channels' in raw: return channel_rows(raw['channels'])
        return [dict(value, **({'id': key} if 'id' not in value else {})) if isinstance(value, dict) else value
                for key, value in raw.items()]
    raise ValueError('channels.json 형식 오류: 원본을 보존했습니다. 채널 목록 또는 채널 객체가 필요합니다.')

def normalize_channels(raw):
    result, seen = [], {}
    for index, item in enumerate(channel_rows(raw)):
        row = copy.deepcopy(item) if isinstance(item, dict) else {'legacy_item': copy.deepcopy(item)}
        for key, aliases in ALIASES.items():
            if key not in row:
                for alias in aliases:
                    if alias in row:
                        row[key] = row[alias]
                        break
        cid = str(row.get('id') or '').strip()
        platform = str(row.get('platform') or '').strip().lower()
        if not platform:
            platform = 'cime' if 'ci.me/' in cid else 'chzzk'
        if '://' in cid:
            parsed = urlparse(cid)
            if platform == 'chzzk' and parsed.hostname == 'chzzk.naver.com': cid = parsed.path.rstrip('/').split('/')[-1]
            elif platform == 'cime' and parsed.hostname == 'ci.me': cid = parsed.path.strip('/').split('/')[0]
        if platform == 'chzzk': cid = cid.lower()
        if platform == 'cime' and cid and not cid.startswith('_recovery_'): cid = '@' + cid.lstrip('@')
        row.update(platform=platform, id=cid, name=str(row.get('name') or ''),
                   output_dir=str(row.get('output_dir') or ''),
                   record_enabled=boolean(row.get('record_enabled'), True),
                   recordWatchParty=boolean(row.get('recordWatchParty')))
        quality = str(row.get('quality') or 'best').strip().lower()
        if 'recording_group' in row:
            row['recording_group'] = row['recording_group'].strip() if isinstance(row['recording_group'], str) else ''
        if quality.isdigit(): quality += 'p'
        if not re.fullmatch(r'best|worst|(?:144|240|360|480|720|1080|1440|2160)p', quality):
            row.setdefault('legacy_quality', row.get('quality'))
            match = re.fullmatch(r'(144|240|360|480|720|1080|1440|2160)p(?:\d{2,3})?', quality)
            quality = match.group(1)+'p' if match else 'best'
        row['quality'] = quality
        row['extension'] = '.' + str(row.get('extension') or 'mp4').lstrip('.').lower()
        tags = row.get('watchPartyExcludeTags', [])
        if isinstance(tags, str): tags = tags.split(',')
        row['watchPartyExcludeTags'] = list(dict.fromkeys(str(t).strip() for t in tags if str(t).strip())) if isinstance(tags, list) else []
        if 'gpu_index' in row:
            try: row['gpu_index'] = int(row['gpu_index'])
            except (TypeError, ValueError): row['gpu_index'] = 0
        errors = []
        if not isinstance(item, dict): errors.append('손상된 채널 항목: 원본 값을 보존했습니다.')
        if platform == 'youtube': errors.append('유튜브는 다시보기만 지원합니다. 라이브 채널을 직접 수정하세요.')
        elif platform not in ('chzzk','cime'): errors.append('알 수 없는 플랫폼입니다.')
        if not cid:
            row.setdefault('original_id', '')
            row['id'] = '_recovery_' + hashlib.sha256(f'{index}|{json.dumps(item,sort_keys=True,ensure_ascii=False)}'.encode()).hexdigest()[:20]
            errors.append('UID가 비어 있습니다.')
        elif not cid.startswith('_recovery_'):
            pattern = r'[0-9a-f]{32}' if platform == 'chzzk' else r'@[A-Za-z0-9_-]+'
            if platform in ('chzzk','cime') and not re.fullmatch(pattern,cid): errors.append('UID 형식을 확인하세요.')
        canonical = row['id'].lstrip('@').lower() if platform == 'chzzk' else row['id'].lstrip('@')
        if canonical in seen:
            row.setdefault('original_id', cid)
            row['duplicate_of'] = seen[canonical]
            row['id'] = '_recovery_' + hashlib.sha256(f'{index}|{json.dumps(row,sort_keys=True,ensure_ascii=False)}'.encode()).hexdigest()[:20]
            errors.append('중복 채널입니다. UID 수정 또는 삭제가 필요합니다.')
        seen[row['id'].lstrip('@')] = row['id']
        if errors:
            row.setdefault('original_id', cid)
            row['validation_error'] = ' '.join(errors)
        if row.get('validation_error'): row['record_enabled'] = False
        if platform == 'cime':
            row['extension'] = '.mp4'
            if row['recordWatchParty']:
                row.setdefault('legacy_recordWatchParty', True)
                row['recordWatchParty'] = False
        result.append(row)
    return result
