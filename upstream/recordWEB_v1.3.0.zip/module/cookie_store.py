"""Shared storage for WEB and downloader platform cookies."""
from contextlib import contextmanager, suppress
import json
import os
from pathlib import Path
import shutil
import tempfile


FIELDS = {
    "chzzk": ("NID_AUT", "NID_SES"),
    "cime": ("mauth-authorization-code", "session-id"),
}
REQUIRED_FIELDS = {"chzzk": FIELDS["chzzk"], "cime": ("mauth-authorization-code",)}


@contextmanager
def _write_lock(path):
    # Lock a stable file because replacing the JSON changes its file identity.
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.with_name(f".{path.name}.lock").open("a+b") as lock:
        if os.name == "nt":
            import msvcrt

            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl

            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        yield
        # Closing the handle releases the lock, including after exceptions.


def _read_json(path, *, encoding="utf-8"):
    with path.open(encoding=encoding) as source:
        return json.load(source)


def _write_json(path, data, *, backup, recovery=False):
    if backup:
        try:
            current = _read_json(path)
        except FileNotFoundError:
            pass
        except (OSError, ValueError):
            with suppress(OSError):
                shutil.copyfile(path, path.with_suffix(path.suffix + ".corrupt.bak"))
        else:
            if current is not None and json.dumps(current, sort_keys=True) == json.dumps(data, sort_keys=True):
                return False

    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="" if not backup else None,
            dir=path.parent, prefix=".platform-cookies-", delete=False,
        ) as output:
            temporary = Path(output.name)
            json.dump(data, output, ensure_ascii=False, indent=4 if backup else 2)
            if not backup:
                output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        if backup and not recovery and path.exists():
            with suppress(OSError):
                shutil.copyfile(path, path.with_suffix(path.suffix + ".bak"))
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return True


def normalize(data):
    if not isinstance(data, dict):
        data = {}
    normalized = {}
    for platform, keys in FIELDS.items():
        values = data.get(platform)
        if not isinstance(values, dict):
            values = {}
        normalized[platform] = {key: str(values.get(key) or "").strip() for key in keys}
    return normalized


def _read_web_locked(path):
    try:
        return _read_json(path)
    except FileNotFoundError:
        return {}
    except (OSError, ValueError):
        try:
            restored = _read_json(path.with_suffix(path.suffix + ".bak"))
        except (OSError, ValueError):
            return {}
        with suppress(OSError):
            _write_json(path, restored, backup=True, recovery=True)
        return restored


def load_web(path):
    path = Path(path)
    try:
        return normalize(_read_json(path))
    except FileNotFoundError:
        return normalize({})
    except (OSError, ValueError):
        try:
            with _write_lock(path):
                data = _read_web_locked(path)
        except OSError:
            data = {}
        return normalize(data)


def save_web(path, data):
    path = Path(path)
    with _write_lock(path):
        return _write_json(path, normalize(data), backup=True)


def _merge_fields(existing, changes, keys, *, gui):
    merged = dict(existing)
    for name in keys:
        value = changes.get(name, "")
        if not isinstance(value, str):
            if gui:
                raise ValueError("쿠키 Value(값)만 입력하세요.")
            continue
        value = value.strip()
        if not value:
            continue
        if gui and (any(ord(char) < 33 or ord(char) == 127 for char in value) or ";" in value or value.startswith(name + "=")):
            raise ValueError("쿠키의 Value(값)만 입력하세요. 전체 Cookie 헤더·이름·줄바꿈은 포함하지 마세요.")
        merged[name] = value
    return merged


def update_web(path, changes, *, replace_chzzk=False):
    path = Path(path)
    with _write_lock(path):
        data = normalize(_read_web_locked(path))
        if replace_chzzk:
            data["chzzk"] = {key: str(changes.get(key) or "").strip() for key in FIELDS["chzzk"]}
        else:
            for platform, keys in FIELDS.items():
                values = changes.get(platform, {})
                if not isinstance(values, dict):
                    raise ValueError("쿠키 형식을 확인하세요.")
                data[platform] = _merge_fields(data[platform], values, keys, gui=False)
        changed = _write_json(path, data, backup=True)
    return data, changed


def load_gui(path):
    try:
        data = _read_json(path, encoding="utf-8-sig")
        if not isinstance(data, dict):
            raise ValueError()
        return data
    except FileNotFoundError:
        return {}
    except (OSError, ValueError):
        raise ValueError("기존 쿠키 파일을 읽지 못했습니다. 기존 파일은 보존했습니다. 파일 권한이나 손상 여부를 확인하세요.") from None


def merge_gui(data, platform, changes):
    if platform not in FIELDS:
        raise ValueError("지원하지 않는 쿠키 플랫폼입니다.")
    existing = data.get(platform, {})
    if not isinstance(existing, dict):
        raise ValueError("기존 플랫폼 쿠키 구조를 읽지 못했습니다. 기존 파일은 보존했습니다.")
    return {**data, platform: _merge_fields(existing, changes, FIELDS[platform], gui=True)}


def save_gui(path, platform, changes):
    if not any(str(changes.get(key) or "").strip() for key in FIELDS.get(platform, ())):
        raise ValueError("저장할 새 쿠키 값을 입력하세요. 빈칸은 기존 값 유지에만 사용됩니다.")
    with _write_lock(path):
        data = merge_gui(load_gui(path), platform, changes)
        if not all(str(data[platform].get(key) or "").strip() for key in REQUIRED_FIELDS[platform]):
            required = "NID_AUT와 NID_SES" if platform == "chzzk" else "mauth-authorization-code"
            raise ValueError(required + " 쿠키 값을 입력하세요. 기존 파일은 변경하지 않았습니다.")
        _write_json(path, data, backup=False)
    return data


def stored_json_is_object(path):
    return isinstance(_read_json(Path(path)), dict)
