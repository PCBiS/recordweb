"""실행 모드와 이전 트레이 설정 호환."""


def resolve_run_mode(config):
    if "runMode" in config:
        mode = config["runMode"]
        return mode if mode in ("normal", "lite", "headless") else "normal"
    if config.get("enableTray") is True and config.get("minimizeToTrayOnStart") is True:
        return "lite"
    return "normal"
