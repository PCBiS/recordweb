"""Streamlink selectors for Chzzk HLS streams."""

import math
import re


def hls_resolution_selector(quality: str, frame_rate=None) -> str:
    # A name returned by Streamlink, such as 720p60 or 720p_alt, is exact.
    if not re.fullmatch(r"\d+p", quality):
        return quality

    names = []
    try:
        fps = float(frame_rate)
        if fps > 30:
            names.append(f"{quality}{math.ceil(fps)}")
    except (TypeError, ValueError, OverflowError):
        pass
    # Some Chzzk metadata omits FPS even when the playlist provides it.
    names.extend((quality, f"{quality}60", f"{quality}50"))
    return ",".join(dict.fromkeys(names))
