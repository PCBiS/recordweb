"""서버 식별 및 UI 사본 관리."""
import hashlib
import os
from pathlib import Path
import shutil
import sys
import tempfile
import atexit

def canonical(path):
    return os.path.normcase(os.path.realpath(path))

def source_fingerprint(root):
    root=Path(root)
    files=[root/name for name in ('recordWEB.bat', 'recordWEB.sh', 'install_windows.ps1', 'runtime_bootstrap.ps1')
           if (root/name).is_file()]
    for directory in ('module','templates','dependent/plugin'):
        files.extend(p for p in (root/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'))
    digest=hashlib.sha256()
    for path in sorted(files):
        digest.update(path.relative_to(root).as_posix().encode());digest.update(b'\0')
        digest.update(path.read_bytes());digest.update(b'\0')
    return digest.hexdigest()

def process_identity(root,version,port=None):
    import psutil
    identity={'ok':True,'product':'recordWEB','version':version,'pid':os.getpid(),
            'pid_started':psutil.Process().create_time(),'project_root':canonical(root),
            'python':canonical(sys.executable),'build':source_fingerprint(root)}
    if port is not None:identity['port']=int(port)
    return identity

def freeze_ui(root,build):
    root=Path(root)
    parent=root/'.runtime/ui-builds'
    # 실행마다 새 UI 사본 생성
    try:
        parent.mkdir(parents=True,exist_ok=True)
        target=Path(tempfile.mkdtemp(prefix=build+'-',dir=parent))
    except OSError:
        # 프로젝트에 쓸 수 없으면 임시 폴더 사용
        target=Path(tempfile.mkdtemp(prefix='recordWEB-ui-'+build[:12]+'-'))
    try:
        shutil.copytree(root/'templates',target/'templates')
        (target/'complete').write_text(build,encoding='ascii')
    except BaseException:
        shutil.rmtree(target,ignore_errors=True)
        raise
    atexit.register(shutil.rmtree,target,ignore_errors=True)
    return target/'templates'

def validate_runtime(status,root,version,python):
    import psutil
    if not isinstance(status,dict) or status.get('product')!='recordWEB' or status.get('ok') is not True:
        return '해당 포트의 프로그램은 recordWEB으로 확인되지 않았습니다.'
    if status.get('version')!=version:
        return '현재 실행 중인 백엔드가 다른 버전입니다.\n실행 중: '+str(status.get('version'))+'\n실행 요청: '+version
    if canonical(status.get('project_root',''))!=canonical(root):return '백엔드의 프로젝트 폴더가 다릅니다.'
    reported=Path(status.get('python',''))
    if sys.platform == 'linux':
        same_python = canonical(reported) == canonical(python)
    else:
        same_python = (canonical(reported.parent) == canonical(Path(python).parent)
                       and reported.name.lower() in ('python.exe','pythonw.exe','python','python3'))
    if not same_python:
        return '백엔드의 Python 실행 경로가 다릅니다.'
    if status.get('build')!=source_fingerprint(root):return '실행 중인 백엔드와 현재 소스의 빌드 지문이 다릅니다.'
    try:
        pid=status['pid']
        if not isinstance(pid,int) or isinstance(pid,bool):return '백엔드 PID 형식이 잘못됐습니다.'
        process=psutil.Process(pid)
        if not process.is_running() or abs(process.create_time()-float(status['pid_started']))>0.1:return '백엔드 PID가 종료되거나 재사용됐습니다.'
        command=process.cmdline()
        if not command or canonical(command[0])!=canonical(reported):return '백엔드 PID와 Python 명령이 일치하지 않습니다.'
        if '--backend' not in command or not any(canonical(arg)==canonical(Path(root)/'module/recordWEB.py') for arg in command[1:] if not arg.startswith('-')):
            return '백엔드 PID가 이 프로젝트의 recordWEB 서버 명령으로 실행되지 않았습니다.'
    except (KeyError,ValueError,TypeError,psutil.Error):return '백엔드 PID/실행 경로를 확인하지 못했습니다.'
    return None
