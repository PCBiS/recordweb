"""WEB과 Worker가 공유하는 채널 입력 검증과 저장 트랜잭션."""
import asyncio
import copy
import re
from datetime import datetime, timezone
from urllib.parse import urlparse, unquote_to_bytes

from fastapi import HTTPException
from module.data_manager import ALLOWED_KEYS, CHANNEL_QUALITY_RE, RecorderManager, saveChannels, toBool
from module.access_control import LOOPBACK


def decode_channel_path(request, fallback):
    # ASGI의 원본 경로를 한 번만 해제해 '%'가 포함된 기존 ID도 보존합니다.
    raw = request.scope.get("raw_path", b"")
    prefix = b"/api/channels/"
    if raw.startswith(prefix):
        try:
            return unquote_to_bytes(raw[len(prefix):]).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise HTTPException(400, "채널 식별자의 UTF-8 인코딩이 잘못되었습니다.") from exc
    return fallback


async def _persist_channels(candidate):
    write = asyncio.create_task(asyncio.to_thread(saveChannels, candidate))
    try:
        await asyncio.shield(write)
    except asyncio.CancelledError:
        await write
        return True
    return False


async def persist_and_publish(state, candidate):
    cancelled = await _persist_channels(candidate)
    state.channels[:] = candidate
    RecorderManager.setChannels(candidate)
    if cancelled:
        raise asyncio.CancelledError


async def toggle_record_enabled(state, channel_id):
    task = asyncio.create_task(_toggle_record_enabled(state, channel_id))
    try:
        return await asyncio.shield(task)
    except asyncio.CancelledError:
        await task
        raise


async def _toggle_record_enabled(state, channel_id):
    async with state.channels_lock:
        candidate = copy.deepcopy(state.channels)
        channel = next((ch for ch in candidate if ch["id"] == channel_id), None)
        if channel is None:
            raise HTTPException(404, "Channel not found")
        enabled = not toBool(channel.get("record_enabled", True))
        channel["record_enabled"] = enabled
        try:
            await persist_and_publish(state, candidate)
        except Exception as exc:
            raise HTTPException(500, "녹화 설정 저장에 실패했습니다.") from exc
        if enabled:
            channel["status"] = "대기 중"
        else:
            # 녹화 중이면 현재 회차는 유지하고 다음 회차부터 적용합니다.
            await state.fsm.onRecordEnabledChanged(channel_id, enabled=False)
    print(f"[DEBUG] toggle_record_enabled: {channel['name']}({channel_id}) {not enabled} -> {enabled}")
    return {"status": "success", "channel_id": channel_id, "record_enabled": enabled}


async def apply_gpu_assignments(state, mapping):
    if not isinstance(mapping, dict):
        return
    async with state.channels_lock:
        candidate = copy.deepcopy(state.channels)
        changed = False
        for channel in candidate:
            platform = str(channel.get("platform", "")).strip().lower()
            cid = str(channel.get("id", "")).strip()
            if platform != "chzzk" or not cid:
                continue
            key = f"{platform}:{cid}"
            if key not in mapping and cid not in mapping:
                continue
            try:
                index = int(int(mapping.get(key, mapping.get(cid))) == 1)
            except (ValueError, TypeError, OverflowError):
                index = 0
            if channel.get("gpu_index") != index:
                channel["gpu_index"] = index
                changed = True
        if changed:
            await persist_and_publish(state, candidate)


def validate_channel(payload, current=None):
    if not isinstance(payload, dict):
        raise ValueError("채널 정보는 객체여야 합니다.")
    payload = dict(payload)
    if "channelId" in payload:
        payload["id"] = payload.pop("channelId")
    unknown = set(payload) - (ALLOWED_KEYS - {"original_id", "duplicate_of", "validation_error"})
    if unknown:
        raise ValueError("수정할 수 없는 필드: " + ", ".join(sorted(unknown)))
    result = {**(current or {}), **payload}
    from module.channel_groups import validate_assignment
    result['recording_group'] = validate_assignment(result.get('recording_group', ''), (current or {}).get('recording_group', ''))
    for key in ("platform", "id", "name", "output_dir", "quality", "extension"):
        if not isinstance(result.get(key), str) or not result[key].strip():
            raise ValueError(f"{key}: 비어 있지 않은 문자열을 입력하세요.")
        result[key] = result[key].strip()
    platform = result["platform"].lower()
    if platform not in ("chzzk", "cime"):
        raise ValueError("platform: 치지직 또는 씨미를 선택하세요.")
    cid = result["id"]
    if "://" in cid:
        url = urlparse(cid)
        host = "chzzk.naver.com" if platform == "chzzk" else "ci.me"
        if url.hostname != host:
            raise ValueError("id: URL과 플랫폼이 일치하지 않습니다.")
        parts = url.path.strip("/").split("/")
        if platform == "chzzk":
            cid = parts[1] if len(parts) == 2 and parts[0] == "live" else ""
        else:
            cid = parts[0].removeprefix("@") if len(parts) <= 2 and (len(parts) == 1 or parts[1] == "live") else ""
    pattern = r"[0-9a-fA-F]{32}" if platform == "chzzk" else r"[A-Za-z0-9_-]+"
    if platform == "cime":
        cid = cid.removeprefix("@")
    if not re.fullmatch(pattern, cid):
        raise ValueError("id: 치지직은 32자리 UID, 씨미는 채널 주소의 @ 뒤 식별자를 입력하세요.")
    result["id"] = cid.lower() if platform == "chzzk" else cid
    if current and platform == "cime" and current.get("id") == "@" + cid:
        result["id"] = "@" + cid
    result["platform"] = platform
    if not CHANNEL_QUALITY_RE.fullmatch(result["quality"]):
        raise ValueError("quality: 지원하지 않는 화질입니다.")
    result["extension"] = "." + result["extension"].lstrip(".")
    if result["extension"] not in (".ts", ".mp4"):
        raise ValueError("extension: ts 또는 mp4를 선택하세요.")
    if platform == "cime":
        result["extension"] = ".mp4"
    for key in ("record_enabled", "recordWatchParty"):
        result[key] = toBool(result.get(key, key == "record_enabled"))
    if platform == "cime":
        result["recordWatchParty"] = False
    tags = result.get("watchPartyExcludeTags", [])
    if isinstance(tags, str):
        tags = tags.split(",")
    if not isinstance(tags, list) or not all(isinstance(t, str) for t in tags):
        raise ValueError("watchPartyExcludeTags: 문자열 목록을 입력하세요.")
    result["watchPartyExcludeTags"] = list(dict.fromkeys(t.strip() for t in tags if t.strip()))
    if result.get("original_id") and current and (result["id"] != current.get("id") or result["platform"] != current.get("platform")):
        for key in ("original_id", "duplicate_of", "validation_error"):
            result.pop(key, None)
    if "gpu_index" in result:
        result["gpu_index"] = int(result["gpu_index"])
    from module.channel_schema import normalize_channels
    return normalize_channels([result])[0]


async def mutate_channel(request, operation, channel_id=None):
    # 연결 종료로 디스크 반영 뒤의 작업 정리가 생략되지 않게 전체 절차를 보호합니다.
    task = asyncio.create_task(_mutate_channel(request, operation, channel_id))
    try:
        return await asyncio.shield(task)
    except asyncio.CancelledError:
        await task
        raise


async def cleanup_channel(state, channel_id):
    pending = getattr(state, "pending_channel_cleanup", {})
    state.pending_channel_cleanup = pending
    entry = pending.get(channel_id, {"action": "stop", "stage": "저장 후 기존 작업 정리"})
    try:
        if entry.get("action") == "start":
            await state.fsm.userStart(channel_id)
        else:
            await state.fsm.userStop(channel_id)
        pending.pop(channel_id, None)
    except Exception as exc:
        pending[channel_id] = {**entry, "error": type(exc).__name__, "created_at": datetime.now(timezone.utc).isoformat()}
        raise HTTPException(503, {"message": "설정은 저장됐지만 기존 작업 정리에 실패했습니다. 정리를 재시도하세요.",
                                  "committed": True, "cleanup_id": channel_id}) from exc


async def _mutate_channel(request, operation, channel_id=None):
    state = request.app.state
    try:
        payload = await request.json() if operation != "delete" else None
        async with state.channels_lock:
            candidate = copy.deepcopy(state.channels)
            index = next((i for i, ch in enumerate(candidate) if ch.get("id") == channel_id), None)
            if operation != "add" and index is None:
                raise HTTPException(404, "채널을 찾을 수 없습니다.")
            stop_old = False
            restart = False
            if operation == "delete":
                stop_old = True
                candidate.pop(index)
                result = None
            else:
                result = validate_channel(payload, candidate[index] if operation == "edit" else None)
                if request.client.host not in LOOPBACK:
                    if operation == 'edit':
                        permitted = {candidate[index].get('output_dir')}
                    else:
                        permitted = {channel.get('output_dir') for channel in candidate}
                    if result['output_dir'] not in permitted:
                        raise HTTPException(403, '새 녹화 저장 경로는 서버 PC에서 지정하세요.')
                if any(str(ch.get("id", "")).removeprefix("@") == result["id"].removeprefix("@") for i, ch in enumerate(candidate) if operation == "add" or i != index):
                    raise HTTPException(409, "이미 등록된 채널입니다.")
                if operation == "edit":
                    if result["id"] != channel_id or result["platform"] != candidate[index].get("platform"):
                        manager = RecorderManager()
                        proc = manager.get_tasks_process(channel_id)
                        if manager.get_status_recording(channel_id) or (proc and proc.returncode is None):
                            raise HTTPException(409, "녹화 중에는 UID·플랫폼을 바꿀 수 없습니다. 다른 설정은 녹화를 유지하며 저장할 수 있습니다.")
                        stop_old = True
                        restart = manager.get_status_reserved(channel_id)
                    candidate[index] = result
                else:
                    candidate.append(result)
            # 저장과 메모리 공개 순서를 직렬화합니다. 저장 실패 시 목록은 유지됩니다.
            await persist_and_publish(state, candidate)
            if stop_old:
                try:
                    await cleanup_channel(state, channel_id)
                except HTTPException as exc:
                    if isinstance(exc.detail, dict):
                        exc.detail.update(channel=result, operation=operation)
                    raise
                if restart and result and result.get("record_enabled"):
                    try:
                        await state.fsm.userStart(result["id"])
                    except Exception as exc:
                        state.pending_channel_cleanup[result["id"]] = {"action": "start", "stage": "변경 채널 감시 시작", "error": type(exc).__name__}
                        raise HTTPException(503, {"message": "저장 후 감시 시작에 실패했습니다.", "committed": True}) from exc
        return {"status": "success", "channel": result}
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except OSError as exc:
        raise HTTPException(500, "채널 저장에 실패했습니다. 저장 경로와 권한을 확인하세요.") from exc


async def batch_channels(request):
    body = await request.json()
    edits = body.get("changes") if isinstance(body, dict) else None
    if not isinstance(edits, list) or not edits or len(edits) > 500:
        raise HTTPException(400, "changes에 1~500개 변경 항목을 입력하세요.")
    state = request.app.state
    try:
        async with state.channels_lock:
            candidate = copy.deepcopy(state.channels)
            seen = set()
            results = []
            for edit in edits:
                if not isinstance(edit, dict) or not isinstance(edit.get("patch"), dict):
                    raise ValueError("변경 항목에는 id와 patch 객체가 필요합니다.")
                cid = edit.get("id")
                if not isinstance(cid, str):
                    raise ValueError("id는 문자열이어야 합니다.")
                if cid in seen:
                    raise ValueError("같은 채널을 두 번 수정할 수 없습니다.")
                seen.add(cid)
                index = next((i for i, c in enumerate(candidate) if c.get("id") == cid), None)
                if index is None:
                    raise ValueError("변경할 채널을 찾을 수 없습니다.")
                if "id" in edit["patch"] or "platform" in edit["patch"]:
                    raise ValueError("UID와 플랫폼 변경은 개별 저장을 사용하세요.")
                updated = validate_channel(edit["patch"], candidate[index])
                if request.client.host not in LOOPBACK and updated['output_dir'] != candidate[index].get('output_dir'):
                    raise HTTPException(403, '녹화 저장 경로는 서버 PC에서 변경하세요.')
                candidate[index] = updated
                results.append(candidate[index])
            await persist_and_publish(state, candidate)
        return {"status": "success", "channels": results}
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except OSError as exc:
        raise HTTPException(500, "일괄 저장 실패. 변경사항을 저장하지 못했습니다.") from exc


class DebouncedSaver:
    """메타데이터 저장도 CRUD와 같은 락 안에서 최신 목록을 저장합니다."""
    def __init__(self, app, delay=1.2):
        self.app, self.delay = app, delay
        self._task = None
        self._pending = False

    def __call__(self, _unused=None):
        self._pending = True
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._run())

    async def _run(self):
        while self._pending:
            await asyncio.sleep(self.delay)
            self._pending = False
            try:
                await self._save()
            except Exception as exc:
                self.app.state.channel_save_error = type(exc).__name__
                print("[ERROR] 채널 자동 저장 실패. 다음 변경 또는 종료 시 다시 저장합니다.")

    async def _save(self):
        async with self.app.state.channels_lock:
            cancelled = await _persist_channels(copy.deepcopy(self.app.state.channels))
            self.app.state.channel_save_error = None
            if cancelled:
                raise asyncio.CancelledError

    async def flush(self):
        if self._task and not self._task.done():
            await self._task
        await self._save()
