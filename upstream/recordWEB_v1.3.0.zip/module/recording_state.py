"""Read-only recording state shared by all HTTP status responses.

Only recorder/FSM lifecycle code may clear manager data. A missing process
handle during startup, rotation or shutdown is not evidence that a task died.
"""
import os
import time
from datetime import datetime

_last_warning = {}

def snapshot(manager, fsm, channel):
    cid = channel['id']
    process = manager.get_tasks_process(cid)
    alive = process is not None and process.returncode is None
    tasks = [manager.get_tasks_worker(cid)]
    for name in ('watchTask', 'recordTask'):
        tasks.append(getattr(fsm, name, {}).get(cid))
    tasks.append(getattr(type(manager), 'tasks_segment', {}).get(cid))
    task_alive = any(task is not None and not task.done() for task in tasks)
    flag = bool(manager.get_status_recording(cid))
    fsm_state = fsm.getState(cid)
    recording = bool(alive or (task_alive and (flag or fsm_state == 'RECORDING')))
    reserved = bool(not recording and not manager.get_is_user_stopped(cid) and
                    (manager.get_status_reserved(cid) or fsm_state == 'WATCHING'))
    evidence = {'fsm': fsm_state, 'manager_recording': flag,
                'process_alive': alive, 'task_alive': task_alive}
    if flag != recording or (alive and fsm_state != 'RECORDING'):
        now = time.monotonic()
        key = (cid, tuple(evidence.values()))
        if now - _last_warning.get(key, -60) >= 60:
            print(f'[STATE-MISMATCH] channel={cid} evidence={evidence} resolved_recording={recording}')
            _last_warning[key] = now
    stamp = getattr(type(manager), 'recording_start_time', {}).get(cid)
    if isinstance(stamp, datetime):
        stamp = stamp.timestamp()
    try:
        elapsed = max(0, int(time.time() - float(stamp))) if stamp and recording else 0
        started = datetime.fromtimestamp(float(stamp)).strftime('%Y-%m-%d %H:%M:%S') if stamp else ''
    except (ValueError, TypeError, OSError, OverflowError):
        elapsed, started = 0, ''
    duration = f'{elapsed//3600:02d}:{elapsed%3600//60:02d}:{elapsed%60:02d}' if recording else ''
    filename = manager.get_recording_filename(cid) or ''
    jobs = getattr(type(manager), 'postprocess_active_jobs', {})
    active_post = [job for job in list(jobs.values()) if job.get('channel_id') == cid]
    history = getattr(type(manager), 'postprocess_recent_history', [])
    recent_post = next((job for job in reversed(list(history)) if job.get('channel_id') == cid), None)
    post = {'active_count':len(active_post),
            'last_result':recent_post.get('status') if recent_post else None}
    scheduled = channel.get('scheduled_start_time')
    if isinstance(scheduled, datetime):
        scheduled = scheduled.strftime('%Y-%m-%d %H:%M:%S')
    return {'recording': recording, 'reserved': reserved, 'duration': duration,
            'filename': os.path.basename(filename), 'status': 'success',
            'state': '녹화 중' if recording else ('예약녹화 중' if reserved else '대기 중'),
            'recording_duration': duration or '00:00:00',
            'recording_start_time': started or '녹화 시작 시간이 설정되지 않았습니다.',
            'scheduled_start_time': scheduled or '예정된 라이브 방송이 없습니다.',
            'stop_requested': bool(manager.get_is_user_stopped(cid)), 'evidence': evidence,
            'postprocess':post}


def recording_page_fields(state):
    """Adapt a snapshot to the recording template's display fields."""
    return {
        'status': state['state'],
        'filename': state['filename'] or ('예약녹화 대기 중' if state['reserved'] else '녹화 중이 아닙니다.'),
        'duration': state['duration'],
    }
