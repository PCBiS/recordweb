"""SABR maintenance belongs to the standalone downloader, outside the WEB app."""
from datetime import datetime
from PyQt6.QtCore import QThread, pyqtSignal, QTimer
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QPlainTextEdit


class SabrWorker(QThread):
    result = pyqtSignal(dict)

    def __init__(self, action, parent=None):
        super().__init__(parent)
        self.action = action

    def run(self):
        from module.sabr_updater import check_update, update_now
        try:
            data = check_update(force=True) if self.action == 'check' else update_now(repair=self.action == 'repair')
        except Exception as exc:
            data = {'status':'처리 실패', 'error':str(exc)}
        self.result.emit(data)


class SabrDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('YouTube 다운로드 도구 · yt-dlp SABR')
        self.resize(720, 470)
        layout = QVBoxLayout(self)
        help_text = QLabel('bashonly/yt-dlp의 SABR 채널을 사용합니다. 일반 yt-dlp 배포본으로 바꾸지 않습니다.\n'
                           '최신 확인 → SHA-256 검증 → 임시 실행 검사 → 교체 순서로 진행하고, 교체 실패 시 기존 설치를 복원합니다.\n'
                           'recordWEB은 계속 실행할 수 있습니다. 이 폴더의 yt-dlp·Deno가 사용 중일 때는 교체하지 않습니다.')
        help_text.setWordWrap(True)
        layout.addWidget(help_text)
        source = QLabel('<a href="https://github.com/bashonly/yt-dlp/releases/tag/sabr">SABR 공식 배포 페이지</a>')
        source.setOpenExternalLinks(True)
        layout.addWidget(source)
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)
        row = QHBoxLayout()
        self.buttons = []
        for label, action in [('최신 버전 다시 확인','check'), ('업데이트','update'), ('강제 복구/재설치','repair')]:
            button = QPushButton(label)
            button.clicked.connect(lambda checked=False, value=action: self.start(value))
            row.addWidget(button)
            self.buttons.append(button)
        close = QPushButton('닫기')
        close.clicked.connect(self.close)
        row.addWidget(close)
        layout.addLayout(row)
        self.worker = None
        QTimer.singleShot(0, lambda: self.start('check'))

    def start(self, action):
        if self.worker is not None and self.worker.isRunning():
            return
        for button in self.buttons:
            button.setEnabled(False)
        self.output.setPlainText('SABR 최신 버전 확인 중…' if action == 'check' else '검증 후 교체 중… 기존 정상 도구는 검사 완료 전까지 유지합니다.')
        self.worker = SabrWorker(action, self)
        self.worker.result.connect(self.render)
        self.worker.finished.connect(lambda: [button.setEnabled(True) for button in self.buttons])
        self.worker.start()

    def render(self, data):
        stamp = data.get('checked_at')
        checked = datetime.fromtimestamp(stamp).strftime('%Y-%m-%d %H:%M:%S') if isinstance(stamp, (int, float)) else '—'
        rows = [f"상태: {data.get('status', '확인 실패')}", f"현재 버전: {data.get('current_version') or '미설치/확인 불가'}",
                f"최신 버전: {data.get('latest_version') or '다시 확인하세요'}", f"확인 시각: {checked}"]
        if data.get('asset_updated_at'): rows.append('배포 파일 갱신: '+data['asset_updated_at'])
        if data.get('path'): rows.append('설치 경로: '+data['path'])
        if data.get('backup'): rows.append('정상 백업: '+data['backup'])
        if data.get('error'): rows.append('오류: '+data['error'])
        self.output.setPlainText('\n'.join(rows))

    def closeEvent(self, event):
        if self.worker is not None and self.worker.isRunning():
            event.ignore()
            return
        event.accept()
