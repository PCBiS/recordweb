@echo off
setlocal
chcp 65001 >nul
set PYTHONUTF8=1
set "PYTHONHOME="
set "PYTHONPATH="
set "PYTHONNOUSERSITE=1"
cd /d "%~dp0"
if /I "%~1"=="--help" goto help
if /I "%~1"=="--check" goto check
if /I "%~1"=="--repair" goto repair
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0module\install\install_windows.ps1"
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -B "%~dp0module\replayDownloader_GUI.py" %*
exit /b %errorlevel%
:check
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0module\install\install_windows.ps1" -CheckReady
if errorlevel 1 exit /b 20
".venv\Scripts\python.exe" -B "%~dp0module\install_tools.py" --root "%~dp0." --check
exit /b %errorlevel%
:repair
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0module\install\install_windows.ps1" -Repair
exit /b %errorlevel%
:help
echo Usage: replayDownloader.bat [--check ^| --repair ^| --help]
echo recordWEB 다시보기 다운로더입니다. recordWEB과 Python, 외부 도구 및 쿠키를 공유하며 녹화 서버는 실행하지 않습니다.
exit /b 0
