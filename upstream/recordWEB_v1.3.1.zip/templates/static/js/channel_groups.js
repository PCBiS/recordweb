(() => {
  const list = document.getElementById('recording-group-list');
  if (!list) return;
  const message = document.getElementById('recording-group-message');
  let busy = false;
  async function request(url, method='GET', body) {
    const response = await fetch(url, {method, headers:{'Content-Type':'application/json'}, ...(body ? {body:JSON.stringify(body)} : {})});
    const data = await response.json();
    if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '그룹 저장 실패');
    return data.groups;
  }
  function render(groups) {
    list.replaceChildren();
    if (!groups.length) list.textContent = '등록된 그룹이 없습니다.';
    groups.forEach(group => {
      const row = document.createElement('div'); row.className = 'group-edit-row';
      const input = document.createElement('input'); input.value = group.name; input.maxLength = 60;
      input.setAttribute('aria-label', '그룹명 수정: '+group.name);
      const save = document.createElement('button'); save.type='button'; save.textContent='수정';
      const remove = document.createElement('button'); remove.type='button'; remove.textContent='삭제';
      save.onclick = () => mutate('/api/channel-groups/'+encodeURIComponent(group.id),'PUT',{name:input.value});
      remove.onclick = async () => {
        if (await recordWebDialog.confirm('이 그룹을 삭제할까요? 해당 채널은 그룹 없음으로 표시되며 녹화는 유지됩니다.'))
          mutate('/api/channel-groups/'+encodeURIComponent(group.id),'DELETE');
      };
      row.append(input,save,remove); list.append(row);
    });
    document.querySelectorAll('.recording-group-select').forEach(select => {
      const value = select.value;
      select.replaceChildren(new Option('없음',''));
      groups.forEach(group => select.add(new Option(group.name,group.id)));
      select.value = groups.some(group=>group.id===value) ? value : '';
    });
  }
  async function mutate(url,method,body) {
    if (busy) return false;
    busy = true;
    document.querySelector('.group-management').setAttribute('aria-busy','true');
    try {
      render(await request(url,method,body));
      message.textContent='그룹 변경사항을 저장했습니다.';
      return true;
    } catch(error) {
      message.textContent=error.message;
      return false;
    }
    finally { busy=false; document.querySelector('.group-management').removeAttribute('aria-busy'); }
  }
  document.getElementById('addRecordingGroup').addEventListener('submit',async event => {
    event.preventDefault();
    const input = document.getElementById('newRecordingGroup');
    const name = input.value;
    const saved = await mutate('/api/channel-groups','POST',{name});
    if (saved && input.value === name) input.value = '';
  });
  request('/api/channel-groups').then(render).catch(error=>message.textContent=error.message);
})();
