document.addEventListener('recordweb:page-ready', () => {
  updateQualityAndExtensionOptions();

  // 플랫폼 변경 시 옵션 갱신
  const platformSel = document.getElementById('platform');
  if (platformSel) platformSel.addEventListener('change', updateQualityAndExtensionOptions);

  setupChannelFormListeners();
  setupBatchChannelSave();
});

// 채널 추가 폼에서 플랫폼에 따른 품질/확장자 옵션 구성
function updateQualityAndExtensionOptions() {
  const platform = document.getElementById("platform").value;
  const qualitySelect = document.getElementById("quality");
  const extensionSelect = document.getElementById("extension");

  qualitySelect.innerHTML = "";
  extensionSelect.innerHTML = "";

  if (platform === "chzzk") {
    ["best", "1080p", "720p", "480p", "360p"].forEach((q) => {
      const o = document.createElement("option");
      o.value = q;
      o.textContent = q;
      qualitySelect.appendChild(o);
    });
    [".mp4", ".ts"].forEach((ext) => {
      const o = document.createElement("option");
      o.value = ext;
      o.textContent = ext;
      extensionSelect.appendChild(o);
    });
    extensionSelect.disabled = false;
  } else if (platform === "cime") {
    ["best", "2160p", "1440p", "1080p", "720p", "480p", "360p", "worst"].forEach((q) => {
      const o = document.createElement("option");
      o.value = q;
      o.textContent = q;
      qualitySelect.appendChild(o);
    });
    const o = document.createElement("option");
    o.value = ".mp4";
    o.textContent = ".mp4";
    extensionSelect.appendChild(o);
    extensionSelect.disabled = true;
  }
}


//채널 관리 페이지: 추가/수정/삭제 리스너
function setupChannelFormListeners() {
  // 채널 추가
  const addChannelForm = document.getElementById("addChannelForm");
  if (addChannelForm) {
    addChannelForm.addEventListener("submit", function (event) {
      event.preventDefault();

      const platform = document.getElementById("platform").value;
      const channelId = document.getElementById("channelId").value;
      const channelName = document.getElementById("channelName").value;
      const outputDir = document.getElementById("outputDir").value;
      const quality = document.getElementById("quality").value;
      const extension = document.getElementById("extension").value;
	  const recordWatchParty = document.getElementById("recordWatchParty").value;
  	  const watchPartyExcludeTags = document.getElementById("watchPartyExcludeTags").value;

	  fetch("/api/channels", {
	    method: "POST",
	    headers: { "Content-Type": "application/json" },
	    body: JSON.stringify({
	  	  platform,
		  id: channelId,
		  name: channelName,
		  output_dir: outputDir,
		  quality,
		  extension,
		  recordWatchParty: recordWatchParty === "true",
		  watchPartyExcludeTags, // 서버가 문자열/배열 모두 정규화
          recording_group: document.getElementById('recordingGroup')?.value || '',
	    }),
	  })
        .then((response) => {
          if (!response.ok) {
            return response.json().then((err) => {
              throw new Error(err.detail);
            });
          }
          return response.json();
        })
        .then((data) => {
          if (data.status === "success") {
            window.location.href = "/channels";
          }
        })
        .catch((error) => {
          console.error("Error adding channel:", error);
          recordWebDialog.notice("채널 추가 중 오류 발생: " + error.message);
        });
    });
  }


// 같이보기 제외태그 토글 폼
(function setupAddFormWatchPartyToggle() {
  const sel = document.getElementById("recordWatchParty");
  const input = document.getElementById("watchPartyExcludeTags");
  if (!sel || !input) return;
  const apply = () => {
    const on = String(sel.value).toLowerCase() === "true";
    input.disabled = !on; 
  };
  sel.addEventListener("change", apply); // change 이벤트로 충분
  apply(); // 초기상태 반영
})();

// 같이보기 제외태그 토글 수정 카드
(function setupEditCardWatchPartyToggle() {
  const cards = document.querySelectorAll(".channel-edit-form");
  if (!cards.length) return;

  cards.forEach((form) => {
    const sel = form.querySelector(".edit-recordWatchParty");
    const input = form.querySelector(".edit-watchPartyExcludeTags");
    if (!sel || !input) return;
    const apply = () => {
      const on = String(sel.value).toLowerCase() === "true";
      input.disabled = !on;
    };
    sel.addEventListener("change", apply);
    apply(); // 카드별 초기상태 반영
  });
})();


  // 채널 수정(카드 내 인라인 폼)
  document.querySelectorAll(".edit-channel").forEach((button) => {
    button.addEventListener("click", function () {
      const card = this.closest(".channel-card");
      const editForm = card.querySelector(".channel-edit-form");
      const id = this.dataset.id;

      const newPlatform = editForm.querySelector(".edit-platform").value;
      const newName = editForm.querySelector(".edit-channel-name").value;
      const newOutputDir = editForm.querySelector(".edit-output-dir").value;
      const newQuality = editForm.querySelector(".edit-quality").value;
      const newExtension = editForm.querySelector(".edit-extension").value;
	  const newRecordWatchParty = editForm.querySelector(".edit-recordWatchParty").value;
	  const newWatchPartyExcludeTags = editForm.querySelector(".edit-watchPartyExcludeTags")?.value || "";

	  fetch(`/api/channels/${encodeURIComponent(id)}`, {
	    method: "PUT",
	    headers: { "Content-Type": "application/json" },
	    body: JSON.stringify({
		  platform: newPlatform,
		  id: editForm.querySelector(".edit-channel-id").value,
		  name: newName,
		  output_dir: newOutputDir,
		  quality: newQuality,
		  extension: newExtension,
		  recordWatchParty: newRecordWatchParty === "true",
		  watchPartyExcludeTags: newWatchPartyExcludeTags,
          recording_group: editForm.querySelector('.edit-recording-group')?.value || '',
	    }),
	  })
        .then((res) => res.json())
        .then((data) => {
          if (data.status === "success") {
            button.textContent = "저장 완료";
            if (data.channel) {
              card.querySelectorAll("[data-id]").forEach((el) => { el.dataset.id = data.channel.id; });
              editForm.querySelector(".edit-channel-id").value = data.channel.id;
              updateSavedChannelCard(editForm, data.channel);
            }
          } else {
            button.textContent = "저장 실패";
            const detail = data.detail;
            if (detail && typeof detail === 'object' && detail.committed) {
              button.textContent = "저장됨 · 작업 정리 필요";
              if (detail.channel) {
                card.querySelectorAll('[data-id]').forEach(el => { el.dataset.id = detail.channel.id; });
                editForm.querySelector('.edit-channel-id').value = detail.channel.id;
                updateSavedChannelCard(editForm, detail.channel);
              }
            }
            recordWebDialog.notice("채널 수정 결과: " + (detail?.message || detail || data.message || "서버 응답 확인 필요"));
          }
        })
        .catch((err) => console.error("채널 수정 오류:", err));
    });
  });

  // 수정 취소
  document.querySelectorAll(".cancel-edit").forEach((button) => {
    button.addEventListener("click", function () {
      const editForm = this.closest(".channel-edit-form");
      editForm.style.display = "none";
    });
  });

  // 플랫폼 변경 시 옵션 갱신 및 기존 값 유지
  document.querySelectorAll(".channel-edit-form").forEach((editForm) => {
    updateEditFormOptions(editForm);

    const card = editForm.closest(".channel-card");
    const savedQuality = card.dataset.quality;
    const savedExtension = card.dataset.extension;

    if (savedQuality) editForm.querySelector(".edit-quality").value = savedQuality;
    if (savedExtension) editForm.querySelector(".edit-extension").value = savedExtension;

    const recordWatchElem = editForm.querySelector(".edit-recordWatchParty");
    if (recordWatchElem) recordWatchElem.value = recordWatchElem.value || "false";

    editForm.querySelector(".edit-platform").addEventListener("change", () => {
      updateEditFormOptions(editForm);
    });
  });

  // 채널 삭제
  document.querySelectorAll(".delete-channel").forEach((button) => {
    button.addEventListener("click", function () {
      const id = this.dataset.id;
      deleteChannel(id);
    });
  });
}


// 채널 수정 폼
function updateEditFormOptions(editForm) {
  const platformSelect = editForm.querySelector(".edit-platform");
  const qualitySelect = editForm.querySelector(".edit-quality");
  const extensionSelect = editForm.querySelector(".edit-extension");

  qualitySelect.innerHTML = "";
  extensionSelect.innerHTML = "";

  const platform = platformSelect.value;
  if (platform === "chzzk") {
    ["best", "1080p", "720p", "480p", "360p"].forEach((q) => {
      const o = document.createElement("option");
      o.value = q;
      o.textContent = q;
      qualitySelect.appendChild(o);
    });
    [".ts", ".mp4"].forEach((ext) => {
      const o = document.createElement("option");
      o.value = ext;
      o.textContent = ext;
      extensionSelect.appendChild(o);
    });
    extensionSelect.disabled = false;
  } else if (platform === "cime") {
    ["best", "2160p", "1440p", "1080p", "720p", "480p", "360p", "worst"].forEach((q) => {
      const o = document.createElement("option");
      o.value = q;
      o.textContent = q;
      qualitySelect.appendChild(o);
    });
    const o = document.createElement("option");
    o.value = ".mp4";
    o.textContent = ".mp4";
    extensionSelect.appendChild(o);
    extensionSelect.disabled = true;
  }
}


// 채널 삭제
async function deleteChannel(id) {
  if (!await recordWebDialog.confirm("이 채널을 삭제하시겠습니까?")) return;

  fetch(`/api/channels/${encodeURIComponent(id)}`, { method: "DELETE" })
    .then((res) => res.json())
    .then((data) => {
      if (data.status === "success") {
        // 녹화현황 페이지: 해당 카드 제거
        document.querySelector(`.channel[data-channel-id="${cssEsc(id)}"]`)?.remove();
        // 폴링 타이머 중단
        if (location.pathname === "/channels") location.reload();
      } else {
        recordWebDialog.notice("채널 삭제에 실패했습니다.");
      }
    })
    .catch((err) => console.error("Error deleting channel:", err));
}

function updateSavedChannelCard(form, channel) {
  const card = form.closest(".channel-card");
  card.querySelector(".channel-name").textContent = channel.name;
  card.querySelector(".channel-output").textContent = "저장 경로: " + channel.output_dir;
  card.querySelector(".channel-quality").textContent = "품질: " + channel.quality + " / 확장자: " + channel.extension;
  card.dataset.quality = channel.quality;
  card.dataset.extension = channel.extension;
}

function setupBatchChannelSave() {
  const button = document.getElementById('save-all-channels');
  button?.addEventListener('click', async () => {
    button.disabled = true;
    try { await saveAllChannels(); }
    catch (error) { showChannelSaveStatus(error.message); }
    finally { button.disabled = false; }
  });
}

function showChannelSaveStatus(message) {
  const status = document.getElementById('maintenance-output');
  if (status) status.textContent = message;
}

async function saveAllChannels() {
  const forms=[...document.querySelectorAll('.channel-edit-form')].filter(form=>form.dataset.recovery!=='true');
  if (!forms.length) {
    await recordWebDialog.notice('저장할 채널이 없습니다. 복구 항목은 개별 수정하세요.');
    return;
  }
  const changes=forms.map(form=>({id:form.querySelector('.edit-channel').dataset.id,patch:{
    name:form.querySelector('.edit-channel-name').value,output_dir:form.querySelector('.edit-output-dir').value,
    quality:form.querySelector('.edit-quality').value,extension:form.querySelector('.edit-extension').value,
    recordWatchParty:form.querySelector('.edit-recordWatchParty').value==='true',
    watchPartyExcludeTags:form.querySelector('.edit-watchPartyExcludeTags').value,
    recording_group:form.querySelector('.edit-recording-group')?.value || ''
  }}));
  showChannelSaveStatus('전체 채널 설정 저장 중');
  let message;
  try {
    const result = await requestJson('/api/channels/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({changes})});
    result.channels.forEach((channel, index) => updateSavedChannelCard(forms[index], channel));
    message = '전체 채널 설정을 저장했습니다.\nUID·플랫폼 변경은 채널별 저장을 사용하세요.';
  } catch (error) {
    message = `전체 채널 설정을 저장하지 못했습니다.\n${error.message}`;
  } finally {
    showChannelSaveStatus('');
  }
  await recordWebDialog.notice(message);
}
