let isSubmitting = false;         // 중복 요청 방지
let isConfirmed = false;          // 계정 삭제 확인 중복 방지

document.addEventListener('recordweb:page-ready', () => {
  // 분할녹화 및 트레이 옵션
  reflectSplitUI();
  document.getElementById('splitRecordingMode')?.addEventListener('change', reflectSplitUI);
  const tray = document.getElementById('enableTray');
  if (tray && typeof window.appConfig?.enableTray !== 'undefined') {
    tray.value = window.appConfig.enableTray ? 'true' : 'false';
  }

  setupConfigFormListeners();
  setupRemoteWanExample();
  setupConfigFileManagerUI();
  setupAccountFormListeners();
  setupNotificationTestButtons();
  setupPresetUI();
});

function setupRemoteWanExample() {
  const input = document.getElementById('remoteAccessWanIpExample');
  const example = document.getElementById('remote-wan-url-example');
  if (!input || !example) return;

  input.addEventListener('input', () => {
    const address = input.value.trim();
    const parts = address.split('.');
    const isIPv4 = parts.length === 4 && parts.every(part => /^(0|[1-9][0-9]{0,2})$/.test(part) && Number(part) <= 255);
    example.textContent = 'http://' + (isIPv4 ? address : '[공유기 외부 IP 주소]') + ':' + example.dataset.port;
  });
  input.addEventListener('keydown', event => {
    if (event.key === 'Enter') event.preventDefault();
  });
}

// 프리셋 세팅 함수
function setupPresetUI() {
  const presets = {
    libx264: ['ultrafast','superfast','veryfast','faster','fast','medium','slow','slower','veryslow','placebo'],
    libx265: ['ultrafast','superfast','veryfast','faster','fast','medium','slow','slower','veryslow','placebo'],
    h264_qsv: ['veryfast','faster','fast','medium','slow','slower'],
    hevc_qsv: ['veryfast','faster','fast','medium','slow','slower'],
    h264_nvenc: ['p1','p2','p3','p4','p5','p6','p7','default','slow','medium','fast','hp','hq','bd','ll','llhq','llhp','lossless','losslesshp'],
    hevc_nvenc: ['p1','p2','p3','p4','p5','p6','p7','default','slow','medium','fast','hp','hq','bd','ll','llhq','llhp','lossless','losslesshp'],
    h264_amf: ['balanced','speed','quality'],
    hevc_amf: ['balanced','speed','quality']
  };

  // GPU0
  const videoCodecSelect = document.getElementById('video_codec');
  const presetSelect     = document.getElementById('preset');

  // GPU1
  const videoCodecSelectGpu1 = document.getElementById('video_codec_gpu1');
  const presetSelectGpu1     = document.getElementById('preset_gpu1');

  const streamCopySel    = document.getElementById('stream_copy');

  // 공용 적용 함수(코덱셀렉트 + 프리셋셀렉트 + 저장프리셋 문자열)
  function applyPreset(codecSel, presetSel, savedStr) {
    if (!codecSel || !presetSel) return;

    const list = presets[codecSel.value] || [];
    presetSel.innerHTML = '';

    list.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v;
      opt.textContent = v;
      presetSel.appendChild(opt);
    });

    const want = (savedStr || '').trim().toLowerCase();
    const found = Array.from(presetSel.options).find(o => o.value.toLowerCase() === want);

    if (found) {
      presetSel.value = found.value;
    } else if (presetSel.options[0]) {
      presetSel.value = presetSel.options[0].value;
    }
  }

  function updatePresetOptions() {
    // GPU0
    applyPreset(videoCodecSelect, presetSelect, window.savedPreset);

    // GPU1
    applyPreset(videoCodecSelectGpu1, presetSelectGpu1, window.savedPresetGpu1);
  }

  function reflectAvailability() {
    const off = streamCopySel && streamCopySel.value === 'true';

    if (presetSelect) {
      presetSelect.disabled = !!off;
      presetSelect.title = off ? '스트림복사에서는 프리셋이 필요 없습니다.' : '';
    }
    if (presetSelectGpu1) {
      presetSelectGpu1.disabled = !!off;
      presetSelectGpu1.title = off ? '스트림복사에서는 프리셋이 필요 없습니다.' : '';
    }
  }

  updatePresetOptions();
  reflectAvailability();

  videoCodecSelect?.addEventListener('change', updatePresetOptions);
  videoCodecSelectGpu1?.addEventListener('change', updatePresetOptions);
  streamCopySel?.addEventListener('change', reflectAvailability);
}


// 분할녹화 설정 반영 
function reflectSplitUI() {
  const toggleEl  = document.getElementById('splitRecordingMode'); 
  const secsEl    = document.getElementById('autoStopInterval');
  const overlapEl = document.getElementById('splitOverlapSec');
  const splitPPEl = document.getElementById('splitPostProcessing');

  if (!toggleEl || !secsEl || !overlapEl) return;

  const val = (toggleEl.type === 'checkbox')
    ? toggleEl.checked
    : String(toggleEl.value).toLowerCase();
  const on = (val === true) || (val === 'true') || (val === 'on') || (val === '1');

  secsEl.disabled     = !on;
  overlapEl.disabled  = !on;

  // 분할녹화 전용 후처리도 함께 토글
  if (splitPPEl) splitPPEl.disabled = !on;

  // 기본값 채우기
  if (on) {
    if (!secsEl.value || secsEl.value === '0') secsEl.value = '3600';
    if (!overlapEl.value) overlapEl.value = '8';

    // 분할 후처리 기본값: ON
    if (splitPPEl && (splitPPEl.value === '' || splitPPEl.value == null)) {

      // select/checkbox 둘 다 대응
      if (splitPPEl.tagName === 'SELECT') {
        splitPPEl.value = 'true';
      } else if (splitPPEl.type === 'checkbox') {
        splitPPEl.checked = true;
      }
    }
  }
}


// 설정 폼 리스너 설정
function setupConfigFormListeners() {
  const configForm = document.getElementById('configForm');
  if (!configForm) return;

  // [GPU UI] gpuCount 변경 시 GPU1 프로필/채널 분배 섹션 즉시 토글
  const gpuCountSelect = document.getElementById('gpuCount');
  const singleGpuSelect = document.getElementById('singleGpuIndex');
  const gpu1ProfileSection = document.getElementById('gpu1ProfileSection');
  const gpuAssignSection = document.getElementById('gpuAssignSection');
  const gpuAssignmentsHidden = document.getElementById('gpuAssignmentsJson');

  function updateGpuSectionsVisibility() {
    if (!gpuCountSelect) return;
    const gpuCount = parseInt(gpuCountSelect.value || '1', 10) || 1;
    const show = (gpuCount === 2);

    if (gpu1ProfileSection) gpu1ProfileSection.style.display = (show || singleGpuSelect?.value === '1') ? 'block' : 'none';
    if (gpuAssignSection)  gpuAssignSection.style.display  = show ? 'block' : 'none';
    if (singleGpuSelect) singleGpuSelect.disabled = show;


    // 단일 GPU로 내렸을 때 hidden 값은 비워두기(제출 시에도 submit 핸들러가 delete 처리하지만, UI 혼동 방지)
    if (!show && gpuAssignmentsHidden) gpuAssignmentsHidden.value = '';
  }

  if (gpuCountSelect) {
    gpuCountSelect.addEventListener('change', updateGpuSectionsVisibility);
    gpuCountSelect.addEventListener('input',  updateGpuSectionsVisibility);
    updateGpuSectionsVisibility(); // 페이지 진입 시 1회 동기화
  }
  singleGpuSelect?.addEventListener('change', updateGpuSectionsVisibility);

  configForm.addEventListener('submit', async function (event) {
    event.preventDefault();
    if (isSubmitting) return;

    const splitToggle  = document.getElementById('splitRecordingMode');  // 체크박스
    const splitSecs    = document.getElementById('autoStopInterval');    // 분할 시간(초)
    const overlapInput = document.getElementById('splitOverlapSec');     // 오버랩(초) - 신규 필드

    isSubmitting = true;
    try {
      const formData = new FormData(this);

      // 트레이 셀렉트가 없거나 disabled로 누락되었을 때 기본 false 보정

      // gpuCount를 먼저 확보(아래 GPU 분배/추가키 보정에 재사용)
      const gpuCountEl = document.getElementById('gpuCount');
      const gpuCount = parseInt((gpuCountEl && gpuCountEl.value) ? gpuCountEl.value : '1', 10) || 1;

      // 후처리 출력 크기 드롭다운이 disabled면 FormData에서 빠질 수 있음 → 현재 값으로 보정
      const ppRes0El = document.getElementById('postprocess_resolution');
      if (!formData.has('postprocess_resolution') && ppRes0El) {
        formData.append('postprocess_resolution', ppRes0El.value || 'source');
      }
      if (gpuCount === 2 || document.getElementById('singleGpuIndex')?.value === '1') {
        const ppRes1El = document.getElementById('postprocess_resolution_gpu1');
        if (!formData.has('postprocess_resolution_gpu1') && ppRes1El) {
          formData.append(
            'postprocess_resolution_gpu1',
            ppRes1El.value || (ppRes0El ? (ppRes0El.value || 'source') : 'source')
          );
        }
      }

      // 1) disabled 때문에 빠질 수 있는 값 보정
      if (!formData.has('timemachine_time_shift')) formData.append('timemachine_time_shift', '0');

      // 2) 체크 안 된 체크박스/셀렉트 기본값 보정
      [
        'autoPostProcessing','deleteAfterPostProcessing','removeFixedPrefix',
        'moveAfterProcessingEnabled','postNewWindow', 'stream_copy',
        'use_bitrate_mode','splitRecordingMode','fileManagerEnabled',
        'fileManagerReadOnly','trashEnabled'

      ].forEach(name => {
        if (!formData.has(name)) formData.append(name, 'false');
      });

      // 3) 숫자 선택사항은 빈 문자열이면 제거 (int 변환 실패 방지)
      if ((formData.get('autoStopInterval') || '') === '') formData.delete('autoStopInterval');

      // 4) 옵션 문자열들 기본값 보정
      [
        'moveAfterProcessing', 'vbv_maxrate','vbv_bufsize', 'extra_ffmpeg_options',
		'telegram_enabled','telegram_bot_token','telegram_chat_id',
		'discord_enabled','discord_webhook_url',
		'notify_record_started','notify_record_finished','notify_record_start_failed',
		'notify_record_abnormally_stopped','notify_record_user_stopped',
		'notify_postprocess_finished','notify_postprocess_failed',
		'notify_cookie_auth_failed','notify_watchparty_skipped',
		'notify_disk_space_low','notify_dedupe_seconds','notify_disk_space_low_gb'

      ].forEach(name => {
        if (!formData.has(name)) formData.append(name, '');
      });

      if ((formData.get('splitOverlapSec') || '') === '') {
        // 빈 값이면 제거 (서버에서 0 처리)
        formData.delete('splitOverlapSec');
      } else {
        const ovRaw = parseInt(formData.get('splitOverlapSec'), 10);
        // 서버와 동일한 가드(0~30초 권장)
        if (!Number.isInteger(ovRaw) || ovRaw < 0) {
          formData.set('splitOverlapSec', '0');
        } else if (ovRaw > 30) {
          formData.set('splitOverlapSec', '30');
        }
      }

      // GPU 채널 분배(hidden) 구성: gpuCount==2일 때만 전송
      formData.delete('gpuAssignmentsJson'); // 혹시 이전 값이 들어가 있었으면 제거

      if (gpuCount === 2) {
        const mapping = {};

        document.querySelectorAll('[data-gpu-assign][data-channel-id]').forEach((sel) => {
          const cid = sel.getAttribute('data-channel-id');
          if (!cid) return;

          const vRaw = parseInt(sel.value || '0', 10);
          const gi = (vRaw === 1 ? 1 : 0);
          mapping[cid] = gi;
        });

        formData.set('gpuAssignmentsJson', JSON.stringify(mapping));
      }

      const response = await fetch('/config', {
        method: 'POST',
        body: formData,
        headers: {'X-recordWEB-Client': 'settings'}
      });
      if (response.ok) {
        const result = await response.json();
        const metadataInterval = document.getElementById('recordingMetadataRefreshInterval');
        if (metadataInterval && result.recordingMetadataRefreshInterval != null) {
          metadataInterval.value = String(result.recordingMetadataRefreshInterval);
        }
        await recordWebDialog.notice(result.message || '설정을 저장했습니다.');
      } else {
        let message = '설정 저장 중 오류가 발생했습니다.';
        const text = await response.text();
        try { message = JSON.parse(text).message || message; } catch (_) {}
        console.error('POST /config failed:', response.status, text);
        recordWebDialog.notice(message);
      }
    } catch (err) {
      console.error('에러 발생:', err);
      recordWebDialog.notice('설정을 저장하지 못했습니다. 서버 연결을 확인하세요.');
    } finally {
      isSubmitting = false;
    }
  });
}


// 계정 수정/삭제 폼 리스너 설정
function setupAccountFormListeners() {
  const updateAccountForm = document.getElementById("updateAccountForm");
  const deleteAccountForm = document.querySelector(".delete-form");

  if (updateAccountForm) {
    // 계정 수정
    updateAccountForm.addEventListener("submit", function (event) {
      event.preventDefault();

      const currentPassword = document.getElementById("current_password").value;
      const newPassword = document.getElementById("new_password").value;
      const newPasswordConfirm = document.getElementById("new_password_confirm").value;

      if (validatePassword(currentPassword, newPassword, newPasswordConfirm)) {
        submitForm(updateAccountForm, "계정이 성공적으로 수정되었습니다.");
      }
    });
  }

  if (deleteAccountForm) {
    // 계정 삭제
    deleteAccountForm.addEventListener("submit", async function (event) {
      event.preventDefault();
      if (isConfirmed || isSubmitting) return;
      const currentPassword = document.getElementById("delete-current_password").value;
      if (!validatePassword(currentPassword)) return;
      isConfirmed = true;
      try {
        if (await recordWebDialog.confirm("정말 계정을 삭제하시겠습니까?")) {
          await submitForm(deleteAccountForm, "계정이 삭제되었습니다.", "/");
        }
      } finally {
        isConfirmed = false;
      }
    });
  }
}


// 공통 폼 제출 래퍼
async function submitForm(formElement, successMessage, redirectUrl) {
  if (isSubmitting) return;
  isSubmitting = true;

  try {
    const formData = new FormData(formElement);
    const action = formData.get("action");

    // 삭제 액션일 땐 새 비번 필드 제외
    if (action === "delete") {
      formData.delete("new_password");
      formData.delete("new_password_confirm");
    }

    const response = await fetch("/updateAccount", {
      method: "POST",
      body: formData,
    });

    const result = await response.json();

    if (!response.ok) {
      recordWebDialog.notice(result.message || "오류가 발생했습니다.");
      return;
    }

    if (result.status === "success") {
      await recordWebDialog.notice(successMessage || result.message);
      setTimeout(() => {
        window.location.href = redirectUrl || result.redirect_url;
      }, 2000);
    } else {
      recordWebDialog.notice(result.message || "오류가 발생했습니다.");
    }
  } catch (error) {
    console.error("폼 제출 중 오류 발생:", error);
    recordWebDialog.notice("서버와의 통신 중 문제가 발생했습니다.");
  } finally {
    isSubmitting = false;
  }
}


// 비밀번호 검증
function validatePassword(currentPassword, newPassword = null, newPasswordConfirm = null) {
  if (!currentPassword) {
    recordWebDialog.notice("현재 비밀번호를 입력해주세요.");
    return false;
  }
  if (newPassword && newPassword !== newPasswordConfirm) {
    recordWebDialog.notice("새 비밀번호가 일치하지 않습니다.");
    return false;
  }
  return true;
}


// 알림 테스트 버튼 설정 함수
function setupNotificationTestButtons() {
  setupNotificationTestButton('testTelegramBtn', 'telegram');
  setupNotificationTestButton('testDiscordBtn', 'discord');
}

function setupNotificationTestButton(buttonId, target) {
  const btn = document.getElementById(buttonId);
  if (!btn) return;

  btn.addEventListener('click', async () => {
    const oldText = btn.textContent;

    try {
      btn.disabled = true;
      btn.textContent = '전송 중…';

      const res = await fetch(`/api/test_notification/${target}`, { method: 'POST' });
      const data = await res.json().catch(() => ({}));

      if (res.ok && data?.status === 'success') {
        recordWebDialog.notice(data.message || '테스트 메시지를 전송했습니다.');
      } else {
        const msg = data?.message || `테스트 실패 (HTTP ${res.status})`;
        recordWebDialog.notice(msg);
      }
    } catch (err) {
      console.error(`${target} notification test failed:`, err);
      recordWebDialog.notice('테스트 중 오류가 발생했습니다.');
    } finally {
      btn.disabled = false;
      btn.textContent = oldText;
    }
  }, { once: false });
}

// 일매니저 관련 UI 토글/행 추가
function setupConfigFileManagerUI() {
  const list = document.getElementById("fm-roots-list");
  if (!list) return;
  document.getElementById("add-fm-root")?.addEventListener("click", () => {
    const row = document.createElement("div");
    row.className = "fm-root-row";
    row.style.cssText = "display:flex;gap:8px;align-items:center;margin:6px 0;";
    row.innerHTML = `
      <input type="text" name="fileManagerRoots" placeholder="예: C:/recordWEB/record" style="flex:1;">
      <button type="button" class="rm-root">삭제</button>`;
    list.appendChild(row);
  });

  list?.addEventListener("click", (e) => {
    const btn = e.target.closest(".rm-root");
    if (!btn) return;
    btn.closest(".fm-root-row")?.remove();
  });
}
