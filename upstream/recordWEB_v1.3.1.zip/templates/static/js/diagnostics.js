(() => {
  const byId = id => document.getElementById(id);
  const show = text => { const out=byId('maintenance-output'); if(out) out.textContent=text; };
  const format = (id,data) => { byId(id).textContent=typeof data==='string'?data:JSON.stringify(data,null,2); };
  const on=(id,fn)=>byId(id)?.addEventListener('click',async event=>{
    const button=event.currentTarget; button.disabled=true;
    try { await fn(event); } catch(error) { show(error.message); }
    finally { button.disabled=false; }
  });
  async function preview() {
    const data=await requestJson('/api/diagnostics');
    format('diagnostics-preview',data); return JSON.stringify(data,null,2);
  }
  on('preview-diagnostics',preview);
  on('copy-diagnostics',async()=>{
    const text=await preview();
    try { await navigator.clipboard.writeText(text); show('진단정보 복사 완료'); }
    catch { show('자동 복사가 제한됐습니다. 미리보기 텍스트를 선택해 복사하세요.'); }
  });
  function postprocessDeleteButton(job, row, target, emptyMessage, retryButton) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'postprocess-action';
    button.textContent = '기록 삭제';
    button.disabled = !job.job_id || job.status === 'retrying';
    button.onclick = async () => {
      if (!await recordWebDialog.confirm(`${job.file}\n\n이 후처리 기록을 삭제할까요? 원본과 결과 영상은 보관됩니다.`)) return;
      const retryWasDisabled = retryButton?.disabled;
      button.disabled = true;
      if (retryButton) retryButton.disabled = true;
      try {
        const result = await requestJson('/api/postprocess-records/' + encodeURIComponent(job.job_id), {method:'DELETE'});
        if (row.parentElement === target) {
          row.remove();
          if (!target.childElementCount) target.textContent = emptyMessage;
        }
        show(result.message);
      } catch (error) {
        show(error.message);
        button.disabled = false;
        if (retryButton) retryButton.disabled = retryWasDisabled;
      }
    };
    return button;
  }
  on('check-postprocess',async()=>{
    const target=byId('postprocess-failures'); target.replaceChildren();
    const jobs=await requestJson('/api/postprocess-failures');
    if(!jobs.length) target.textContent='활성 후처리 실패가 없습니다.';
    for(const job of jobs) {
      const row=document.createElement('div'); row.className='diagnostic-job';
      const text=document.createElement('p');
      const names={failed:'실패',failed_again:'재시도 실패',retrying:'재시도 중'};
      text.textContent=[job.file,names[job.status]||job.status,job.reason||''].join(' · ');
      const retry = document.createElement('button');
      retry.type = 'button';
      retry.className = 'postprocess-action';
      retry.textContent = job.requires_confirmation ? '원본 확인 필요' : job.cleanup_pending ? '결과 정리 재개' : '현재 설정으로 재시도';
      retry.disabled=job.status==='retrying'||job.status==='원본 없음'||job.requires_confirmation;
      const remove = postprocessDeleteButton(job, row, target, '활성 후처리 실패가 없습니다.', retry);
      retry.onclick=async()=>{
        retry.disabled=true;
        remove.disabled=true;
        try { const result=await requestJson('/api/postprocess-retry/'+encodeURIComponent(job.job_id),{method:'POST'}); show(result.message||'재시도 요청 완료'); }
        catch(error) { show(error.message); retry.disabled=false; remove.disabled=!job.job_id; }
      };
      const actions = document.createElement('div');
      actions.className = 'action-row';
      actions.append(retry, remove);
      row.append(text, actions);
      target.append(row);
    }
  });
  on('check-postprocess-history',async()=>{
    const target=byId('postprocess-history'); target.replaceChildren();
    const jobs=await requestJson('/api/postprocess-history');
    if(!jobs.length) target.textContent='복구 이력이 없습니다.';
    for (const job of jobs) {
      const row = document.createElement('div');
      row.className = 'diagnostic-job';
      const text = document.createElement('p');
      text.textContent = [job.file,'복구 완료',job.recovered_at||'',job.output_file||''].join(' · ');
      row.append(text, postprocessDeleteButton(job, row, target, '복구 이력이 없습니다.'));
      target.append(row);
    }
  });
  on('check-cleanups',async()=>{
    const target=byId('channel-cleanups'); target.replaceChildren();
    const jobs=await requestJson('/api/channel-cleanups');
    if(!jobs.length) target.textContent='채널 정리 오류가 없습니다.';
    jobs.forEach(job=>{
      const row=document.createElement('div'); row.className='diagnostic-job';
      const text=document.createElement('p'); text.textContent=[job.id||'',job.stage,job.error,job.created_at||'시각 기록 없음'].join(' · ');
      const retry=document.createElement('button'); retry.type='button'; retry.textContent='정리 재시도';
      retry.onclick=async()=>{retry.disabled=true;try{await requestJson('/api/channel-cleanup/'+encodeURIComponent(job.id),{method:'POST'});row.remove();}catch(error){show(error.message);retry.disabled=false;}};
      row.append(text,retry);target.append(row);
    });
  });
})();
