"""기록된 실패 작업만 식별자로 다시 실행합니다."""
import asyncio
from fastapi import HTTPException
from module import data_manager as dm
from module.diagnostics import redact
from module.process_lifecycle import finish_before_cancel


def failures():
    from module.postprocess_store import records
    return records()


def list_failures():
    from module.postprocess_store import is_failure_record
    jobs = [job for job in failures() if is_failure_record(job)]
    return [{"job_id": job.get("job_id"), "file": redact(job.get("input_file", "")),
             "reason": redact((job.get("reason") or "").replace("검증 성공 후 파일 정리 실패", "후처리 파일 정리 실패")), "finished_at": job.get("finished_at"),
             "status": job.get("status", "failed"), "retry_count": job.get("retry_count", 0),
             "cleanup_pending": bool(job.get("cleanup")),
             "requires_confirmation": not (job.get("input_identities") or job.get("cleanup")),
             "first_failure_at": job.get("first_failure_at", job.get("finished_at")),
             "first_reason": redact(job.get("first_reason", job.get("reason", ""))),
             "last_retry_at": job.get("last_retry_at"), "retry_profile": job.get("retry_profile"),
             "output_file": redact(job.get("output_file", ""))}
            for job in jobs[-30:]]


def list_history():
    return [{"job_id": job.get("job_id"), "file": redact(job.get("input_file", "")),
             "status": job.get("status"), "recovered_at": job.get("recovered_at"),
             "output_file": redact(job.get("output_file", "")),
             "retry_count": job.get("retry_count", 0)}
            for job in failures()[-100:] if isinstance(job, dict) and job.get("status") == "recovered"]


async def retry(request, job_id):
    return await finish_before_cancel(asyncio.create_task(_retry(request, job_id)))


async def _retry(request, job_id):
    import os
    from module.file_manager import busyFilePaths, isLocked
    from module.live_recorder import (buildPostCfgForChannel, claimPostprocess, handlePostProcessing,
                                      queueBatchPattern, releasePostprocess, trackPostprocessTask)
    await asyncio.to_thread(dm.loadConfig)
    if dm.getConfigLoadStatus() == "safe_mode":
        raise HTTPException(409, "설정 안전모드입니다. 설정 복구 후 후처리를 재시도하세요.")
    job = next((job for job in failures() if isinstance(job, dict) and job.get("job_id") == job_id), None)
    if job is None:
        raise HTTPException(404, "실패 작업을 찾을 수 없습니다.")
    from module.postprocess_store import begin_retry, failed, is_failure_record, is_split_job
    if not is_failure_record(job):
        raise HTTPException(404, "실패 작업을 찾을 수 없습니다.")
    path = job.get("input_path")
    channel_id = job.get("channel_id")
    channel = next((c for c in request.app.state.channels if c.get("id") == channel_id), {})
    cfg = {} if job.get("cleanup") else buildPostCfgForChannel(channel)
    retry_job = await asyncio.to_thread(begin_retry, job_id, {key: cfg.get(key) for key in ("_profile", "gpu_index", "video_codec", "preset", "stream_copy")})
    try:
        busy = busyFilePaths(dm.RecorderManager(), request.app.state.channels)
        checked = os.path.dirname(path) if is_split_job(retry_job) else path
        if isLocked(checked, busy):
            raise HTTPException(409, "원본 경로에서 녹화 또는 후처리가 진행 중입니다.")
        if is_split_job(retry_job):
            if not await queueBatchPattern(channel_id, path, retry_job=retry_job, retry_cfg=cfg):
                raise HTTPException(409, "분할 후처리 재시도를 시작하지 못했습니다.")
            return {"status": "success", "message": "기존 분할 결과 정리를 재개했습니다." if retry_job.get("cleanup")
                    else "현재 설정으로 분할 후처리 재시도를 시작했습니다."}
        claim = claimPostprocess(path)
        if claim is None:
            raise HTTPException(409, "같은 원본의 후처리가 실행 중입니다.")
        work = handlePostProcessing(path, channel_id, job.get("channel_name", ""), cfg,
                                    recovery_job=retry_job, claim=claim)
        try:
            worker = asyncio.create_task(work)
        except Exception:
            work.close()
            releasePostprocess(claim)
            raise

        def cancelled(result):
            try:
                if result.cancelled():
                    current = next((row for row in failures() if row.get("job_id") == job_id), {})
                    if current.get("status") == "retrying":
                        failed({**current, "reason": "후처리 실행이 취소되었습니다."})
            finally:
                releasePostprocess(claim)
        worker.add_done_callback(cancelled)
        trackPostprocessTask(worker)
    except Exception as exc:
        reason = exc.detail if isinstance(exc, HTTPException) else str(exc)
        await asyncio.to_thread(failed, {**retry_job, "reason": reason})
        raise
    return {"status": "success", "message": "기존 후처리 결과 정리를 재개했습니다." if retry_job.get("cleanup")
            else "현재 후처리 설정으로 재시도를 시작했습니다."}

