"""FFprobe 조회와 미디어 출력 검증."""
import json
import math
import os
import subprocess


def _run_probe(ffprobe, path, entries, *, stream=None, output="default=nw=1:nk=1", **options):
    command = [ffprobe, "-v", "error"]
    if stream is not None:
        command += ["-select_streams", stream]
    command += ["-show_entries", entries, "-of", output, path]
    return subprocess.run(command, **options)


def _first_line(text):
    return next((line.strip() for line in text.splitlines() if line.strip()), "")


def _video_field(ffprobe, path, fields, *, output="default=nw=1:nk=1", check=True):
    if check:
        if not path or not os.path.exists(path):
            return ""
        stdout = _run_probe(
            ffprobe, path, fields, stream="v:0", output=output, check=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=3,
        ).stdout.decode("utf-8", "ignore")
    else:
        stdout = _run_probe(
            ffprobe, path, fields, stream="v:0", output=output,
            capture_output=True, text=True, timeout=3,
        ).stdout
    return _first_line(stdout or "")


def get_media_duration(ffprobe_path, path):
    if not path or not os.path.exists(path):
        return 0.0
    try:
        result = _run_probe(
            ffprobe_path, path, "format=duration", check=True, stdout=subprocess.PIPE, text=True,
        )
        return float(result.stdout.strip() or 0)
    except (OSError, TypeError, ValueError, subprocess.SubprocessError):
        return 0.0


def probe_video_codec(ffprobe_path, path, *, check=True):
    try:
        return _video_field(ffprobe_path, path, "stream=codec_name", check=check).lower()
    except (OSError, TypeError, ValueError, subprocess.SubprocessError):
        return ""


def probe_video_height(ffprobe_path, path, *, check=True):
    try:
        value = _video_field(ffprobe_path, path, "stream=height", check=check)
        return int(value) if value.isdigit() else 0
    except (OSError, TypeError, ValueError, subprocess.SubprocessError):
        return 0


def probe_video_size(ffprobe_path, path):
    try:
        value = _video_field(ffprobe_path, path, "stream=width,height", output="csv=p=0:s=x")
        width, height = value.split("x", 1)
        if width.isdigit() and height.isdigit():
            return int(width), int(height)
    except (OSError, TypeError, ValueError, subprocess.SubprocessError):
        pass
    return (0, 0)


def probe_format_name(ffprobe, path):
    try:
        result = _run_probe(
            ffprobe, path, "format=format_name", capture_output=True, text=True, timeout=3,
        )
        return (result.stdout or "").strip().lower()
    except (OSError, TypeError, ValueError, subprocess.SubprocessError):
        return ""


def probe_video_details(ffprobe, path):
    result = _run_probe(
        ffprobe, path, "stream=width,height,r_frame_rate,avg_frame_rate",
        stream="v:0", output="json", check=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, text=True, timeout=5,
    )
    streams = json.loads(result.stdout or "{}").get("streams") or []
    return streams[0] if streams else {}


def has_video_stream(path, ffprobe=None):
    """Return True only when FFprobe confirms a video stream."""
    if not ffprobe:
        return None
    try:
        result = _run_probe(
            str(ffprobe), str(path), "stream=codec_type", stream="v:0", output="json",
            capture_output=True, text=True, errors="replace", timeout=15,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode != 0:
            return False
        return any(item.get("codec_type") == "video" for item in json.loads(result.stdout or "{}").get("streams", []))
    except (OSError, subprocess.TimeoutExpired, ValueError, TypeError):
        return False


def output_has_minimum_size(path, minimum_bytes, *, regular_file=False):
    exists = os.path.isfile if regular_file else os.path.exists
    return exists(path) and os.path.getsize(path) >= minimum_bytes


def classify_duration(expected, actual):
    if actual is None or expected is None:
        return "길이 확인 필요"
    if actual <= 0 or actual + max(3.0, expected * 0.01) < expected:
        return "부분 다운로드"
    if actual > expected + max(10.0, expected * 0.03):
        return "길이 확인 필요"
    return "완료"


def requested_duration(section):
    if not section:
        return None
    parts = section.replace("~", "-").split("-")
    if len(parts) != 2:
        raise ValueError("구간은 시작시각~종료시각으로 입력하세요.")
    def seconds(value):
        h, m, s = map(float, value.strip().split(":"))
        if h < 0 or not 0 <= m < 60 or not 0 <= s < 60:
            raise ValueError("구간 시각 범위가 잘못되었습니다.")
        return h * 3600 + m * 60 + s
    duration = seconds(parts[1]) - seconds(parts[0])
    if duration <= 0:
        raise ValueError("종료시각은 시작시각보다 커야 합니다.")
    return duration


def verify_output(path, ffprobe, expected=None):
    actual = None
    error = None
    try:
        result = _run_probe(
            ffprobe, path, "format=format_name,duration", output="json", capture_output=True, text=True,
            timeout=30, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode != 0:
            error = "출력 파일 검사 실패"
        else:
            media_format = json.loads(result.stdout)["format"]
            if not media_format.get("format_name"):
                raise ValueError("format_name")
            duration = media_format.get("duration")
            if duration not in (None, "N/A"):
                actual = float(duration)
                if not math.isfinite(actual):
                    raise ValueError("duration")
    except (AttributeError, TypeError, OSError, ValueError, KeyError, subprocess.TimeoutExpired) as exc:
        error = type(exc).__name__
    return {"status": "검증 실패" if error else classify_duration(expected, actual),
            "expected_seconds": expected, "actual_seconds": actual, "validation_error": error,
            "segments_verified": False}
