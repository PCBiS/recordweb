"""One remote-access policy for form/API settings and server binding."""
from ipaddress import ip_address, ip_network
import socket
from urllib.parse import urlsplit

import psutil

LOOPBACK = {'127.0.0.1', '::1', 'localhost'}


def _interface_ipv4_entries():
    for interface, entries in psutil.net_if_addrs().items():
        for entry in entries:
            if entry.family == socket.AF_INET:
                address = ip_address(entry.address)
                if not address.is_loopback and not address.is_unspecified:
                    yield interface, address


def interface_ipv4_addresses():
    return sorted({str(address) for _, address in _interface_ipv4_entries()})


def interface_ipv4_display():
    private_networks = tuple(ip_network(network) for network in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"))
    groups = {"lan": [], "tailscale": [], "link_local": [], "other": []}
    for interface, address in _interface_ipv4_entries():
        if address.is_link_local:
            group = "link_local"
        elif interface.casefold().startswith("tailscale"):
            group = "tailscale"
        elif any(address in network for network in private_networks):
            group = "lan"
        else:
            group = "other"
        groups[group].append({"address": str(address), "interface": interface})
    return groups


def allowed_host(host, actual_port, bound_remote):
    try:
        parsed = urlsplit('http://' + host)
        name = parsed.hostname
        if not name or parsed.username or parsed.path or parsed.query or parsed.fragment:
            return False
        if (parsed.port or 80) != actual_port:
            return False
        if name in LOOPBACK:
            return True
        address = ip_address(name)
        if not bound_remote or address.version != 4 or address.is_unspecified:
            return False
        return name in interface_ipv4_addresses()
    except (OSError, ValueError):
        return False

def validate_network(config, account):
    from module.data_manager import toBool
    from module.server_port import parse_port
    result = dict(config)
    result['loginMode'] = toBool(result.get('loginMode', False))
    result['remoteAccessEnabled'] = toBool(result.get('remoteAccessEnabled', False))
    result['port'] = parse_port(result.get('port', 5000), allow_legacy=True)
    return result
