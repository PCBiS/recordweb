import asyncio 
import time 
import random
from typing import Any, Dict, List, Callable, Awaitable, Tuple, Optional

from module.runtime_log import debugThrottle
from module.data_manager import DEFAULT_RECORDING_METADATA_REFRESH_INTERVAL, RecorderManager


# 기본 주기
FAST_TTL      = 60       # 라이브 제목, 카테고리, 썸네일의 공통 TTL
OFFLINE_TTL   = 90       # 종료 상태일 때 메타 TTL
BACKOFF_STEPS = [30, 60, 120, 300]  # 에러 시 지수 백오프
JITTER_SEC    = 3


def _now() -> float:
    return time.monotonic()


# app.state에 캐시 관련 상태를 보장
def ensure(app) -> None:
    if not hasattr(app.state, "meta_cache"):
        app.state.meta_cache = {}  # {cid: {"data":dict|None,"ts_meta":float,"err":int}}
    if not hasattr(app.state, "meta_lock"):
        app.state.meta_lock = asyncio.Lock()
    if not hasattr(app.state, "meta_semaphore"):
        app.state.meta_semaphore = asyncio.Semaphore(4)
    if not hasattr(app.state, "meta_tasks"):
        app.state.meta_tasks = set()
    if not hasattr(app.state, "refreshing"):
        app.state.refreshing = set()


def isOpen(platform: str, data: Optional[Dict[str, Any]]) -> bool:
    if not data:
        return False
    p = (platform or "").lower()
    if p == "chzzk":
        return data.get("status") == "OPEN"
    if p == "cime":
        return bool(data.get("is_live")) or data.get("status") == "OPEN"
    return False


def recordingInterval(app):
    return getattr(app.state, "config", {}).get("recordingMetadataRefreshInterval", DEFAULT_RECORDING_METADATA_REFRESH_INTERVAL)


def makeEntry(data, now, session=None, interval=None):
    return {"data": data, "ts_meta": now, "err": 0, "session": session,
            "interval": interval, "revision": str(time.monotonic_ns())}


def displayData(data):
    values = dict(data)
    if not values.get("live_title") and values.get("liveTitle"):
        values["live_title"] = values["liveTitle"]
    return values


async def getDisplayCache(app, cid):
    """Reuse the metadata already obtained by the recorder for this process."""
    async with app.state.meta_lock:
        entry = app.state.meta_cache.get(cid)
        process, initial = RecorderManager().get_recording_display_session(cid)
        if process is not None:
            interval = recordingInterval(app)
            if entry is None or entry.get("session") is not process:
                previous = (entry or {}).get("data") or {}
                started, metadata = initial if initial is not None else (_now(), {})
                entry = makeEntry({**previous, **displayData(metadata)}, started, process, interval)
                app.state.meta_cache[cid] = entry
            elif entry["interval"] != interval:
                if entry["interval"] == 0:
                    entry["ts_meta"] = _now()
                entry["interval"] = interval
        elif entry is not None and entry.get("session") is not None:
            entry.update(session=None, interval=None, err=0)
        return entry


def cacheTtl(platform, entry):
    if entry and entry.get("session") is not None:
        return entry["interval"]
    return FAST_TTL if entry and isOpen(platform, entry["data"]) else OFFLINE_TTL


def needsRefresh(platform, entry, now):
    if not entry:
        return True
    ttl = cacheTtl(platform, entry)
    if entry.get("session") is not None:
        return ttl > 0 and now - entry["ts_meta"] >= ttl
    errors = entry["err"]
    backoff = BACKOFF_STEPS[min(errors, len(BACKOFF_STEPS) - 1)] if errors else 0
    return now - entry["ts_meta"] >= max(ttl, backoff)


# 채널 dict에 제목/카테고리/썸네일만 반영
def mergeChannelFields(real: Dict[str, Any], data: Dict[str, Any]) -> bool:
    changed = False
    platform = str(real.get("platform") or data.get("platform") or "").lower()
    default_thumb = "/static/img/cimeclosed_thumbnail.png" if platform == "cime" else "/static/img/default_thumbnail.png"
    mapping = [
        ("live_title",    "live_title",    "방송 제목 없음"),
        ("category",      "category",      "카테고리 없음"),
        ("thumbnail_url", "thumbnail_url", default_thumb),
    ]
    for dst, src, default in mapping:
        nv = data.get(src, default)
        if not nv:
            continue
        old = real.get(dst)

        # 기존 값이 있고, 신규 값이 플레이스홀더라면 덮어쓰지 않음
        if old and nv == default:
            continue

        if old != nv:
            real[dst] = nv
            changed = True
    return changed


async def refreshOneChannel(app, channel: Dict[str, Any], fetcher: Callable[[Dict[str, Any]], Awaitable[Optional[Dict[str, Any]]]],
                            channels_lock: asyncio.Lock, session) -> None:
    cid = channel["id"]

    def still_current():
        process, _ = RecorderManager().get_recording_display_session(cid)
        return process is session and (session is None or recordingInterval(app) != 0)

    try:
        async with app.state.meta_semaphore:
            if not still_current():
                return
            try:
                data = await asyncio.wait_for(fetcher(dict(channel)), timeout=15)
            except Exception:
                data = None
        async with app.state.meta_lock:
            if not still_current():
                return
            entry = app.state.meta_cache.get(cid)
            # A platform failure can return an offline/default payload while the recorder is still running.
            success = isinstance(data, dict) and bool(data) and (session is None or isOpen(channel.get("platform"), data))
            if not success:
                previous = entry or makeEntry(None, _now())
                previous.update(ts_meta=_now(), err=min(previous["err"] + 1, len(BACKOFF_STEPS)))
                app.state.meta_cache[cid] = previous
                return
            data = displayData(data)
            if session is not None:
                app.state.meta_cache[cid] = makeEntry({**entry["data"], **data}, _now(), session, recordingInterval(app))
                return
            app.state.meta_cache[cid] = makeEntry(data, _now())
        async with channels_lock:
            real = next((c for c in app.state.channels if c["id"] == cid), None)
            if real and still_current():
                mergeChannelFields(real, data)
    finally:
        app.state.refreshing.discard(cid)


async def refreshLoop(app, fetcher: Callable[[Dict[str, Any]], Awaitable[Optional[Dict[str, Any]]]], saveChannels: Callable[[List[Dict[str, Any]]], None],
                      channels_lock: asyncio.Lock,) -> None:
    # 주기적으로 채널 메타/썸네일 캐시 갱신
    ensure(app)
    while True:
        async with channels_lock:
            chs = list(app.state.channels)
        delay = 3 + random.uniform(-JITTER_SEC, JITTER_SEC)
        for ch in chs:
            cid = ch["id"]
            platform = (ch.get("platform") or "").lower()
            ent = await getDisplayCache(app, cid)
            now = _now()
            if ent and ent.get("session") is not None and ent["interval"] > 0:
                interval = ent["interval"]
                delay = min(delay, interval)
                elapsed = now - ent["ts_meta"]
                if elapsed < interval <= elapsed + delay:
                    delay = min(delay, interval - elapsed)
            if needsRefresh(platform, ent, now):
                schedule_refresh(app, ch, fetcher, channels_lock, ent)
        await asyncio.sleep(delay)


# meta_cache.py
async def getMetadataCached(app, channel_id: str, platform: str, fetcher: Callable[[Dict[str, Any]], Awaitable[Optional[Dict[str, Any]]]],
                            saveChannels: Callable[[List[Dict[str, Any]]], None], channels_lock: asyncio.Lock,) -> Tuple[Dict[str, Any], bool, bool]:

    ensure(app)
    ent = await getDisplayCache(app, channel_id)
    data = ent["data"] if ent else None
    now = _now()
    ttl = cacheTtl(platform, ent)
    fresh = bool(ent and (ttl == 0 or now - ent["ts_meta"] < ttl))

    if data is None:
        async with channels_lock:
            ch = next((dict(c) for c in app.state.channels if c['id'] == channel_id), None)
        if ch and needsRefresh(platform, ent, now):
            schedule_refresh(app, ch, fetcher, channels_lock, ent)
        default = {
            'live_title': (ch or {}).get('live_title') or '방송 제목 없음',
            'category': (ch or {}).get('category') or '카테고리 없음',
            'thumbnail_url': (ch or {}).get('thumbnail_url') or (
                '/static/img/cimeclosed_thumbnail.png' if platform == 'cime' else '/static/img/default_thumbnail.png'),
            'is_live': None,
        }
        return default, False, False

    # (2) 데이터는 있으나 stale이면 백그라운드 갱신만
    if needsRefresh(platform, ent, now) and channel_id not in app.state.refreshing:
        async with channels_lock:
            ch = next((c for c in app.state.channels if c["id"] == channel_id), None)
        if ch:
            schedule_refresh(app, ch, fetcher, channels_lock, ent)

    # (3) 캐시값 반환
    return data, True, fresh



# 각 채널 썸네일 URL 리스트 반환
async def getThumbnailsCached(app, channels: List[Dict[str, Any]], fetcher: Callable[[Dict[str, Any]], Awaitable[Optional[Dict[str, Any]]]],
                              saveChannels: Callable[[List[Dict[str, Any]]], None], channels_lock: asyncio.Lock,) -> List[Dict[str, Any]]:

    ensure(app)
    out = []
    for ch in channels:
        cid = ch["id"]
        platform = (ch.get("platform") or "").lower()
        ent = await getDisplayCache(app, cid)
        data = ent["data"] if ent else None
        if needsRefresh(platform, ent, _now()):
            schedule_refresh(app, ch, fetcher, channels_lock, ent)

        if data and isinstance(data, dict):
            thumb = data.get("thumbnail_url")
        else:
            thumb = "/static/img/cimeclosed_thumbnail.png" if platform == "cime" else "/static/img/default_thumbnail.png"

        # 썸네일 URL 로그 (실제 URL일 때만, 채널/플랫폼별 60초에 1번)
        if isinstance(thumb, str) and thumb.startswith("http"):
            debugThrottle(
                f"thumb:{platform}:{cid}",
                f"Generated thumbnail URL: {thumb}",
                min_secs=60.0
            )

        out.append({'id': cid, 'platform': platform, 'thumbnail_url': thumb,
                    'live_title': (data or ch).get('live_title') or '방송 제목 없음',
                    'category': (data or ch).get('category') or '카테고리 없음',
                    'is_live': isOpen(platform, data), 'adult': (data or {}).get('adult', False),
                    'recording': bool(ent and ent.get('session') is not None),
                    'metadata_revision': ent['revision'] if ent else None})

    return out

def schedule_refresh(app, channel, fetcher, channels_lock, entry):
    cid = channel['id']
    if cid in app.state.refreshing:
        return
    app.state.refreshing.add(cid)
    session = entry.get("session") if entry else None
    track_refresh(app, refreshOneChannel(app, channel, fetcher, channels_lock, session))

def track_refresh(app, coroutine):
    task = asyncio.create_task(coroutine)
    app.state.meta_tasks.add(task)
    task.add_done_callback(app.state.meta_tasks.discard)
