"""녹화 모듈에서 생성한 프로세스를 앱 종료 시 끝까지 정리합니다."""
import asyncio
import os
import signal
import subprocess

_processes = {}
_waiters = set()
_closing = False


def resume():
    global _closing
    _closing = False


async def finish_before_cancel(task):
    """Wait for an owned operation before allowing even repeated cancellation."""
    cancelled = False
    while not task.done():
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError:
            cancelled = True
    result = task.result()
    if cancelled:
        raise asyncio.CancelledError
    return result


async def create_process(*args, **kwargs):
    if _closing:
        raise RuntimeError("앱 종료 중에는 새 프로세스를 시작하지 않습니다.")
    if os.name == "posix":
        kwargs["start_new_session"] = True
    try:
        proc = await asyncio.create_subprocess_exec(*args, **kwargs)
    except OSError:
        from module.inspection_cache import cache
        cache.invalidate('environment')
        raise
    _processes[proc.pid] = proc
    async def reap():
        try:
            code = await proc.wait()
            if code and not _closing:
                from module.inspection_cache import cache
                cache.invalidate('environment')
        finally:
            if os.name == "posix" and not _closing:
                try:
                    await stop_group(proc)
                finally:
                    _processes.pop(proc.pid, None)
            elif os.name != "posix":
                _processes.pop(proc.pid, None)
    waiter = asyncio.create_task(reap())
    _waiters.add(waiter)
    waiter.add_done_callback(_waiters.discard)
    if _closing:
        await shutdown()
        raise RuntimeError("앱 종료와 동시에 생성된 프로세스를 정리했습니다.")
    return proc


def signal_group(pid, sig):
    try:
        os.killpg(pid, sig)
        return True
    except ProcessLookupError:
        return False


async def shutdown():
    global _closing
    _closing = True
    async def stop(proc):
        if os.name == "posix":
            try:
                await stop_group(proc)
            finally:
                _processes.pop(proc.pid, None)
            return
        if proc.returncode is not None:
            return
        try:
            if os.name == "nt":
                await asyncio.to_thread(subprocess.run, ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                                        capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            await asyncio.wait_for(proc.wait(), timeout=5)
        except (ProcessLookupError, asyncio.TimeoutError):
            if proc.returncode is None:
                proc.kill()
                await proc.wait()
    results = await asyncio.gather(*(stop(proc) for proc in list(_processes.values())), return_exceptions=True)
    for result in results:
        if isinstance(result, BaseException):
            print("[WARN] 일부 프로세스 종료 실패:", type(result).__name__)


async def stop_group(proc):
    if not signal_group(proc.pid, signal.SIGTERM):
        return
    deadline = asyncio.get_running_loop().time() + 5
    while signal_group(proc.pid, 0):
        if asyncio.get_running_loop().time() >= deadline:
            signal_group(proc.pid, signal.SIGKILL)
            break
        await asyncio.sleep(.1)
    await asyncio.wait_for(proc.wait(), timeout=2)
