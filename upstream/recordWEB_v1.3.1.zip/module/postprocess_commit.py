"""File identities and the recoverable final step of a postprocess job."""
import asyncio
import hashlib
import os
import stat
from pathlib import Path

from module.process_lifecycle import finish_before_cancel
from module.safe_files import move_new


def identity(path):
    with open(path, "rb") as source:
        before = os.fstat(source.fileno())
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("일반 파일이 아닙니다.")
        digest = hashlib.sha256(source.read(65536))
        if before.st_size > 65536:
            source.seek(max(65536, before.st_size - 65536))
            digest.update(source.read(65536))
        after = os.fstat(source.fileno())
    fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns")
    result = {key: getattr(before, key) for key in fields}
    if result != {key: getattr(after, key) for key in fields}:
        raise OSError("확인 도중 파일이 변경되었습니다.")
    return {**result, "sample": digest.hexdigest()}


def matches(path, expected):
    if not isinstance(expected, dict) or not expected.get("sample"):
        return False
    try:
        actual = identity(path)
    except FileNotFoundError:
        return False
    return actual == expected


def path_key(path):
    return os.path.normcase(os.path.realpath(path))


def reserve_output(path):
    path = Path(path)
    for index in range(10000):
        candidate = path if not index else path.with_name(f"{path.stem}({index}){path.suffix}")
        try:
            with candidate.open("xb"):
                pass
            return str(candidate)
        except FileExistsError:
            continue
    raise FileExistsError(str(path))


def plan(source, expected, output, policy):
    if not matches(source, expected) or path_key(source) == path_key(output):
        raise OSError("작업 원본이 등록된 파일과 다릅니다.")
    output = Path(output).absolute()
    name = output.name.removeprefix("fixed_") if policy.get("removeFixedPrefix") else output.name
    move = policy.get("moveAfterProcessing") if policy.get("moveAfterProcessingEnabled") else None
    if move:
        from module.data_manager import validateMediaDirectory
        directory = Path(validateMediaDirectory(move)).absolute()
    else:
        directory = output.parent
    return {"source": os.path.abspath(source), "source_identity": expected,
            "output": str(output), "output_identity": identity(output),
            "destination": str(directory / name), "delete_source": bool(policy.get("deleteAfterPostProcessing")),
            "move": bool(move), "published": False, "done": False}


def safe_to_resume(entry):
    if not isinstance(entry, dict) or not all(
        isinstance(entry.get(key), str) and os.path.isabs(entry[key]) for key in ("source", "output", "destination")
    ) or not all(isinstance(entry.get(key), bool) for key in ("done", "published", "move", "delete_source")):
        raise ValueError("후처리 정리 기록 형식이 잘못됐습니다.")
    source, destination = entry["source"], entry["destination"]
    work = entry["output"]
    published_id = entry.get("published_identity", entry["output_identity"])
    if entry["done"]:
        return matches(destination, published_id)
    changed = os.path.lexists(source) and not matches(source, entry["source_identity"])
    if changed and not (path_key(source) == path_key(destination) and matches(destination, entry["output_identity"])):
        return False
    if entry["published"] or not os.path.lexists(work):
        return matches(destination, published_id)
    return matches(work, entry["output_identity"])


def commit(entries, save):
    for entry in entries:
        source, work = entry["source"], entry["output"]
        if not safe_to_resume(entry):
            raise OSError("정리할 원본 또는 결과 파일이 변경됐습니다. 사용자 확인이 필요합니다.")
        if entry["done"]:
            continue
        if not entry["published"]:
            destination = entry["destination"]
            replaced = path_key(source) == path_key(destination)
            already_published = entry.get("published_identity") and matches(destination, entry["published_identity"])
            if not already_published and path_key(work) != path_key(destination) and os.path.lexists(work):
                if replaced and entry["delete_source"] and not entry["move"]:
                    if not matches(source, entry["source_identity"]):
                        raise OSError("교체 직전 원본이 변경됐습니다.")
                    os.replace(work, destination)
                else:
                    target = Path(destination)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    for index in range(10000):
                        candidate = target if not index else target.with_name(f"{target.stem}({index}){target.suffix}")
                        entry["destination"] = str(candidate)
                        def before_publish(staged):
                            entry["published_identity"] = identity(staged)
                            save(entries)
                        try:
                            move_new(work, candidate, before_publish=before_publish)
                            break
                        except FileExistsError:
                            continue
                    else:
                        raise FileExistsError(str(target))
            entry["published"] = True
            save(entries)
        destination = entry["destination"]
        if not matches(destination, entry.get("published_identity", entry["output_identity"])):
            raise OSError("저장된 결과를 확인할 수 없습니다.")
        if path_key(work) != path_key(destination) and matches(work, entry["output_identity"]):
            os.unlink(work)
        if entry["delete_source"] and path_key(source) != path_key(destination) and os.path.lexists(source):
            if not matches(source, entry["source_identity"]):
                raise OSError("삭제 직전 원본이 변경됐습니다.")
            os.unlink(source)
        entry["done"] = True
        save(entries)
    return entries[0]["destination"]


async def commit_job(job_id, entries):
    from module.data_manager import RecorderManager
    from module.postprocess_store import set_cleanup
    manager = RecorderManager()

    def save(rows):
        manager.postprocess_set_cleanup_paths(
            job_id, tuple(entry[key] for entry in rows for key in ("source", "output", "destination"))
        )
        set_cleanup(job_id, rows)

    def run():
        save(entries)
        return commit(entries, save)

    return await finish_before_cancel(asyncio.create_task(asyncio.to_thread(run)))
