"""후처리 실패와 재시도를 같은 작업 ID로 원자적으로 갱신합니다."""
from datetime import datetime, timezone
import os
import re
from module import data_manager as dm
from module.postprocess_commit import matches, safe_to_resume


def now():
    return datetime.now(timezone.utc).isoformat()


def records():
    try:
        jobs = dm.readJsonSafe(dm.POSTPROCESS_FAILED_PATH, [], strict=True)
    except (OSError, ValueError) as error:
        raise OSError("후처리 복구 저장소를 읽을 수 없습니다.") from error
    if not isinstance(jobs, list):
        raise OSError("후처리 복구 저장소 형식이 잘못됐습니다.")
    return [job for job in jobs if isinstance(job, dict)]


def is_failure_record(job):
    if job.get("status", "failed") not in ("failed", "failed_again", "retrying", "원본 없음", "복구 보류"):
        return False
    reason = str(job.get("reason") or "")
    if job.get("retry_mode") == "validation" and reason != "검증 성공 후 파일 정리 실패":
        return False
    if reason.startswith(("후처리 결과 검증 실패:", "분할 후처리 출력 검증 실패.")):
        return False
    if reason == "copyStream returned False":
        from module.postprocess_legacy import was_validation_timeout
        return not was_validation_timeout(job, dm.base_directory)
    return True


def is_split_job(job):
    path = job.get("input_path") or ""
    return "segment_indexes" in job or (
        not os.path.isfile(path) and bool(re.search(r"_%0\d+d\.[^.]+$", path))
    )


def input_problem(job):
    entries = job.get("cleanup")
    if entries:
        return None if all(safe_to_resume(entry) for entry in entries) else "정리 대상 파일이 변경됐습니다. 사용자 확인이 필요합니다."
    inputs = job.get("input_identities")
    if not isinstance(inputs, dict) or not inputs:
        return "원본 정체성 정보가 없는 기록입니다. 자동 재시도 불가 · 사용자 확인 필요."
    path = job.get("input_path") or ""
    if not is_split_job(job):
        return None if matches(path, inputs.get(os.path.abspath(path))) else "원본 파일이 없거나 다른 파일로 바뀌었습니다."

    from module.live_recorder import listNumericSegments, parseSegPattern
    parsed = parseSegPattern(path)
    try:
        segments = listNumericSegments(*parsed) if parsed else []
    except FileNotFoundError:
        segments = []
    indexes = [index for index, _ in segments]
    if not consecutive(indexes) or set(indexes) != set(job.get("segment_indexes") or ()):
        return "분할 원본 세그먼트 번호가 누락되거나 바뀌었습니다."
    if any(not matches(name, inputs.get(os.path.abspath(name))) for _, name in segments):
        return "등록된 분할 원본이 다른 파일로 바뀌었습니다."
    return None


def consecutive(indexes):
    return bool(indexes) and all(index == expected for expected, index in enumerate(indexes))


def set_cleanup(job_id, entries):
    with dm._json_write_lock:
        jobs = records()
        job = next((item for item in jobs if item.get("job_id") == job_id), None)
        if job is None:
            raise OSError("후처리 복구 기록을 찾을 수 없습니다.")
        job["cleanup"] = entries
        dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)


def started(job):
    with dm._json_write_lock:
        jobs = records()
        if not any(item.get("job_id") == job["job_id"] for item in jobs):
            dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, [*jobs, job])


def set_output_path(job_id, path):
    with dm._json_write_lock:
        jobs = records()
        for item in jobs:
            if item.get("job_id") == job_id:
                item["output_path"] = path
                dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)
                break


def failed(job):
    with dm._json_write_lock:
        jobs = records()
        old = next((item for item in jobs if item.get("job_id") == job["job_id"]), {})
        merged = {**old, **job, "status": "failed_again" if old.get("retry_count", 0) else "failed",
                  "first_failure_at": old.get("first_failure_at", job.get("finished_at", now())),
                  "first_reason": old.get("first_reason", job.get("reason", "")),
                  "retry_count": old.get("retry_count", 0)}
        jobs = [item for item in jobs if item.get("job_id") != job["job_id"]]
        jobs.append(merged)
        active = [item for item in jobs if item.get("status") in {"running", "retrying"}]
        history = [item for item in jobs if item.get("status") not in {"running", "retrying"}]
        dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, [*active, *history[-300:]])


def recovered(job):
    with dm._json_write_lock:
        jobs = records()
        for item in jobs:
            if item.get("job_id") == job["job_id"]:
                if item.get("status") == "running":
                    jobs.remove(item)
                else:
                    item.update(status="recovered", recovered_at=now(), output_file=job.get("output_path"), reason="")
                dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)
                break


def delete_record(job_id):
    from fastapi import HTTPException

    with dm._json_write_lock:
        jobs = dm.readJsonSafe(dm.POSTPROCESS_FAILED_PATH, [])
        matches = [
            job for job in jobs
            if isinstance(job, dict) and job.get("job_id") == job_id
        ] if isinstance(jobs, list) else []
        if not matches:
            raise HTTPException(404, "후처리 기록을 찾을 수 없습니다.")
        if any(job.get("status") in {"running", "retrying"} for job in matches):
            raise HTTPException(409, "후처리가 끝난 뒤 기록을 삭제할 수 있습니다.")
        remaining = [
            job for job in jobs
            if not isinstance(job, dict) or job.get("job_id") != job_id
        ]
        try:
            dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, remaining)
        except OSError as exc:
            raise HTTPException(500, "후처리 기록을 저장하지 못했습니다.") from exc


def begin_retry(job_id, profile):
    from fastapi import HTTPException
    with dm._json_write_lock:
        jobs = records()
        item = next((item for item in jobs if item.get("job_id") == job_id), None)
        if item is None:
            raise HTTPException(404, "실패 작업을 찾을 수 없습니다.")
        if item.get("status") in ("running", "retrying", "recovered"):
            raise HTTPException(409, "이미 재시도 중이거나 복구 완료된 작업입니다.")
        if not is_failure_record(item):
            raise HTTPException(404, "실패 작업을 찾을 수 없습니다.")
        try:
            problem = input_problem(item)
        except (OSError, ValueError, TypeError, KeyError) as error:
            problem = f"복구 데이터 또는 저장장치 확인 실패: {type(error).__name__}"
        if problem:
            item.update(status="복구 보류", reason=problem)
            dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)
            raise HTTPException(400, problem)
        item.setdefault("first_failure_at", item.get("finished_at"))
        item.setdefault("first_reason", item.get("reason"))
        item.pop("retry_mode", None)
        item.update(status="retrying", retry_count=item.get("retry_count", 0) + 1,
                    last_retry_at=now(), retry_profile=profile)
        dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)
        return dict(item)


def recover_interrupted():
    with dm._json_write_lock:
        jobs = records()
        changed = False
        for item in jobs:
            status = item.get("status")
            if status not in ("running", "retrying") or item.get("retry_mode") == "validation":
                continue
            try:
                problem = input_problem(item)
                output_exists = os.path.isfile(item.get("output_path") or "")
            except (OSError, ValueError, TypeError, KeyError) as error:
                problem = f"복구 데이터 또는 저장장치 확인 실패: {type(error).__name__}"
                output_exists = False
            reason = "중단된 후처리. " + (problem or "원본을 확인했습니다. 현재 설정으로 재시도할 수 있습니다.")
            if output_exists:
                reason += " 기존 결과 파일도 보존했습니다."
            item.update(status="복구 보류" if problem else ("failed" if status == "running" else "failed_again"),
                        reason=reason, finished_at=now())
            changed = True
        if changed:
            dm.writeJsonSafe(dm.POSTPROCESS_FAILED_PATH, jobs)
