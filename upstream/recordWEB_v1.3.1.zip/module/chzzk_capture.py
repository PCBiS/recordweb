"""Finish a direct Streamlink capture before publishing its recording name."""
import json
import math
import os
from pathlib import Path
import subprocess
import tempfile

from module.postprocess_commit import identity, matches
from module.safe_files import rename_new


_FORMATS = {".ts": "mpegts", ".mp4": "mp4", ".mkv": "matroska"}
_TAIL_SECONDS = 10


def _run(command, timeout):
    return subprocess.run(command, capture_output=True, text=True, errors="replace", timeout=timeout,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def _probe(ffprobe, path):
    result = _run([ffprobe, "-v", "error", "-show_entries", "format=format_name,start_time,duration:stream=codec_type",
                   "-of", "json", str(path)], 15)
    if result.returncode or result.stderr.strip():
        raise ValueError("파일 헤더 또는 스트림 정보를 읽지 못했습니다.")
    media = json.loads(result.stdout)
    return media["format"], {item.get("codec_type") for item in media.get("streams", [])}


def _verify(ffmpeg, ffprobe, path, container, maximum_seconds, required_streams):
    media, streams = _probe(ffprobe, path)
    if container not in media["format_name"].split(",") or not required_streams <= streams:
        raise ValueError("컨테이너 또는 영상·오디오 스트림이 예상과 다릅니다.")
    duration = float(media["duration"])
    if (not math.isfinite(duration) or duration <= 0
            or (maximum_seconds is not None and duration > maximum_seconds)):
        raise ValueError("녹화 길이가 유효하지 않거나 실제 녹화 시간보다 지나치게 깁니다.")
    def decode(target, seconds=None):
        seek = ["-sseof", f"-{seconds}"] if seconds is not None and duration > seconds + 2 else []
        limit = ["-t", str(seconds + 2)] if seconds is not None else []
        return _run([ffmpeg, "-nostdin", "-v", "error", "-xerror", "-err_detect", "explode", *seek,
                     "-i", str(target), "-map", "0:v:0", "-map", "0:a:0?", *limit,
                     "-fps_mode", "passthrough", "-enc_time_base:v", "1:90000",
                     "-progress", "pipe:1", "-nostats", "-f", "null", "-"], 30)

    result = decode(path, _TAIL_SECONDS)
    # Seeking into an open H.264 GOP can start before the necessary reference frames.
    # Prove the same tail again from further back; genuine decoder errors still fail.
    errors = result.stderr.strip().splitlines()
    if (duration > _TAIL_SECONDS + 2 and not result.returncode and errors
            and all(line.endswith("co located POCs unavailable") for line in errors)):
        if duration <= _TAIL_SECONDS * 2 + 2:
            result = decode(path, _TAIL_SECONDS * 2)
        else:
            with tempfile.TemporaryDirectory(prefix="tail-check-", dir=Path(path).parent) as directory:
                tail = Path(directory, "tail.mkv")
                extract = _run([ffmpeg, "-nostdin", "-v", "error", "-xerror", "-sseof", f"-{_TAIL_SECONDS * 2}",
                                "-i", str(path), "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy", str(tail)], 30)
                if extract.returncode or extract.stderr.strip():
                    raise ValueError("키프레임부터 파일 끝부분을 확인하지 못했습니다.")
                result = decode(tail)
    if (result.returncode or result.stderr.strip()
            or not any(line.partition("=")[2].strip().isdigit() and int(line.partition("=")[2]) > 0
                       for line in result.stdout.splitlines() if line.startswith("frame="))):
        raise ValueError("파일 끝부분을 정상적으로 디코딩하지 못했습니다.")
    return duration


def finalize_capture(raw, destination, ffmpeg, ffprobe, maximum_seconds):
    """Keep the capture until a verified result has its final name."""
    raw, destination = Path(raw), Path(destination)
    original = identity(raw)
    container = _FORMATS.get(destination.suffix.lower())
    if container is None:
        raise ValueError("지원하지 않는 녹화 컨테이너입니다.")
    required = {"video"}
    try:
        media, streams = _probe(ffprobe, raw)
        required.update({"audio"} & streams)
        # Direct output from fMP4 typically carries the broadcast clock rather than the capture clock.
        if "mov" in media["format_name"].split(","):
            raise ValueError("fragmented MP4 타임스탬프 정리 필요")
        duration = _verify(ffmpeg, ffprobe, raw, container, maximum_seconds, required)
    except (ValueError, KeyError, TypeError, subprocess.TimeoutExpired):
        stage = raw.with_name(raw.name + ".finalized" + destination.suffix)
        muxer = {"matroska": "matroska", "mp4": "mp4", "mpegts": "mpegts"}[container]
        timeout = min(7200, max(120, math.ceil(original["st_size"] / (1024 * 1024)) + 30))
        result = _run([ffmpeg, "-nostdin", "-v", "error", "-n",
                       "-fflags", "+genpts+discardcorrupt", "-err_detect", "ignore_err",
                       "-i", str(raw), "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy",
                       "-f", muxer, str(stage)], timeout)
        if result.returncode:
            raise ValueError(f"스트림 복사 마무리 실패 (FFmpeg {result.returncode})")
        duration = _verify(ffmpeg, ffprobe, stage, container, maximum_seconds, required)
        if not matches(raw, original):
            raise OSError("마무리 도중 임시 원본이 변경됐습니다.")
        rename_new(stage, destination)
        try:
            raw.unlink()
        except OSError as error:
            print(f"[CHZZK][FINALIZE][WARN] 검증된 결과는 저장됐으나 임시 원본을 정리하지 못했습니다. {error}")
        return duration, True

    if not matches(raw, original):
        raise OSError("검증 도중 임시 원본이 변경됐습니다.")
    rename_new(raw, destination)
    return duration, False
