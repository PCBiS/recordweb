"""Read-only recording state shared by all HTTP status responses.

Only recorder/FSM lifecycle code may clear manager data. A missing process
handle during startup, rotation or shutdown is not evidence that a task died.
"""
import os
import time
from collections import deque
from datetime import datetime

_last_warning = {}


class StallRecovery:
    """Bound reconnects for one broadcast within the owning watch task."""
    def __init__(self, limit):
        self.limit = limit
        self.key = None
        self.attempts = 0
        self.exhausted = False

    def may_record(self, key):
        if key is not None and self.key != key:
            self.key = key
            self.attempts = 0
            self.exhausted = False
        return not self.exhausted

    def retry(self):
        if self.attempts >= self.limit:
            self.exhausted = True
            return False
        self.attempts += 1
        return True


class ChzzkBroadcastRecovery(StallRecovery):
    """Distinguish a new broadcast from a missing or refreshed live identifier."""
    OFFLINE_GAP_SECONDS = 30
    IDENTITY_FIELDS = ("liveId", "playback_live_id", "_chzzk_open_date", "_chzzk_playback_open")

    def __init__(self, limit):
        super().__init__(limit)
        self.signals = {}
        self.previous_signals = deque(maxlen=8)
        self.closed_since = None
        self.confirmed_gap = False
        self.changed_broadcast = False

    def observe_closed(self, confirmed, now):
        if not confirmed:
            self.closed_since = None
        elif self.closed_since is None:
            self.closed_since = now
        elif now - self.closed_since >= self.OFFLINE_GAP_SECONDS:
            self.confirmed_gap = True

    def may_record(self, metadata):
        observed = {key: str(metadata[key]).strip() for key in self.IDENTITY_FIELDS if metadata.get(key)}
        shared = next((key for key in self.IDENTITY_FIELDS if key in observed and key in self.signals), None)
        self.changed_broadcast = (observed[shared] != self.signals[shared] if shared else self.confirmed_gap)
        if self.changed_broadcast:
            if shared and ((shared.startswith("_chzzk_") and observed[shared] < self.signals[shared])
                           or any(previous.get(shared) == observed[shared] for previous in self.previous_signals)):
                # A delayed observation of a previous broadcast must not rearm the current budget.
                self.changed_broadcast = False
                return False
            if self.signals:
                self.previous_signals.append(self.signals)
            self.signals = {}
            self.attempts = 0
            self.exhausted = False
        for key, value in observed.items():
            self.signals.setdefault(key, value)
        self.closed_since = None
        self.confirmed_gap = False
        return not self.exhausted


def exit_result(code, user_stopped, has_output, stalled=False):
    if user_stopped:
        return "user_stopped"
    if code != 0 or stalled or not has_output:
        return "failed"
    return "finished"

def snapshot(manager, fsm, channel):
    cid = channel['id']
    process = manager.get_tasks_process(cid)
    alive = process is not None and process.returncode is None
    tasks = [manager.get_tasks_worker(cid)]
    for name in ('watchTask', 'recordTask'):
        tasks.append(getattr(fsm, name, {}).get(cid))
    tasks.append(getattr(type(manager), 'tasks_segment', {}).get(cid))
    task_alive = any(task is not None and not task.done() for task in tasks)
    flag = bool(manager.get_status_recording(cid))
    fsm_state = fsm.getState(cid)
    stopped = manager.get_is_user_stopped(cid)
    diagnostics = getattr(manager, 'session_diagnostics', {}).get(cid, {})
    finishing = bool(diagnostics.get('capture_finalizing'))
    fault = diagnostics.get('capture_error') or (diagnostics.get('recording_fault') if not stopped or alive else None)
    recording = not fault and not finishing and bool(alive or (task_alive and (flag or fsm_state == 'RECORDING')))
    reserved = bool(not finishing and not recording and not manager.get_is_user_stopped(cid) and
                    (manager.get_status_reserved(cid) or fsm_state == 'WATCHING'))
    evidence = {'fsm': fsm_state, 'manager_recording': flag,
                'process_alive': alive, 'task_alive': task_alive}
    if not finishing and (flag != recording or (alive and fsm_state != 'RECORDING')):
        now = time.monotonic()
        key = (cid, tuple(evidence.values()))
        if now - _last_warning.get(key, -60) >= 60:
            print(f'[STATE-MISMATCH] channel={cid} evidence={evidence} resolved_recording={recording}')
            _last_warning[key] = now
    stamp = getattr(type(manager), 'recording_start_time', {}).get(cid)
    if isinstance(stamp, datetime):
        stamp = stamp.timestamp()
    try:
        elapsed = max(0, int(time.time() - float(stamp))) if stamp and recording else 0
        started = datetime.fromtimestamp(float(stamp)).strftime('%Y-%m-%d %H:%M:%S') if stamp else ''
    except (ValueError, TypeError, OSError, OverflowError):
        elapsed, started = 0, ''
    duration = f'{elapsed//3600:02d}:{elapsed%3600//60:02d}:{elapsed%60:02d}' if recording else ''
    filename = manager.get_recording_filename(cid) or ''
    jobs = getattr(type(manager), 'postprocess_active_jobs', {})
    active_post = [job for job in list(jobs.values()) if job.get('channel_id') == cid]
    history = getattr(type(manager), 'postprocess_recent_history', [])
    recent_post = next((job for job in reversed(list(history)) if job.get('channel_id') == cid), None)
    post = {'active_count':len(active_post),
            'last_result':recent_post.get('status') if recent_post else None}
    scheduled = channel.get('scheduled_start_time')
    if isinstance(scheduled, datetime):
        scheduled = scheduled.strftime('%Y-%m-%d %H:%M:%S')
    return {'recording': recording, 'reserved': reserved, 'duration': duration,
            'filename': os.path.basename(filename), 'status': 'success',
            'state': '녹화 마무리 중' if finishing else ('녹화 오류' if fault else ('녹화 중' if recording else ('예약녹화 중' if reserved else '대기 중'))),
            'finalizing': finishing,
            'recording_fault': fault,
            'recording_duration': duration or '00:00:00',
            'recording_start_time': started or '녹화 시작 시간이 설정되지 않았습니다.',
            'scheduled_start_time': scheduled or '예정된 라이브 방송이 없습니다.',
            'stop_requested': bool(manager.get_is_user_stopped(cid)), 'evidence': evidence,
            'postprocess':post}


def recording_page_fields(state):
    """Adapt a snapshot to the recording template's display fields."""
    return {
        'status': state['state'],
        'filename': state['filename'] or ('예약녹화 대기 중' if state['reserved'] else '녹화 중이 아닙니다.'),
        'duration': state['duration'],
    }
