from module.process_lifecycle import create_process, finish_before_cancel, signal_group
from module.recording_state import ChzzkBroadcastRecovery, exit_result
from module.chzzk_capture import finalize_capture
from module.postprocess_commit import commit_job, identity, matches, path_key, plan, reserve_output
from module.data_manager import resolveFFprobe
from module.cookie_checker import buildNaverCookieHeader, getChzzkCookieData
from module.media_validation import (
    get_media_duration, has_video_stream, output_has_minimum_size, probe_format_name,
    probe_video_codec as probeVcodec, probe_video_height as probeVideoHeight,
    probe_video_size as probeVideoSize,
)
from module.chzzk_hls_selector import hls_resolution_selector
from module.linux_gpu import LinuxGpuError, QSV, NVENC, QSV_UPLOAD, gpu_failure, linux_device_args
import os
import shlex
import asyncio
import re
import subprocess
import sys
import httpx
import contextlib
import signal
import locale
import json 
import time
import tempfile
import hashlib
import math 

from datetime import datetime

from module.data_manager import (
    RecorderManager, loadAccount, saveAccount, loadCookies, saveCookies, toBool,
    loadChannels, saveChannels, loadConfig, saveConfig, uniqueFilename, getConfigLoadStatus,
    notifyEvent, checkDiskSpaceLow, last_notified_state, base_directory, CONFIG_PATH, CHANNELS_PATH,
    COOKIE_PATH, LOGIN_PATH, getFFmpeg, getFFprobe, getStreamlink, validateMediaDirectory
)


# RecorderManager 인스턴스 생성
recorder_manager = RecorderManager()

# 후처리 백그라운드 태스크 참조 보관용
_postprocess_background_tasks: set[asyncio.Task] = set()
_postprocess_claims = {}
# Streamlink opens its output asynchronously, after the command is built.
_chzzk_output_paths = set()


def claimPostprocess(path):
    key = path_key(path)
    if key in _postprocess_claims:
        return None
    owner = object()
    _postprocess_claims[key] = owner
    return key, owner


def releasePostprocess(claim):
    if claim is not None and _postprocess_claims.get(claim[0]) is claim[1]:
        del _postprocess_claims[claim[0]]


def queuePostprocess(path, channel_id, channel_name, config):
    try:
        source_identity = identity(path)
    except (OSError, ValueError) as exc:
        print(f"[POST][ERROR] 후처리 원본 확인 실패: {exc}")
        return False
    claim = claimPostprocess(path)
    if claim is None:
        return False
    work = handlePostProcessing(path, channel_id, channel_name, config,
                                source_identity=source_identity, claim=claim)
    try:
        task = asyncio.create_task(work)
    except Exception:
        work.close()
        releasePostprocess(claim)
        raise
    task.add_done_callback(lambda _: releasePostprocess(claim))
    trackPostprocessTask(task)
    return True

def trackPostprocessTask(task: asyncio.Task) -> asyncio.Task:
    _postprocess_background_tasks.add(task)
    task.add_done_callback(_postprocess_background_tasks.discard)
    return task


async def shutdownPostprocessTasks():
    tasks = list(_postprocess_background_tasks)
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)

# 기본 언어인코딩 설정
default_encoding = locale.getpreferredencoding()

_httpxClient = None
_httpxLock = None 

# 분할녹화시 꼬리파일 방지 쿨다운
TAIL_GUARD_COOLDOWN_SEC = 60 

CHZZK_STREAM_QUALITY_RE = re.compile(
    r"^(best|worst|(?:144|240|360|480|720|1080|1440|2160)p)$",
    re.IGNORECASE
)

# 파일명에 들어가는 텍스트 길이 제한
FILENAME_PART_LIMIT = 60
FILENAME_LIVE_TITLE_LIMIT = 45
FILENAME_CHANNEL_NAME_LIMIT = 40

def sanitizeChzzkStreamQuality(value, fallback: str = "best") -> str:
    q = str(value or "").strip().lower()

    if CHZZK_STREAM_QUALITY_RE.fullmatch(q):
        return q

    m = re.match(r"^(144|240|360|480|720|1080|1440|2160)(?:p)?(?:\d{2,3})?$", q)
    if m:
        return f"{m.group(1)}p"

    return fallback


def chzzkStreamlinkSelector(channel, metadata):
    metadata = metadata or {}
    configured = sanitizeChzzkStreamQuality(channel.get("quality"))
    quality = sanitizeChzzkStreamQuality(metadata.get("resolved_quality"), configured)
    return hls_resolution_selector(quality, metadata.get("frame_rate"))


def sanitizeFilenamePart(value, fallback="recording", limit=FILENAME_PART_LIMIT):
    text = str(value or fallback).replace("\r", " ").replace("\n", " ")
    text = re.sub(r'[\\/*?:"<>|+]', "_", text)
    text = re.sub(r"\s+", " ", text).strip(" ._")
    return (text or fallback)[:limit]


def sanitizeGeneratedFilename(filename, fallback_ext=".ts"):
    text = str(filename or "").replace("\r", " ").replace("\n", " ")
    text = text.replace("/", "_").replace("\\", "_")
    base, ext = os.path.splitext(text)
    base = re.sub(r'[:*?"<>|]+', "_", base)
    base = re.sub(r"\s+", " ", base).strip(" ._")

    if not ext:
        ext = fallback_ext or ""
    if ext and not ext.startswith("."):
        ext = "." + ext

    return (base or "recording") + ext


def makeChzzkQualityLabel(video_height) -> str:
    try:
        h = int(float(video_height))
    except Exception:
        return ""

    if h <= 0:
        return ""

    return f"{h}p"


def makeChzzkFrameLabel(video_frame_rate) -> str:
    try:
        fps = int(round(float(video_frame_rate)))
    except Exception:
        return "알 수 없는 프레임 레이트"

    if fps <= 0:
        return "알 수 없는 프레임 레이트"

    return str(fps)



# 재탐색 지터 & PROBE 동시성 상한 전역
PROBE_MAX_CONCURRENCY = int(os.environ.get("PROBE_MAX_CONCURRENCY", "4"))   # 기본 4
_probe_sem = asyncio.Semaphore(max(1, PROBE_MAX_CONCURRENCY))               # HLS probe 동시 상한

START_MONO = time.monotonic()                                               # 절대시간 앵커(페이즈 기준)
JITTER_RATIO = float(os.environ.get("RECHECK_JITTER_RATIO", "0.15"))        # 지터 비율(기본 15%)
_JITTER_PHASE = {}                                                          # {channel_id: phase(sec)} 채널별 초기 위상 캐시


# 헤더에 세션 정보를 추가하는 함수
def buildChzzkCookieHeader(cookies: dict | None) -> str:
    return buildNaverCookieHeader(cookies)


def getAuthtoHeaders(cookies):
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' if os.name == 'nt' else 'Mozilla/5.0 (X11; Linux x86_64)'
    headers = {
        'User-Agent': ua,
        'Accept': 'application/json, text/plain, */*',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
    }

    # chzzk 쿠키만 꺼내 Cookie 헤더로 구성
    cookie_header = buildChzzkCookieHeader(cookies)
    if cookie_header:
        headers['Cookie'] = cookie_header

    return headers


async def getHttpxClient() -> httpx.AsyncClient:
    global _httpxClient, _httpxLock
    if _httpxLock is None:
        _httpxLock = asyncio.Lock()

    async with _httpxLock:
        if _httpxClient is None:
            # httpx 버전 호환: Limits 파라미터 이름
            try:
                limits = httpx.Limits(max_keepalive_connections=30, max_connections=30)
            except TypeError:
                limits = httpx.Limits(max_keepalive=30, max_connections=30)

            # Timeout: default + 4개 모두 명시 (0.27에서도 안전)
            timeout = httpx.Timeout(10.0, connect=3.0, read=8.0, write=8.0, pool=3.0)

            _httpxClient = httpx.AsyncClient(
                timeout=timeout,
                limits=limits,
                headers={"User-Agent": "recordWEB/1.0"},
                follow_redirects=True,
            )
        return _httpxClient


async def closeHttpxClient():
    global _httpxClient
    if _httpxClient is not None:
        await _httpxClient.aclose()
        _httpxClient = None


async def getJsonWithRetry(url: str, *, headers: dict | None = None,
                           retries: int = 3,
                           connect_timeout: float = 3.0,
                           read_timeout: float = 8.0) -> tuple[int | None, dict | None]:

    client = await getHttpxClient()
    backoff = 0.7
    for attempt in range(retries + 1):
        try:
            req_timeout = httpx.Timeout(10.0, connect=connect_timeout, read=read_timeout, write=8.0, pool=3.0)

            resp = await client.get(url, headers=headers, timeout=req_timeout)
            if resp.status_code == 200:
                try:
                    return 200, resp.json()
                except Exception:
                    return 200, None
            if resp.status_code in (404, 410):
                return resp.status_code, None
            if resp.status_code in (429, 500, 502, 503, 504) and attempt < retries:
                await asyncio.sleep(backoff); backoff *= 1.8
                continue
            return resp.status_code, None
        except httpx.RequestError:
            if attempt < retries:
                await asyncio.sleep(backoff); backoff *= 1.8
                continue
            return None, None


async def checkUrlOkWithRetry(url: str, *, headers: dict | None = None,
                              retries: int = 2) -> bool:

    client = await getHttpxClient()
    backoff = 0.5
    for attempt in range(retries + 1):
        try:
            req_timeout = httpx.Timeout(6.0, connect=2.0, read=3.5, write=3.0, pool=2.0)

            r = await client.get(url, headers=headers, timeout=req_timeout)
            if r.status_code == 200:
                return True
            if r.status_code in (429, 500, 502, 503, 504) and attempt < retries:
                await asyncio.sleep(backoff); backoff *= 1.8
                continue
            return False
        except httpx.RequestError:
            if attempt < retries:
                await asyncio.sleep(backoff); backoff *= 1.8
                continue
            return False


# 라이브 메타데이터를 가져오는 함수
async def getLiveMetadata(channel, cookies):
    try:
        cookies = await asyncio.to_thread(loadCookies)
        headers = getAuthtoHeaders(cookies)
        url = f"https://api.chzzk.naver.com/service/v3/channels/{channel['id']}/live-detail?_={int(time.time() * 1000)}"

        # 재시도/백오프 + 커넥션 재사용
        status, body = await getJsonWithRetry(url, headers=headers)
        info = RecorderManager.session_diagnostics.setdefault(channel["id"], {})
        info["last_http_status"] = status
        if status == 200:
            info["last_success"] = time.time()
        else:
            info["last_error_stage"] = "메타데이터 조회"
            info["last_error_time"] = time.time()
            info["error_category"] = ("네트워크 연결 실패" if status is None else
                                      "인증·쿠키 오류" if status in (401, 403) else
                                      "방송 종료/비공개/삭제" if status in (404, 410) else
                                      "서버 5xx" if status >= 500 else "요청 실패")

        if status is None:
            # 네트워크 레벨 최종 실패
            print(f"요청 오류 발생: {url}")
            return {"thumbnail_url": "/static/img/default_thumbnail.png", "name": channel.get('name') or ""}

        if status in (404, 410):
            print(f"[INFO] {channel['name']} 현재 방송이 종료된 상태(CLOSE) 이므로 세부정보가 없습니다.")
            return {
                "status": "CLOSE",
                "_chzzk_confirmed_closed": True,
                "thumbnail_url": "/static/img/liveclosed_thumbnail.png",
                "name": channel.get("name") or "",
                "live_title": "방송 제목 없음",
                "category": "카테고리 없음",
            }

        if status != 200 or not isinstance(body, dict):
            print(f"[WARN] {channel['name']} 메타데이터 조회 실패 http={status}")
            return None

        metadata_content = (body or {}).get("content")
        if not metadata_content:
            print(f"{channel['name']} 채널의 메타데이터가 없습니다 (content가 None).")
            return None

        # 방송 기본 정보
        live_title = metadata_content.get("liveTitle", "방송 제목 없음")
        category   = metadata_content.get("liveCategoryValue", "카테고리 없음")
        metadata_content["watchPartyNo"]  = metadata_content.get("watchPartyNo")
        metadata_content["watchPartyTag"] = metadata_content.get("watchPartyTag") or ""


        # 썸네일
        live_image_url = metadata_content.get("liveImageUrl")
        if live_image_url:
            thumbnail_url = live_image_url.format(type="360")
            print(f"Generated thumbnail URL: {thumbnail_url}")
        else:
            thumbnail_url = "/static/img/default_thumbnail.png"
            print("Using default thumbnail as no liveImageUrl provided.")

        # 성인 채널이면 쿠키 검증
        if metadata_content.get("adult", False) and thumbnail_url.startswith(("http://","https://")):
            ok = await checkUrlOkWithRetry(thumbnail_url, headers=headers, retries=2)
            if not ok:
                print("쿠키값이 유효하지 않습니다. 기본 썸네일을 사용합니다.")
                thumbnail_url = "/static/img/default_thumbnail.png"

        # 방송 상태에 따라 닫힘 썸네일
        if metadata_content.get("status") != "OPEN":
            thumbnail_url = "/static/img/liveclosed_thumbnail.png"
            print(f"Final thumbnail URL for {channel['name']}: {thumbnail_url}")
        elif not thumbnail_url:
            thumbnail_url = "/static/img/default_thumbnail.png"
            print("Thumbnail URL is empty, using default thumbnail.")

        # 이름 보존
        if channel.get('name'):
            metadata_content["name"] = channel["name"]
        else:
            print(f"채널 이름이 None이거나 빈 값입니다: {channel['id']}")

        metadata_content["thumbnail_url"] = thumbnail_url
        metadata_content["liveTitle"]    = live_title
        metadata_content["category"]      = category

        playback_json = {}
        try:
            playback_json = json.loads(metadata_content.get("livePlaybackJson") or "{}")
        except Exception:
            playback_json = {}

        playback_meta = playback_json.get("meta") or {}
        playback_live = playback_json.get("live") or {}

        metadata_content["playback_live_id"] = str(playback_meta.get("liveId") or "")
        metadata_content["playback_open"] = playback_live.get("open")
        metadata_content["playback_start"] = playback_live.get("start")

        def _parse_chzzk_dt(value):
            if not value:
                return None
            text = str(value).strip().replace("T", " ")
            text = text.split("+", 1)[0].replace("Z", "")
            text = text.split(".", 1)[0]
            try:
                return datetime.strptime(text, "%Y-%m-%d %H:%M:%S")
            except ValueError:
                return None

        opened = _parse_chzzk_dt(metadata_content.get("openDate"))
        playback_opened = _parse_chzzk_dt(metadata_content.get("playback_open"))
        if opened:
            metadata_content["_chzzk_open_date"] = opened.isoformat()
        if playback_opened:
            metadata_content["_chzzk_playback_open"] = playback_opened.isoformat()
        metadata_content["_chzzk_confirmed_closed"] = metadata_content.get("status") == "CLOSE"
        broadcast_dt = (
            playback_opened
            or _parse_chzzk_dt(metadata_content.get("playback_start"))
            or opened
            or datetime.now()
        )

        metadata_content["start_time"] = broadcast_dt.strftime("%Y-%m-%d")
        metadata_content["broadcast_time"] = broadcast_dt.strftime("%y%m%d_%H%M%S")

        # 품질 선택
        user_selected = (channel.get('quality') or 'best').strip().lower()
        frame_rate = "알 수 없는 프레임 레이트"
        record_quality_for_name = "알 수 없는 품질"
        resolved_quality_for_cmd = user_selected

        if metadata_content.get("livePlaybackJson") is None:
            metadata_content["status"] = metadata_content.get("status", "CLOSE")
            metadata_content["record_quality"] = "알 수 없는 품질"
            metadata_content["frame_rate"] = "알 수 없는 프레임 레이트"

            # 방송중인데 playback 정보만 늦게 내려오는 경우에만 경고로 판단
            if metadata_content.get("status") == "OPEN":
                print(f"[WARNING] {channel['name']} livePlaybackJson 없음. HLS 프로브로 재확인합니다.")
                metadata_content["_playback_missing"] = True

            return metadata_content

        playback_json = playback_json or json.loads(metadata_content["livePlaybackJson"])
        encoding_tracks = playback_json.get("media", [])
        variants_by_label = {}

        for track in encoding_tracks:
            for enc in track.get("encodingTrack", []):
                try:
                    if enc.get("audioOnly"):
                        continue

                    h = int(float(enc.get("videoHeight")))
                    label = makeChzzkQualityLabel(h)
                    if not label:
                        continue

                    fps = makeChzzkFrameLabel(enc.get("videoFrameRate"))
                    raw_track_id = str(enc.get("encodingTrackId") or "").strip().lower()

                    try:
                        bitrate = int(enc.get("videoBitRate") or 0)
                    except Exception:
                        bitrate = 0

                    item = {
                        "height": h,
                        "label": label,
                        "fps": fps,
                        "track_id": raw_track_id,
                        "bitrate": bitrate,
                    }

                    # HLS/LLHLS 중복 품질 제거
                    old = variants_by_label.get(label)
                    if old is None:
                        variants_by_label[label] = item
                    else:
                        old_fps = int(old["fps"]) if str(old.get("fps", "")).isdigit() else 0
                        new_fps = int(fps) if str(fps).isdigit() else 0

                        if (h, new_fps, bitrate) > (old["height"], old_fps, old.get("bitrate", 0)):
                            variants_by_label[label] = item

                except Exception:
                    continue

        variants = sorted(
            variants_by_label.values(),
            key=lambda x: (x["height"], int(x["fps"]) if str(x["fps"]).isdigit() else 0)
        )

        if not variants:
            metadata_content["record_quality"] = "알 수 없는 품질"
            metadata_content["frame_rate"] = frame_rate
            metadata_content["available_qualities"] = []
            metadata_content["resolved_quality"] = sanitizeChzzkStreamQuality(user_selected, "best")
            return metadata_content

        available_labels = [
            v["label"]
            for v in sorted(variants, key=lambda x: x["height"], reverse=True)
        ]

        user_selected_raw = str(channel.get("quality") or "best").strip().lower()
        user_selected = sanitizeChzzkStreamQuality(user_selected_raw, "best")

        def _fps_num(v):
            return int(v["fps"]) if str(v.get("fps", "")).isdigit() else 0

        def _choose_best():
            return max(variants, key=lambda x: (x["height"], _fps_num(x), x.get("bitrate", 0)))

        def _choose_worst():
            return min(variants, key=lambda x: (x["height"], _fps_num(x), x.get("bitrate", 0)))

        def _find_by_label(label: str):
            label = str(label or "").strip().lower()
            for v in variants:
                if v["label"].lower() == label:
                    return v
            return None

        def _find_by_track_id(track_id: str):
            track_id = str(track_id or "").strip().lower()
            if not track_id:
                return None

            for v in variants:
                if v.get("track_id") == track_id:
                    return v
            return None

        chosen = None
        resolved_quality_for_cmd = "best"
        chosen = _find_by_track_id(user_selected_raw)

        if chosen is not None:
            resolved_quality_for_cmd = chosen["label"]

        elif user_selected == "best":
            chosen = _choose_best()
            resolved_quality_for_cmd = "best"

        elif user_selected == "worst":
            chosen = _choose_worst()
            resolved_quality_for_cmd = "worst"

        else:
            chosen = _find_by_label(user_selected)

            if chosen is None:
                m = re.match(r"(\d+)", user_selected)
                target = int(m.group(1)) if m else None

                if target is not None:
                    candidates = [v for v in variants if v["height"] <= target]
                    if candidates:
                        chosen = max(candidates, key=lambda x: (x["height"], _fps_num(x), x.get("bitrate", 0)))

            if chosen is not None:
                resolved_quality_for_cmd = chosen["label"]
            else:
                chosen = _choose_best()
                resolved_quality_for_cmd = "best"

        record_quality_for_name = chosen["label"]
        frame_rate = chosen["fps"]

        if user_selected_raw and user_selected_raw != resolved_quality_for_cmd and not CHZZK_STREAM_QUALITY_RE.fullmatch(user_selected_raw):
            print(
                f"[WARN] {channel.get('name')} 비표준 치지직 품질값 보정: "
                f"{user_selected_raw!r} -> {resolved_quality_for_cmd!r}"
            )

        metadata_content["record_quality"]      = record_quality_for_name
        metadata_content["frame_rate"]          = frame_rate
        metadata_content["available_qualities"] = available_labels
        metadata_content["resolved_quality"]    = sanitizeChzzkStreamQuality(resolved_quality_for_cmd, "best")
        metadata_content["is_live"]             = (metadata_content.get("status") == "OPEN")

        return metadata_content

    except httpx.HTTPStatusError as e:
        print(f"HTTP 오류 발생: {e.response.status_code}")
    except httpx.RequestError as e:
        print(f"요청 오류 발생: {getattr(e, 'request', None) and e.request.url}")

    return {"thumbnail_url": "/static/img/default_thumbnail.png", "name": channel.get('name') or ""}


def isUnresolvedQualityMetadata(metadata: dict | None) -> bool:
    if not metadata:
        return True

    if metadata.get("status") != "OPEN":
        return False

    record_quality = str(metadata.get("record_quality") or "").strip()
    frame_rate = str(metadata.get("frame_rate") or "").strip()

    if not metadata.get("livePlaybackJson"):
        return True

    if not record_quality or "알 수 없는" in record_quality or record_quality.startswith("Unknown"):
        return True

    if not frame_rate or "알 수 없는" in frame_rate or frame_rate.startswith("Unknown"):
        return True

    return False


def normalizeQualityNameParts(channel: dict, metadata: dict | None) -> tuple[str, str]:
    metadata = metadata or {}

    raw_quality = str(metadata.get("record_quality") or "").strip()
    raw_frame = str(metadata.get("frame_rate") or "").strip()

    selected_quality = str(
        metadata.get("resolved_quality")
        or channel.get("quality")
        or "best"
    ).strip()

    def is_unknown(value: str) -> bool:
        return (
            not value
            or "알 수 없는" in value
            or value.startswith("Unknown")
        )

    if is_unknown(raw_quality):
        if selected_quality and selected_quality.lower() != "best":
            m = re.match(r"(\d+)", selected_quality)
            raw_quality = f"{m.group(1)}p" if m else selected_quality
        else:
            raw_quality = "best"

    if is_unknown(raw_frame):
        raw_frame = ""

    return raw_quality, raw_frame


def isUnstableChzzkIdentityMetadata(metadata: dict | None) -> bool:
    if not isinstance(metadata, dict):
        return True

    if metadata.get("status") != "OPEN":
        return True

    if metadata.get("_playback_missing"):
        return True

    if not metadata.get("livePlaybackJson"):
        return True

    live_title = str(metadata.get("liveTitle") or "").strip()
    if not live_title or live_title in ("방송 제목 없음", "녹화"):
        return True

    start_time = str(metadata.get("start_time") or "").strip()
    broadcast_time = str(metadata.get("broadcast_time") or "").strip()

    if not start_time or start_time == "UnknownTime":
        return True

    if not broadcast_time:
        return True

    return False


def applySafeChzzkFilenameMetadata(channel: dict, metadata: dict | None, recording_time: str) -> dict:
    if not isinstance(metadata, dict):
        metadata = {}

    if isUnstableChzzkIdentityMetadata(metadata):
        now_dt = datetime.now()
        metadata["status"] = "OPEN"
        metadata["liveTitle"] = channel.get("name") or "녹화"
        metadata["start_time"] = now_dt.strftime("%Y-%m-%d")
        metadata["broadcast_time"] = recording_time
    else:
        metadata["liveTitle"] = str(metadata.get("liveTitle") or channel.get("name") or "녹화").strip()
        metadata["start_time"] = str(metadata.get("start_time") or datetime.now().strftime("%Y-%m-%d")).strip()
        metadata["broadcast_time"] = str(metadata.get("broadcast_time") or recording_time).strip()

    record_quality, frame_rate = normalizeQualityNameParts(channel, metadata)
    metadata["record_quality"] = record_quality
    metadata["frame_rate"] = frame_rate

    return metadata


async def waitStableChzzkMetadata(channel: dict, cookies: dict,
                                  first_metadata: dict | None = None,
                                  retries: int = 4,
                                  delay: float = 1.5) -> dict | None:
    metadata = first_metadata
    last_signature = None

    for attempt in range(retries + 1):
        if metadata and metadata.get("status") != "OPEN":
            return metadata

        if metadata:
            signature = (
                str(metadata.get("liveId") or ""),
                str(metadata.get("playback_live_id") or ""),
                str(metadata.get("liveTitle") or ""),
                str(metadata.get("broadcast_time") or ""),
            )

            quality_ready = not isUnresolvedQualityMetadata(metadata)
            identity_ready = not isUnstableChzzkIdentityMetadata(metadata)

            if quality_ready and identity_ready and signature == last_signature:
                return metadata

            last_signature = signature

        if attempt >= retries:
            break

        print(f"[META][WAIT] {channel.get('name')} 라이브 메타데이터 안정화 대기 중... ({attempt + 1}/{retries})")
        await asyncio.sleep(delay)
        metadata = await getLiveMetadata(channel, cookies)

    if metadata:
        record_quality, frame_rate = normalizeQualityNameParts(channel, metadata)
        metadata["record_quality"] = record_quality
        metadata["frame_rate"] = frame_rate

    return metadata


def buildCommand(channel, metadata, recording_time, cookies, filenamePattern, plugin_type, timemachine_time_shift):
    if channel is None:
        print(f"[ERROR] 전달된 채널이 None입니다. 명령을 생성할 수 없습니다.")
        return []

    # base path 확정
    output_dir_abs_path = os.path.join(base_directory, validateMediaDirectory(channel.get('output_dir', './output')))

    metadata = applySafeChzzkFilenameMetadata(channel, metadata, recording_time)

    # 1) 플러그인/시프트 정규화
    normalized_plugin = (plugin_type or "basic").lower()
    if normalized_plugin not in ("basic", "timemachine_plus"):
        normalized_plugin = "basic"

    try:
        _shift = int(timemachine_time_shift or 0)
    except Exception:
        _shift = 0

    normalized_shift = max(0, min(10, _shift)) if normalized_plugin == "basic" else max(0, min(3600, _shift))

    # 2) 공통 값 계산
    stream_url = f"https://chzzk.naver.com/live/{channel['id']}"
    ffmpeg_path = getFFmpeg()
    streamlink_path = getStreamlink()

    resolved_quality = chzzkStreamlinkSelector(channel, metadata)

    file_extension = channel.get('extension', '.ts')

    # 3) 파일명 생성
    live_title = metadata.get("liveTitle") or "녹화"
    safe_live_title = sanitizeFilenamePart(live_title, "녹화", FILENAME_LIVE_TITLE_LIMIT)
    safe_channel_name = sanitizeFilenamePart(
        channel.get("name") or channel.get("id") or "chzzk", "chzzk", FILENAME_CHANNEL_NAME_LIMIT)

    start_time = metadata.get('start_time', 'UnknownTime')
    broadcast_time = metadata.get("broadcast_time") or recording_time

    record_quality_for_name, frame_rate_for_name = normalizeQualityNameParts(channel, metadata)

    filename = filenamePattern.format(
        recording_time=recording_time,
        start_time=start_time,
        broadcast_time=broadcast_time,
        safe_live_title=safe_live_title,
        channel_name=safe_channel_name,
        record_quality=sanitizeFilenamePart(record_quality_for_name, "best", 20),
        frame_rate=sanitizeFilenamePart(frame_rate_for_name, "", 10),
        file_extension=file_extension
    )

    filename = sanitizeGeneratedFilename(filename, file_extension)

    checkDiskSpaceLow(
        output_dir_abs_path,
        channel_id=channel.get("id"),
        channel_name=channel.get("name") or channel.get("id")
    )

    unique_filename = uniqueFilename(output_dir_abs_path, filename, add_suffix=True, reserved=_chzzk_output_paths)
    output_path = os.path.join(output_dir_abs_path, unique_filename)
    channel["output_path"] = output_path


    # 4) Streamlink 커맨드 생성
    cmd_list = [
        streamlink_path,
        "--ffmpeg-copyts",
        "--ffmpeg-ffmpeg", ffmpeg_path,
        "--progress=force",
        "--stream-segment-timeout", "15",
        "--stream-segment-attempts", "12",
        "--stream-segmented-queue-deadline", "0",
        "--stream-timeout", "60",
    ]
    # 공통 옵션
    cmd_list.extend(buildCommonPluginArgs(channel, cookies, normalized_plugin=normalized_plugin))

    if normalized_plugin in ("timemachine_plus",):
        cmd_list.append("--hls-live-restart")
        if normalized_shift > 0:
            cmd_list.extend(["--hls-start-offset", str(normalized_shift)])

    # URL/품질/출력
    cmd_list.extend([stream_url, resolved_quality, "-o", output_path])

    print(f"[DEBUG] plugin_type={normalized_plugin}, hls-live-restart=ON, hls-start-offset={normalized_shift}")
    return cmd_list


# 공용 헬퍼
def buildStreamlinkEnv(plugin_type, timemachine_time_shift):
    normalized_plugin = (plugin_type or "basic").lower()
    if normalized_plugin not in ("basic", "timemachine_plus"):
        normalized_plugin = "basic"
    try:
        _shift = int(timemachine_time_shift or 0)
    except Exception:
        _shift = 0
    normalized_shift = max(0, min(10, _shift)) if normalized_plugin == "basic" else max(0, min(3600, _shift))

    env = os.environ.copy()
    env["RWEB_TM_SHIFT"] = str(normalized_shift)
    return env


async def finishChzzkCapture(raw, destination, started, plugin_type, diagnostics):
    diagnostics["capture_finalizing"] = True
    try:
        elapsed = time.monotonic() - started
        # Live restart may include a long section from before the recorder was started.
        maximum_seconds = None if plugin_type == "timemachine_plus" else elapsed + max(30, elapsed * .20)
        duration, remuxed = await asyncio.to_thread(finalize_capture, raw, destination, getFFmpeg(), getFFprobe(), maximum_seconds)
        diagnostics["capture_duration"] = duration
        print(f"[CHZZK][FINALIZE] {destination} duration={duration:.3f}s remux={remuxed}")
        return True
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        message = "녹화 무결성 확인 실패 · 임시 원본은 정리하지 않았습니다."
        diagnostics.update(capture_error=message, recording_fault=message)
        print(f"[CHZZK][FINALIZE][ERROR] {raw}: {error}")
        return False
    finally:
        diagnostics.pop("capture_finalizing", None)


# 실제 하위 프로세스가 살아 있는지 확인
def procAlive(channel_id: str) -> bool:
    try:
        p = recorder_manager.get_tasks_process(channel_id)
        return (p is not None) and (p.returncode is None)
    except Exception:
        return False


# stdout을 읽는 함수
async def read_stdout(proc, channel_id, stream_ended_flag):
    try:
        while True:
            stdout_line = await proc.stdout.readline()
            if not stdout_line:
                break

            # 시스템의 기본 인코딩으로 디코딩
            decoded_stdout = stdout_line.decode(default_encoding, errors='replace').strip()

            # 출력 내용을 콘솔에 출력
            print(decoded_stdout)

            # "Stream ended" 메시지를 감지하면 플래그 설정 및 루프 종료
            if "Stream ended" in decoded_stdout:
                print(f"[DEBUG] {channel_id} 채널에서 'Stream ended' 메시지가 감지되었습니다.")
                stream_ended_flag.set()  # Stream ended 플래그 설정
                break

    except Exception as e:
        print(f"[ERROR] read_stdout 중 오류 발생: {str(e)}")


# stderr를 읽는 함수
async def read_stderr(proc, channel_id, transient_end_flag: asyncio.Event | None = None):
    try:
        while True:
            stderr_chunk = await proc.stderr.read(1024)
            if not stderr_chunk:
                break

            try:
                decoded_stderr = stderr_chunk.decode(default_encoding, errors='replace')
            except UnicodeDecodeError:
                decoded_stderr = stderr_chunk.decode('utf-8', errors='replace')

            # 콘솔로 그대로 출력
            print(decoded_stderr, end='')

            # ★ 패턴 매칭: 404/403 세그먼트 실패, 세그먼트 중단 경고 등 → 일시 장애로 간주
            if transient_end_flag is not None:
                s = decoded_stderr
                if (
                    ("Failed to fetch segment" in s and ("404" in s or "403" in s or "416" in s))
                    or ("No new segments in playlist" in s)     
                    or ("Read timeout" in s)                         
                ):
                    try:
                        transient_end_flag.set()
                    except Exception:
                        pass

    except Exception as e:
        print(f"[ERROR] read_stderr 중 오류 발생: {str(e)}")


def buildChannelUrl(channel):
    # 녹화 명령과 동일한 URL 규칙 사용
    return f"https://chzzk.naver.com/live/{channel['id']}"


def buildCommonPluginArgs(channel, cookies=None, *, normalized_plugin: str = "basic"):
    args = []

    # chzzk 쿠키만 꺼내 Streamlink Cookie 헤더로 구성
    cookie_value = buildChzzkCookieHeader(cookies)
    if cookie_value:
        args.extend(["--http-header", f"Cookie={cookie_value}"])

    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' if os.name == 'nt' else 'Mozilla/5.0 (X11; Linux x86_64)'
    args.extend(["--http-header", "Referer=https://chzzk.naver.com/"])
    args.extend(["--http-header", "Origin=https://chzzk.naver.com"])
    args.extend(["--http-header", f"User-Agent={ua}"])

    # plugin-dir
    plugin_dir = os.path.join(
        base_directory, "dependent", "plugin",
        "timemachine_plus" if normalized_plugin == "timemachine_plus" else "basic"
    )
    if os.path.isdir(plugin_dir):
        args.extend(["--plugin-dir", plugin_dir])

    return args



# 세그먼트 중지시 일시적인 타임아웃인지 확인 함수
async def probeStream(channel, cookies=None, timeout_sec=10):
    streamlink_path = getStreamlink()
    url = buildChannelUrl(channel)
    quality = "best"

    # plugin만 정규화 
    cfg = loadConfig() or {}
    normalized_plugin = (cfg.get("plugin_type") or "basic").lower()
    if normalized_plugin not in ("basic", "timemachine_plus"):
        normalized_plugin = "basic"

    # 옵션(플러그인/쿠키) → URL → 기타 옵션 순서
    cmd = [streamlink_path]
    cmd.extend(buildCommonPluginArgs(channel, cookies, normalized_plugin=normalized_plugin))
    cmd.extend([
        url, quality,
        "--stdout",
        "--stream-segment-timeout", "3",
        "--stream-segment-attempts", "1",
        "--stream-timeout", str(timeout_sec),
        "--hls-playlist-reload-attempts", "1",
    ])

    # probeStream 하이라이트 
    proc = await create_process(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL
    )

    try:
        # 첫 바이트만 빨리 확인
        try:
            first = await asyncio.wait_for(proc.stdout.read(1), timeout=timeout_sec)
        except asyncio.TimeoutError:
            first = b""

        return bool(first)

    finally:
        # 항상 깔끔하게 종료 + 파이프 드레인
        with contextlib.suppress(Exception):
            if proc.returncode is None:
                proc.kill()  
            if proc.stdout or proc.stderr:
                try:
                    await asyncio.wait_for(proc.communicate(), timeout=1.5)
                except asyncio.TimeoutError:
                    # 종료 대기
                    await proc.wait()
            else:
                await proc.wait()



# PROBE 세마포어 논블로킹 래퍼: 바쁘면 이번 라운드 스킵
async def probeStreamBounded(channel, cookies=None, timeout_sec=10):
    channel["_last_probe_reason"] = None
    try:
        await asyncio.wait_for(_probe_sem.acquire(), timeout=0.001)  # 대기 0
    except asyncio.TimeoutError:
        channel["_last_probe_reason"] = "skip"
        print(f"[INFO] PROBE 슬롯 바쁨 → 이번 라운드 스킵: {channel.get('name')}")
        return False
    try:
        ok = await asyncio.wait_for(
            probeStream(channel, cookies, timeout_sec=timeout_sec),
            timeout=timeout_sec + 2
        )
        channel["_last_probe_reason"] = "ok" if ok else "fail"
        return ok
    except asyncio.TimeoutError:
        channel["_last_probe_reason"] = "timeout"
        print(f"[WARN] HLS probe timeout: {channel.get('name')} ({timeout_sec}s)")
        return False
    finally:
        _probe_sem.release()



async def gracefulTerminate(proc: asyncio.subprocess.Process, timeout: float = 5.0):
    if not proc or proc.returncode is not None:
        return
    try:
        if os.name == "nt":
            # 1) CTRL_BREAK → 2) terminate → 3) kill 순
            try:
                proc.send_signal(signal.CTRL_BREAK_EVENT)
                await asyncio.wait_for(proc.wait(), timeout=timeout)
            except Exception:
                try:
                    proc.terminate()
                    await asyncio.wait_for(proc.wait(), timeout=2.0)
                except Exception:
                    proc.kill()
                    await asyncio.wait_for(proc.wait(), timeout=3)
        else:
            # POSIX: TERM → KILL
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except Exception:
                proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except Exception:
                    proc.kill()
                await asyncio.wait_for(proc.wait(), timeout=3)
    finally:
        # 파이프 정리 짧게 드레인 시도
        with contextlib.suppress(Exception):
            if (getattr(proc, "stdout", None) is not None) or (getattr(proc, "stderr", None) is not None):
                try:
                    await asyncio.wait_for(proc.communicate(), timeout=1.5)
                except asyncio.TimeoutError:
                    pass


async def _cancel_task_safely(task: asyncio.Task | None) -> None:
    if task is None:
        return
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass
    except Exception as exc:
        print(f"[REC][WARN] 보조 작업 종료 오류: {type(exc).__name__}: {exc}")


def _file_ready(path: str) -> bool:
    try:
        # 존재 + stat 가능하면 일단 OK
        if not os.path.exists(path):
            return False
        os.stat(path)
        # Windows에서 공유락에 막히는 케이스 최소화: r 모드 열기 시도
        with open(path, "rb"):
            return True
    except Exception:
        return False


async def quiesce_last_segment(session_dir: str, base_noext: str, ext: str, attempts: int = 10, interval: float = 0.3):
    last_path = None
    last_size = -1
    for _ in range(attempts):
        segs = listNumericSegments(session_dir, base_noext, ext)
        if not segs:
            await asyncio.sleep(interval); continue
        _, last_path = segs[-1]
        try:
            size = os.path.getsize(last_path)
        except Exception:
            size = -1
        if size == last_size and _file_ready(last_path):
            return
        last_size = size
        await asyncio.sleep(interval)
    # 시도 끝, 그냥 진행


def _clamp_gpu_index(v) -> int:
    try:
        return 1 if int(v) == 1 else 0
    except Exception:
        return 0


def _clamp_gpu_count(v) -> int:
    try:
        return 2 if int(v) == 2 else 1
    except Exception:
        return 1


def buildPostCfgForChannel(channel: dict, cfg=None) -> dict:
    if cfg is None:
        cfg = loadConfig() or {}
    from module.config_validator import validateExtraFfmpegOptions
    gpu_count = _clamp_gpu_count(cfg.get("gpuCount", 1))

    ch_gpu = _clamp_gpu_index(cfg.get('singleGpuIndex', 0)) if gpu_count == 1 else _clamp_gpu_index(channel.get("gpu_index", 0))
    suffix = "" if ch_gpu == 0 else "_gpu1"

    used_keys = {}

    def pick(key: str):
        k = (key + suffix) if (suffix and (key + suffix) in cfg) else key
        used_keys[key] = k
        return cfg.get(k)

    post_cfg = {
        "autoPostProcessing": bool(cfg.get("autoPostProcessing", True)),
        "deleteAfterPostProcessing": bool(cfg.get("deleteAfterPostProcessing", True)),
        "removeFixedPrefix": bool(cfg.get("removeFixedPrefix", True)),
        "moveAfterProcessingEnabled": bool(cfg.get("moveAfterProcessingEnabled", False)),
        "moveAfterProcessing": cfg.get("moveAfterProcessing", "") or "",
        "postNewWindow": bool(cfg.get("postNewWindow", False)),
        "splitPostProcessing": bool(cfg.get("splitPostProcessing", True)),

        # 키가 없으면 기본값으로 진행하고 최소한 로그로 추적 가능
        "stream_copy": bool(cfg.get("stream_copy", True)),
        "video_codec": pick("video_codec"),
        "preset": pick("preset"),
        "postprocess_resolution": pick("postprocess_resolution") or "source",
        "use_bitrate_mode": bool(pick("use_bitrate_mode")),
        "video_quality": pick("video_quality"),
        "video_bitrate": pick("video_bitrate"),
        "vbv_maxrate": pick("vbv_maxrate") or "",
        "vbv_bufsize": pick("vbv_bufsize") or "",
        "audio_codec": pick("audio_codec"),
        "audio_bitrate": pick("audio_bitrate"),
        "extra_ffmpeg_options": pick("extra_ffmpeg_options") or "",

        "gpu_index": ch_gpu,

        # 디버그용 메타
        "_gpu_count": gpu_count,
        "_profile": ("gpu0" if ch_gpu == 0 else "gpu1"),
        "_used_keys": used_keys,
    }

    validateExtraFfmpegOptions(post_cfg['extra_ffmpeg_options'])
    return post_cfg


# 후처리 작업 함수
async def handlePostProcessing(input_path: str, channel_id: str, channel_name: str, post_cfg: dict | None,
                               recovery_job=None, source_identity=None, claim=None):
    job_id = None
    claim = claim or claimPostprocess(input_path)
    if claim is None:
        if recovery_job:
            from module.postprocess_store import failed
            failed({**recovery_job, "reason": "같은 원본의 후처리가 실행 중입니다."})
        return

    try:
        cfg = post_cfg or {}
        key = os.path.abspath(input_path)
        inputs = recovery_job.get("input_identities") if recovery_job else {key: source_identity or identity(input_path)}

        used = cfg.get("_used_keys", {})
        prof = cfg.get("_profile", "?")
        gidx = cfg.get("gpu_index", None)

        job_id = recorder_manager.postprocess_register_job(
            channel_id=channel_id,
            channel_name=channel_name,
            input_path=input_path,
            post_cfg=cfg,
            job_id=recovery_job["job_id"] if recovery_job else None,
            inputs=inputs,
        )

        if recovery_job and recovery_job.get("cleanup"):
            output = await commit_job(job_id, recovery_job["cleanup"])
            recorder_manager.postprocess_set_output_path(job_id, output)
            recorder_manager.postprocess_finish_job(job_id)
            return

        print(
            f"[POST][JOB-START] job={job_id} ch={channel_name} cid={channel_id} "
            f"profile={prof} gpu_index={gidx} src={os.path.basename(input_path or '')}"
        )

        # 1) 설정 검증
        errors = []

        stream_copy = cfg.get("stream_copy", None)
        if stream_copy is None:
            errors.append("stream_copy 설정 키가 누락됨")

        # stream_copy=False(인코딩) 인데 필수 설정이 비면 진행중지
        if stream_copy is False:
            vc = cfg.get("video_codec", None)
            pr = cfg.get("preset", None)
            ac = cfg.get("audio_codec", None)
            ab = cfg.get("audio_bitrate", None)

            if not vc:
                errors.append(f"video_codec 값이 비어있음(사용키={used.get('video_codec')})")
            if not pr:
                errors.append(f"preset 값이 비어있음(사용키={used.get('preset')})")
            if not ac:
                errors.append(f"audio_codec 값이 비어있음(사용키={used.get('audio_codec')})")
            if not ab:
                errors.append(f"audio_bitrate 값이 비어있음(사용키={used.get('audio_bitrate')})")

        if errors:
            reason = " / ".join(errors)
            print(f"[POST][CFG-ERROR] job={job_id} {channel_name} profile={prof} gpu_index={gidx} src={os.path.basename(input_path)}")
            for e in errors:
                print(f"[POST][CFG-ERROR] - {e}")
            print(f"[POST][CFG-ERROR] used_keys={used}")
            print(f"[POST][ABORT] 설정 오류로 후처리 중단(자동이동/원본삭제/파일명 변경 진행 안 함)")

            if job_id:
                recorder_manager.postprocess_fail_job(job_id, reason)

            notifyEvent(
                "postprocess_failed",
                "후처리 실패",
                "후처리 설정 오류로 작업을 중단했습니다.",
                channel_id=channel_id,
                channel_name=channel_name,
                detail=reason,
                severity="error"
            )

            return

        # 2) 어떤 프로필/키/값으로 실행되는지 로그로 남김
        print(
            f"[POST][CFG] job={job_id} ch={channel_name} cid={channel_id} profile={prof} gpu_index={gidx} "
            f"res={cfg.get('postprocess_resolution','source')} "
            f"stream_copy={cfg.get('stream_copy')} vcodec={cfg.get('video_codec')} preset={cfg.get('preset')} "
            f"mode={'bitrate' if cfg.get('use_bitrate_mode') else 'quality'} q={cfg.get('video_quality')} br={cfg.get('video_bitrate')} "
            f"vbv_maxrate={cfg.get('vbv_maxrate')} vbv_bufsize={cfg.get('vbv_bufsize')} "
            f"acodec={cfg.get('audio_codec')} abr={cfg.get('audio_bitrate')} extra={cfg.get('extra_ffmpeg_options')} "
            f"keys={cfg.get('_used_keys')}"
        )

        # 3) copyStream은 성공/실패를 bool로 반환하여 실패시 중지
        ok = await copyStream(
            input_path=input_path,
            deleteAfterPostProcessing=cfg.get('deleteAfterPostProcessing', False),
            removeFixedPrefix=cfg.get('removeFixedPrefix', False),
            stream_copy=stream_copy,
            preset=cfg.get('preset'),
            postprocess_resolution=cfg.get('postprocess_resolution', 'source'),
            use_bitrate_mode=cfg.get('use_bitrate_mode', False),
            video_bitrate=cfg.get('video_bitrate'),
            video_codec=cfg.get('video_codec'),
            video_quality=cfg.get('video_quality'),
            audio_codec=cfg.get('audio_codec'),
            audio_bitrate=cfg.get('audio_bitrate'),
            vbv_maxrate=cfg.get('vbv_maxrate', ''),
            vbv_bufsize=cfg.get('vbv_bufsize', ''),
            moveAfterProcessingEnabled=cfg.get('moveAfterProcessingEnabled', False),
            moveAfterProcessing=cfg.get('moveAfterProcessing', ''),
            extra_ffmpeg_options=cfg.get('extra_ffmpeg_options', ''),
            gpu_index=cfg.get("gpu_index", None),
            ffmpeg_console_mode=("new" if bool(cfg.get("postNewWindow", False)) else "inherit"),
            job_id=job_id,
            source_identity=inputs[key],
        )

        if not ok:
            reason = "copyStream returned False"
            print(f"[POST][FAIL] job={job_id} {channel_name} 후처리 실패 → 자동이동/원본삭제/파일명 변경 진행 안 함")
            if job_id:
                recorder_manager.postprocess_fail_job(job_id, reason)

            notifyEvent(
                "postprocess_failed",
                "후처리 실패",
                "후처리 작업이 실패했습니다.",
                channel_id=channel_id,
                channel_name=channel_name,
                detail=f"{reason}: {os.path.basename(input_path or '')}",
                severity="error"
            )

            return

        print(f"[POST][OK] job={job_id} {channel_name} 후처리 완료")
        if job_id:
            recorder_manager.postprocess_finish_job(job_id)

        notifyEvent(
            "postprocess_finished",
            "후처리 완료",
            "후처리 작업이 완료되었습니다.",
            channel_id=channel_id,
            channel_name=channel_name,
            detail=os.path.basename(input_path or ""),
            severity="info"
        )

    except asyncio.CancelledError:
        if job_id:
            recorder_manager.postprocess_fail_job(job_id, "앱 종료 또는 사용자 취소")
        raise
    except Exception as e:
        reason = str(e)
        print(f"[POST][ERROR] job={job_id} {channel_name} {reason}")
        if job_id:
            recorder_manager.postprocess_fail_job(job_id, reason)

        notifyEvent(
            "postprocess_failed",
            "후처리 실패",
            "후처리 중 예외가 발생했습니다.",
            channel_id=channel_id,
            channel_name=channel_name,
            detail=reason,
            severity="error"
        )

    finally:
        releasePostprocess(claim)


# 파일 작업을 처리하는 함수
async def commitPostprocess(job_id, entries):
    output = await commit_job(job_id, entries)
    recorder_manager.postprocess_set_output_path(job_id, output)


# 후처리 파일을 복사하거나 인코딩하는 함수
async def copyStream(input_path, deleteAfterPostProcessing, removeFixedPrefix, stream_copy, preset,
                     use_bitrate_mode, video_bitrate, video_codec, video_quality, audio_codec, audio_bitrate,
                     vbv_maxrate="", vbv_bufsize="", postprocess_resolution: str = "source",
                     moveAfterProcessingEnabled=False, moveAfterProcessing="",
                     extra_ffmpeg_options="", gpu_index: int | None = None,
                     ffmpeg_console_mode: str = "new", job_id: str | None = None, source_identity=None):

    if not input_path:
        print(f"[ERROR] 전달된 input_path가 None입니다. 스트림 복사 작업을 수행할 수 없습니다.")
        return False

    in_dir  = os.path.dirname(input_path) or "."
    in_base = os.path.basename(input_path)

    if stream_copy is False:
        _res = str(postprocess_resolution or "source").strip().lower()
        if _res not in ("source", "1080p", "720p", "480p"):
            _res = "source"

        _extra_raw = str(extra_ffmpeg_options or "").strip()
        _extra_tokens = shlex.split(_extra_raw) if _extra_raw else []
        _has_vf = any(
            (t == "-vf") or t.startswith("-vf=") or (t == "-filter:v") or t.startswith("-filter:v=")
            for t in _extra_tokens
        )

        if (not _has_vf) and (_res != "source"):
            th = 1080 if _res == "1080p" else (720 if _res == "720p" else 480)

            ffprobe_path = getFFprobe()
            ih = await asyncio.to_thread(probeVideoHeight, ffprobe_path, input_path)

            # 실제로 downscale 되는 경우(입력 height > 목표 height)만 파일명 태그 교체
            if ih > th:
                stem, ext = os.path.splitext(in_base)

                # 1순위: 파일명 끝의 "1080p60" / "1080p" 형태를 교체
                m = re.search(r"(?P<res>(?:2160|1440|1080|720|480)p)(?P<fps>\d{2,3})?$", stem)
                if m:
                    fps = m.group("fps") or ""
                    stem = stem[:m.start("res")] + _res + fps
                else:
                    # 2순위: 파일명 전체에서 마지막 해상도 태그를 교체
                    ms = list(re.finditer(r"(?P<res>(?:2160|1440|1080|720|480)p)(?P<fps>\d{2,3})?", stem))
                    if ms:
                        lm = ms[-1]
                        fps = lm.group("fps") or ""
                        stem = stem[:lm.start("res")] + _res + fps + stem[lm.end():]

                in_base = stem + ext

    if in_base.startswith("fixed_"):
        out_base = in_base
    else:
        out_base = "fixed_" + in_base

    if not await asyncio.to_thread(matches, input_path, source_identity):
        raise OSError("후처리 시작 전 원본이 변경됐습니다.")
    output_path = reserve_output(os.path.join(in_dir, out_base))
    if job_id:
        recorder_manager.postprocess_set_output_path(job_id, output_path)


    if not os.path.exists(in_dir):
        print(f"[ERROR] 출력 경로가 잘못되었습니다: {output_path}")
        return False

    print(
        f"[POST][COPY-START] job={job_id} input={input_path} output={output_path} "
        f"stream_copy={stream_copy} codec={video_codec} gpu_index={gpu_index}"
    )

    # 인코딩(stream_copy=False)인데 핵심 옵션이 비어있으면 여기서도 차단
    if stream_copy is False:
        if not video_codec or not preset or not audio_codec or not audio_bitrate:
            print("[ERROR] 인코딩 설정 누락으로 후처리 중단")
            print(f"[ERROR] video_codec={video_codec}, preset={preset}, audio_codec={audio_codec}, audio_bitrate={audio_bitrate}")
            return False

    try:
        await copySpecificFile(
            input_path=input_path,
            output_path=output_path,
            stream_copy=stream_copy,
            preset=preset,
            postprocess_resolution=postprocess_resolution,
            use_bitrate_mode=use_bitrate_mode,
            video_bitrate=video_bitrate,
            video_codec=video_codec,
            video_quality=video_quality,
            audio_codec=audio_codec,
            audio_bitrate=audio_bitrate,
            vbv_maxrate=vbv_maxrate,
            vbv_bufsize=vbv_bufsize,
            extra_ffmpeg_options=extra_ffmpeg_options,
            gpu_index=gpu_index,
            ffmpeg_console_mode=ffmpeg_console_mode,
            job_id=job_id,
        )
    except LinuxGpuError:
        raise
    except Exception as e:
        print(f"[ERROR] 후처리 작업 중 FFmpeg 처리 오류 발생: {str(e)}")
        raise RuntimeError('FFmpeg 처리 실패: '+type(e).__name__) from e

    if not output_has_minimum_size(output_path, 1, regular_file=True):
        raise RuntimeError("후처리 출력이 없거나 비어 있습니다. 원본을 보존했습니다.")
    if not await asyncio.to_thread(has_video_stream, output_path, getFFprobe()):
        raise RuntimeError(f"후처리 출력에 읽을 수 있는 영상 스트림이 없습니다. 원본을 보존했습니다: {output_path}")

    policy = dict(deleteAfterPostProcessing=deleteAfterPostProcessing, removeFixedPrefix=removeFixedPrefix,
                  moveAfterProcessingEnabled=moveAfterProcessingEnabled, moveAfterProcessing=moveAfterProcessing)
    entry = await asyncio.to_thread(plan, input_path, source_identity, output_path, policy)
    await commitPostprocess(job_id, [entry])

    print(f"[DEBUG] 후처리가 완료되었습니다.")
    return True


# 후처리시 GPU HW 디코딩 가속
def pickHwaccel(ffmpeg_path: str, ffprobe_path: str, input_path: str,
                video_codec: str, stream_copy: bool, gpu_index: int | None = None) -> list[str]:

    if stream_copy:
        return []

    vc = (video_codec or "").lower()
    pre: list[str] = []

    if sys.platform == "linux" and vc in QSV | NVENC:
        return linux_device_args(ffmpeg_path, vc, gpu_index)

    in_codec = probeVcodec(ffprobe_path, input_path)

    # Intel QSV
    if vc in ("h264_qsv", "hevc_qsv"):
        # 멀티 GPU 선택
        dev = "qsv=qsv:hw"
        if gpu_index is not None:
            if os.name == "nt":
                dev = f"qsv=qsv:hw,child_device={int(gpu_index)},child_device_type=d3d11va"
            else:
                dev = f"qsv=qsv:hw,child_device={int(gpu_index)}"

        pre += ["-extra_hw_frames", "32"]

        pre += ["-init_hw_device", dev,
                "-filter_hw_device", "qsv",
                "-hwaccel", "qsv",
                "-hwaccel_output_format", "qsv"]

        if in_codec in ("h264", "avc1"):
            pre += ["-c:v:0", "h264_qsv"]
        elif in_codec in ("hevc", "h265"):
            pre += ["-c:v:0", "hevc_qsv"]

    elif vc in ("h264_nvenc", "hevc_nvenc"):
        dev = "cuda=cuda:0"
        if gpu_index is not None:
            dev = f"cuda=cuda:{int(gpu_index)}"

        pre += ["-init_hw_device", dev,
                "-filter_hw_device", "cuda",
                "-hwaccel", "cuda",
                "-hwaccel_output_format", "cuda"]


        # NVDEC(CUVID) 디코더 고정
        if in_codec in ("h264", "avc1"):
            pre += ["-c:v:0", "h264_cuvid"]
        elif in_codec in ("hevc", "h265", "hev1", "hvc1"):
            pre += ["-c:v:0", "hevc_cuvid"]

    elif vc in ("h264_amf", "hevc_amf"):
        if os.name == "nt":
            dev = "d3d11va=d3d11"
            if gpu_index is not None:
                dev = f"d3d11va=d3d11:{int(gpu_index)}"
            pre += ["-init_hw_device", dev,
                    "-filter_hw_device", "d3d11",
                    "-hwaccel", "d3d11va",
                    "-hwaccel_output_format", "d3d11"]
        else:
            pre += ["-init_hw_device", "vaapi=vaapi",
                    "-filter_hw_device", "vaapi",
                    "-hwaccel", "vaapi",
                    "-hwaccel_output_format", "vaapi"]

    return pre


async def copySpecificFile(input_path, output_path, stream_copy, preset, use_bitrate_mode, video_bitrate,
                           video_codec, video_quality, audio_codec, audio_bitrate, vbv_maxrate="", vbv_bufsize="",
                           postprocess_resolution: str = "source",
                           extra_ffmpeg_options="", gpu_index: int | None = None,
                           ffmpeg_console_mode: str = "auto", job_id: str | None = None):

    ffmpeg_path = getFFmpeg()
    ffprobe_path = getFFprobe()

    def _creationflags(mode: str) -> int:
        if os.name != "nt": return 0
        m = (mode or "auto").lower()
        if m == "inherit": return 0
        if m == "new":     return subprocess.CREATE_NEW_CONSOLE
        return subprocess.CREATE_NEW_CONSOLE

    # 입력 컨테이너/코덱 간단 프로빙
    in_ext  = os.path.splitext(input_path)[1].lower()
    out_ext = os.path.splitext(output_path)[1].lower()
    in_vc   = await asyncio.to_thread(probeVcodec, ffprobe_path, input_path, check=False)
    in_fmt  = await asyncio.to_thread(probe_format_name, ffprobe_path, input_path)
    pre     = await asyncio.to_thread(pickHwaccel, ffmpeg_path, ffprobe_path, input_path, video_codec, stream_copy, gpu_index=gpu_index)

    if not stream_copy:
        print(
            f"[POST][HWACCEL] job={job_id} codec={video_codec} gpu_index={gpu_index} "
            f"in_codec={in_vc} in_fmt={in_fmt} args={' '.join(shlex.quote(x) for x in pre)}"
        )

    # 입력 안정화 옵션 보강: genpts + discardcorrupt / err_detect
    input_prefix = [ffmpeg_path, "-y", "-nostdin",
                    "-fflags", "+genpts+discardcorrupt", "-err_detect", "ignore_err"]
    cmd = input_prefix + pre + ["-i", input_path]

    # 데이터 스트림 등 노이즈 제거
    cmd += ["-map", "0:v:0?", "-map", "0:a:0?"]

    if stream_copy:
        cmd += ["-c:v", "copy", "-c:a", "copy"]

        if out_ext in (".ts", ".m2ts", ".mts"):
            # 입력이 mp4 계열이거나, 코덱이 h264/hevc로 판정되면 적용
            if ("mp4" in in_fmt or "mov" in in_fmt or "ism" in in_fmt or "m4a" in in_fmt
                or in_vc in ("h264", "avc1", "hev1", "hvc1", "hevc", "h265")):
                if in_vc in ("h264", "avc1", ""):
                    cmd += ["-bsf:v", "h264_mp4toannexb"]
                elif in_vc in ("hevc", "h265", "hev1", "hvc1"):
                    cmd += ["-bsf:v", "hevc_mp4toannexb"]

        # TS → MP4 리멕스 시에는 기존대로 ADTS→ASC (오디오)만 적용
        if out_ext == ".mp4" and in_ext in (".ts", ".m2ts", ".mts"):
            cmd += ["-bsf:a", "aac_adtstoasc"]

    else:
        cmd += ["-c:v", video_codec, "-preset", str(preset)]

        # source / 1080p / 720p / 480p
        _res = str(postprocess_resolution or "source").strip().lower()
        if _res not in ("source", "1080p", "720p", "480p"):
            _res = "source"

        _extra_tokens = shlex.split(extra_ffmpeg_options) if extra_ffmpeg_options.strip() else []
        _has_vf = any(
            (t == "-vf") or t.startswith("-vf=") or (t == "-filter:v") or t.startswith("-filter:v=")
            for t in _extra_tokens
        )

        # QSV에서 원본 해상도인 경우 사용자가 -vf를 안 줬으면 NV12 포맷 정규화
        _is_qsv = (str(video_codec or "").lower() in ("h264_qsv", "hevc_qsv"))
        _res = str(postprocess_resolution or "source").strip().lower()
        if _is_qsv and (_res == "source") and (not _has_vf):
            cmd += ["-vf", QSV_UPLOAD if sys.platform == "linux" else "vpp_qsv=format=nv12"]
            _has_vf = True

        # -vf 위치(재시도 시 교체용)
        _vf_idx: int | None = None
        _vf_fallback: str | None = None

        def _infer_size_from_name(_p: str) -> tuple[int, int]:
            try:
                base = os.path.splitext(os.path.basename(_p))[0]
                m = re.findall(r"\b(2160|1440|1080|720|480)p\b", base)
                if not m:
                    return 0, 0
                h = int(m[-1])
                w_map = {2160: 3840, 1440: 2560, 1080: 1920, 720: 1280, 480: 854}
                w = int(w_map.get(h, 0) or 0)
                return (w, h) if w and h else (0, 0)
            except Exception:
                return 0, 0

        if (not _has_vf) and (_res != "source"):
            # 목표 해상도 (업스케일은 하지 않음)
            if _res == "1080p":
                tw, th = 1920, 1080
            elif _res == "720p":
                tw, th = 1280, 720
            else:  # 480p
                tw, th = 854, 480

            # hwaccel_output_format에 따라 가능한 스케일 필터로 자동 선택
            _hwfmt = ""
            try:
                if "-hwaccel_output_format" in pre:
                    _hwfmt = str(pre[pre.index("-hwaccel_output_format") + 1]).lower()
            except Exception:
                _hwfmt = ""

            # 입력 해상도 프로브 (동일 해상도면 -vf 자체를 안 붙이기 위해 필요)
            iw, ih = await asyncio.to_thread(probeVideoSize, ffprobe_path, input_path)
            if iw <= 0 or ih <= 0:
                iw2, ih2 = _infer_size_from_name(input_path)
                if iw2 > 0 and ih2 > 0:
                    iw, ih = iw2, ih2

            # 다운스케일 필요 여부 판단 (동일/더 작으면 필터 자체를 생략)
            _need_scale = True
            ow = oh = 0
            if iw > 0 and ih > 0:
                s = min(1.0, min(tw / float(iw), th / float(ih)))
                if s >= 0.999999:
                    _need_scale = False
                else:
                    ow = max(2, int(iw * s) // 2 * 2)
                    oh = max(2, int(ih * s) // 2 * 2)

            if _need_scale:
                # 해상도 미확인(iw/ih=0)인 경우: 안정성 우선 (업스케일 방지 표현식을 사용)
                if _hwfmt == "qsv":
                    if iw > 0 and ih > 0:
                        # QSV: scale_qsv 우선 → 실패 시 vpp_qsv 폴백
                        _scale = f"scale_qsv=w={ow}:h={oh}:format=nv12"
                        _vf_fallback = f"vpp_qsv=w={ow}:h={oh}:format=nv12"
                    else:
                        # QSV는 표현식으로 업스케일 방지 가능(프로브 불가 시에도 동작)
                        _sf = f"min(1\\,min({tw}/iw\\,{th}/ih))"
                        _w  = f"trunc(iw*{_sf}/2)*2"
                        _h  = f"trunc(ih*{_sf}/2)*2"
                        _scale = f"scale_qsv=w='{_w}':h='{_h}':format=nv12"
                        _vf_fallback = f"vpp_qsv=w='{_w}':h='{_h}':format=nv12"

                elif _hwfmt == "cuda":
                    if iw > 0 and ih > 0:
                        _scale = f"scale_cuda=w={ow}:h={oh}:format=nv12"
                    else:
                        # 프로브 실패 시에도 GPU 스케일 유지 
                        _sf = f"min(1\\,min({tw}/iw\\,{th}/ih))"
                        _w  = f"trunc(iw*{_sf}/2)*2"
                        _h  = f"trunc(ih*{_sf}/2)*2"
                        _scale = f"scale_cuda=w='{_w}':h='{_h}':format=nv12"

                elif _hwfmt == "d3d11":
                    if iw > 0 and ih > 0:
                        _scale = f"vpp_amf=w={ow}:h={oh}:format=nv12"
                    else:
                        # 프로브 실패 시에도 GPU 스케일 유지 
                        _sf = f"min(1\\,min({tw}/iw\\,{th}/ih))"
                        _w  = f"trunc(iw*{_sf}/2)*2"
                        _h  = f"trunc(ih*{_sf}/2)*2"
                        _scale = f"vpp_amf=w='{_w}':h='{_h}':format=nv12"

                else:
                    # SW : 소프트 스케일
                    if iw > 0 and ih > 0:
                        _scale = f"scale=w={ow}:h={oh}"
                    else:
                        _scale = f"scale=w='min(iw\\,{tw})':h='min(ih\\,{th})':force_original_aspect_ratio=decrease"

                if _is_qsv and sys.platform == "linux":
                    _scale += f",{QSV_UPLOAD}"
                cmd += ["-vf", _scale]
                _vf_idx = len(cmd) - 1

        elif _has_vf and (_res != "source"):
            print(f"[WARN] extra_ffmpeg_options에 -vf/-filter:v가 포함되어 있어 후처리 해상도({_res}) 스케일은 적용하지 않습니다.")


        if _is_qsv and sys.platform == "linux" and not _has_vf and _vf_idx is None:
            cmd += ["-vf", QSV_UPLOAD]

        # NVENC 멀티 GPU 선택(-gpu) 
        vc = (video_codec or "").lower()
        if vc in NVENC and (gpu_index is not None or sys.platform == "linux"):
            cmd += ["-gpu", str(0 if gpu_index is None else int(gpu_index))]

        if use_bitrate_mode:
            cmd += ["-b:v", str(video_bitrate)]
            if vbv_maxrate: cmd += ["-maxrate", str(vbv_maxrate)]
            if vbv_bufsize: cmd += ["-bufsize", str(vbv_bufsize)]
        else:
            if video_codec in ("libx264","libx265"):
                cmd += ["-crf", str(video_quality)]
            elif video_codec in ("h264_nvenc","hevc_nvenc"):
                cmd += ["-cq", str(video_quality)]
            elif video_codec in ("h264_qsv","hevc_qsv"):
                cmd += ["-global_quality", str(video_quality)]
            elif video_codec == "h264_amf":
                cmd += ["-rc","qvbr","-qvbr_quality_level", str(video_quality)]
            elif video_codec == "hevc_amf":
                cmd += ["-rc","qvbr","-quality","quality","-qvbr_quality_level", str(video_quality)]
            else:
                cmd += ["-crf", str(video_quality)]

        if str(audio_bitrate).lower() == "copy":
            cmd += ["-c:a", "copy"]
        else:
            cmd += ["-c:a", audio_codec, "-b:a", str(audio_bitrate)]

        # extra는 위에서 split한 토큰 그대로 1회만 append
        if _extra_tokens:
            cmd += _extra_tokens

    # faststart는 MP4에만
    if out_ext == ".mp4":
        cmd += ["-movflags", "+faststart"]

    cmd += [output_path]

    print(f"[POST][FFMPEG-CMD] job={job_id} {' '.join(shlex.quote(x) for x in cmd)}")

    flags = _creationflags(ffmpeg_console_mode)

    async def _run_once(_cmd):
        if flags != 0:
            ret, _ = await runPostprocessProcess(_cmd, job_id=job_id, creationflags=flags)
            return ret, ""

        ret, err_b = await runPostprocessProcess(_cmd, job_id=job_id, capture=True)
        err_txt = (err_b or b"").decode(errors="replace")
        return ret, err_txt

    def _print_tail(_err: str, _n: int = 40):
        if not _err:
            return
        tail_lines = [x for x in _err.splitlines() if x.strip()][-_n:]
        for line in tail_lines:
            print("[FFMPEG]", line)

    ret, err_txt = await _run_once(cmd)

    if (ret != 0 and os.name == "nt" and not stream_copy and video_codec in QSV
            and gpu_index is not None and not _extra_tokens
            and (not err_txt or "error creating a mfx session" in err_txt.lower()
                 or "device creation failed" in err_txt.lower())):
        # 일부 구형 Intel 드라이버는 D3D11VA 세션을 열지 못합니다.
        device = f"qsv=qsv:hw,child_device={int(gpu_index)},child_device_type=dxva2"
        retry = (input_prefix + ["-init_hw_device", device, "-filter_hw_device", "qsv"]
                 + cmd[len(input_prefix) + len(pre):])
        if "-vf" in retry:
            index = retry.index("-vf") + 1
            scale = re.match(r"(?:scale|vpp)_qsv=(.*):format=nv12$", retry[index])
            retry[index] = f"scale={scale[1]},format=nv12" if scale else "format=nv12"
        else:
            retry[-1:-1] = ["-vf", "format=nv12"]
        print("[POST][QSV] DXVA2로 같은 GPU에서 다시 시도합니다.")
        ret, err_txt = await _run_once(retry)
        cmd = retry
        _vf_fallback = None

    # scale_qsv 실패 시 vpp_qsv로 자동 폴백 
    if (ret != 0) and _vf_fallback and (_vf_idx is not None):
        e = (err_txt or "").lower()
        _hint = (
            ("scale_qsv" in e)
            or ("no such filter" in e)
            or ("error while filtering" in e)
            or ("error reinitializing filters" in e)
            or ("failed to configure output pad" in e)
        )
        # 콘솔 상속 모드(flags!=0)에서는 stderr를 못 받으니 폴백 시도
        if (flags != 0) or (not err_txt) or _hint:
            print("[WARN] scale_qsv 처리 중 오류가 발생하여 vpp_qsv로 재시도합니다.")
            cmd2 = list(cmd)
            cmd2[_vf_idx] = _vf_fallback
            ret2, err2 = await _run_once(cmd2)
            if ret2 != 0:
                _print_tail(err2 or err_txt)
                raise subprocess.CalledProcessError(ret2, cmd2)
            # 성공 시 cmd 교체 (디버그/로그 일관성)
            cmd = cmd2
            ret = 0
            err_txt = err2

    if ret != 0:
        _print_tail(err_txt)
        if sys.platform == "linux" and not stream_copy and video_codec in QSV | NVENC:
            raise gpu_failure(video_codec, err_txt)
        raise subprocess.CalledProcessError(ret, cmd)

    print(f"{input_path} → {output_path} 완료")



# 재시작 없이 설정 업데이트 헬퍼 함수
def resolveRecordingPrefs():
    cfg = loadConfig() or {}

    # plugin_type 정규화
    plugin = (cfg.get("plugin_type") or "basic").lower()
    normalized_plugin = plugin if plugin in ("basic", "timemachine_plus") else "basic"

    # timemachine shift 정규화
    try:
        _shift = int(cfg.get("timemachine_time_shift") or 0)
    except Exception:
        _shift = 0
    if normalized_plugin == "basic":
        normalized_shift = max(0, min(10, _shift))
    else:
        normalized_shift = max(0, min(3600, _shift))

    # 분할/오버랩/최대시간
    split_mode = toBool(cfg.get("splitRecordingMode", False))
    try:
        auto_stop = int(cfg.get("autoStopInterval") or 0)
    except Exception:
        auto_stop = 0
    if not split_mode:
        auto_stop = 0

    try:
        ov = int(cfg.get("splitOverlapSec") or 0)
    except Exception:
        ov = 0
    ov = max(0, min(30, ov))
    if not split_mode:
        ov = 0

    # 숫자형 옵션 안전 파싱
    try:
        recheck = int(cfg.get("recheckInterval") or 60)
    except Exception:
        recheck = 60
    try:
        vq = int(cfg.get("video_quality") if cfg.get("video_quality") not in (None, "") else 23)
    except Exception:
        vq = 23

    # 최종 prefs
    prefs = {
        "plugin_type": normalized_plugin,
        "timemachine_time_shift": normalized_shift,
        "splitRecordingMode": split_mode,
        "splitPostProcessing":       toBool(cfg.get("splitPostProcessing", True)),
        "autoStopInterval": auto_stop,
        "splitOverlapSec": ov,

        "filenamePattern": cfg.get("filenamePattern") or "[{start_time}] {safe_live_title}",
        "recheckInterval": recheck,

        "autoPostProcessing":        toBool(cfg.get("autoPostProcessing", False)),
        "deleteAfterPostProcessing": toBool(cfg.get("deleteAfterPostProcessing", False)),
        "removeFixedPrefix":         toBool(cfg.get("removeFixedPrefix", False)),
        "moveAfterProcessingEnabled":toBool(cfg.get("moveAfterProcessingEnabled", False)),
        "moveAfterProcessing":       (cfg.get("moveAfterProcessing") or None),
        "postNewWindow":             toBool(cfg.get("postNewWindow", False)),
        "stream_copy":               toBool(cfg.get("stream_copy", True)),

        "video_codec":               cfg.get("video_codec") or "libx264",
        "preset":                    cfg.get("preset") or "medium",
        "use_bitrate_mode":          toBool(cfg.get("use_bitrate_mode", False)),
        "video_quality":             vq,
        "video_bitrate":             cfg.get("video_bitrate") or "1000k",
        "vbv_maxrate":               cfg.get("vbv_maxrate") or "",
        "vbv_bufsize":               cfg.get("vbv_bufsize") or "",
        "audio_codec":               cfg.get("audio_codec") or "aac",
        "audio_bitrate":             cfg.get("audio_bitrate") or "copy",
        "extra_ffmpeg_options":      cfg.get("extra_ffmpeg_options") or "",
    }

    return prefs


# 공통 설정 헬퍼
def postCfg() -> dict:
    prefs = resolveRecordingPrefs()
    return {
        "stream_copy":                prefs["stream_copy"],
        "video_codec":                prefs["video_codec"],
        "preset":                     prefs["preset"],
        "use_bitrate_mode":           prefs["use_bitrate_mode"],
        "video_quality":              prefs["video_quality"],
        "video_bitrate":              prefs["video_bitrate"],
        "vbv_maxrate":                prefs["vbv_maxrate"],
        "vbv_bufsize":                prefs["vbv_bufsize"],
        "extra_ffmpeg_options":       prefs["extra_ffmpeg_options"],
        "audio_codec":                prefs["audio_codec"],
        "audio_bitrate":              prefs["audio_bitrate"],
        "deleteAfterPostProcessing":  prefs["deleteAfterPostProcessing"],
        "removeFixedPrefix":          prefs["removeFixedPrefix"],
        "moveAfterProcessingEnabled": prefs["moveAfterProcessingEnabled"],
        "moveAfterProcessing":        prefs["moveAfterProcessing"] or "",
        "postNewWindow":              prefs["postNewWindow"],
    }


def splitGate() -> tuple[bool, int, int]:
    prefs = resolveRecordingPrefs()
    split_on = bool(prefs["splitRecordingMode"] and prefs["autoStopInterval"] > 0)
    return split_on, int(prefs["autoStopInterval"] or 0), int(prefs["splitOverlapSec"] or 0)


# 세그먼트 패턴 추적
def parseSegPattern(path: str) -> tuple[str, str, str] | None:
    if not path:
        return None
    out_dir, base = os.path.dirname(path), os.path.basename(path)
    m = re.match(r"(.+)_%0\d+d(\.[^.]+)$", base) or re.match(r"(.+)_\d{3,}(\.[^.]+)$", base)
    if not m:
        return None
    if not os.path.isdir(out_dir):
        return None
    base_noext, seg_ext = m.group(1), m.group(2)
    return out_dir, base_noext, seg_ext



def buildPipeCmds(channel: dict, cookies: dict, metadata: dict | None, *,
                  segmentPattern: str, segmentSec: int, plugin_settings):
    plugin, shift = plugin_settings
    normalized_plugin = (plugin or "basic").lower()
    if normalized_plugin not in ("basic", "timemachine_plus"):
        normalized_plugin = "basic"

    try:
        _shift = int(shift or 0)
    except Exception:
        _shift = 0
    normalized_shift = max(0, min(10, _shift)) if normalized_plugin == "basic" else max(0, min(3600, _shift))

    streamlink_path = getStreamlink()
    ffmpeg_path = getFFmpeg()

    sl_cmd = [streamlink_path]
    sl_cmd.extend(buildCommonPluginArgs(channel, cookies, normalized_plugin=normalized_plugin))

    # timemachine 플러그인일 때만 live-restart + 양수 오프셋
    if normalized_plugin in ("timemachine_plus",):
        sl_cmd.append("--hls-live-restart")
        if normalized_shift > 0:
            sl_cmd.extend(["--hls-start-offset", str(normalized_shift)])

    quality = chzzkStreamlinkSelector(channel, metadata)

    sl_cmd.extend([
        buildChannelUrl(channel),
        quality, 
        "--stdout",
        "--stream-segment-timeout", "15",
        "--stream-segment-attempts", "12",
    ])

    ff_cmd = [
        ffmpeg_path,
        "-y", "-nostdin", "-hide_banner", "-loglevel", "warning",
        "-fflags", "+genpts",
        "-analyzeduration", "100M", "-probesize", "100M",
        "-i", "-",
        "-map", "0:v:0?", "-map", "0:a:0?",
        "-c:v", "copy", "-c:a", "copy",
        "-flush_packets", "1",
        "-f", "segment",
        "-segment_format", "mpegts",      
        "-segment_time", str(int(segmentSec)),
        "-segment_time_delta", "0.5",     
        "-reset_timestamps", "1",
        segmentPattern
    ]

    try:
        print("[FF-CMD]", " ".join(shlex.quote(x) for x in ff_cmd))
    except Exception:
        print("[FF-CMD]", ff_cmd)

    return sl_cmd, ff_cmd


async def pumpPipe(src_proc, dst_proc, chunk: int = 256*1024):
    total = 0
    last_report = time.time()
    try:
        while True:
            buf = await src_proc.stdout.read(chunk)
            if not buf:
                break
            dst_proc.stdin.write(buf)
            await dst_proc.stdin.drain()
            total += len(buf)
            now = time.time()
            if now - last_report >= 5:
                print(f"[PUMP] wrote ~{total/1024/1024:.1f} MiB so far")
                last_report = now
    except Exception as _e:
        print(f"[PUMP][WARN] {type(_e).__name__}: {_e}")
    finally:
        with contextlib.suppress(Exception):
            if dst_proc.stdin:
                dst_proc.stdin.close()


def idxName(i: int, width: int = 3) -> str:

    try:
        return f"{int(i):0{width}d}"
    except Exception:
        return str(i)


def encodeOpts(cfg: dict) -> tuple[list[str], list[str]]:
    vc  = (cfg.get("video_codec") or "libx264").lower()
    pr  = str(cfg.get("preset") or "medium")
    use_br = bool(cfg.get("use_bitrate_mode", False))
    vb  = str(cfg.get("video_bitrate") or "2000k")
    vq  = str(cfg.get("video_quality") or "23")
    ac  = (cfg.get("audio_codec") or "aac").lower()
    ab  = str(cfg.get("audio_bitrate") or "copy")
    vbv_max = str(cfg.get("vbv_maxrate") or "")
    vbv_buf = str(cfg.get("vbv_bufsize") or "")
    extra   = (cfg.get("extra_ffmpeg_options") or "").strip()

    v = ["-c:v", vc, "-preset", pr]
    if vc in ('h264_nvenc', 'hevc_nvenc') and cfg.get('gpu_index') is not None:
        v += ['-gpu', str(_clamp_gpu_index(cfg['gpu_index']))]
    if use_br:
        v += ["-b:v", vb]
        if vbv_max: v += ["-maxrate", vbv_max]
        if vbv_buf: v += ["-bufsize", vbv_buf]
    else:
        if vc in ("libx264","libx265"):
            v += ["-crf", vq]
        elif vc in ("h264_nvenc","hevc_nvenc"):
            v += ["-cq", vq]
        elif vc in ("h264_qsv","hevc_qsv"):
            v += ["-global_quality", vq]
        elif vc in ("h264_amf",):
            v += ["-rc","qvbr","-qvbr_quality_level", vq]
        elif vc in ("hevc_amf",):
            v += ["-rc","qvbr","-quality","quality","-qvbr_quality_level", vq]
        else:
            v += ["-crf", vq]

    if ab.strip().lower() == "copy":
        a = ["-c:a", "copy"]
    else:
        a = ["-c:a", ac, "-b:a", ab]

    if extra:
        v += shlex.split(extra)
    return v, a


async def runPostprocessProcess(cmd, *, job_id=None, capture=False, creationflags=0):
    pipe = asyncio.subprocess.PIPE if capture else None
    spawning = asyncio.create_task(create_process(*cmd, stdout=pipe, stderr=pipe, creationflags=creationflags))
    waiting = None
    try:
        proc = await asyncio.shield(spawning)
        if job_id:
            print(f"[POST][FFMPEG-PID] job={job_id} pid={proc.pid}")
        waiting = asyncio.create_task(proc.communicate() if capture else proc.wait())
        result = await asyncio.shield(waiting)
        return proc.returncode, result[1] if capture else b""
    except asyncio.CancelledError:
        async def stop():
            proc = await spawning
            if os.name == "posix" and (proc.returncode is None or (waiting and not waiting.done())):
                signal_group(proc.pid, signal.SIGKILL)
            elif proc.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    proc.kill()
            if waiting is not None:
                await waiting
            elif capture:
                await proc.communicate()
            else:
                await proc.wait()

        await finish_before_cancel(asyncio.create_task(stop()))
        raise


async def ffAsync(cmd: list[str], *, console_mode="auto"):
    def _creationflags(mode: str) -> int:
        if os.name != "nt": return 0
        m = (mode or "auto").lower()
        if m == "inherit": return 0
        if m == "new":     return subprocess.CREATE_NEW_CONSOLE
        return subprocess.CREATE_NEW_CONSOLE

    code, _ = await runPostprocessProcess(cmd, creationflags=_creationflags(console_mode))
    if code != 0:
        raise subprocess.CalledProcessError(code, cmd)


def listNumericSegments(session_dir: str, base_noext: str, ext: str = ".mp4") -> list[tuple[int,str]]:
    pref = f"{base_noext}_"
    out = []
    for n in os.listdir(session_dir):
        if not (n.startswith(pref) and n.endswith(ext)): continue
        s = n[len(pref):-len(ext)]
        if s.isdigit():
            out.append((int(s), os.path.join(session_dir, n)))
    out.sort(key=lambda x: x[0])
    return out


# 분할녹화용 후처리 함수
async def batchEncodeSegments(session_dir: str, base_noext: str, overlap_sec: int, post_cfg: dict,
                              input_ext: str = ".ts", job_id=None, inputs=None):
    from module.postprocess_store import consecutive
    mode = "new" if toBool(post_cfg.get("postNewWindow", False)) else "inherit"
    ff = getFFmpeg()
    ffprobe = resolveFFprobe(ff)
    segs = listNumericSegments(session_dir, base_noext, input_ext)
    if not consecutive([index for index, _ in segs]) or set(inputs or ()) != {os.path.abspath(source) for _, source in segs}:
        raise RuntimeError(f"분할 원본 번호가 누락되거나 목록이 변경됐습니다: {session_dir}")

    do_copy = toBool(post_cfg.get("stream_copy", True))
    vopts, aopts = encodeOpts(post_cfg)
    device_args = []
    codec = str(post_cfg.get('video_codec') or '').lower()
    index = _clamp_gpu_index(post_cfg.get('gpu_index', 0))
    linux_gpu = sys.platform == 'linux' and not do_copy and codec in QSV | NVENC
    if linux_gpu:
        device_args = await asyncio.to_thread(linux_device_args, ff, codec, index)
        if codec in NVENC and post_cfg.get('gpu_index') is None:
            vopts += ['-gpu', str(index)]
    elif not do_copy and codec in ('h264_qsv', 'hevc_qsv'):
        device_args = ['-init_hw_device', f'qsv=qsv:hw,child_device={index},child_device_type=d3d11va', '-filter_hw_device', 'qsv'] if os.name == 'nt' else ['-init_hw_device', f'qsv=qsv:hw,child_device={index}', '-filter_hw_device', 'qsv']
    elif not do_copy and codec in ('h264_amf', 'hevc_amf') and os.name == 'nt':
        device_args = ['-init_hw_device', f'd3d11va=d3d11:{index}', '-filter_hw_device', 'd3d11']
    out_base_noext = base_noext
    scale_vf: list[str] = []
    overlap_sec = max(0, int(overlap_sec or 0))

    def _concat_file_line(path: str) -> str:
        safe = os.path.abspath(path).replace("\\", "/").replace("'", "'\\''")
        return f"file '{safe}'\n"

    async def _make_overlap_input(prev_path: str, cur_path: str, idx: int) -> tuple[str, list[str]]:
        if overlap_sec <= 0 or not prev_path or not os.path.exists(prev_path):
            return cur_path, []

        stem = f".overlap_{idxName(idx)}"
        tail_path = os.path.join(session_dir, f"{stem}_tail.ts")
        list_path = os.path.join(session_dir, f"{stem}.ffconcat")
        merged_path = os.path.join(session_dir, f"{stem}_merged.ts")
        temp_paths = [tail_path, list_path, merged_path]

        try:
            await ffAsync([
                ff, "-y", "-nostdin",
                "-sseof", f"-{overlap_sec}",
                "-i", prev_path,
                "-map", "0:v:0?", "-map", "0:a:0?",
                "-c", "copy",
                "-f", "mpegts",
                tail_path,
            ], console_mode=mode)

            with open(list_path, "w", encoding="utf-8") as f:
                f.write(_concat_file_line(tail_path))
                f.write(_concat_file_line(cur_path))

            await ffAsync([
                ff, "-y", "-nostdin",
                "-f", "concat", "-safe", "0",
                "-i", list_path,
                "-c", "copy",
                "-f", "mpegts",
                merged_path,
            ], console_mode=mode)

            print(f"[BATCH][OVERLAP] {os.path.basename(cur_path)} 앞에 이전 세그먼트 {overlap_sec}s를 붙였습니다.")
            return merged_path, temp_paths

        except Exception as e:
            print(f"[BATCH][OVERLAP][WARN] {os.path.basename(cur_path)} 오버랩 생성 실패 → 원본 세그먼트로 진행: {e}")
            for p in temp_paths:
                with contextlib.suppress(Exception):
                    if os.path.exists(p):
                        os.remove(p)
            return cur_path, []

    def _replace_last_res_tag(name: str, new_res: str) -> str:
        # 1순위: 끝이 같은 형태면 suffix만 교체
        m = re.search(r"(?P<res>(?:2160|1440|1080|720|480)p)(?P<fps>\d{2,3})?$", name)
        if m:
            fps = m.group("fps") or ""
            return name[:m.start("res")] + new_res + fps

        # 2순위: 문자열 전체에서 마지막 해상도 토큰(2160/1440/1080/720/480p)을 찾아 교체
        ms = list(re.finditer(r"(?P<res>(?:2160|1440|1080|720|480)p)(?P<fps>\d{2,3})?", name))
        if ms:
            lm = ms[-1]
            fps = lm.group("fps") or ""
            return name[:lm.start("res")] + new_res + fps + name[lm.end():]

        return name

    # 사용자가 이미 -vf/-filter를 줬으면 자동 scale 및 파일명 교체를 하지 않음
    _has_vf = any(
        (t in ("-vf", "-filter:v", "-filter_complex")) or str(t).startswith("-vf=") or str(t).startswith("-filter:v=")
        for t in vopts
    )

    _req_res = str(post_cfg.get("postprocess_resolution", "source") or "source").strip().lower()
    if _req_res not in ("source", "1080p", "720p", "480p"):
        _req_res = "source"

    # stream_copy면 파일명도 바꾸지 않음
    if (not do_copy) and (not _has_vf) and (_req_res != "source"):
        tw, th = (1920, 1080) if _req_res == "1080p" else ((1280, 720) if _req_res == "720p" else (854, 480))

        ih = 0
        for _idx, p in segs:
            try:
                if os.path.getsize(p) < 32 * 1024:
                    continue
            except Exception:
                continue
            ih = await asyncio.to_thread(probeVideoHeight, ffprobe, p, check=False)
            if ih:
                break

        # ffprobe가 높이를 못 뽑는 경우(ih=0) → 파일명 끝의 "1080p60"/"1080p" 태그로 보정
        if not ih:
            m = re.search(r"(?P<res>(?:2160|1440|1080|720|480)p)(?P<fps>\d{2,3})?$", base_noext)
            if m:
                try:
                    ih = int(m.group("res")[:-1])  # '1080p' -> 1080
                except Exception:
                    ih = 0

        # 실제 다운스케일이 적용되는 경우에만 scale + 파일명 태그 교체
        if ih > th:
            scale_vf = [
                "-vf",
                f"scale=w='min(iw\\,{tw})':h='min(ih\\,{th})':force_original_aspect_ratio=decrease:force_divisible_by=2"
            ]
            out_base_noext = _replace_last_res_tag(base_noext, _req_res)
            if out_base_noext != base_noext:
                print(f"[BATCH] downscale active: {base_noext} -> {out_base_noext} (h={ih} > {th})")

    completed_segments = set()
    completed_outputs = []
    retained_overlap_paths = []
    for i, (idx, cur) in enumerate(segs):
        if not await asyncio.to_thread(matches, cur, inputs[os.path.abspath(cur)]):
            raise OSError("인코딩 전 분할 원본이 변경됐습니다.")
        # 너무 작은/깨진 세그먼트 스킵
        try:
            if os.path.getsize(cur) < 32 * 1024:
                print(f"[BATCH] skip tiny/corrupt segment: {os.path.basename(cur)}")
                continue
        except Exception:
            pass

        out = reserve_output(os.path.join(session_dir, f"fixed_{out_base_noext}_{idxName(idx)}.mp4"))
        if job_id and not completed_segments:
            recorder_manager.postprocess_set_output_path(job_id, out)
        print(f"[BATCH] -> {os.path.basename(out)}")

        temp_overlap_paths: list[str] = []
        effective_cur = cur
        if i > 0 and overlap_sec > 0:
            effective_cur, temp_overlap_paths = await _make_overlap_input(segs[i - 1][1], cur, idx)

        # (A) 1차 시도: 기존 경로 → .ts 입력이면 demux 강제
        gpu_scale_vf = scale_vf
        if linux_gpu and codec in QSV and not _has_vf:
            gpu_scale_vf = ['-vf', f'{scale_vf[1]},{QSV_UPLOAD}' if scale_vf else QSV_UPLOAD]

        def cmd_first_pass():
            is_ts = effective_cur.lower().endswith(".ts")
            base = [
                ff, "-y", "-nostdin",
                "-fflags", "+genpts+discardcorrupt", "-analyzeduration", "100M", "-probesize", "100M",
                "-err_detect", "ignore_err", "-ignore_unknown",
            ]
            if is_ts:
                base += ["-f", "mpegts"]
            base += device_args + ["-i", effective_cur, "-map", "0:v:0?", "-map", "0:a:0?"]

            if do_copy:
                cmd = base + ["-c:v", "copy", "-c:a", "copy"]
                if out.lower().endswith(".mp4") and is_ts:
                    cmd += ["-bsf:a", "aac_adtstoasc"]
                return cmd + ["-movflags", "+faststart", out]
            else:
                return base + gpu_scale_vf + vopts + aopts + ["-movflags", "+faststart", out]


        # (B) 2차 시도: 강제 디멀티플렉서 + 재인코드(비디오만이라도 살리기)
        def cmd_second_pass():
            # do_copy여도 실패 시엔 비디오 재인코드로 강제
            vopts_force = vopts[:] if not do_copy else ["-c:v", "libx264", "-preset", "veryfast", "-crf", "24"]
            return [
                ff, "-y", "-nostdin",
                "-fflags", "+genpts+discardcorrupt", "-analyzeduration", "200M", "-probesize", "200M",
                "-err_detect", "ignore_err", "-ignore_unknown",
            ] + device_args + [
                "-f", "mpegts", "-i", effective_cur,        # 컨테이너 강제
                "-map", "0:v:0?", "-map", "0:a:0?",
                "-shortest",
            ] + gpu_scale_vf + vopts_force + aopts + ["-movflags", "+faststart", out]

        # (C) 3차 시도: 마지막 세그먼트면 살짝 트림하여 재시도
        def cmd_third_pass_trim(dur):
            # dur이 신뢰 가능하고 충분히 길 때만(>1.2s)
            cut = max(0.0, dur - 0.7)
            vopts_force = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "24"]
            return [
                ff, "-y", "-nostdin",
                "-fflags", "+genpts+discardcorrupt", "-analyzeduration", "200M", "-probesize", "200M",
                "-err_detect", "ignore_err", "-ignore_unknown",
                "-f", "mpegts", "-i", effective_cur,
                "-map", "0:v:0?", "-map", "0:a:0?",
                "-t", f"{cut:.2f}",
                "-shortest",
            ] + scale_vf + vopts_force + aopts + ["-movflags", "+faststart", out]

        try:
            try:
                await ffAsync(cmd_first_pass(), console_mode=mode)
            except subprocess.CalledProcessError:
                print(f"[BATCH][WARN] 1st pass failed: {os.path.basename(cur)} → retry (force demux/reencode)")

                try:
                    await ffAsync(cmd_second_pass(), console_mode=mode)

                except subprocess.CalledProcessError:
                    dur = await asyncio.to_thread(get_media_duration, ffprobe, effective_cur) if i == len(segs) - 1 else 0.0
                    if i == len(segs) - 1 and dur > 1.2:
                        print(f"[BATCH][WARN] 2nd pass failed: trimming tail and retry ({dur:.2f}s)")

                        try:
                            await ffAsync(cmd_third_pass_trim(dur), console_mode=mode)

                        except subprocess.CalledProcessError as e3:
                            print(f"[BATCH][WARN] 3rd pass failed on {os.path.basename(cur)} rc={e3.returncode} → skip")
                            continue

                    else:
                        print(f"[BATCH][WARN] 2nd pass failed on {os.path.basename(cur)} → skip")
                        continue
            completed_segments.add(idx)
            completed_outputs.append((cur, out))
        finally:
            retained_overlap_paths.extend(temp_overlap_paths)

    if len(completed_segments) != len(segs):
        if linux_gpu:
            raise gpu_failure(codec)
        raise RuntimeError('완료되지 않은 분할 후처리가 있습니다. 원본 세그먼트를 보존합니다.')
    await finalizeBatchProcessing(completed_outputs, post_cfg, retained_overlap_paths, job_id, inputs)


async def finalizeBatchProcessing(pairs, post_cfg, overlap_paths, job_id, inputs):
    if any(not output_has_minimum_size(output, 1, regular_file=True) for _, output in pairs):
        raise RuntimeError("분할 후처리 결과 파일이 없거나 비어 있습니다.")
    ffprobe = getFFprobe()
    for _, output in pairs:
        if not await asyncio.to_thread(has_video_stream, output, ffprobe):
            raise RuntimeError(f"분할 후처리 출력에 읽을 수 있는 영상 스트림이 없습니다. 원본을 보존했습니다: {output}")
    entries = [await asyncio.to_thread(plan, source, inputs[os.path.abspath(source)], output, post_cfg)
               for source, output in pairs]
    await commitPostprocess(job_id, entries)
    for path in overlap_paths:
        with contextlib.suppress(OSError):os.remove(path)


async def _watchChzzkStorage(proc, output_path, channel_id, channel_name, recover_on_stall, segments=None):
    last_growth = time.monotonic()
    next_disk_check = last_growth + 120
    last_sample = None
    stalled = False
    directory = os.path.dirname(output_path)
    diagnostics = RecorderManager.session_diagnostics.setdefault(channel_id, {})
    diagnostics.pop("write_stall_since", None)
    while proc.returncode is None and not recorder_manager.get_is_user_stopped(channel_id):
        await asyncio.sleep(10)
        if proc.returncode is not None or recorder_manager.get_is_user_stopped(channel_id):
            return
        now = time.monotonic()
        if now >= next_disk_check:
            next_disk_check = now + 120
            await asyncio.to_thread(checkDiskSpaceLow, directory, channel_id=channel_id, channel_name=channel_name)
        index, path = (-1, output_path)
        if segments is not None:
            available = segments()
            if available:
                index, path = available[-1]
        try:
            size = os.path.getsize(path)
        except FileNotFoundError:
            size = 0
        except OSError:
            size = 0
        sample = (index, size)
        if last_sample is None or sample > last_sample:
            last_growth = now
            stalled = False
            diagnostics.pop("write_stall_since", None)
        last_sample = sample
        if not stalled and now - last_growth >= 120 and proc.returncode is None:
            stalled = True
            diagnostics["write_stall_since"] = time.time() - (now - last_growth)
            print(f"[REC][WARN] {channel_name} 녹화 파일 쓰기 정체: {path}")
            retry = bool(recover_on_stall and recover_on_stall())
            diagnostics["recording_fault"] = "쓰기 정체 · 재연결 대기" if retry else "쓰기 정체 · 복구 한도 소진"
            try:
                await gracefulTerminate(proc)
            except (OSError, asyncio.TimeoutError) as exc:
                diagnostics["recording_fault"] = "쓰기 정체 · 프로세스 종료 실패"
                print(f"[REC][WARN] {channel_name} 정체 복구 실패: {exc}")
            return


# 분할 파이프라인 루프
async def stopSegmentProcesses(ffmpeg, streamlink, pump_task):
    drains = []
    if streamlink and pump_task is None:
        async def drain(stream):
            if stream:
                while await stream.read(65536):
                    pass
        drains = [asyncio.create_task(drain(stream)) for stream in (streamlink.stdout, streamlink.stderr)]
    try:
        if streamlink and streamlink.returncode is None:
            with contextlib.suppress(ProcessLookupError):
                streamlink.terminate()
        if pump_task and not pump_task.done():
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(pump_task, timeout=2)
        if ffmpeg and ffmpeg.stdin:
            ffmpeg.stdin.close()
        first_error = None
        for proc, timeout in ((ffmpeg, 9), (streamlink, 3)):
            if proc is None:
                continue
            try:
                try:
                    await asyncio.wait_for(proc.wait(), timeout=timeout)
                except asyncio.TimeoutError:
                    with contextlib.suppress(ProcessLookupError):
                        proc.kill()
                    await asyncio.wait_for(proc.wait(), timeout=3)
            except Exception as exc:
                first_error = first_error or exc
        if first_error is not None:
            raise first_error
    finally:
        for task in drains:
            await _cancel_task_safely(task)


async def runSegLoop(updated_channel: dict, channel_id: str, channel_name: str, metadata: dict, cookies: dict,
                     *, segmentSec: int, splitOverlapSec: int, autoPostProcessing: bool, post_cfg: dict,
                     base_noext: str, out_dir: str, recover_on_stall=None, plugin_settings=None):
    # (1) 세그먼트 패턴/디렉토리
    seg_ext = ".ts"
    INDEX_WIDTH = 3
    INDEX_PATTERN = f"%0{INDEX_WIDTH}d"
    segmentPattern = os.path.join(out_dir, f"{base_noext}_{INDEX_PATTERN}{seg_ext}")
    os.makedirs(out_dir, exist_ok=True)
    print("[SEGCFG] out_dir=", out_dir)
    print("[SEGCFG] pattern=", segmentPattern)

    streamlink = ffmpeg = None
    slErrTask = ffErrTask = pump_task = storage_task = None

    if plugin_settings is None:
        prefs = resolveRecordingPrefs()
        plugin_settings = prefs["plugin_type"], prefs["timemachine_time_shift"]
    # (2) 커맨드 생성
    sl_cmd, ff_cmd = buildPipeCmds(
        updated_channel, cookies, metadata,
        segmentPattern=segmentPattern,
        segmentSec=int(segmentSec),
        plugin_settings=plugin_settings,
    )
    try:
        print("[SL-CMD]", formatChzzkCmdForLog(sl_cmd))
    except Exception:
        print("[SL-CMD] <명령 표시 실패>")

    # (3) 환경/프로세스 스폰
    env = buildStreamlinkEnv(*plugin_settings)
    print(f"[DEBUG] export RWEB_TM_SHIFT={env.get('RWEB_TM_SHIFT')} (seg path)")

    kwargs_sl, kwargs_ff = {}, {}
    if os.name == "nt":
        kwargs_sl["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
        kwargs_ff["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW

    try:
        streamlink = await create_process(
            *sl_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            **kwargs_sl,
            env=env
        )

        ffmpeg = await create_process(
            *ff_cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
            **kwargs_ff
        )

        # 프로세스 등록
        recorder_manager.set_tasks_process(channel_id, ffmpeg, display_metadata=metadata)
        recorder_manager.recording_set_filename(channel_id, segmentPattern)
        recorder_manager.set_status_recording(channel_id, True)
        recorder_manager.set_status_reserved(channel_id, False)
        recorder_manager.recording_set_start_time(channel_id)

        # 리더/펌프
        slErrTask = asyncio.create_task(read_stderr(streamlink, channel_id))
        ffErrTask = asyncio.create_task(read_stderr(ffmpeg,     channel_id))
        pump_task = asyncio.create_task(pumpPipe(streamlink, ffmpeg))

        # (4) 세그먼트 감시 + 진행상태
        def listSegments():
            patt = f"{base_noext}_"
            files = []
            try:
                for name in os.listdir(out_dir):
                    if name.startswith(patt) and name.endswith(seg_ext):
                        try:
                            idx = int(name[len(patt):-len(seg_ext)])
                            files.append((idx, os.path.join(out_dir, name)))
                        except ValueError:
                            pass
            except Exception:
                pass
            files.sort(key=lambda x: x[0])
            return files

        storage_task = asyncio.create_task(_watchChzzkStorage(
            streamlink, segmentPattern, channel_id, channel_name, recover_on_stall, listSegments))
        seen_names: set[str] = set()
        last_progress_ts = 0.0

        while True:
            # ffmpeg 종료 시 탈출
            if ffmpeg and ffmpeg.returncode is not None:
                break

            # 사용자 중지 → 부드럽게 종료
            if recorder_manager.get_is_user_stopped(channel_id):
                break

            # 신규 세그먼트 로그/트래킹
            segs = listSegments()
            for idx, path in segs:
                if path in seen_names:
                    continue
                seen_names.add(path)
                print(f"[SEG] detected: {os.path.basename(path)}")

            # 진행 상태 (5초 주기)
            now = time.time()
            if segs and now - last_progress_ts >= 5.0:
                active_idx, active_path = segs[-1]
                try:
                    mib = os.path.getsize(active_path) / (1024 * 1024)
                    print(f"[SEG-PROG] {base_noext}_{idxName(active_idx)}{seg_ext} ~{mib:.1f} MiB")
                except Exception:
                    pass
                last_progress_ts = now

            await asyncio.sleep(0.5)

    finally:
        original_error = sys.exc_info()[1]
        producer_exit = streamlink.returncode if streamlink else None
        await _cancel_task_safely(storage_task)
        cleanup_error = None
        try:
            await stopSegmentProcesses(ffmpeg, streamlink, pump_task)
            if ffmpeg:
                segments = listNumericSegments(out_dir, base_noext, seg_ext)
                info = RecorderManager.session_diagnostics.setdefault(channel_id, {})
                exit_code = producer_exit if ffmpeg.returncode == 0 and producer_exit is not None else ffmpeg.returncode
                has_output = any(output_has_minimum_size(path, 1, regular_file=True) for _, path in segments)
                outcome = exit_result(exit_code, recorder_manager.get_is_user_stopped(channel_id),
                                      has_output, stalled=bool(info.get("recording_fault")))
                info.update(last_exit_code=ffmpeg.returncode, last_streamlink_exit_code=streamlink.returncode,
                            last_recording_outcome=outcome)
                if outcome == "failed":
                    info.setdefault("recording_fault", f"분할 녹화 비정상 종료 (FFmpeg {ffmpeg.returncode}, Streamlink {producer_exit})")
            if autoPostProcessing and ffmpeg and segments:
                await quiesce_last_segment(out_dir, base_noext, seg_ext, attempts=15, interval=0.4)
                if not await queueBatchPattern(channel_id, segmentPattern, session_cfg=post_cfg, overlap=splitOverlapSec):
                    raise RuntimeError("분할 후처리 등록 실패. 원본을 보존했습니다.")
        except Exception as e:
            cleanup_error = e
            RecorderManager.session_diagnostics.setdefault(channel_id, {})["recording_fault"] = "분할 녹화 종료 또는 후처리 등록 실패"
            print(f"[SEG][FINALIZE][ERROR] {channel_name}: {e}")

        # stderr 태스크 마무리
        for t in (slErrTask, ffErrTask):
            if t:
                try:
                    await asyncio.wait_for(t, timeout=1.5)
                except asyncio.TimeoutError:
                    with contextlib.suppress(Exception):
                        t.cancel()
                        await t

        with contextlib.suppress(OSError):
            os.rmdir(out_dir)

        # 세션 상태 정리
        try:
            recorder_manager.set_status_recording(channel_id, False)
            recorder_manager.recording_remove_start_time(channel_id)
            recorder_manager.recording_remove_filename(channel_id)
            if ffmpeg is None or ffmpeg.returncode is not None:
                recorder_manager.clear_tasks_process(channel_id)
        except Exception:
            pass

        # 종료 직후 예약/대기 재마킹 
        try:
            stop_req = recorder_manager.get_is_user_stopped(channel_id)
            latest = RecorderManager.getChannels() or []
            latest_ch = next((c for c in latest if c.get("id") == channel_id), None) or updated_channel
            rec_enabled_now = bool(latest_ch.get("record_enabled", True))
            if rec_enabled_now and not stop_req:
                recorder_manager.set_status_reserved(channel_id, True)
            else:
                recorder_manager.set_status_reserved(channel_id, False)
        except Exception:
            pass
        if cleanup_error is not None and original_error is None:
            raise cleanup_error


async def queueBatchPattern(channel_id: str, pattern_path: str, *, session_cfg=None, overlap=0, retry_job=None, retry_cfg=None) -> bool:
    claim = None
    job_id = None
    try:
        parsed = parseSegPattern(pattern_path)
        if not parsed:
            return False
        out_dir, base_noext, seg_ext = parsed
        claim = claimPostprocess(pattern_path)
        if claim is None:
            return False
        if retry_job is None:
            channels = RecorderManager.getChannels() or []
            channel = next((item for item in channels if item.get("id") == channel_id), {})
            channel_name = channel.get("name") or channel_id
            cfg = session_cfg
            segments = listNumericSegments(out_dir, base_noext, seg_ext)
            indexes = [index for index, _ in segments]
            inputs = await asyncio.to_thread(lambda: {os.path.abspath(path): identity(path) for _, path in segments})
        else:
            channel_name = retry_job.get("channel_name") or channel_id
            cfg = retry_cfg
            overlap = retry_job.get("split_overlap_sec") or 0
            indexes = retry_job["segment_indexes"]
            inputs = retry_job["input_identities"]
        job_id = recorder_manager.postprocess_register_job(
            channel_id=channel_id,
            channel_name=channel_name,
            input_path=pattern_path,
            post_cfg={
                **(cfg or {}),
                "_profile": (cfg or {}).get("_profile") or "batch",
            },
            job_id=retry_job["job_id"] if retry_job else None,
            segment_indexes=indexes,
            split_overlap_sec=overlap,
            inputs=inputs,
        )

        print(
            f"[BATCH][JOB-START] job={job_id} ch={channel_name} "
            f"pattern={pattern_path} out_dir={out_dir}"
        )

        async def work():
            if retry_job and retry_job.get("cleanup"):
                output = await commit_job(job_id, retry_job["cleanup"])
                recorder_manager.postprocess_set_output_path(job_id, output)
                return
            await batchEncodeSegments(
                session_dir=out_dir,
                base_noext=base_noext,
                overlap_sec=overlap,
                post_cfg=cfg,
                input_ext=seg_ext,
                job_id=job_id,
                inputs=inputs,
            )
        worker = work()
        try:
            t = asyncio.create_task(worker)
        except Exception:
            worker.close()
            raise

        def _on_batch_done(task: asyncio.Task):
            try:
                task.result()
                recorder_manager.postprocess_finish_job(job_id)
                print(f"[BATCH][JOB-OK] job={job_id} ch={channel_name} pattern={pattern_path}")
            except asyncio.CancelledError:
                recorder_manager.postprocess_fail_job(job_id, '앱 종료 또는 사용자 취소')
            except Exception as e:
                reason = f"batchEncodeSegments failed: {e}"
                recorder_manager.postprocess_fail_job(job_id, reason)
                print(f"[BATCH][JOB-FAIL] job={job_id} ch={channel_name} reason={reason}")
            finally:
                releasePostprocess(claim)

        t.add_done_callback(_on_batch_done)
        trackPostprocessTask(t)

        print(f"[BATCH][FALLBACK][PATTERN] start: {out_dir}")
        return True

    except asyncio.CancelledError:
        releasePostprocess(claim)
        raise
    except Exception as e:
        print(f"[BATCH][FALLBACK][PATTERN][ERROR] {channel_id} {e}")
        try:
            if job_id:
                recorder_manager.postprocess_fail_job(job_id, f"분할 후처리 시작 실패: {e}")
        finally:
            releasePostprocess(claim)
        return False


# 분할녹화 외부 폴백 트리거
# 분할녹화 저장 폴더 덮어쓰기 방지
def uniqueSessionDir(base_dir: str, base_noext: str) -> str:
    os.makedirs(base_dir, exist_ok=True)
    for index in range(1, 10001):
        path = os.path.join(base_dir, base_noext if index == 1 else f"{base_noext} ({index})")
        try:
            os.mkdir(path)
            return path
        except FileExistsError:
            continue
    raise FileExistsError(base_noext)


def formatChzzkCmdForLog(cmd: list) -> str:
    safe = []

    for item in cmd:
        text = str(item)

        if text.startswith("Cookie="):
            text = "Cookie=<hidden>"

        safe.append(shlex.quote(text))

    from module.diagnostics import redact
    return redact(" ".join(safe))


# 치지직용 녹화시작 함수
async def chzzkStartRecording(channel, cookies, recheckInterval, autoStopInterval, autoPostProcessing, filenamePattern,
                              plugin_type, timemachine_time_shift, is_user_request=False, splitRecordingMode=False, post_cfg=None):


    recent_live_block = {"live_id": None, "until": 0.0}

    # 0) 인자로 id 또는 dict 모두 허용
    if isinstance(channel, dict):
        channel_id = channel.get("id")
    else:
        channel_id = str(channel) if channel is not None else None
    if not channel_id:
        print("[ERROR] chzzkStartRecording: 유효하지 않은 채널 인자")
        return


    # 1) 현재 상태에서 dict 재조회 (메모리 동기화 보장 + 디스크 폴백)
    state_channels = RecorderManager.getChannels() or []
    channel_obj = next((c for c in state_channels if c.get("id") == channel_id), None)
    if not channel_obj:
        try:
            disk_channels = loadChannels() or []
            channel_obj = next((c for c in disk_channels if c.get("id") == channel_id), None)
        except Exception:
            channel_obj = None
    if not channel_obj:
        print(f"[ERROR] chzzkStartRecording: '{channel_id}' 채널을 찾을 수 없습니다.")
        return

    channel = channel_obj
    channel_id = channel["id"]
    channel_name = channel["name"]

    # 하드 가드: 사용자 중지면 어떤 경로로도 시작하지 않음
    if recorder_manager.get_is_user_stopped(channel_id):
        print(f"[DEBUG] {channel_name} 중지 요청 상태(하드 가드). 시작하지 않습니다.")
        return


    # 2) 녹화 플래그가 True인데 실제 프로세스가 없으면 상태 치유(힐링)
    if recorder_manager.get_status_recording(channel_id) and not procAlive(channel_id):
        print(f"[WARN] {channel_name} recording flag True but no live process. Healing state.")
        recorder_manager.set_status_recording(channel_id, False)
        recorder_manager.recording_remove_start_time(channel_id)
        recorder_manager.recording_remove_filename(channel_id)
        recorder_manager.clear_tasks_process(channel_id)

    # 3) 사용자 시작이면 stop 해제
    # 4) 중지 요청 상태면 시작 거절
    if recorder_manager.get_is_user_stopped(channel_id):
        print(f"[DEBUG] {channel_name} 채널은 중지 요청 상태. 시작하지 않음.")
        return

    # 5) 이미 '진짜' 녹화 중이면 거절
    if procAlive(channel_id):
        print(f"[DEBUG] {channel_name} 채널은 이미 녹화 중입니다.")
        return

    storage_recovery = ChzzkBroadcastRecovery(1)

    # 6) 예약 상태 선표시: 토글 ON & stop 아님 → 예약 표기, 그 외는 예약 해제
    if channel.get("record_enabled", True) and not recorder_manager.get_is_user_stopped(channel_id):
        recorder_manager.set_status_reserved(channel_id, True)
    else:
        recorder_manager.set_status_reserved(channel_id, False)

    # 7) 스트림 재시작 루프 (감시/녹화/종료/재탐색)
    while True:
        proc = None
        reserved_output = None
        capture_dir = capture_path = capture_task = None
        capture_started = None
        stdout_task = None
        storage_task = None
        stderr_task = None
        stream_ended_flag = asyncio.Event()

        try:
            # 7-1) 루프마다 채널 최신화(토글 변경 반영)
            updated_channels = RecorderManager.getChannels() or []
            if not updated_channels:
                try:
                    updated_channels = loadChannels() or []
                    if updated_channels:
                        RecorderManager.setChannels(updated_channels)
                except Exception as _e:
                    print(f"[WARN] 메모리 복구 실패(무시): {_e}")
                    updated_channels = []

            updated_channel = next((c for c in updated_channels if c.get("id") == channel_id), None)
            if updated_channel is None:
                break
            # 다음 감시/재연결부터 적용
            cookies = await asyncio.to_thread(loadCookies)
            from module.data_manager import COOKIE_PATH
            info = RecorderManager.session_diagnostics.setdefault(channel_id, {})
            info["cookie_applied_at"] = time.time()
            try:
                info["cookie_generation"] = os.stat(COOKIE_PATH).st_mtime_ns
            except OSError:
                info["cookie_generation"] = None
            rec_enabled = bool(updated_channel.get("record_enabled", True))

            config = loadConfig() or {}
            if getConfigLoadStatus() == "safe_mode":
                recorder_manager.set_status_reserved(channel_id, False)
                break
            post_cfg = buildPostCfgForChannel(updated_channel, config)
            autoPostProcessing = bool(config.get("autoPostProcessing", autoPostProcessing))
            recheckInterval = max(5, int(config.get("recheckInterval", recheckInterval)))
            autoStopInterval = int(config.get("autoStopInterval", autoStopInterval) or 0)
            splitRecordingMode = bool(config.get("splitRecordingMode", splitRecordingMode))
            filenamePattern = config.get("filenamePattern") or filenamePattern
            plugin_type = updated_channel.get("plugin_type") or config.get("plugin_type", plugin_type)
            timemachine_time_shift = config.get("timemachine_time_shift", timemachine_time_shift)

            post_queued = False  # 이번 세션에서 후처리 큐잉 여부

            # 7-2) 자동-재탐색 경로: 사용자 트리거가 아니고 토글 OFF면 감시 루프 종료
            if not is_user_request and not rec_enabled:
                print(f"[DEBUG] {channel_name} 자동녹화 OFF → 루프 종료(감시 안 함).")
                break

            # 7-3) 중지 버튼 감지 시 종료
            if recorder_manager.get_is_user_stopped(channel_id):
                print(f"[DEBUG] {channel_name} 중지 요청 감지. 루프 종료.")
                break

            # 7-4) 메타데이터 조회 (OPEN 여부)
            metadata = await getLiveMetadata(updated_channel, cookies)
            metadata = await waitStableChzzkMetadata(updated_channel, cookies, metadata)
            is_open = bool(metadata and (metadata.get("status") == "OPEN"))
            confirmed_closed = bool((metadata or {}).get("_chzzk_confirmed_closed"))
            probe_failed = False
            info["watchparty_detected"] = bool((metadata or {}).get("watchPartyNo"))
            info["requested_quality"] = updated_channel.get("quality")
            info["selected_quality"] = (metadata or {}).get("record_quality")
            is_open_meta = bool(metadata and (metadata.get("status") == "OPEN")) # 힐트리거용 별도 변수

            live_id = (metadata or {}).get("liveId")
            now_ts  = time.time()

            # tail-guard: 분할녹화에서 방종 직후 같은 라이브로 되감기 재접속 금지
            tail_guard_active = False
            if splitRecordingMode and (autoStopInterval or 0) > 0:
                if (recent_live_block["live_id"]
                    and live_id == recent_live_block["live_id"]
                    and now_ts < recent_live_block["until"]):
                    tail_guard_active = True
                    is_open = False
                    remain = int(recent_live_block['until'] - now_ts)
                    print(f"[DEBUG] {channel_name} tail-guard ON for liveId={live_id} ({remain}s left) → treat as CLOSED")
                elif recent_live_block["live_id"] and live_id and live_id != recent_live_block["live_id"]:
                    # 새 라이브 시작 → 쿨다운 즉시 해제
                    recent_live_block["until"] = 0.0

            # 메타가 애매할 때만 프로브, tail-guard 중엔 프로브 금지
            if not is_open and not tail_guard_active:
                ok = await probeStreamBounded(updated_channel, cookies, timeout_sec=6)
                _reason = updated_channel.get("_last_probe_reason")
                probe_failed = _reason == "fail"

                if ok:
                    print(f"[DEBUG] {channel_name} OPEN fallback: HLS probe 통과 → 진행")

                    metadata = await waitStableChzzkMetadata(
                        updated_channel,
                        cookies,
                        None,
                        retries=5,
                        delay=1.5
                    )

                    if not metadata or metadata.get("status") != "OPEN" or isUnstableChzzkIdentityMetadata(metadata):
                        now_dt = datetime.now()
                        signals = {key: metadata[key] for key in ChzzkBroadcastRecovery.IDENTITY_FIELDS
                                   if metadata and metadata.get("status") == "OPEN" and metadata.get(key)}
                        metadata = {
                            **signals,
                            "status": "OPEN",
                            "liveTitle": updated_channel.get("name") or "녹화",
                            "start_time": now_dt.strftime("%Y-%m-%d"),
                            "broadcast_time": now_dt.strftime("%y%m%d_%H%M%S"),
                            "_probe_fallback": True,
                        }

                    if metadata:
                        record_quality_for_name, frame_rate_for_name = normalizeQualityNameParts(updated_channel, metadata)
                        metadata["record_quality"] = record_quality_for_name
                        metadata["frame_rate"] = frame_rate_for_name

                    is_open = True
                else:
                    if _reason == "skip":
                        print(f"[INFO] {channel_name} HLS probe 스킵(슬롯 바쁨) → CLOSED 유지")
                    elif _reason == "timeout":
                        print(f"[WARN] {channel_name} HLS probe 타임아웃 → CLOSED 유지")
                    else:
                        print(f"[DEBUG] {channel_name} HLS probe 실패 → CLOSED 유지")             

            # 예약+OPEN인데 실제 녹화 프로세스가 없으면 해제
            if is_open_meta and not tail_guard_active and recorder_manager.get_status_reserved(channel_id):
                p = recorder_manager.get_tasks_process(channel_id)
                age = recorder_manager.guard_get_start_age(channel_id)  # None이면 가드가 없음

                stalled = float(age) if age is not None else 0.0

                # 가드가 존재할 때만 오래된 잠금 해제
                if (not p) and (age is not None) and (stalled > 45.0):
                    print(f"[HEAL] {channel_name} reserved+OPEN(meta) but no process for {int(stalled)}s → guard_release_start() & retry")
                    recorder_manager.guard_release_start(channel_id)

            if not is_open:
                storage_recovery.observe_closed(confirmed_closed and probe_failed, time.monotonic())

                print(f"[DEBUG] {channel_name} 방송 종료/미오픈 상태.")
                recorder_manager.set_status_recording(channel_id, False)

                if rec_enabled:
                    # 토글 ON → 예약 유지(감시)
                    recorder_manager.set_status_reserved(channel_id, True)
                    new_state = "예약녹화 중"
                    if last_notified_state.get(channel_id) != new_state:
                        last_notified_state[channel_id] = new_state

                    _base = max(10, int(recheckInterval))
                    _jit  = max(1, int(_base * JITTER_RATIO))
                    _seed = int(hashlib.blake2b(str(channel_id).encode(), digest_size=4).hexdigest(), 16)

                    _phase = _JITTER_PHASE.get(channel_id)
                    if _phase is None:
                        _phase = (_seed % (2 * _jit + 1)) - _jit   # [-_jit, +_jit]
                        _JITTER_PHASE[channel_id] = _phase

                    now = time.monotonic()
                    period = _base
                    k = math.floor((now - (START_MONO + _phase)) / period) + 1
                    next_time = START_MONO + _phase + k * period
                    _sleep = max(1, int(next_time - now))

                    print(f"[DEBUG] {channel_name} 예약 유지. {_sleep}s 후 재탐색(초기위상={_phase:+d}s, 주기={period}s).")
                    await asyncio.sleep(_sleep)

                    # 재탐색 직전 OFF/STOP 재확인
                    updated_channels = RecorderManager.getChannels() or []
                    updated_channel = next((c for c in updated_channels if c.get("id") == channel_id), None) or channel
                    if not updated_channel.get("record_enabled", True):
                        print(f"[DEBUG] {channel_name} 토글 OFF 감지. 루프 종료.")
                        break
                    if recorder_manager.get_is_user_stopped(channel_id):
                        print(f"[DEBUG] {channel_name} 중지 요청. 루프 종료.")
                        break
                    continue
                else:
                    # 토글 OFF → 1회성. 감시 유지 안 함.
                    recorder_manager.set_status_reserved(channel_id, False)
                    try:
                        updated_channel["status"] = "대기 중"
                    except Exception:
                        pass
                    print(f"[DEBUG] {channel_name} 토글 OFF이므로 '대기 중' 전환 후 루프 종료.")
                    break

            # 7-5) OPEN 상태 → '같이보기만 녹화' 옵션 + 태그 제외 필터
            if updated_channel.get("recordWatchParty", False):
                # 7-5-1) 같이보기 미활성 → 스킵
                if metadata.get("watchPartyNo") is None:
                    print(f"[DEBUG] {channel_name} 같이보기 미활성 → 녹화 스킵.")
                    recorder_manager.set_status_recording(channel_id, False)

                    if rec_enabled:
                        recorder_manager.set_status_reserved(channel_id, True)
                        await asyncio.sleep(recheckInterval)
                        continue
                    else:
                        recorder_manager.set_status_reserved(channel_id, False)
                        print(f"[DEBUG] {channel_name} 토글 OFF(1회성). '대기 중' 전환 후 루프 종료.")
                        break

                # 7-5-2) 같이보기 활성 + 녹화 제외할 태그 매칭 시 스킵
                exclude_list = (updated_channel.get("watchPartyExcludeTags") or [])
                if exclude_list:
                    tag = (metadata.get("watchPartyTag") or "")
                    lt = tag.lower()
                    hit = next((kw for kw in exclude_list
                                if (kw or "").strip() and (kw.lower() in lt)), None)
                    if hit is not None:
                        print(f"[DEBUG] {channel_name} [같이보기만 녹화에서 제외 태그 확인] 태그에 '{hit}' 포함 → 녹화 스킵.")
                        recorder_manager.set_status_recording(channel_id, False)
                        if rec_enabled:
                            recorder_manager.set_status_reserved(channel_id, True)
                            await asyncio.sleep(recheckInterval)
                            continue
                        else:
                            recorder_manager.set_status_reserved(channel_id, False)
                            print(f"[DEBUG] {channel_name} 토글 OFF(1회성). '대기 중' 전환 후 루프 종료.")
                            break

            # 7-6) 같이보기 알림 플래그 리셋
            if metadata.get("watchPartyNo") is not None:
                recorder_manager.reset_watch_party_off_notified(channel_id)

            # 7-7) 파일명 구성
            recording_time = datetime.now().strftime("%y%m%d_%H%M%S")

            if isUnstableChzzkIdentityMetadata(metadata) or isUnresolvedQualityMetadata(metadata):
                fresh_metadata = await waitStableChzzkMetadata(
                    updated_channel,
                    cookies,
                    None,
                    retries=5,
                    delay=1.0
                )

                if fresh_metadata and fresh_metadata.get("status") == "OPEN":
                    metadata = fresh_metadata

            if not storage_recovery.may_record(metadata):
                await asyncio.sleep(recheckInterval)
                continue
            if storage_recovery.changed_broadcast:
                for key in ("write_stall_since", "last_exit_code", "last_streamlink_exit_code", "last_recording_outcome"):
                    info.pop(key, None)
                recent_live_block["until"] = 0.0

            metadata = applySafeChzzkFilenameMetadata(updated_channel, metadata, recording_time)

            record_quality_for_name, frame_rate_for_name = normalizeQualityNameParts(
                updated_channel,
                metadata
            )

            live_title = metadata.get("liveTitle", "녹화")
            safe_live_title = sanitizeFilenamePart(live_title, "녹화", FILENAME_LIVE_TITLE_LIMIT)
            safe_channel_name = sanitizeFilenamePart(channel_name, channel_id, FILENAME_CHANNEL_NAME_LIMIT)
            start_time = metadata.get("start_time", "UnknownTime")
            broadcast_time = metadata.get("broadcast_time") or recording_time
            file_extension = updated_channel.get("extension", ".ts")

            filename = filenamePattern.format(
                recording_time=recording_time,
                start_time=start_time,
                broadcast_time=broadcast_time,
                safe_live_title=safe_live_title,
                channel_name=safe_channel_name,
                record_quality=sanitizeFilenamePart(record_quality_for_name, "best", 20),
                frame_rate=sanitizeFilenamePart(frame_rate_for_name, "", 10),
                file_extension=file_extension,
            )

            filename = sanitizeGeneratedFilename(filename, file_extension)

            output_dir_abs_path = os.path.join(base_directory, validateMediaDirectory(updated_channel.get("output_dir", "./output")))

            checkDiskSpaceLow(
                output_dir_abs_path,
                channel_id=channel_id,
                channel_name=channel_name
            )

            unique_filename_ = uniqueFilename(output_dir_abs_path, filename, add_suffix=True)
            output_path = os.path.join(output_dir_abs_path, unique_filename_)
            updated_channel["output_path"] = output_path

            try:
                splitOverlapSec_cfg = int(config.get("splitOverlapSec", 0) or 0)
            except Exception:
                splitOverlapSec_cfg = 0
            splitOverlapSec_cfg = max(0, min(30, splitOverlapSec_cfg))

            info.pop("recording_fault", None)
            info.pop("capture_error", None)
            info.pop("capture_duration", None)

            # 분할 ON이면 일반 경로 스킵하고 파이프라인으로 직행
            if splitRecordingMode and (autoStopInterval or 0) > 0:
                base_dir  = os.path.dirname(output_path)
                base_name = os.path.basename(output_path)
                base_noext, ext = os.path.splitext(base_name)

                session_dir = uniqueSessionDir(base_dir, base_noext)

                print(f"[PIPE] split path engaged: interval={autoStopInterval}s overlap={splitOverlapSec_cfg}s")
                print(f"[PIPE] session_dir={session_dir}")

                segment_task = None
                try:
                    segment_worker = runSegLoop(
                        updated_channel, channel_id, channel_name, metadata, cookies,
                        segmentSec=autoStopInterval,
                        splitOverlapSec=splitOverlapSec_cfg,
                        autoPostProcessing=post_cfg["splitPostProcessing"],
                        post_cfg=post_cfg or {},
                        base_noext=base_noext,
                        out_dir=session_dir, recover_on_stall=storage_recovery.retry,
                        plugin_settings=(plugin_type, timemachine_time_shift),
                    )
                    try:
                        segment_task = asyncio.create_task(segment_worker)
                    except Exception:
                        segment_worker.close()
                        raise
                    RecorderManager.tasks_segment[channel_id] = segment_task
                    await asyncio.shield(segment_task)

                except asyncio.CancelledError:
                    if segment_task is not None:
                        if not segment_task.done() and not segment_task.cancelling():
                            segment_task.cancel()
                        await asyncio.gather(segment_task, return_exceptions=True)
                    raise
                finally:
                    if segment_task is not None and RecorderManager.tasks_segment.get(channel_id) is segment_task:
                        RecorderManager.tasks_segment.pop(channel_id, None)
                    if segment_task is not None:
                        cooldown = TAIL_GUARD_COOLDOWN_SEC
                        recent_live_block["live_id"] = (metadata or {}).get("liveId")
                        recent_live_block["until"] = time.time() + cooldown
                        print(f"[DEBUG] {channel_name} tail-guard ARMED (split finalize) {cooldown}s")

                    with contextlib.suppress(Exception):
                        os.rmdir(session_dir)

                # 분할 경로는 다음 감시 루프로
                continue


            # 7-8) 녹화 명령 생성
            cmd = buildCommand(
                updated_channel, metadata, recording_time, cookies, filenamePattern, plugin_type, timemachine_time_shift
            )

            if not cmd or not isinstance(cmd, (list, tuple)):
                print(f"[ERROR] {channel_name} 명령 생성 실패: {cmd}")

                notifyEvent(
                    "record_start_failed",
                    "녹화 시작 실패",
                    "녹화 명령을 생성하지 못했습니다.",
                    channel_id=channel_id,
                    channel_name=channel_name,
                    detail=str(cmd),
                    severity="error"
                )

                recorder_manager.set_status_recording(channel_id, False)
                recorder_manager.recording_remove_start_time(channel_id)
                recorder_manager.recording_remove_filename(channel_id)

                # 토글 ON이면 예약 유지하고 재시도, OFF면 종료
                if rec_enabled:
                    recorder_manager.set_status_reserved(channel_id, True)
                    await asyncio.sleep(recheckInterval)
                    continue
                else:
                    recorder_manager.set_status_reserved(channel_id, False)
                    print(f"[DEBUG] {channel_name} 토글 OFF이므로 명령 실패 후 루프 종료.")
                    break

            # 7-9) 프로세스 실행
            output_path = updated_channel["output_path"]
            reserved_output = path_key(output_path)
            _chzzk_output_paths.add(reserved_output)
            if not autoPostProcessing:
                capture_dir = tempfile.mkdtemp(prefix=".recordweb-capture-", dir=os.path.dirname(output_path))
                capture_path = os.path.join(capture_dir, os.path.basename(output_path))
                cmd[-1] = capture_path
                capture_started = time.monotonic()
            try:
                print(f"[DEBUG] {channel_name} cmd: " + formatChzzkCmdForLog(cmd))
            except Exception:
                print(f"[DEBUG] {channel_name} cmd: <명령 출력 중 오류>")
            kwargs = {}
            if os.name == "nt":
                kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW

            proc = await create_process(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                **kwargs,
            )

            recorder_manager.recording_set_filename(channel_id, output_path, temp_path=capture_path)
            recorder_manager.set_tasks_process(channel_id, proc, display_metadata=metadata)

            # 7-10) 프로세스 핸들/파일명 세팅 완료 후 상태 승격
            recorder_manager.set_status_recording(channel_id, True)
            recorder_manager.set_status_reserved(channel_id, False)
            recorder_manager.recording_set_start_time(channel_id)

            # 7-11) 알림
            new_state = "녹화 중"
            if last_notified_state.get(channel_id) != new_state:
                notifyEvent(
                    "record_started",
                    "녹화 시작",
                    "녹화가 시작되었습니다.",
                    channel_id=channel_id,
                    channel_name=channel_name,
                    severity="info"
                )

                last_notified_state[channel_id] = new_state

            # 7-12) 출력 리더 태스크
            stream_ended_flag = asyncio.Event()
            transient_end_flag = asyncio.Event()  
            stdout_task = asyncio.create_task(read_stdout(proc, channel_id, stream_ended_flag))
            stderr_task = asyncio.create_task(read_stderr(proc, channel_id, transient_end_flag))

            # 7-12) 일반 대기
            storage_task = asyncio.create_task(_watchChzzkStorage(
                proc, capture_path or output_path, channel_id, channel_name, storage_recovery.retry))
            exit_code = await proc.wait()
            await _cancel_task_safely(storage_task)
            current_output_path = updated_channel.get("output_path")
            output_present = False
            with contextlib.suppress(OSError):
                output_present = bool(current_output_path and output_has_minimum_size(current_output_path, 1, regular_file=True))
            if capture_path:
                capture_task = asyncio.create_task(finishChzzkCapture(capture_path, output_path, capture_started, plugin_type, info))
                output_present = await finish_before_cancel(capture_task)
            outcome = exit_result(exit_code, recorder_manager.get_is_user_stopped(channel_id), output_present,
                                  stalled=bool(info.get("recording_fault")))
            if capture_path and not output_present:
                outcome = "failed"
            info.update(last_exit_code=exit_code, last_recording_outcome=outcome)
            if outcome == "failed":
                info.setdefault("recording_fault", f"녹화 비정상 종료 (Streamlink {exit_code})")

            # 끝난 즉시 후처리
            current_output_path = updated_channel.get("output_path")
            if (autoPostProcessing and current_output_path and os.path.exists(current_output_path)
                    and not post_queued):

                post_queued = queuePostprocess(current_output_path, channel_id, channel_name, post_cfg)

            # 종료 즉시 알림
            try:
                if outcome != "user_stopped":
                    dur = recorder_manager.get_recording_duration(channel_id)  # "HH:MM:SS"
                    failed = outcome == "failed"
                    label = "녹화 비정상 종료" if failed else "녹화 종료"
                    if last_notified_state.get(channel_id) != label:
                        notifyEvent(
                            "record_abnormally_stopped" if failed else "record_finished",
                            label,
                            info["recording_fault"] if failed else f"녹화가 종료되었습니다. 녹화시간: {dur}",
                            channel_id=channel_id,
                            channel_name=channel_name,
                            detail=os.path.basename(current_output_path or ""),
                            severity="error" if failed else "info"
                        )

                        last_notified_state[channel_id] = label

            except Exception as _e:
                print(f"[WARN] finalize telegram failed: {_e}")

            # 무조건 stale 경로 제거
            with contextlib.suppress(Exception):
                updated_channel.pop("output_path", None)

            # 방종 꼬리 쿨다운
            if stream_ended_flag.is_set() and not recorder_manager.get_is_user_stopped(channel_id):
                # 1) stderr에서 일시장애로 표기되었으면 메타/HLS 재확인 후 쿨다운 없이 재시작
                if 'transient_end_flag' in locals() and transient_end_flag.is_set():
                    try:
                        meta2 = await getLiveMetadata(updated_channel, cookies)
                        if meta2 and meta2.get("status") == "OPEN":
                            # 실제 HLS도 열려있는지 빠른 프로브
                            ok = await probeStreamBounded(updated_channel, cookies, timeout_sec=6)
                            if ok:
                                # 상태만 정리하고 즉시 다음 루프로(명령 재생성 → 재연결)
                                recorder_manager.set_status_recording(channel_id, False)
                                recorder_manager.recording_remove_start_time(channel_id)
                                recorder_manager.recording_remove_filename(channel_id)
                                print(f"[DEBUG] {channel_name} 일시적 HLS 에러 감지 → 쿨다운 없이 즉시 재시작.")
                                await asyncio.sleep(1.0)
                                continue
                    except Exception as _e:
                        print(f"[WARN] transient restart check failed: {_e}")

                # 2) 여기로 오면 '진짜 종료'로 간주 → 기존 로직 수행(쿨다운/예약 유지)
                recorder_manager.set_status_recording(channel_id, False)

                # 최신 채널 토글 재확인
                latest = RecorderManager.getChannels() or []
                latest_ch = next((c for c in latest if c.get("id") == channel_id), None) or updated_channel
                rec_enabled_now = bool(latest_ch.get("record_enabled", True))

                if not rec_enabled_now:
                    # 즉시 예약 해제 + 상태 문자열 힌트
                    recorder_manager.set_status_reserved(channel_id, False)
                    try:
                        latest_ch["status"] = "대기 중"
                    except Exception:
                        pass
                    stream_ended_flag.clear()
                    break  # OFF이므로 다음 회차 감시로 가지 않고 즉시 루프 종료

                # ON이면 기존처럼 예약 유지 + 쿨다운
                recorder_manager.set_status_reserved(channel_id, True)
                print("[DEBUG] Stream ended detected. Mark reserved immediately; cooldown before re-scan.")
                stream_ended_flag.clear()
                await asyncio.sleep(TAIL_GUARD_COOLDOWN_SEC)


            # 리더 태스크 마무리
            await stdout_task
            if stderr_task:
                await stderr_task

            # 7-13) 종료 후 분기: 사용자 Stop / 토글 ON / 토글 OFF
            updated_channels = RecorderManager.getChannels() or []
            updated_channel = next((c for c in updated_channels if c.get("id") == channel_id), None) or channel
            rec_enabled = bool(updated_channel.get("record_enabled", True))

            if recorder_manager.get_is_user_stopped(channel_id):
                recorder_manager.set_status_reserved(channel_id, False)
                print(f"[DEBUG] {channel_name} 사용자 중지로 루프 종료.")
                break
            else:
                if rec_enabled:
                    recorder_manager.set_status_reserved(channel_id, True)

                    _base = max(10, int(recheckInterval))
                    _jit  = max(1, int(_base * JITTER_RATIO))
                    _seed = int(hashlib.blake2b(str(channel_id).encode(), digest_size=4).hexdigest(), 16)

                    _phase = _JITTER_PHASE.get(channel_id)
                    if _phase is None:
                        _phase = (_seed % (2 * _jit + 1)) - _jit
                        _JITTER_PHASE[channel_id] = _phase

                    now = time.monotonic()
                    period = _base
                    k = math.floor((now - (START_MONO + _phase)) / period) + 1
                    next_time = START_MONO + _phase + k * period
                    _sleep = max(1, int(next_time - now))

                    print(f"[DEBUG] {channel_name} 종료 → 예약 유지. {_sleep}s 후 재탐색(초기위상={_phase:+d}s, 주기={period}s).")
                    await asyncio.sleep(_sleep)

                    # 재탐색 직전 OFF/STOP 재확인
                    updated_channels = RecorderManager.getChannels() or []
                    updated_channel = next((c for c in updated_channels if c.get("id") == channel_id), None) or channel
                    if not updated_channel.get("record_enabled", True):
                        print(f"[DEBUG] {channel_name} OFF 감지. 루프 종료.")
                        break
                    if recorder_manager.get_is_user_stopped(channel_id):
                        print(f"[DEBUG] {channel_name} 사용자 중지 요청. 루프 종료.")
                        break

                    # 다음 루프
                    continue
                else:
                    # 1회성: 예약 없이 종료
                    recorder_manager.set_status_reserved(channel_id, False)
                    print(f"[DEBUG] {channel_name} 토글 OFF(1회성). 루프 종료.")
                    break

        except asyncio.CancelledError:
            print(f"[DEBUG] {channel_name} 녹화 태스크 중지")
            await _cancel_task_safely(storage_task)

            # 프로세스 소프트 종료
            if proc and proc.returncode is None:
                await gracefulTerminate(proc)
            capture_ok = True
            if capture_path and proc and proc.returncode is not None:
                if capture_task is None:
                    capture_task = asyncio.create_task(finishChzzkCapture(capture_path, output_path, capture_started, plugin_type, info))
                capture_ok = await finish_before_cancel(capture_task)
            if proc and (not capture_ok or recorder_manager.get_is_user_stopped(channel_id)):
                info.update(last_exit_code=proc.returncode, last_recording_outcome="user_stopped" if capture_ok else "failed")

            current_output_path = None
            try:
                current_output_path = output_path  # noqa: F821
            except Exception:
                pass
            if not current_output_path:
                try:
                    current_output_path = updated_channel.get("output_path")
                except Exception:
                    current_output_path = None

            # The split task owns its own finalization and queue submission.
            if splitRecordingMode and autoStopInterval > 0:
                if recorder_manager.get_is_user_stopped(channel_id):
                    break
                raise

            # 분할 모드가 아닐 때: 실제 녹화 세션이었던 경우에만 후처리 큐잉
            else:
                if (autoPostProcessing and proc is not None and recorder_manager.get_status_recording(channel_id) 
                    and current_output_path and os.path.exists(current_output_path) and not post_queued):

                    post_queued = queuePostprocess(current_output_path, channel_id, channel_name, post_cfg)

                # 어떤 경우든(큐잉 여부와 무관) stale 경로는 즉시 정리
                with contextlib.suppress(Exception):
                    updated_channel.pop("output_path", None)

            for t in (stdout_task, stderr_task):
                if t:
                    with contextlib.suppress(Exception):
                        await asyncio.wait_for(t, timeout=1.5)
            for t in (stdout_task, stderr_task):
                if t and not t.done():
                    t.cancel()
                    with contextlib.suppress(Exception):
                        await t

            stop_req = recorder_manager.get_is_user_stopped(channel_id)
            auto_cfg = (loadConfig() or {}).get("autoRecordingMode", False)
            rec_enabled_dbg = bool(channel.get("record_enabled", True))

            print(
                f"[REC-END] {channel_name} auto={auto_cfg} "
                f"enabled={rec_enabled_dbg} stop_requested={stop_req}"
            )

            try:
                recorder_manager.set_status_recording(channel_id, False)
                recorder_manager.recording_remove_start_time(channel_id)
                recorder_manager.recording_remove_filename(channel_id)
                recorder_manager.clear_tasks_process(channel_id)
            except Exception as _e:
                print(f"[WARN] end-of-session cleanup failed: {_e}")

            if not stop_req:
                recorder_manager.set_is_user_stopped(channel_id, False)

            print(f"[DEBUG] {channel_name} 세션 종료. FSM 후속 전이.")

            try:
                # 최신 토글/사용자중지 상태 재조회
                stop_req = recorder_manager.get_is_user_stopped(channel_id)
                latest = RecorderManager.getChannels() or []
                latest_ch = next((c for c in latest if c.get("id") == channel_id), None) or channel
                rec_enabled_now = bool(latest_ch.get("record_enabled", True))

                if stop_req:
                    # 사용자 중지면 예약 해제하고 루프 종료
                    recorder_manager.set_status_reserved(channel_id, False)
                    print(f"[DEBUG] {channel_name} 사용자 중지 감지 → 루프 종료.")
                    break

                if not rec_enabled_now:
                    # 토글 OFF면 예약 해제하고 루프 종료
                    recorder_manager.set_status_reserved(channel_id, False)
                    print(f"[DEBUG] {channel_name} 토글 OFF → 루프 종료.")
                    break

                # 이 외에는 예약 유지 후 다음 회차를 위해 재탐색 진입
                recorder_manager.set_status_reserved(channel_id, True)

                _base = max(10, int(recheckInterval))
                _jit  = max(1, int(_base * JITTER_RATIO))
                _seed = int(hashlib.blake2b(str(channel_id).encode(), digest_size=4).hexdigest(), 16)

                _phase = _JITTER_PHASE.get(channel_id)
                if _phase is None:
                    _phase = (_seed % (2 * _jit + 1)) - _jit
                    _JITTER_PHASE[channel_id] = _phase

                now = time.monotonic()
                period = _base
                k = math.floor((now - (START_MONO + _phase)) / period) + 1
                next_time = START_MONO + _phase + k * period
                _sleep = max(1, int(next_time - now))

                print(f"[DEBUG] {channel_name} 종료 → 예약 유지. {_sleep}s 후 재탐색(초기위상={_phase:+d}s, 주기={period}s).")
                await asyncio.sleep(_sleep)

                continue  # 다음 루프로 진입 

            except Exception as _e:
                # 예약 유지 후 재탐색 재시도
                print(f"[WARN] {channel_name} 종료 분기 처리 실패({_e}) → {recheckInterval}s 후 재탐색 재시도")
                try:
                    recorder_manager.set_status_reserved(channel_id, True)
                except Exception:
                    pass
                await asyncio.sleep(recheckInterval)
                continue

        finally:
            try:
                await _cancel_task_safely(storage_task)
                if proc and proc.returncode is None:
                    await gracefulTerminate(proc, timeout=3.0)
            finally:
                if reserved_output is not None:
                    _chzzk_output_paths.discard(reserved_output)
                if capture_dir:
                    with contextlib.suppress(OSError):
                        os.rmdir(capture_dir)

            for t in (stdout_task, stderr_task):
                if t and not t.done():
                    with contextlib.suppress(Exception):
                        await asyncio.wait_for(t, timeout=1.0)
                if t and not t.done():
                    t.cancel()
                    with contextlib.suppress(Exception):
                        await t

    print(f"[DEBUG] {channel_name} 녹화 루프가 종료됩니다.")
    recorder_manager.set_status_recording(channel_id, False)
    if not procAlive(channel_id):
        recorder_manager.clear_tasks_process(channel_id)
    recorder_manager.recording_remove_start_time(channel_id)
    recorder_manager.recording_remove_filename(channel_id)

    if recorder_manager.get_is_user_stopped(channel_id):
        # 사용자 요청 녹화중지시 재탐색하지 않고 완전 대기
        recorder_manager.set_status_reserved(channel_id, False)
        try:
            channel["status"] = "대기 중"   
        except Exception:
            pass
        print(f"[DEBUG] {channel_name} 사용자 요청으로 완전히 중지.")

    else:
        # 자연 종료 케이스: 다음 방송을 대비해 예약 상태로 복귀
        recorder_manager.set_is_user_stopped(channel_id, False)

        latest = RecorderManager.getChannels() or []
        latest_ch = next((c for c in latest if c.get("id") == channel_id), None) or channel
        rec_enabled_now = bool(latest_ch.get("record_enabled", True))

        if rec_enabled_now:
            recorder_manager.set_status_reserved(channel_id, True)
            try:
                latest_ch["status"] = "예약녹화 중"
            except Exception:
                pass
        else:
            recorder_manager.set_status_reserved(channel_id, False)
            try:
                latest_ch["status"] = "대기 중"
            except Exception:
                pass


# 치지직용 녹화중지 함수
async def chzzkStopRecording(channel_id):
    print(f"[DEBUG] chzzkStopRecording 시작 - 채널 ID: {channel_id}")

    # 이미 STOP이면 재진입 금지
    if recorder_manager.get_is_user_stopped(channel_id):
        print(f"[DEBUG] {channel_id} 중복 stop 요청 → 무시")
        return

    recorder_manager.set_is_user_stopped(channel_id, True)
