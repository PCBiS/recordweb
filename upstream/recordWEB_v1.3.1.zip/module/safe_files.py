"""Publish media paths without replacing a file belonging to another job."""
import errno
import os
import shutil
import tempfile
from pathlib import Path


def rename_new(source, target):
    if os.name == "nt":
        os.rename(source, target)  # Windows MoveFileEx without REPLACE_EXISTING
        return
    import ctypes
    libc = ctypes.CDLL(None, use_errno=True)
    try:
        rename = libc.renameat2
    except AttributeError as error:
        raise OSError(errno.ENOTSUP, "덮어쓰지 않는 이름 변경을 지원하지 않습니다.") from error
    rename.argtypes = (ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint)
    if rename(-100, os.fsencode(source), -100, os.fsencode(target), 1):
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code), os.fspath(target))


def move_new(source, target, *, before_publish=None):
    if before_publish is not None:
        before_publish(source)
    try:
        rename_new(source, target)
    except OSError as error:
        if error.errno != errno.EXDEV or os.path.islink(source):
            raise
        target = Path(target)
        with tempfile.TemporaryDirectory(prefix=".recordweb-move-", dir=target.parent) as staging:
            copied = Path(staging, target.name)
            is_directory = os.path.isdir(source)
            if is_directory:
                shutil.copytree(source, copied, symlinks=True)
            else:
                shutil.copy2(source, copied)
                with copied.open("r+b") as output:
                    os.fsync(output.fileno())
            if before_publish is not None:
                before_publish(copied)
            rename_new(copied, target)
        if is_directory:
            shutil.rmtree(source)
        else:
            os.unlink(source)
    return os.fspath(target)


def move_unique(source, target):
    target = Path(target)
    for index in range(10000):
        candidate = target if not index else target.with_name(f"{target.stem}({index}){target.suffix}")
        try:
            return move_new(source, candidate)
        except FileExistsError:
            continue
    raise FileExistsError(os.fspath(target))
