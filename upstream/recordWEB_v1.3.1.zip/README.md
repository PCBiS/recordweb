# recordWEB v1.3.1

WEB 녹화 앱은 **`recordWEB.bat`**, 독립 다시보기 GUI는 **`replayDownloader.bat`**으로 실행합니다. Python 명령 앞에 BAT 파일을 붙이지 마세요.

압축을 푼 뒤 사용할 프로그램의 BAT 파일을 더블클릭하세요. CMD에서는 해당 BAT 파일 이름을 직접 입력하면 됩니다.

recordWEB은 치지직·씨미 라이브를 녹화합니다. 치지직·씨미·유튜브 다시보기는 별도 프로그램인 replayDownloader에서 다운로드합니다.

처음 설치하면 치지직 15개 채널과 씨미 헤비(@hebi)가 등록됩니다. 기본 품질은 best, 확장자는 MP4이며 녹화 파일은 설치 폴더의 output에 저장합니다. 기존 채널·그룹 파일이 있으면 그 설정을 사용합니다.

치지직·씨미는 각 탭의 안내에 따라 로그인 쿠키의 Value(값)를 입력하고 저장하세요. 유튜브는 새 Chrome 시크릿/Edge InPrivate 창에서 로그인하고, 같은 탭의 `https://www.youtube.com/robots.txt`에서 Get cookies.txt LOCALLY의 Netscape/Export As로 내보냅니다. **쿠키 파일 불러오기** 또는 직접 붙여넣기 후 **쿠키 저장 → 쿠키 검사**를 누르고, 사용했던 시크릿/InPrivate 창은 완전히 닫으세요. 프로그램이 저장 파일을 관리하며, 저장한 쿠키는 재시작 없이 다음 분석·다운로드부터 적용됩니다. 기존 저장 값은 화면에 자동 표시하지 않습니다. 공개 영상은 쿠키 없이 이용할 수 있고, 실제 로그인·영상 권한은 영상 분석 결과로 확인합니다.

배포 ZIP 하나에 녹화 앱과 다시보기 다운로더가 함께 들어 있습니다. 압축을 한 번 풀고 같은 폴더에서 필요한 실행기를 선택하세요. Windows에서 두 실행기는 전용 Python 3.14.10, `.venv`, 외부 도구와 쿠키를 공유하며 동시에 실행할 수 있습니다. 다시보기 GUI의 `SABR 버전/업데이트`에서 공식 SABR 채널 최신 확인·업데이트·강제 복구를 실행합니다. 설치 중인 도구가 실제 사용 중이면 교체하지 않습니다.

처음 실행하면 공식 Python 3.14.10을 `runtime/python`에 준비하고 전용 `.venv`와 도구를 검사합니다. 최초 준비에는 인터넷이 필요합니다. 시스템 Python·PATH·파일 연결은 설치에 사용하거나 변경하지 않습니다. 기존 설치는 검사 후 재사용합니다.

Windows 10/11 64비트용 1.3.1 의존성 기준은 Python **3.14.10**, Streamlink **8.6.3**, FFmpeg **8.1.3-34-ga35157abb9**입니다. FFmpeg는 BtbN의 8.1 유지보수 빌드를 사용합니다. 기존 Python 버전에서 업그레이드할 때는 recordWEB과 replayDownloader를 완전히 종료해야 하며, 설치 중 실패하면 기존 Python과 가상환경을 복원합니다.

| 실행 | 동작 |
|---|---|
| `recordWEB.bat` | 서버를 시작하고 실행 모드에 따라 트레이와 전용 창을 표시 |
| `recordWEB.bat --startup` | Windows 로그인용 실행. 해당 모드의 서버와 트레이를 시작하고 전용 창은 열지 않음 |
| `recordWEB.bat --check` | 설치·실행 환경 검사 |
| `recordWEB.bat --repair` | 전용 환경과 누락·손상 도구 복구 |

`json/config.json`의 `runMode`에서 실행 모드를 설정합니다. 저장 후 완전히 종료했다가 다시 실행하면 적용됩니다.

| 실행 모드 | 동작 |
|---|---|
| `normal` | 시스템 트레이와 전용 창을 함께 엽니다. |
| `lite` | 트레이만 표시합니다. 트레이의 **recordWEB 창 열기**를 누르거나 BAT를 한 번 더 실행하면 전용 창이 열립니다. |
| `headless` | 서버만 실행합니다. |

기존 설정에 `runMode`가 없으면 트레이 사용과 시작 시 최소화가 모두 켜져 있을 때 `lite`로 실행합니다. 나머지는 `normal`로 실행합니다.

전용 창의 X는 창만 닫습니다. 녹화와 후처리는 계속됩니다. 수동으로 서버를 처음 시작한 CMD를 닫거나 **recordWEB 완전 종료**를 선택하면 서버도 종료됩니다. 이미 실행 중인 서버에 연결한 전용 창이나 CMD를 닫아도 기존 서버는 계속 실행됩니다.

자동녹화는 기존 `autoRecordingMode`, Windows 자동 실행은 `runAtWindowsStartup`으로 별도 관리합니다. 녹화는 치지직·씨미만 지원합니다. 기본 CDN과 녹화 파일 조작 정책을 바꾸지 않았습니다.

원격 접속은 설정의 **다른 기기에서 접속 허용**에서 켭니다. 일반 기능은 로그인 없이 열리며, 파일매니저는 계정 로그인이 필요합니다. 기본 바인딩은 `127.0.0.1`입니다. `config.json`의 `port`는 다음 실행에 사용할 포트이며, 실행 중인 창과 트레이는 런타임에 기록된 현재 포트를 사용합니다. 포트·바인딩 변경은 완전 종료 후 재실행하면 적용됩니다. 원격 접속 비활성화에 따른 접근 차단은 즉시 적용합니다.

다른 기기에서는 **설정관리 → 일반 / 접속**의 현재 접속 주소를 브라우저에 입력하세요. 연결되지 않으면 서버 PC의 Windows Defender 방화벽 또는 Linux 방화벽(ufw·firewalld)에서 화면에 표시된 TCP 포트를 같은 네트워크에 허용하세요.

### 집 밖에서 접속하기

**Tailscale 사용 (권장)**

1. 서버 PC와 스마트폰·태블릿에 Tailscale을 설치하고 같은 Tailscale 네트워크에 연결합니다.
2. recordWEB의 **다른 기기에서 접속 허용**을 켭니다. 서버가 로컬 전용으로 실행 중이었다면 완전히 종료한 뒤 다시 실행합니다.
3. 스마트폰·태블릿에서 Wi-Fi를 끄고 LTE와 Tailscale을 켠 뒤 서버 PC의 Tailscale IPv4와 recordWEB의 현재 포트를 브라우저에 입력합니다. 주소 형식은 `http://[서버 PC의 Tailscale IPv4]:[현재 접속 포트]`입니다. 대괄호 부분에는 본인이 확인한 서버 PC 주소와 실행 중인 포트를 입력합니다.

공유기에서 포트포워딩을 설정할 필요가 없습니다. 방화벽에 막힌 경우 서버 PC에서 스마트폰·태블릿의 Tailscale IPv4를 원격 주소로 지정해 recordWEB의 TCP 포트만 허용합니다. [Tailscale 기기 연결 안내](https://tailscale.com/docs/how-to/connect-to-devices) · [Windows 방화벽의 원격 주소 범위](https://learn.microsoft.com/en-us/windows/win32/api/netfw/nf-netfw-inetfwrule-get_remoteaddresses)

**VPN 없이 공인 IP로 접속**

가정용 공유기에서는 공유기의 WAN에 공인 IP가 할당되고 외부 연결을 내부 서버로 전달할 수 있어야 합니다. 통신사 공유 IP(CGNAT)를 사용한다면 공유기 자체의 포트포워딩만으로는 외부 연결을 받기 어렵습니다. [포트포워딩과 WAN IP 안내](https://www.tp-link.com/us/support/faq/1379/)

현재 recordWEB은 서버 PC에 할당된 IPv4 주소를 확인하므로 공유기의 공인 IP나 외부 도메인을 주소로 사용하는 요청을 거부합니다. TCP 포트를 전달하거나 방화벽에서 허용해도 앱에 도달하면 HTTP 400이 발생합니다. 또한 일반 기능에 로그인 요구가 없으므로 recordWEB 포트를 인터넷에 공개하지 마세요.

VPN 없이 브라우저 접속을 제공하는 구성에는 HTTPS와 인증을 담당하는 리버스 프록시, 외부 주소와 요청 출처를 검증하고 프록시 뒤에서도 로컬 관리 권한을 구분하는 앱 지원이 필요합니다. 이런 외부 공개 구성은 현재 배포판에서 지원하지 않습니다. [리버스 프록시의 HTTPS 구성](https://caddyserver.com/docs/quick-starts/reverse-proxy)

## Linux에서 실행

배포 ZIP을 쓰기 가능한 Linux 폴더에 풀고, 일반 사용자로 실행하세요.

```sh
./recordWEB.sh
```

실행 권한을 보존하지 않는 압축 해제 도구를 사용한 경우에만 `chmod +x recordWEB.sh`를 한 번 실행하세요.

Ubuntu/Debian과 Fedora/Rocky/Alma/RHEL 계열의 x86-64 및 ARM64를 대상으로 합니다. 실행 스크립트가 Python 3.11~3.14를 확인하고, 프로젝트 전용 `.venv-linux`를 준비합니다. 처음 실행하거나 의존성이 빠진 경우 패키지를 설치·복구합니다. 시스템 패키지가 부족할 때만 `sudo`를 사용합니다. RHEL 계열에서 현재 저장소에 FFmpeg가 없으면 관리자가 FFmpeg와 FFprobe를 제공하는 신뢰할 수 있는 저장소나 실행 파일을 준비해야 합니다. `./recordWEB.sh --check`는 환경 준비만 실행합니다.

일반 모드는 전용 창과 트레이를 열고, 라이트 모드는 트레이에서 필요할 때 전용 창을 열 수 있습니다. 그래픽 세션이 없는 서버에서는 저장된 실행 모드를 보존하고 Headless로 시작합니다. 실행 모드와 자동녹화 설정은 별개입니다.

Linux 전용 창은 GTK 3과 WebKitGTK 4.1을 사용합니다. 트레이는 StatusNotifier를 제공하는 패널 또는 X11 시스템 트레이가 필요합니다. GUI 환경을 준비하지 못하면 콘솔에 접속 주소를 표시하고 서버를 계속 실행합니다. Windows에서 옮긴 녹화·후처리 경로는 Linux 경로로 바꿔 주세요.

Linux 로그인 자동 실행 등록은 현재 제공하지 않습니다. Linux 데스크톱 실환경 검증은 Debian 12의 XFCE/X11 테스트 세션에서 진행했습니다. Fedora Desktop·Wayland·GNOME·KDE·ARM64는 실환경 검증이 남아 있습니다.

Core는 FFmpeg·FFprobe·Streamlink를 사용합니다. yt-dlp는 별도 다시보기 다운로더용이며, ytarchive는 사용하지 않습니다. Linux Headless 실행에는 데스크톱 환경이나 recordWEB GUI 패키지가 필요하지 않습니다. Fedora에서는 시스템 `ffmpeg-free` 패키지 설치 시 배포판 의존성으로 GTK 라이브러리가 함께 설치될 수 있습니다.

Linux에서 Intel QSV를 선택하면 PCI 주소 순서로 Intel GPU의 렌더 장치를 찾습니다. QSV에는 호환되는 Intel 드라이버와 렌더 장치 접근 권한이, NVENC에는 NVIDIA 드라이버와 NVENC 지원 FFmpeg가 필요합니다.

다른 버전·폴더·Python·소스 빌드의 서버가 응답하면 새 UI를 연결하지 않습니다. 기존 앱에서 진행 중인 작업을 확인하고 완전 종료한 뒤 다시 실행하세요. 설치 파일을 실행 중인 프로그램에 덮어쓰기보다 먼저 앱을 완전 종료한 뒤 새 배포본을 적용하는 것이 권장 절차입니다. 사용자 `json`, 쿠키, 녹화 폴더는 덮어쓰지 마세요.

Python 실행 파일과 설치 스크립트는 `module/`에 있습니다. 기존 설치 폴더를 업데이트할 때는 앱을 종료한 뒤 압축을 풀고, 루트에 남은 이전 버전의 `recordWEB.py`, `recordWEB_launcher.py`, `replayDownloader_GUI.py`를 정리하세요.

설치용 `requirements-*.txt`는 `module/install/`에 있습니다. 이전 배포본 위에 압축을 풀었다면 루트에 남아 있는 기존 `requirements-*.txt` 네 파일은 삭제해도 됩니다.

후처리의 GPU 수를 1로 둘 때 `단일 GPU 사용 시 선택할 장치`에서 GPU0 또는 GPU1만 사용을 선택합니다. GPU1만 사용하는 경우 GPU1 프로필과 추가 인코딩 옵션을 사용합니다. GPU 수 2에서는 치지직 채널별 분배를 사용합니다. GPU 번호는 FFmpeg 인코더의 장치 번호를 기준으로 합니다.

후처리 실패는 진단로그의 **현재 설정으로 재시도**에서 다시 처리할 수 있습니다.

**설정관리 → 알림/진단 → 진단 로그**에서 보관 기간을 선택합니다. 기본값은 최근 3일(72시간)입니다. 계속 실행 중이어도 새 로그를 기록하고 보관 기간이 지난 로그는 주기적으로 정리합니다. 백엔드 로그는 `logs/recordWEB_backend.log`에 기록하며 이전 기록은 시간대별 파일에 보관합니다. 이전 버전에서 시각 없이 저장한 로그는 파일의 마지막 수정 시각을 기준으로 정리합니다. 기록 안 함은 새 로그 저장을 멈추며, 무제한은 기간에 따른 정리를 건너뜁니다.

녹화와 후처리를 마친 뒤 앱을 완전 종료하고 다시 실행하면 코드와 화면 수정이 적용됩니다.

새 버전은 배포처에서 받은 ZIP을 적용합니다.
