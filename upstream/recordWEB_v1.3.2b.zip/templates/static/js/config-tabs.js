document.addEventListener('DOMContentLoaded', () => {
  const form=document.getElementById('configForm'); if(!form) return;
  const categories=[['record','녹화'],['post','후처리'],['automation','자동화'],['notify','알림/진단'],['network','일반 / 원격']];
  const tabs=document.createElement('div'); tabs.className='config-tabs'; tabs.setAttribute('role','tablist'); tabs.setAttribute('aria-label','설정 카테고리');
  const panels={};
  categories.forEach(([id,label])=>{
    const panel=document.createElement('section'); panel.id='config-panel-'+id; panel.className='card config-panel';panel.setAttribute('role','tabpanel');
    const heading=document.createElement('h2'); heading.textContent=label; panel.append(heading);panels[id]=panel;
    const button=document.createElement('button');button.type='button';button.id='config-tab-'+id;button.textContent=label;button.setAttribute('role','tab');button.setAttribute('aria-controls',panel.id);panel.setAttribute('aria-labelledby',button.id);
    button.onclick=()=>select(id); tabs.append(button);
  });
  const automation=new Set(['runAtWindowsStartup','runAtLinuxStartup','autoRecordingMode','recheckInterval','recordingMetadataRefreshInterval']);
  const recording=new Set(['plugin_type','timemachine_time_shift','filenamePattern','splitRecordingMode','splitPostProcessing','autoStopInterval','splitOverlapSec']);
  function category(key) {
    if(automation.has(key)) return 'automation'; if(recording.has(key)) return 'record';
    if(key==='diagnosticLogDays'||/^(telegram|discord|notify_)/.test(key)) return 'notify';
    if(/^(runMode|fileManager|trash|remoteAccess|login|port)/.test(key)) return 'network';
    return 'post';
  }
  const original=[...form.children]; let current='automation';
  const footer=document.createElement('div');footer.className='config-save-footer';
  original.forEach(node=>{
    if(node.matches('input[type="hidden"]')) return;
    if(node.matches('input[type="submit"],button[type="submit"]')) {node.value='전체 설정 저장';node.textContent=node.tagName==='BUTTON'?'전체 설정 저장':node.textContent;footer.append(node);return;}
    const key=node.getAttribute('for')||node.querySelector('label[for]')?.getAttribute('for')||node.querySelector('input[id],select[id]')?.id;
    if(key) current=category(key);
    else if(node.matches('h3')) {
      if(node.textContent.includes('알림')) current='notify';
      else if(/로그인|파일 관리/.test(node.textContent)) current='network';
    }
    if(node.matches('hr')) {node.remove();return;}
    panels[current].append(node);
  });
  const network=panels.network;
  for (const id of ['loginMode','remoteAccessEnabled','port','runMode']) {
    const label=network.querySelector(`label[for="${id}"]`);
    if (!label) continue;
    const nodes=[label]; let next=label.nextElementSibling;
    while(next && next.tagName!=='LABEL' && next.tagName!=='H3') {nodes.push(next);next=next.nextElementSibling;}
    nodes.reverse().forEach(node=>network.insertBefore(node,network.children[1]));
  }
  form.prepend(tabs);categories.forEach(([id])=>form.append(panels[id]));form.append(footer);
  form.querySelectorAll('table').forEach(table=>{
    const wrapper=document.createElement('div');wrapper.className='config-table-scroll';
    if (table.closest('.gpu-encoding-help')) {
      wrapper.tabIndex = 0;
      wrapper.setAttribute('role', 'region');
      wrapper.setAttribute('aria-labelledby', table.getAttribute('aria-labelledby'));
    }
    table.before(wrapper);wrapper.append(table);
  });
  const account=document.getElementById('account-fields');
  function select(id) {
    if(id==='advanced') id='post';
    if(!panels[id]) id='record';
    categories.forEach(([key])=>{
      panels[key].hidden=key!==id;
      const button=document.getElementById('config-tab-'+key);
      button.setAttribute('aria-selected',String(key===id));button.tabIndex=key===id?0:-1;
    });
    if(account) account.hidden=id!=='network';
    try{sessionStorage.setItem('recordweb-config-tab',id);}catch{}
  }
  tabs.addEventListener('keydown',event=>{
    if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
    event.preventDefault();const buttons=[...tabs.children];let i=buttons.indexOf(document.activeElement);
    i=event.key==='Home'?0:event.key==='End'?buttons.length-1:(i+(event.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;
    buttons[i].click();buttons[i].focus();
  });
  form.addEventListener('invalid',event=>{
    const panel=event.target.closest('.config-panel');if(panel) select(panel.id.replace('config-panel-',''));
  },true);
  let initial='record';try{initial=sessionStorage.getItem('recordweb-config-tab')||initial;}catch{}
  select(initial);
  document.dispatchEvent(new Event('recordweb:config-ready'));
});
