document.addEventListener('recordweb:page-ready', () => {
  const fileInput = document.getElementById('backup-zip');
  const preview = document.getElementById('backup-preview');
  const status = document.getElementById('backup-status');
  const download = document.getElementById('backup-download');
  const restore = document.getElementById('backup-restore');
  const options = document.getElementById('backup-options');
  const choices = Array.from(options.querySelectorAll('input[type=checkbox]'));
  const updateRestore = () => { restore.disabled = !choices.some(choice => choice.checked); };

  async function checkedFetch(url, options) {
    const response = await fetchWithTimeout(url, options, 15000);
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(body.detail || '백업 요청을 처리하지 못했습니다.');
    }
    return response;
  }

  download.addEventListener('click', async () => {
    download.disabled = true;
    try {
      const response = await checkedFetch('/api/backup/download', {cache: 'no-store'});
      const url = URL.createObjectURL(await response.blob());
      const link = document.createElement('a');
      link.href = url;
      link.download = response.headers.get('Content-Disposition')?.match(/filename="([^"]+)"/)?.[1] || 'recordWEB_backup.zip';
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (error) {
      recordWebDialog.notice(error.message);
    } finally {
      download.disabled = false;
    }
  });

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    preview.hidden = true;
    restore.disabled = true;
    if (!file) return;
    status.textContent = '백업 ZIP을 확인하는 중입니다.';
    try {
      const response = await checkedFetch('/api/backup/inspect', {method: 'POST', body: file});
      const info = await response.json();
      if (file !== fileInput.files[0]) return;
      document.getElementById('backup-created').textContent = info.created_at || '기록 없음';
      document.getElementById('backup-version').textContent = info.version || '기록 없음';
      document.getElementById('backup-included').textContent = info.included.join(', ');
      document.getElementById('backup-missing').textContent = info.missing.join(', ') || '없음';
      document.getElementById('backup-errors').textContent = Object.keys(info.errors).join(', ') || '없음';
      for (const choice of choices) {
        choice.disabled = !info.available.includes(choice.value);
        choice.checked = !choice.disabled;
      }
      status.textContent = '';
      preview.hidden = false;
      updateRestore();
    } catch (error) {
      if (file === fileInput.files[0]) status.textContent = error.message;
    }
  });

  options.addEventListener('change', updateRestore);
  restore.addEventListener('click', async () => {
    const file = fileInput.files[0];
    const query = new URLSearchParams();
    choices.filter(choice => choice.checked).forEach(choice => query.append('selected', choice.value));
    if (!file || !query.size) return;
    fileInput.disabled = options.disabled = restore.disabled = true;
    let queued = false;
    try {
      if (!await recordWebDialog.confirm('선택한 항목을 다음 실행 시 복원하시겠습니까? 현재 파일은 적용 전에 자동 백업합니다.')) return;
      const response = await checkedFetch(`/api/backup/restore?${query}`, {method: 'POST', body: file});
      const result = await response.json();
      queued = true;
      status.textContent = result.message;
      await recordWebDialog.notice(result.message);
    } catch (error) {
      await recordWebDialog.notice(error.message);
    } finally {
      if (!queued) {
        fileInput.disabled = options.disabled = false;
        updateRestore();
      }
    }
  });
});
