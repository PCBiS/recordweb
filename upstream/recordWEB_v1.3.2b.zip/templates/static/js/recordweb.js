let isListenersAdded = false;     // 중복 리스너 방지

const FETCH_TIMEOUT_MS = 8000;  // 채널별 요청 타임아웃(ms)


// CSS.escape 폴백(특수문자 있는 채널ID 대응)
const cssEsc = (window.CSS && CSS.escape)
  ? CSS.escape
  : s => String(s).replace(/[^a-zA-Z0-9_\u00A0-\uFFFF-]/g, ch => `\\${ch.codePointAt(0).toString(16)} `);

// 공통 fetch timeout 래퍼
async function fetchWithTimeout(url, opts = {}, timeoutMs = FETCH_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, {
      credentials: 'same-origin',
      ...(opts || {}),
      signal: controller.signal
    });
  } finally {
    clearTimeout(timer);
  }
}

async function requestJson(url,options) {
  const response=await fetch(url,options), data=await response.json();
  if(!response.ok) throw new Error(typeof data.detail==='string'?data.detail:JSON.stringify(data.detail));
  return data;
}

const recordWebDialog = (() => {
  let queue = Promise.resolve();

  function show(mode, message, initialValue = '') {
    const result = queue.then(() => new Promise(resolve => {
      const dialog = document.getElementById('recordweb-message');
      const input = document.getElementById('recordweb-message-input');
      const confirmButton = dialog.querySelector('button[value="confirm"]');
      const cancelButton = dialog.querySelector('button[value="cancel"]');
      document.getElementById('recordweb-message-text').textContent = String(message);
      input.hidden = mode !== 'prompt';
      input.value = initialValue;
      cancelButton.hidden = mode === 'notice';
      dialog.returnValue = 'cancel';
      dialog.addEventListener('close', () => {
        const confirmed = dialog.returnValue === 'confirm';
        resolve(mode === 'prompt' ? (confirmed ? input.value : null) : confirmed);
      }, {once: true});
      dialog.showModal();
      if (mode === 'prompt') {
        input.focus();
        input.select();
      } else {
        (mode === 'notice' ? confirmButton : cancelButton).focus();
      }
    }));
    queue = result.catch(() => {});
    return result;
  }

  return {
    notice: message => show('notice', message),
    confirm: message => show('confirm', message),
    prompt: (message, value) => show('prompt', message, value),
  };
})();

// 부트스트랩
document.addEventListener("DOMContentLoaded", async function () {
  if (window.recordWebReady) await window.recordWebReady;
  // 중복 등록 방지
  if (isListenersAdded) return;
  isListenersAdded = true;



  window.addEventListener('pywebviewready', () => {
    document.querySelectorAll('.sidenav').forEach(nav => {
      if (nav.querySelector('[data-desktop-quit]')) return;
      const quit = document.createElement('button');
      quit.type = 'button';
      quit.dataset.desktopQuit = 'true';
      quit.className = 'desktop-quit';
      quit.textContent = 'recordWEB 완전 종료';
      quit.onclick = async () => {
        quit.disabled = true;
        const requestQuit = confirm => fetch('/api/runtime/quit', {
          method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({confirm})
        });
        try {
          if (!await recordWebDialog.confirm('서버, 감시, 녹화 및 후처리를 완전히 종료하시겠습니까?')) return;
          let response = await requestQuit(false);
          if (response.status === 409) {
            if (!await recordWebDialog.confirm('진행중인 작업이 있습니다. 녹화를 중단하고 완전히 종료할까요?')) return;
            response = await requestQuit(true);
          }
          if (response.ok) {
            if (window.pywebview?.api?.close_for_shutdown) await window.pywebview.api.close_for_shutdown();
            else window.close();
          }
        } finally {
          quit.disabled = false;
          quit.focus();
        }
      };
      nav.append(quit);
    });
  });

  // 슬라이드 메뉴 바인딩
  const sidenav = document.getElementById('mySidenav');
  const menuIcon = document.querySelector('.menu-icon');
  const closeBtn = document.querySelector('#mySidenav .closebtn');
  const filesLink = sidenav?.querySelector('[data-check-file-access]');
  filesLink?.addEventListener('click', async event => {
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    if (filesLink.getAttribute('aria-busy') === 'true') return;
    filesLink.setAttribute('aria-busy', 'true');
    try {
      const response = await fetchWithTimeout('/api/files/access', {cache: 'no-store'});
      if (response.ok) {
        window.location.assign(filesLink.href);
      } else {
        const error = await response.json();
        await recordWebDialog.notice(error.detail || '파일관리를 사용할 수 없습니다.');
      }
    } catch {
      await recordWebDialog.notice('파일관리 사용 여부를 확인하지 못했습니다. 잠시 후 다시 시도해 주세요.');
    } finally {
      filesLink.removeAttribute('aria-busy');
    }
  });
  const accessNotice = document.querySelector('[data-access-notice]');
  if (accessNotice) recordWebDialog.notice(accessNotice.textContent.trim());

  function openNav(e) {
    if (e) e.preventDefault();
    if (!sidenav) return;
    const cs = getComputedStyle(sidenav);
    // 일부 사용자 환경에서 display:none이면 width만 바꿔도 안 보이는 문제 보정
    if (cs.display === 'none') sidenav.style.display = 'block';
    sidenav.style.width = '250px';
    if (menuIcon) menuIcon.setAttribute('aria-expanded', 'true');
  }

  function closeNav(e) {
    if (e) e.preventDefault();
    if (!sidenav) return;
    sidenav.style.width = '0';
    if (menuIcon) menuIcon.setAttribute('aria-expanded', 'false');
  }

  if (menuIcon) {
    menuIcon.addEventListener('click', openNav);
    // 키보드 접근성: Enter/Space로도 열기
    menuIcon.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' || ev.key === ' ') openNav(ev);
    });
  }

  if (closeBtn) closeBtn.addEventListener('click', closeNav);


  // 사용자 정보/메뉴 표시
  fetchUserInfo();

  document.dispatchEvent(new Event('recordweb:page-ready'));

  // 로그인 폼 리스너
  setupLoginFormListener();
});

// 사용자/인증 관련
async function fetchUserInfo() {
  try {
    const response = await fetch('/user_info');
    const data = await response.json();

    const usernameDisplay = document.getElementById('username-display');
    const logoutBtn = document.getElementById('logout-btn');
    const restrictedMenuItems = document.querySelectorAll('.restricted-menu');

	// 설정 페이지에 트레이 사용 옵션 값 반영
	const trayWebSel = document.getElementById('enableTray');
	if (trayWebSel && data && data.config && Object.prototype.hasOwnProperty.call(data.config, 'enableTray')) {
	  trayWebSel.value = (data.config.enableTray ? 'true' : 'false');
	}

    if (data.logged_in) {
      if (data.logged_in) {
        if (usernameDisplay) usernameDisplay.textContent = `로그인: ${data.username}`;
        if (logoutBtn) logoutBtn.style.display = 'block';
        restrictedMenuItems.forEach(item => item.style.display = 'block');
      } else {
        if (usernameDisplay) usernameDisplay.textContent = '로그인되지 않음';
        if (logoutBtn) logoutBtn.style.display = 'none';
        restrictedMenuItems.forEach(item => item.style.display = 'none');
      }
    } else {
      if (usernameDisplay) usernameDisplay.textContent = '로그인 모드 OFF';
      if (logoutBtn) logoutBtn.style.display = 'none';
      restrictedMenuItems.forEach(item => item.style.display = 'block');
    }
  } catch (error) {
    console.error('사용자 정보를 가져오는 중 오류 발생:', error);
  }
}


// 로그인 폼 제출 처리
function setupLoginFormListener() {
  const loginForm = document.getElementById('loginForm');
  if (!loginForm) return;

  loginForm.addEventListener('submit', async function (event) {
    event.preventDefault();
    const formData = new FormData(this);

    try {
      const response = await fetch('/login', { method: 'POST', body: formData });
      const result = await response.json();

      if (response.ok) {
        await recordWebDialog.notice(result.message || "로그인 성공");
        const redirectUrl = result.redirect_url || '/';
        setTimeout(() => { window.location.href = redirectUrl; }, 2000);
      } else {
        recordWebDialog.notice(result.message || "아이디 또는 비밀번호가 올바르지 않습니다.");
      }
    } catch (error) {
      console.error("로그인 중 오류 발생:", error);
      recordWebDialog.notice("서버와의 통신 중 문제가 발생했습니다.");
    }
  });
}
