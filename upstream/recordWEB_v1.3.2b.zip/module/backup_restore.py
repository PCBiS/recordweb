"""Prepare a restore online and apply it under the backend's startup lock."""
from datetime import datetime
import os
from pathlib import Path
import tempfile
from threading import Lock
from uuid import uuid4

from module import backup_archive as archive, cookie_store, data_manager as dm
from module.access_control import validate_network
from module.channel_schema import channel_rows
from module.config_validator import validateExtraFfmpegOptions
from module.run_mode import resolve_run_mode
from module.server_port import ensure_port_available, parse_port
from module.youtube_cookies import MAX_BYTES as MAX_YOUTUBE_COOKIE, inspect_text


_queue_lock = Lock()
_PENDING = "backup_restore.pending.json"
_STATUS = "backup_restore_status.json"


def data_dir():
    return Path(dm.CONFIG_PATH).parent


def capture(root):
    files = {}
    for name in archive.FILES:
        try:
            with (root / name).open("rb") as source:
                files[name] = source.read(archive.MAX_CONTENT + 1)
        except FileNotFoundError:
            continue
        if sum(map(len, files.values())) > archive.MAX_CONTENT:
            raise ValueError("설정 파일의 전체 크기가 백업 한도를 초과합니다.")
    return archive.create_archive(files)


def normalize_file(name, raw):
    if name == "ycookie.txt":
        text = raw.decode("utf-8-sig")
        status = inspect_text(text)
        empty_netscape = status["status"] == "missing" and (
            not text.strip() or text.startswith(("# Netscape HTTP Cookie File", "# HTTP Cookie File"))
        )
        if len(raw) > MAX_YOUTUBE_COOKIE or not (status["format_valid"] or empty_netscape):
            raise ValueError("유튜브 쿠키는 Netscape 형식이어야 합니다.")
        return text

    data = archive.json_data(raw)
    if name == "channels.json":
        if any(not isinstance(row, dict) for row in channel_rows(data)):
            raise ValueError("채널 목록에 잘못된 항목이 있습니다.")
        return dm.normalizeChannelsList(data)
    if name == "channel_groups.json":
        if not isinstance(data, list) or any(
            not isinstance(row, dict) or any(not isinstance(row.get(k), str) or not row[k].strip() for k in ("id", "name"))
            for row in data
        ):
            raise ValueError("채널 그룹 목록의 형식이 올바르지 않습니다.")
        if len({row["id"] for row in data}) != len(data) or len({row["name"].casefold() for row in data}) != len(data):
            raise ValueError("채널 그룹 ID 또는 이름이 중복됩니다.")
        return data
    if not isinstance(data, dict):
        raise ValueError("JSON 객체가 필요합니다.")
    if name == "cookie.json":
        if any(k in data for k in cookie_store.FIELDS["chzzk"]) and "chzzk" not in data:
            data = {**data, "chzzk": {key: data.get(key, "") for key in cookie_store.FIELDS["chzzk"]}}
        for platform, keys in cookie_store.FIELDS.items():
            values = data.get(platform, {})
            if not isinstance(values, dict) or any(key in values and not isinstance(values[key], str) for key in keys):
                raise ValueError("치지직/씨미 쿠키 값의 형식이 올바르지 않습니다.")
            if any(any(ord(char) < 32 or ord(char) == 127 for char in values.get(key, "")) for key in keys):
                raise ValueError("쿠키 값에 줄바꿈 또는 제어 문자가 있습니다.")
        normalized = cookie_store.normalize(data)
        if data and not cookie_store.FIELDS.keys() & data.keys():
            raise ValueError("치지직 또는 씨미 쿠키 구조가 필요합니다.")
        return {platform: normalized[platform] for platform in normalized if platform in data}
    defaults = dm.normalizeConfig({})
    permitted = {*defaults, "runMode", "autoStopInterval"}
    values = {k: v for k, v in data.items() if k in permitted and v is not None}
    for key, default in defaults.items():
        if key not in values:
            continue
        value = values[key]
        if isinstance(value, (dict, list)) and not isinstance(default, type(value)):
            raise ValueError(f"{key} 설정 형식을 확인하세요.")
    if "filenamePattern" in values and not isinstance(values["filenamePattern"], str):
        raise ValueError("파일명 규칙은 텍스트여야 합니다.")
    if "port" in values:
        values["port"] = parse_port(values["port"], allow_legacy=True)
    config = validate_network(dm.normalizeConfig(values), {})
    config["runMode"] = resolve_run_mode(config)
    config["config_schema_version"] = defaults["config_schema_version"]
    for key in ("extra_ffmpeg_options", "extra_ffmpeg_options_gpu1"):
        validateExtraFfmpegOptions(config.get(key, ""))
    return config


def prepare(content):
    files, manifest = archive.read_archive(content)
    valid, errors = {}, {}
    for name, raw in files.items():
        try:
            valid[name] = normalize_file(name, raw)
        except (ValueError, OverflowError, RecursionError):
            errors[name] = "파일을 읽을 수 없거나 설정 형식이 올바르지 않습니다."
    summary = {
        "created_at": manifest["created_at"] if manifest else None,
        "version": manifest["recordweb_version"] if manifest else None,
        "included": sorted(files),
        "missing": [name for name in archive.FILES if name not in files],
        "errors": errors,
        "available": [key for key, names in archive.ITEMS.items()
                      if any(name in valid for name in names) and not any(name in errors for name in names)],
    }
    return valid, summary


def queue_restore(root, content, selected):
    values, summary = prepare(content)
    if not selected or any(item not in summary["available"] for item in selected):
        raise ValueError("복원할 수 있는 항목을 선택하세요. 누락되거나 손상된 파일을 확인해 주세요.")
    changes = {name: values[name] for item in selected for name in archive.ITEMS[item] if name in values}
    with _queue_lock:
        pending = root / _PENDING
        if pending.exists():
            raise ValueError("이미 예약된 복원이 있습니다. recordWEB을 다시 실행해 주세요.")
        dm.writeJsonSafe(pending, {"changes": changes}, preserve_backup=True)
    return sorted(changes)


def restore_status(root):
    if (root / _PENDING).exists():
        return {"status": "pending"}
    return dm.readJsonSafe(root / _STATUS, {})


def write_bytes(path, data):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".restore-", delete=False) as output:
            temporary = Path(output.name)
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def apply_pending(root, current_config):
    """Return whether config must be reloaded. An incomplete rollback blocks startup."""
    pending = root / _PENDING
    if not pending.exists():
        return False
    journal = dm.readJsonSafe(pending, {}, strict=True)
    changes = journal.get("changes", {})
    if not isinstance(changes, dict) or not changes or not set(changes) <= set(archive.FILES):
        raise ValueError("복원 예약 기록의 형식이 올바르지 않습니다.")
    recovery_dir = root / "backups"
    backup = journal.get("backup")
    if backup and (Path(backup).name != backup or not backup.startswith("before_restore_") or not backup.endswith(".zip")):
        raise ValueError("복원 자동 백업 이름이 올바르지 않습니다.")

    def finish(state, message):
        dm.writeJsonSafe(root / _STATUS, {"status": state, "message": message, "backup": backup}, preserve_backup=True)
        pending.unlink()
        print(f"[BACKUP] {message}")

    def rollback():
        original, _ = archive.read_archive((recovery_dir / backup).read_bytes(), allow_empty=True)
        for name in changes:
            path = root / name
            if name in original:
                write_bytes(path, original[name])
            else:
                path.unlink(missing_ok=True)

    if backup:
        rollback()
        finish("failed", "도중에 중단된 복원을 취소하고 기존 설정을 되돌렸습니다.")
        return "config.json" in changes

    try:
        if "config.json" in changes:
            config = changes["config.json"]
            config["runAtWindowsStartup"] = current_config.get("runAtWindowsStartup", False)
            ensure_port_available(config["port"], "0.0.0.0" if config["remoteAccessEnabled"] else "127.0.0.1",
                                  previous_port=config["port"])
        recovery_dir.mkdir(exist_ok=True)
        _, content = capture(root)
        name = f"before_restore_{datetime.now():%Y%m%d_%H%M%S}_{uuid4().hex[:8]}.zip"
        write_bytes(recovery_dir / name, content)
        backup = name
        dm.writeJsonSafe(pending, {**journal, "backup": backup}, preserve_backup=True)
    except (OSError, ValueError):
        finish("failed", "서버 포트 또는 자동 백업을 확인하지 못해 복원을 적용하지 않았습니다.")
        return False

    try:
        for name, value in changes.items():
            if name == "ycookie.txt":
                write_bytes(root / name, value.encode("utf-8"))
            elif name == "cookie.json":
                cookie_store.restore_web(root / name, value)
            else:
                dm.writeJsonSafe(root / name, value, preserve_backup=True)
    except (OSError, ValueError):
        rollback()
        finish("failed", "파일 저장에 실패해 복원을 취소하고 기존 설정을 되돌렸습니다.")
        return False

    finish("success", "복원이 완료되었습니다. 채널관리와 설정관리에서 내용을 확인한 뒤 저장해 주세요.")
    return "config.json" in changes
