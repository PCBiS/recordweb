"""Register recordWEB in the current user's systemd boot target."""
import os
from pathlib import Path
import shutil
import subprocess
import sys


UNIT_NAME = "recordweb-autostart.service"


def available():
    return (sys.platform == "linux" and os.getuid() != 0
            and Path("/run/systemd/system").is_dir() and shutil.which("loginctl") is not None)


def _unit_paths():
    config_home = Path(os.environ.get("XDG_CONFIG_HOME", ""))
    if not config_home.is_absolute():
        config_home = Path.home() / ".config"
    directory = config_home / "systemd/user"
    return directory / UNIT_NAME, directory / "default.target.wants" / UNIT_NAME


def _unit_text(root):
    script = str(Path(root).resolve() / "recordWEB.sh")
    if any(ord(char) < 32 or ord(char) == 127 for char in script):
        raise ValueError("systemd에 등록할 수 없는 설치 경로입니다.")
    script = script.replace("\\", "\\\\").replace('"', '\\"')
    script = script.replace("%", "%%").replace("$", "$$")
    return (
        "[Unit]\n"
        "Description=recordWEB automatic startup\n"
        "[Service]\n"
        f'ExecStart=/usr/bin/env bash "{script}" --service\n'
        "Restart=on-failure\n"
        "RestartSec=10s\n"
        "KillMode=mixed\n"
        "[Install]\n"
        "WantedBy=default.target\n"
    )


def _owns_unit(unit, root):
    return (not unit.is_symlink() and unit.is_file()
            and unit.read_text(encoding="utf-8", errors="replace") == _unit_text(root))


def startup_enabled(root):
    unit, link = _unit_paths()
    return link.is_symlink() and link.resolve() == unit.resolve() and _owns_unit(unit, root)


def set_startup_enabled(root, enabled):
    active = startup_enabled(root)
    if enabled == active:
        return
    if not available():
        raise ValueError("Linux 자동 실행에는 systemd와 일반 사용자 계정이 필요합니다.")
    unit, link = _unit_paths()
    owned = _owns_unit(unit, root)
    if (unit.exists() or unit.is_symlink()) and not owned:
        raise ValueError("같은 이름의 systemd 서비스가 다른 설치에서 사용 중입니다.")
    if not enabled:
        try:
            link.unlink()
        except OSError as error:
            raise ValueError(f"systemd 자동 실행을 해제하지 못했습니다. {error}") from error
        return
    try:
        result = subprocess.run(
            ["loginctl", "show-user", str(os.getuid()), "--property=Linger", "--value"],
            capture_output=True, text=True, timeout=5, check=False,
        )
        if result.returncode != 0 or result.stdout.strip() != "yes":
            raise ValueError("터미널에서 loginctl enable-linger를 실행한 뒤 다시 저장하세요.")
        link.parent.mkdir(parents=True, exist_ok=True)
        created = False
        try:
            if not owned:
                with unit.open("x", encoding="utf-8") as file:
                    created = True
                    file.write(_unit_text(root))
            link.symlink_to(unit)
        except OSError:
            if created:
                unit.unlink(missing_ok=True)
            raise
    except (OSError, subprocess.SubprocessError) as error:
        raise ValueError(f"systemd 자동 실행을 등록하지 못했습니다. {error}") from error
