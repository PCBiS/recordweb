"""실행 중인 recordWEB 백엔드에 전용 창을 연결합니다."""
from pathlib import Path
import argparse
import asyncio
import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid
from contextlib import contextmanager, ExitStack

ROOT = Path(__file__).resolve().parents[1]
if __name__ == "__main__":
    sys.path.insert(0, str(ROOT))
RUNTIME_DIR = ROOT / ".runtime"
OWNER_SESSION = None
# 콘솔 제어 문자 제거
CONSOLE_CONTROLS = re.compile(r'(?:\x1b\[|\x9b)[0-?]*[ -/]*[@-~]|[\x00-\x08\x0b-\x1f\x7f-\x9f]')

class RuntimeConflict(RuntimeError):
    pass

class RuntimeUnavailable(RuntimeConflict):
    """Listener exists but has not returned an identity yet."""
    pass


def local_url(port):
    return f"http://127.0.0.1:{int(port)}"


def configured_port():
    from module.data_manager import loadConfig
    from module.server_port import DEFAULT_PORT, parse_port
    # The backend restores the backup and exposes the recovery status in its UI.
    return parse_port((loadConfig(restore_backup=False) or {}).get("port", DEFAULT_PORT), allow_legacy=True)


def runtime_port_hint():
    """살아 있는 백엔드가 기록한 실제 listen 포트를 반환합니다."""
    import psutil
    from module.runtime_guard import RuntimeGuard
    from module.runtime_identity import canonical

    info = RuntimeGuard.read_info(str(ROOT))
    if not info:
        return None
    try:
        pid = info.get("pid")
        if not isinstance(pid, int) or isinstance(pid, bool):
            return None
        process = psutil.Process(pid)
        if not process.is_running():
            return None
        started = info.get("pid_started")
        if started is not None and abs(process.create_time() - float(started)) > 0.1:
            return None
        command = process.cmdline()
        backend_path = canonical(ROOT / "module/recordWEB.py")
        if "--backend" not in command or not any(
            canonical(arg) == backend_path for arg in command[1:] if not arg.startswith("-")
        ):
            return None
        project_root = info.get("project_root")
        if project_root and canonical(project_root) != canonical(ROOT):
            return None
        port = info.get("port")
        if port is not None:
            port = int(port)
            if 1 <= port <= 65535:
                return port
        # 3단계 이전 백엔드에 붙을 때는 PID의 listen socket을 사용합니다.
        listeners = [
            connection.laddr.port for connection in process.net_connections(kind="tcp")
            if connection.status == psutil.CONN_LISTEN and connection.laddr
        ]
        return listeners[0] if len(set(listeners)) == 1 else None
    except (OSError, TypeError, ValueError, psutil.Error):
        return None


def _port_is_listening(port):
    import psutil
    try:
        return any(
            connection.status == psutil.CONN_LISTEN and connection.laddr.port == port
            for connection in psutil.net_connections(kind="tcp")
        )
    except psutil.Error:
        return False


def _runtime_status_at(port, timeout, *, expected_runtime=False):
    url = local_url(port)
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(url + "/api/runtime/ping", timeout=timeout) as response:
            status = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        raise RuntimeConflict(f"포트 {port}번의 프로그램이 recordWEB 식별 API에 응답하지 않습니다: HTTP {error.code}") from error
    except urllib.error.URLError as error:
        if not _port_is_listening(port):
            return None
        if expected_runtime:
            raise RuntimeUnavailable(f"포트 {port}번에서 기존 서버의 식별 정보를 확인하는 중입니다. {error.reason}") from error
        raise RuntimeConflict(
            f"서버 포트 {port}번은 다른 프로그램이 사용 중입니다. 다른 포트를 설정하거나 해당 프로그램을 종료해 주세요."
        ) from error
    except TimeoutError as error:
        if not _port_is_listening(port):
            return None
        if expected_runtime:
            raise RuntimeUnavailable(f"포트 {port}번의 기존 서버 식별 응답을 기다리는 중입니다.") from error
        raise RuntimeConflict(
            f"서버 포트 {port}번은 다른 프로그램이 사용 중입니다. 다른 포트를 설정하거나 해당 프로그램을 종료해 주세요."
        ) from error
    except (OSError, ValueError) as error:
        raise RuntimeConflict(f"포트 {port}번의 서버 식별 응답이 올바르지 않습니다.") from error

    from module.runtime_identity import validate_runtime
    if sys.platform == 'linux':
        from module.runtime_guard import RuntimeGuard
        current = RuntimeGuard.read_info(ROOT) or {}
        version = current.get('version')
        backend_python = ROOT / '.venv-linux/bin/python'
    else:
        from module.data_manager import PROGRAM_VERSION
        version, backend_python = PROGRAM_VERSION, sys.executable
    reason = validate_runtime(status, ROOT, version, backend_python)
    if reason:
        raise RuntimeConflict(
            reason + "\n기존 앱에서 작업을 확인하고 완전 종료한 뒤 recordWEB.bat을 다시 실행하세요. 기존 작업은 종료하지 않았습니다."
        )
    reported_port = status.get("port", port)
    if int(reported_port) != int(port):
        raise RuntimeConflict("실행 중인 recordWEB의 런타임 포트 정보가 일치하지 않습니다.")
    status["port"] = int(port)
    return status


def runtime_status(timeout=3.0):
    runtime_port = runtime_port_hint()
    if runtime_port is not None:
        return _runtime_status_at(runtime_port, timeout, expected_runtime=True)
    port = configured_port()
    try:
        return _runtime_status_at(port, timeout)
    except RuntimeConflict:
        # 첫 조회와 ping 사이에 우리 백엔드가 서버 정보를 기록할 수 있습니다.
        if runtime_port_hint() == port:
            return _runtime_status_at(port, timeout, expected_runtime=True)
        raise


def log_position(path):
    try:
        stat = path.stat()
        return stat.st_size, (stat.st_dev, stat.st_ino)
    except FileNotFoundError:
        return 0, None


def start_backend(startup=False):
    global OWNER_SESSION
    RUNTIME_DIR.mkdir(exist_ok=True)
    log_path = ROOT / "logs" / "recordWEB_backend.log"
    log_offset, log_identity = log_position(log_path)
    python = Path(sys.executable)
    pythonw = python.with_name("pythonw.exe")
    executable = pythonw if startup and pythonw.is_file() else python
    flags = 0
    if os.name == "nt":
        flags = subprocess.CREATE_NEW_PROCESS_GROUP
        if startup:
            flags |= subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW
    if not startup and os.name == 'nt':
        import psutil
        OWNER_SESSION = uuid.uuid4().hex
        command = [str(pythonw if pythonw.is_file() else python), '-m', 'module.session_owner',
                   str(os.getpid()), str(psutil.Process().create_time()), OWNER_SESSION]
        flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW
    else:
        command = [str(executable), '-u', str(ROOT / 'module/recordWEB.py'), '--backend', *(['--startup'] if startup else [])]
    launched = subprocess.Popen(
        command,
        cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        close_fds=True, creationflags=flags,
    )
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        try:
            status = runtime_status(timeout=1.0)
        except RuntimeUnavailable:
            # 백엔드 응답 대기
            status = None
        if status:
            return status
        exit_code = launched.poll()
        if exit_code is not None:
            detail = f"종료 코드 {exit_code}"
            try:
                with log_path.open("rb") as source:
                    source.seek(0, 2)
                    size = source.tell()
                    stat = os.fstat(source.fileno())
                    same_file = (stat.st_dev, stat.st_ino) == log_identity
                    source.seek(max(log_offset if same_file and log_offset <= size else 0, size - 16384))
                    detail_text = source.read().decode("utf-8", errors="replace")
                    lines = CONSOLE_CONTROLS.sub('', detail_text.replace('\r\n', '\n')).splitlines()
                if lines:
                    detail = '\n'.join(lines[-5:])
            except OSError:
                pass
            raise RuntimeError('백엔드가 시작 중 종료됐습니다.\n'+detail)
        time.sleep(0.25)
    raise RuntimeError("recordWEB 백엔드가 30초 안에 응답하지 않았습니다. logs/recordWEB_backend.log를 확인하세요.")


def acquire_window_lock():
    RUNTIME_DIR.mkdir(exist_ok=True)
    handle = open(RUNTIME_DIR / "desktop-window.lock", "a+b")
    if os.name != "nt":
        import fcntl
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return handle
        except BlockingIOError:
            handle.close()
            (RUNTIME_DIR / "show-ui.signal").touch()
            return None
        except OSError:
            handle.close()
            raise
    import msvcrt
    handle.seek(0)
    if handle.read(1) == b"":
        handle.write(b"0")
        handle.flush()
    handle.seek(0)
    try:
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        return handle
    except OSError:
        handle.close()
        (RUNTIME_DIR / "show-ui.signal").touch()
        return None


@contextmanager
def launch_lock():
    if os.name != "nt":
        yield
        return
    import msvcrt
    RUNTIME_DIR.mkdir(exist_ok=True)
    with (RUNTIME_DIR / "backend-launch.lock").open("a+b") as handle:
        deadline = time.monotonic() + 35
        while True:
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                break
            except OSError as error:
                if time.monotonic() >= deadline:
                    raise RuntimeError("다른 recordWEB 실행 요청이 끝나기를 기다리는 중입니다.") from error
                time.sleep(0.2)
        yield


class DesktopBridge:
    def __init__(self, version=None):
        if version is None:
            from module.data_manager import PROGRAM_VERSION
            version = PROGRAM_VERSION
        self.version = version

    def close_for_shutdown(self):
        import webview
        if webview.windows:
            webview.windows[0].destroy()

    def select_folder(self):
        import webview
        result = webview.windows[0].create_file_dialog(webview.FOLDER_DIALOG)
        return result[0] if result else None

    def desktop_info(self):
        return {"desktop": True, "version": self.version, "native_folder_picker": True}


def signal_loop(window, backend, bridge, stop, last):
    import psutil
    signal = RUNTIME_DIR / "show-ui.signal"
    while not stop.wait(0.5):
        try:
            process = psutil.Process(backend['pid'])
            if not process.is_running() or process.status() == psutil.STATUS_ZOMBIE or abs(process.create_time()-backend['pid_started']) > .1:
                bridge.close_for_shutdown()
                return
            current = signal.stat().st_mtime_ns if signal.exists() else 0
            if current != last:
                last = current
                window.show()
                window.restore()
        except psutil.NoSuchProcess:
            bridge.close_for_shutdown()
            return
        except Exception:
            return


def show_desktop(path="/", backend=None):
    signal = RUNTIME_DIR / "show-ui.signal"
    try:
        last = signal.stat().st_mtime_ns
    except FileNotFoundError:
        last = 0
    lock = acquire_window_lock()
    if lock is None:
        return None
    stop = threading.Event()
    try:
        with ExitStack() as resources:
            return _show_desktop_window(path, backend, stop, last, resources)
    finally:
        stop.set()
        lock.close()


def _show_desktop_window(path, backend, stop, last, resources):
    import webview
    backend = backend or runtime_status()
    if not backend:
        raise RuntimeError("실행 중인 recordWEB 서버를 찾지 못했습니다.")
    bridge = DesktopBridge(backend["version"])
    webview.settings["ALLOW_DOWNLOADS"] = True
    icon = ROOT / "templates/static/img/recordweb.ico"
    if sys.platform == "linux":
        from PIL import Image
        png = Path(resources.enter_context(tempfile.TemporaryDirectory(dir=RUNTIME_DIR))) / 'recordweb.png'
        with Image.open(icon) as image:
            image.save(png)
        icon = png
    window = webview.create_window(
        f"recordWEB {bridge.version}", local_url(backend["port"]) + path, width=1280, height=860,
        min_size=(820, 600), js_api=bridge, confirm_close=False,
    )
    webview.start(
        signal_loop, (window, backend, bridge, stop, last),
        gui="gtk" if sys.platform == "linux" else "edgechromium",
        icon=str(icon), debug=False, private_mode=False,
    )
    return 0


def check_environment():
    from module.diagnostics import environment_check
    print(json.dumps(asyncio.run(environment_check()), ensure_ascii=False, indent=2))


def follow_backend_log(stop, offset=None, identity=None):
    path = ROOT / 'logs' / 'recordWEB_backend.log'
    from module.runtime_log import log_archives

    try:
        while not stop.is_set():
            try:
                with path.open('rb') as source:
                    stat = os.fstat(source.fileno())
                    current = stat.st_dev, stat.st_ino
                    if identity is None and offset is None:
                        offset = stat.st_size
                    rotated = identity is not None and identity != current
                    if rotated or offset > stat.st_size:
                        position = 0
                    else:
                        position = offset
                    source.seek(position)
                    lines = source.readlines(16 * 1024)
                    new_offset = source.tell()
            except FileNotFoundError:
                if identity is None:
                    offset = 0
                stop.wait(0.2)
                continue
            if rotated:
                for archive in log_archives(path):
                    try:
                        with archive.open('rb') as source:
                            stat = os.fstat(source.fileno())
                            if (stat.st_dev, stat.st_ino) == identity:
                                source.seek(offset)
                                lines = source.readlines() + lines
                                break
                    except FileNotFoundError:
                        pass
            identity, offset = current, new_offset
            if not lines:
                stop.wait(0.2)
                continue
            try:
                message = b''.join(lines).decode('utf-8', errors='replace')
                print(CONSOLE_CONTROLS.sub('', message.replace('\r\n', '\n').replace('\r', '\n')), end='', flush=True)
            except (OSError, ValueError):
                return
    except OSError as error:
        print(f'[LOG] 로그 연결 실패: {error}')


def main():
    global OWNER_SESSION
    if sys.platform == "linux":
        if sys.argv[1:] != ["--open-ui"]:
            print("./recordWEB.sh로 실행하세요.", file=sys.stderr)
            return 20
        try:
            port = runtime_port_hint()
            status = _runtime_status_at(port, 3, expected_runtime=True) if port is not None else None
            if status and status["run_mode"] in ("normal", "lite"):
                return show_desktop(backend=status) or 0
            return 0
        except Exception as error:
            print(f"[recordWEB] 전용 창을 열 수 없습니다. 서버는 계속 실행됩니다. {error}", file=sys.stderr)
            return 21
    from module.runtime_identity import canonical
    from module.run_mode import resolve_run_mode
    if canonical(sys.executable) not in {canonical(ROOT/'.venv/Scripts/python.exe'), canonical(ROOT/'.venv/Scripts/pythonw.exe')}:
        print('recordWEB.bat으로 실행하세요. recordWEB 전용 Python 환경이 필요합니다.',file=sys.stderr)
        return 20
    parser = argparse.ArgumentParser(description="recordWEB desktop launcher (normally use recordWEB.bat)")
    launch_kind = parser.add_mutually_exclusive_group()
    launch_kind.add_argument("--startup", action="store_true")
    launch_kind.add_argument("--open-ui", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.check:
        check_environment()
        return 0
    log_path = ROOT/'logs/recordWEB_backend.log'
    log_offset, log_identity = log_position(log_path)
    stop = threading.Event()
    try:
        with launch_lock():
            status = runtime_status()
            existing = status is not None
            if not existing:
                if args.open_ui:
                    return 0
                status = start_backend(startup=args.startup)
        show_ui = False
        if not args.startup:
            mode = resolve_run_mode({"runMode": status.get("run_mode")})
            show_ui = mode == "normal" or (mode == "lite" and existing)
        if existing:
            if show_ui:
                show_desktop("/", backend=status)
            return 0

        if args.startup:
            print(f"[recordWEB] 자동 실행 완료: {local_url(status['port'])}", flush=True)
            print('[recordWEB] 이 CMD 창을 닫아도 서버와 녹화는 계속됩니다.', flush=True)
        else:
            print('[recordWEB] 이 CMD 창을 닫으면 recordWEB이 종료됩니다.', flush=True)
        threading.Thread(target=follow_backend_log, args=(stop, log_offset, log_identity), daemon=True).start()
        if show_ui:
            try:
                show_desktop("/", backend=status)
            except Exception as error:
                print(f'[recordWEB] 전용 창을 열 수 없습니다. 서버는 계속 실행됩니다. {error}', flush=True)
            else:
                print('[recordWEB] 웹뷰 창을 닫았습니다. 녹화와 예약 녹화는 계속됩니다.', flush=True)
        import psutil
        try:
            process = psutil.Process(status['pid'])
            if abs(process.create_time() - status['pid_started']) <= 0.1:
                process.wait()
        except psutil.NoSuchProcess:
            pass
        return 0
    except (RuntimeError, OSError) as error:
        print(f'[recordWEB] 실행 중단: {error}', flush=True)
        return 21
    except KeyboardInterrupt:
        print('[recordWEB] '+('소유 백엔드에 정상 종료를 요청합니다.' if OWNER_SESSION else '연결을 해제합니다.'))
        return 0
    finally:
        stop.set()
        if OWNER_SESSION:
            from module.session_owner import request_shutdown
            session, OWNER_SESSION = OWNER_SESSION, None
            request_shutdown('Local\\recordWEB-shutdown-'+session)


if __name__ == "__main__":
    raise SystemExit(main())
