from __future__ import annotations

import json
import os
import sys
import re
import requests
import hashlib
import glob
import secrets
import asyncio
import time
import shutil
import tempfile
import threading
import contextlib  
import weakref
import base64
from threading import RLock
from datetime import datetime
from pathlib import Path
from cryptography.fernet import Fernet
from typing import Dict, Set, Optional

from module import cookie_store
from module.runtime_log import DEFAULT_DIAGNOSTIC_LOG_DAYS, normalize_diagnostic_log_days, printOnce

base_directory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 프로그램 공통 정보
PROGRAM_NAME = "recordWEB"
PROGRAM_VERSION = "v1.3.2b"
WEB_UI_TITLE = "recordWEB"

CONFIG_PATH = os.path.join(base_directory, 'json', 'config.json')
CHANNELS_PATH = os.path.join(base_directory, 'json', 'channels.json')
COOKIE_PATH = os.path.join(base_directory, 'json', 'cookie.json')
yCOOKIE_PATH = os.path.join(base_directory, 'json', 'ycookie.txt')
LOGIN_PATH = os.path.join(base_directory, 'json', 'login.json')
NOTIFICATION_PATH = os.path.join(base_directory, 'json', 'notification.json')
POSTPROCESS_FAILED_PATH = os.path.join(base_directory, 'json', 'postprocess_failed.json')

BUNDLED_TOOL_LAYOUT = {
    "ffmpeg": ("ffmpeg", "bin/ffmpeg.exe"),
    "ffprobe": ("ffmpeg", "bin/ffprobe.exe"),
    "streamlink": ("streamlink", "bin/streamlink.exe"),
    "aria2c": ("aria2c", "aria2c.exe"),
    "yt-dlp": ("yt-dlp", "yt-dlp.exe"),
    "deno": ("yt-dlp", "deno.exe"),
}
BUNDLED_TOOL_PATHS = {
    name: Path("dependent", directory, executable)
    for name, (directory, executable) in BUNDLED_TOOL_LAYOUT.items()
}

# 전역 asyncio 락 
move_async_lock = asyncio.Lock()

TRUE_SET  = {"1","true","t","yes","y","on"}
FALSE_SET = {"0","false","f","no","n","off",""}

CHANNEL_QUALITY_RE = re.compile(
    r"^(best|worst|(?:144|240|360|480|720|1080|1440|2160)p)$",
    re.IGNORECASE
)

DEFAULT_NOTIFICATION = {
    "telegram_enabled": False,
    "telegram_bot_token": "",
    "telegram_chat_id": "",
    "discord_enabled": False,
    "discord_webhook_url": "",
    "events": {
        "record_started": False,
        "record_finished": False,
        "record_start_failed": True,
        "record_abnormally_stopped": True,
        "record_user_stopped": False,
        "postprocess_finished": True,
        "postprocess_failed": True,
        "cookie_auth_failed": True,
        "watchparty_skipped": False,
        "disk_space_low": True,
    },
    "limits": {
        "dedupe_seconds": 300,
        "disk_space_low_gb": 10,
    },
}

_notify_last_sent = {}


def normalizeChannelQuality(value) -> str:
    q = str(value or "best").strip().lower()

    if CHANNEL_QUALITY_RE.fullmatch(q):
        return q

    m = re.match(r"^(144|240|360|480|720|1080|1440|2160)(?:p)?(?:\d{2,3})?$", q)
    if m:
        return f"{m.group(1)}p"

    print(f"[WARN] 지원하지 않는 품질값을 best로 보정합니다: {value!r}")
    return "best"

ALLOWED_KEYS = {
    "platform", "id", "name", "output_dir",
    "quality", "extension", "record_enabled",
    "recordWatchParty", "watchPartyExcludeTags",
    "gpu_index", "original_id", "duplicate_of", "validation_error", "recording_group"
    }


def toBool(v, *, default=False):
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v != 0
    if isinstance(v, str):
        s = v.strip().lower()
        if s in TRUE_SET:
            return True
        if s in FALSE_SET:
            return False
        return default
    return bool(v)


def canonJson(obj) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    except Exception:
        return ""


def readJsonSafe(path: str, default, *, strict=False):
    try:
        return _read_json(path)
    except FileNotFoundError:
        return default
    except (OSError, ValueError):
        with _json_write_lock:
            # A writer may have repaired or removed the file before we got the lock.
            try:
                return _read_json(path)
            except FileNotFoundError:
                return default
            except (OSError, ValueError):
                recovered = _restoreFromBak(path, default)
                if recovered is not default:
                    with contextlib.suppress(OSError):
                        _writeJsonSafe(path, recovered, preserve_backup=True)
                elif strict:
                    raise
                return recovered


def _read_json(path, *, encoding="utf-8"):
    with open(path, encoding=encoding) as source:
        return json.load(source)


_json_write_lock = RLock()


def writeJsonSafe(path: str, data, *, preserve_backup=False) -> bool:
    with _json_write_lock:
        return _writeJsonSafe(os.fspath(path), data, preserve_backup=preserve_backup)


def _writeJsonSafe(path: str, data, *, preserve_backup=False) -> bool:
    path = os.fspath(path)
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    backup_current = False
    try:
        current = _read_json(path)
    except FileNotFoundError:
        pass
    except (OSError, ValueError):
        with contextlib.suppress(OSError):
            shutil.copyfile(path, path + ".corrupt.bak")
    else:
        if current is not None and canonJson(current) == canonJson(data):
            return False
        backup_current = not preserve_backup

    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=directory,
            prefix=f".{os.path.basename(path)}-", suffix=".tmp", delete=False,
        ) as output:
            temporary = output.name
            json.dump(data, output, ensure_ascii=False, indent=4)
            output.flush()
            os.fsync(output.fileno())
        if backup_current:
            with contextlib.suppress(OSError):
                shutil.copyfile(path, path + ".bak")
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            with contextlib.suppress(FileNotFoundError):
                os.unlink(temporary)
    return True


def _restoreFromBak(path: str, default):
    try:
        return _read_json(os.fspath(path) + ".bak")
    except (OSError, ValueError):
        return default


def filterChannelKeys(ch: dict, allowed: set) -> dict:
    return {k: v for k, v in ch.items() if k in allowed}


def normalizeChannelsList(lst: list[dict]) -> list[dict]:
    from module.channel_schema import normalize_channels
    return normalize_channels(lst)
class RecorderManager:
    session_diagnostics = {}
    # A) UI/알림 상태
    status_recording      : Dict[str, bool]   = {}
    status_reserved       : Dict[str, bool]   = {}
    status_last_notified  : Dict[str, str]    = {}     # 알림 상태 캐시
    status_watchparty_off : Set[str]          = set()  # 같이보기 OFF 알림 플래그

    # B) 사용자 의도/요청
    is_user_stopped       : Set[str]          = set()  # 사용자 '중지' 의도

    # C) 진입/중복 가드
    guard_starting        : Set[str]          = set()  # 시작 진입 가드(원자성)
    guard_starting_at     : Dict[str, float]  = {}     # 가드 획득 시각(자가치유용)

    # D) 동시성/자원
    tasks_worker          : Dict[str, asyncio.Task]                 = {}
    tasks_segment         : Dict[str, asyncio.Task]                 = {}
    tasks_process         : Dict[str, asyncio.subprocess.Process]   = {}

    # E) 녹화 메타
    recording_start_time  : Dict[str, float]  = {}
    recording_display_info : dict = {}
    recording_state_observers = weakref.WeakSet()
    recording_filename    : Dict[str, str]    = {}
    recording_temp_path   : Dict[str, str]    = {}

    # E-1) 후처리 작업 추적
    postprocess_active_jobs: Dict[str, dict] = {}
    postprocess_recent_history: list[dict] = []

    # F) 채널 목록(프로세스 전역 메모리 캐시/레퍼런스)
    _channels_cache_lock = threading.RLock()
    _channels_cache: list = []
    _channels_ref = None             # 외부(ref)로 직접 관리되는 리스트를 가리킬 수 있음
    _channels_lock_ref = None        # 외부 락 레퍼런스


    def __init__(self):
        self._lock = threading.RLock()

    # 채널 목록 접근(기존 호환)
    @classmethod
    def setChannelsRef(cls, ref):
        cls._channels_ref = ref

    @classmethod
    def setChannelsLockRef(cls, ref):
        cls._channels_lock_ref = ref

    @classmethod
    def getChannelsLockRef(cls):
        return cls._channels_lock_ref

    @classmethod
    def getChannels(cls) -> list:
        # 1) 캐시 우선
        with cls._channels_cache_lock:
            if cls._channels_cache:
                return list(cls._channels_cache)

        # 2) 레퍼런스 포인터 사용
        if cls._channels_ref is not None:
            lock = cls._channels_lock_ref

            try:
                import asyncio as _aio
                if isinstance(lock, _aio.Lock):
                    return list(cls._channels_ref)
            except Exception:
                pass
            # 일반 락이면 잡고 반환, 실패해도 복사본 반환
            if lock is not None:
                try:
                    with lock:
                        return list(cls._channels_ref)
                except Exception:
                    return list(cls._channels_ref)
            return list(cls._channels_ref)

        # 3) 마지막 폴백: 디스크 → 캐시 적재
        try:
            data = loadChannels() or []
        except Exception:
            data = []
        with cls._channels_cache_lock:
            cls._channels_cache = list(data)
        return list(cls._channels_cache)

    @classmethod
    def setChannels(cls, channels: list) -> None:
        with cls._channels_cache_lock:
            cls._channels_cache = list(channels or [])


    # A) UI/알림 상태
    def get_status_recording(self, channel_id: str) -> bool:
        with self._lock:
            return bool(self.__class__.status_recording.get(channel_id, False))

    def set_status_recording(self, channel_id: str, value: bool) -> None:
        with self._lock:
            previous = self.__class__.status_recording.get(channel_id, False)
            if bool(previous) != bool(value):
                info = self.__class__.session_diagnostics.setdefault(channel_id, {})
                info["last_recording_start" if value else "last_recording_end"] = time.time()
            self.__class__.status_recording[channel_id] = bool(value)
        # Lifecycle writers notify the owning FSM; status GETs remain read-only.
        for observer in list(self.__class__.recording_state_observers):
            observer.recordingChanged(channel_id, bool(value))

    def get_status_reserved(self, channel_id: str) -> bool:
        with self._lock:
            return bool(self.__class__.status_reserved.get(channel_id, False))

    def set_status_reserved(self, channel_id: str, value: bool) -> None:
        with self._lock:
            self.__class__.status_reserved[channel_id] = bool(value)

    # watch party off 알림 플래그
    def is_watch_party_off_notified(self, channel_id: str) -> bool:
        with self._lock:
            return channel_id in self.__class__.status_watchparty_off

    def set_watch_party_off_notified(self, channel_id: str, value: bool) -> None:
        with self._lock:
            if value:
                self.__class__.status_watchparty_off.add(channel_id)
            else:
                self.__class__.status_watchparty_off.discard(channel_id)

    def reset_watch_party_off_notified(self, channel_id: str) -> None:
        with self._lock:
            self.__class__.status_watchparty_off.discard(channel_id)

    # B) 사용자 의도/요청
    def get_is_user_stopped(self, channel_id: str) -> bool:
        with self._lock:
            return channel_id in self.__class__.is_user_stopped

    def set_is_user_stopped(self, channel_id: str, value: bool) -> None:
        with self._lock:
            if value:
                self.__class__.is_user_stopped.add(channel_id)
            else:
                self.__class__.is_user_stopped.discard(channel_id)

    # C) 진입/중복 가드
    def guard_try_acquire_start(self, channel_id: str) -> bool:
        with self._lock:
            if channel_id in self.__class__.guard_starting:
                return False
            self.__class__.guard_starting.add(channel_id)
            self.__class__.guard_starting_at[channel_id] = time.monotonic()
            return True

    def guard_release_start(self, channel_id: str) -> None:
        with self._lock:
            self.__class__.guard_starting.discard(channel_id)
            self.__class__.guard_starting_at.pop(channel_id, None)

    def guard_get_start_age(self, channel_id: str) -> Optional[float]:
        with self._lock:
            if channel_id not in self.__class__.guard_starting:
                return None
            ts = self.__class__.guard_starting_at.get(channel_id)
            if not ts:
                return None
            return time.monotonic() - float(ts)

    # D) 동시성/자원 (태스크/프로세스)
    def get_tasks_worker(self, channel_id: str) -> Optional[asyncio.Task]:
        with self._lock:
            return self.__class__.tasks_worker.get(channel_id)

    def set_tasks_worker(self, channel_id: str, task: asyncio.Task) -> None:
        with self._lock:
            self.__class__.tasks_worker[channel_id] = task

    def clear_tasks_worker(self, channel_id: str) -> None:
        with self._lock:
            self.__class__.tasks_worker.pop(channel_id, None)

    def get_tasks_process(self, channel_id: str) -> Optional[asyncio.subprocess.Process]:
        with self._lock:
            return self.__class__.tasks_process.get(channel_id)

    def set_tasks_process(self, channel_id: str, proc: asyncio.subprocess.Process, *, display_metadata=None) -> None:
        with self._lock:
            self.__class__.tasks_process[channel_id] = proc
            if display_metadata is None:
                self.__class__.recording_display_info.pop(channel_id, None)
            else:
                fields = ("status", "is_live", "live_title", "liveTitle", "category", "thumbnail_url", "adult", "video_codec")
                display = {key: display_metadata[key] for key in fields if key in display_metadata}
                self.__class__.recording_display_info[channel_id] = (time.monotonic(), display)

    def get_recording_display_session(self, channel_id):
        with self._lock:
            cls = self.__class__
            proc = cls.tasks_process.get(channel_id)
            if (proc is not None and proc.returncode is None and cls.status_recording.get(channel_id)
                    and channel_id not in cls.is_user_stopped
                    and not cls.session_diagnostics.get(channel_id, {}).get("recording_fault")):
                return proc, cls.recording_display_info.get(channel_id)
            return None, None

    def clear_tasks_process(self, channel_id: str) -> None:
        with self._lock:
            self.__class__.tasks_process.pop(channel_id, None)
            self.__class__.recording_display_info.pop(channel_id, None)

    # E) 녹화 메타
    def recording_set_start_time(self, channel_id: str, ts: Optional[float] = None) -> None:
        with self._lock:
            self.__class__.recording_start_time[channel_id] = ts if ts is not None else time.time()

    def recording_remove_start_time(self, channel_id: str) -> None:
        with self._lock:
            self.__class__.recording_start_time.pop(channel_id, None)

    def recording_set_filename(self, channel_id: str, path: str, *, temp_path=None) -> None:
        with self._lock:
            self.__class__.recording_filename[channel_id] = path
            if temp_path:
                self.__class__.recording_temp_path[channel_id] = temp_path

    def get_recording_temp_path(self, channel_id: str):
        with self._lock:
            return self.__class__.recording_temp_path.get(channel_id)

    def recording_remove_filename(self, channel_id: str) -> None:
        with self._lock:
            self.__class__.recording_filename.pop(channel_id, None)
            self.__class__.recording_temp_path.pop(channel_id, None)

    # 후처리 작업 등록
    def postprocess_register_job(self, channel_id: str, channel_name: str,
                                 input_path: str, post_cfg: dict | None, job_id=None,
                                 *, segment_indexes=None, split_overlap_sec=None, inputs=None) -> str:
        cfg = post_cfg or {}
        raw = f"{channel_id}|{input_path}|{time.time_ns()}"
        job_id = job_id or hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:12]

        job = {
            "job_id": job_id,
            "status": "running",
            "channel_id": channel_id,
            "channel_name": channel_name,
            "input_path": input_path,
            "input_file": os.path.basename(input_path or ""),
            "profile": cfg.get("_profile"),
            "gpu_index": cfg.get("gpu_index"),
            "stream_copy": cfg.get("stream_copy"),
            "video_codec": cfg.get("video_codec"),
            "preset": cfg.get("preset"),
            "postprocess_resolution": cfg.get("postprocess_resolution"),
            "audio_codec": cfg.get("audio_codec"),
            "audio_bitrate": cfg.get("audio_bitrate"),
            "started_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "finished_at": None,
            "reason": "",
        }

        if segment_indexes is not None:
            job.update(segment_indexes=segment_indexes, split_overlap_sec=split_overlap_sec)
        if inputs is not None:
            job["input_identities"] = inputs
        from module.postprocess_store import started
        started(job)
        with self._lock:
            self.__class__.postprocess_active_jobs[job_id] = job

        return job_id

    def postprocess_set_output_path(self, job_id: str, path: str) -> None:
        with self._lock:
            job = self.__class__.postprocess_active_jobs.get(job_id)
            if job is not None:
                from module.postprocess_store import set_output_path
                set_output_path(job_id, path)
                job["output_path"] = path

    def postprocess_set_cleanup_paths(self, job_id: str, paths: tuple[str, ...]) -> None:
        with self._lock:
            job = self.__class__.postprocess_active_jobs.get(job_id)
            if job is not None:
                job["cleanup_paths"] = paths

    # 후처리 성공 처리
    def postprocess_finish_job(self, job_id: str) -> None:
        with self._lock:
            job = self.__class__.postprocess_active_jobs.get(job_id)
            if not job:
                return

            job["status"] = "success"
            job["finished_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            from module.postprocess_store import recovered
            recovered(job)
            self.__class__.postprocess_active_jobs.pop(job_id, None)
            job.pop("cleanup_paths", None)

            self.__class__.postprocess_recent_history.append(job)
            self.__class__.postprocess_recent_history = self.__class__.postprocess_recent_history[-100:]

    # 후처리 실패 처리 + json 기록
    def postprocess_fail_job(self, job_id: str, reason: str) -> None:
        with self._lock:
            job = self.__class__.postprocess_active_jobs.pop(job_id, None)
            if not job:
                return

            job.pop("cleanup_paths", None)
            job["status"] = "failed"
            job["finished_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            job["reason"] = str(reason or "")

            self.__class__.postprocess_recent_history.append(job)
            self.__class__.postprocess_recent_history = self.__class__.postprocess_recent_history[-100:]

            from module.postprocess_store import failed
            failed(job)

    # 현재 실행 중인 후처리 목록 조회
    def get_postprocess_active_jobs(self) -> list[dict]:
        with self._lock:
            return list(self.__class__.postprocess_active_jobs.values())

    # 최근 후처리 이력 조회
    def get_postprocess_recent_history(self) -> list[dict]:
        with self._lock:
            return list(self.__class__.postprocess_recent_history)

    # F) 헬스
    def get_recording_filename(self, channel_id: str):
        with self._lock:
            return self.__class__.recording_filename.get(channel_id)

    def get_recording_start_ts(self, channel_id: str):
        with self._lock:
            return self.__class__.recording_start_time.get(channel_id)

    def get_recording_start_time(self, channel_id: str):
        ts = self.get_recording_start_ts(channel_id)
        try:
            from datetime import datetime
            return datetime.fromtimestamp(float(ts)) if ts else None
        except Exception:
            return None

    # G) 백워드 호환 래퍼
    def get_recording_status(self, channel_id: str) -> bool:
        return self.get_status_recording(channel_id)

    def set_recording_status(self, channel_id: str, value: bool) -> None:
        self.set_status_recording(channel_id, value)

    def get_reserved_recording(self, channel_id: str) -> bool:
        return self.get_status_reserved(channel_id)

    def set_reserved_recording(self, channel_id: str, value: bool) -> None:
        self.set_status_reserved(channel_id, value)

    # 사용자 중지
    def is_stop_requested(self, channel_id: str) -> bool:
        return self.get_is_user_stopped(channel_id)

    def add_stop_requested_channel(self, channel_id: str) -> None:
        self.set_is_user_stopped(channel_id, True)

    def remove_stop_requested_channel(self, channel_id: str) -> None:
        self.set_is_user_stopped(channel_id, False)

    def recording_get_filename(self, channel_id: str):
        return self.get_recording_filename(channel_id)


    # 워커 태스크
    def get_worker_task(self, channel_id: str):
        return self.get_tasks_worker(channel_id)

    def set_worker_task(self, channel_id: str, task: asyncio.Task):
        self.set_tasks_worker(channel_id, task)

    def clear_worker_task(self, channel_id: str):
        self.clear_tasks_worker(channel_id)

    # 시작 가드
    def try_acquire_start(self, channel_id: str) -> bool:
        return self.guard_try_acquire_start(channel_id)

    def release_start(self, channel_id: str) -> None:
        self.guard_release_start(channel_id)

    # 프로세스
    def set_recording_process(self, channel_id: str, proc: asyncio.subprocess.Process) -> None:
        self.set_tasks_process(channel_id, proc)

    def get_recording_process(self, channel_id: str) -> Optional[asyncio.subprocess.Process]:
        return self.get_tasks_process(channel_id)

    def remove_recording_process(self, channel_id: str) -> None:
        self.clear_tasks_process(channel_id)

    # 시작 시간/파일명
    def set_recording_start_time(self, channel_id: str) -> None:
        self.recording_set_start_time(channel_id)

    def remove_recording_start_time(self, channel_id: str) -> None:
        self.recording_remove_start_time(channel_id)

    def set_recording_filename(self, channel_id: str, path: str) -> None:
        self.recording_set_filename(channel_id, path)

    def remove_recording_filename(self, channel_id: str) -> None:
        self.recording_remove_filename(channel_id)

    # 채널 워커 제거
    async def force_terminate_worker(self, channel_id: str, timeout: float = 5.0) -> bool:
        with self._lock:
            task = self.__class__.tasks_worker.get(channel_id)

        if not task:
            return True

        if task.done():
            self.clear_tasks_worker(channel_id)
            return True

        try:
            task.cancel()
            try:
                await asyncio.wait_for(task, timeout=timeout)
            except asyncio.TimeoutError:
                pass
        except Exception:
            pass
        finally:
            self.clear_tasks_worker(channel_id)

        return True



    # 녹화 경과 시간 계산 함수 
    def get_recording_duration(self, channel_id: str) -> str:
        with self._lock:
            start_ts = self.__class__.recording_start_time.get(channel_id)

        if not start_ts:
            return "00:00:00"

        try:
            elapsed = int(time.time() - float(start_ts))
            if elapsed < 0:
                elapsed = 0
        except Exception:
            return "00:00:00"

        h, r = divmod(elapsed, 3600)
        m, s = divmod(r, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"


# alias 연결 
last_notified_state = RecorderManager.status_last_notified


# 계정 불러오기 함수
def loadAccount():
    try:
        data = _read_json(LOGIN_PATH)
    except FileNotFoundError:
        return None
    except ValueError as exc:
        print(f"[ERROR] {LOGIN_PATH} 파일을 읽는 중 오류가 발생했습니다: {type(exc).__name__}")
        return None
    if not isinstance(data, dict) or not data.get('username') or not data.get('password'):
        return None
    return {
        'username': data['username'],
        'password': data['password'],
        'secret_key': data.get('secret_key', secrets.token_hex(32)),
    }


# 계정 저장 함수
def saveAccount(account):
    with _json_write_lock:
        disk = readJsonSafe(LOGIN_PATH, {})
        if not isinstance(disk, dict):
            disk = {}
        data = {
            **disk,
            'username': account.get('username'),
            'password': account.get('password'),
            'secret_key': disk.get('secret_key', secrets.token_hex(32)),
        }
        writeJsonSafe(LOGIN_PATH, data)


def deleteAccount():
    with _json_write_lock:
        try:
            os.remove(LOGIN_PATH)
        except FileNotFoundError:
            return False
        return True


# channels.json 로드 함수 (치지직과 씨미를 통합)
def _channel_migration_backup(original: bytes):
    digest = hashlib.sha256(original).hexdigest()
    backup = CHANNELS_PATH + ".migration-" + digest[:16] + ".bak"
    try:
        with open(backup, "xb") as output:
            output.write(original)
    except FileExistsError:
        pass
    return backup


def loadChannels() -> list[dict]:
    if not os.path.exists(CHANNELS_PATH):
        return []
    with _json_write_lock:
        with open(CHANNELS_PATH, "rb") as source:
            original = source.read()
        recovered = False
        try:
            raw = json.loads(original.decode("utf-8-sig"))
        except (ValueError, UnicodeError) as error:
            backup = CHANNELS_PATH + ".bak"
            if not os.path.exists(backup):
                raise ValueError("channels.json을 읽지 못했습니다. 원본을 빈 목록으로 덮어쓰지 않았습니다.") from error
            raw = _read_json(backup, encoding="utf-8-sig")
            recovered = True
        normalized = normalizeChannelsList(raw)
        if recovered or raw != normalized or original.startswith(b"\xef\xbb\xbf"):
            backup = _channel_migration_backup(original)
            audit = {"migrated_at": datetime.now().isoformat(), "backup": backup, "before": raw, "after": normalized,
                     "changes": [{"index": i, "fields": sorted(set(before) | set(after))}
                                 for i, (before, after) in enumerate(zip(raw if isinstance(raw, list) else [], normalized))
                                 if before != after and isinstance(before, dict)]}
            # Audit before replacing the source; failure leaves the original intact.
            writeJsonSafe(backup + ".comparison.json", audit)
            writeJsonSafe(CHANNELS_PATH, normalized, preserve_backup=recovered)
            print(f"[MIGRATION] channels: {len(normalized)}개, 원본 백업/비교 기록: {backup}")
        return normalized


def saveChannels(data: list[dict]):
    norm = normalizeChannelsList(data)
    changed = writeJsonSafe(CHANNELS_PATH, norm)
    if changed:
        print(f"[DEBUG] {CHANNELS_PATH} 저장 완료.")
        RecorderManager.setChannels(norm)
DEFAULT_COOKIE_DATA = cookie_store.normalize({})
normalizeCookies = cookie_store.normalize


def loadCookies():
    return cookie_store.load_web(COOKIE_PATH)


def saveCookies(data):
    try:
        if cookie_store.save_web(COOKIE_PATH, data):
            print(f"[DEBUG] {COOKIE_PATH} 저장 완료.")
    except Exception as e:
        print(f"[ERROR] {COOKIE_PATH} 저장 오류: {e}")
        raise


def updatePlatformCookies(changes, *, replace_chzzk=False):
    data, changed = cookie_store.update_web(COOKIE_PATH, changes, replace_chzzk=replace_chzzk)
    if changed:
        print(f"[DEBUG] {COOKIE_PATH} 저장 완료.")
    return data


def getChzzkCookies():
    cookies = loadCookies()
    return cookies.get("chzzk", {})


def getCimeCookies():
    cookies = loadCookies()
    return cookies.get("cime", {})


def getCimeCookieHeader():
    cime = getCimeCookies()

    parts = []
    for key in ("mauth-authorization-code", "session-id"):
        value = str(cime.get(key, "") or "").strip()
        if value:
            parts.append(f"{key}={value}")

    return "; ".join(parts)


_CONFIG_SAFE_VALUES = dict.fromkeys((
    "autoRecordingMode", "autoPostProcessing", "splitPostProcessing", "deleteAfterPostProcessing",
    "removeFixedPrefix", "moveAfterProcessingEnabled", "remoteAccessEnabled", "runAtWindowsStartup",
    "fileManagerEnabled",
), False)
_config_load_status = (None, "default")


def getConfigLoadStatus():
    path, state = _config_load_status
    return state if path == os.path.abspath(CONFIG_PATH) else "default"


def _set_config_load_status(state):
    global _config_load_status
    status = (os.path.abspath(CONFIG_PATH), state)
    if status != _config_load_status:
        _config_load_status = status
        if state == "safe_mode":
            print("[CONFIG][ERROR] config.json을 읽을 수 없고 정상 백업도 없습니다. 안전모드에서 새 녹화와 후처리 재시도를 중지합니다.")
        elif state == "recovered":
            print("[CONFIG][WARN] config.json 읽기에 실패하여 정상 백업에서 설정을 읽었습니다.")


def _read_config_data(*, restore_backup=True):
    def read_object(path):
        value = _read_json(path)
        if not isinstance(value, dict):
            raise ValueError("config.json은 JSON 객체여야 합니다.")
        return value

    with _json_write_lock:
        try:
            data = read_object(CONFIG_PATH)
        except (OSError, ValueError) as primary_error:
            try:
                data = read_object(os.fspath(CONFIG_PATH) + ".bak")
            except (OSError, ValueError) as backup_error:
                fresh = (getConfigLoadStatus() == "default" and isinstance(primary_error, FileNotFoundError)
                         and isinstance(backup_error, FileNotFoundError))
                _set_config_load_status("default" if fresh else "safe_mode")
                return {} if fresh else dict(_CONFIG_SAFE_VALUES)
            if restore_backup:
                try:
                    with contextlib.suppress(OSError):
                        shutil.copyfile(CONFIG_PATH, os.fspath(CONFIG_PATH) + ".corrupt.bak")
                    _writeJsonSafe(CONFIG_PATH, data, preserve_backup=True)
                except OSError as error:
                    printOnce("config:restore-write", f"[CONFIG][WARN] 백업을 읽었으나 원본에 복원하지 못했습니다. {type(error).__name__}")
            _set_config_load_status("recovered")
            return data

        if getConfigLoadStatus() != "recovered":
            _set_config_load_status("normal")
        return data


DEFAULT_RECORDING_METADATA_REFRESH_INTERVAL = 60


def parseRecordingMetadataRefreshInterval(value):
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return DEFAULT_RECORDING_METADATA_REFRESH_INTERVAL
        if re.fullmatch(r"[0-9]+", value):
            value = int(value)
    if type(value) is not int or value < 0:
        raise ValueError("녹화 중 방송 정보 갱신 주기는 0 이상의 정수로 입력해 주세요.")
    return value


# config.json 파일에서 데이터를 불러오는 함수
def loadConfig(*, restore_backup=True):
    return normalizeConfig(_read_config_data(restore_backup=restore_backup))


def normalizeConfig(data):
    # 기본값
    defaults = {
        "config_schema_version": 2,
        "diagnosticLogDays": DEFAULT_DIAGNOSTIC_LOG_DAYS,
        "autoRecordingMode": False,
        "runAtWindowsStartup": False,
        "remoteAccessEnabled": False,
        "plugin_type": "basic",
        "timemachine_time_shift": 0,
        "autoPostProcessing": True,
        "deleteAfterPostProcessing": True,
        "removeFixedPrefix": True,
        "moveAfterProcessingEnabled": False,
        "moveAfterProcessing": "",
        "postNewWindow": False,
        "recheckInterval": 60,
        "recordingMetadataRefreshInterval": DEFAULT_RECORDING_METADATA_REFRESH_INTERVAL,
        "filenamePattern": "[{start_time}] {channel_name} {safe_live_title} {record_quality}{frame_rate}{file_extension}",
        "splitRecordingMode": False,
        "splitPostProcessing": True,
        "autoStopInterval": 0,
        "splitOverlapSec": 0,
        "gpuCount": 1,
        "singleGpuIndex": 0,
        "stream_copy": True,
        "video_codec": "libx264",
        "preset": "fast",
        "postprocess_resolution": "source",
        "postprocess_resolution_gpu1": "source",
        "use_bitrate_mode": True,
        "video_quality": 33,
        "video_bitrate": "1000k",
        "vbv_maxrate": "",
        "vbv_bufsize": "",
        "audio_codec": "aac",
        "audio_bitrate": "copy",
        "extra_ffmpeg_options": "",
        "video_codec_gpu1": "libx264",
        "preset_gpu1": "fast",
        "use_bitrate_mode_gpu1": True,
        "video_quality_gpu1": 33,
        "video_bitrate_gpu1": "1000k",
        "vbv_maxrate_gpu1": "",
        "vbv_bufsize_gpu1": "",
        "audio_codec_gpu1": "aac",
        "audio_bitrate_gpu1": "copy",
        "extra_ffmpeg_options_gpu1": "",        
        "loginMode": False,
        "port": 5000,
        "enableTray": False,
        "minimizeToTrayOnClose": False,
        "minimizeToTrayOnStart": False,
        "fileManagerEnabled": False,
        "fileManagerRoots": [],
        "fileManagerMode": "blacklist",
        "fileManagerReadOnly": False,
        "trashEnabled": False,
    }

    merged = {**defaults, **data}
    merged.pop("appUpdateRepository", None)
    for key, default in defaults.items():
        if isinstance(default, bool):
            merged[key] = toBool(merged.get(key), default=default)

    # gpuCount 정규화
    try:
        _gc = int(merged.get("gpuCount", 1) or 1)
    except Exception:
        _gc = 1
    merged["gpuCount"] = 2 if _gc == 2 else 1
    try:
        merged['singleGpuIndex'] = 1 if int(merged.get('singleGpuIndex', 0)) == 1 else 0
    except (ValueError, TypeError):
        merged['singleGpuIndex'] = 0

    # GPU1 프로필 누락 시 GPU0 값으로 fallback
    profile_keys = [
        "video_codec", "preset", "use_bitrate_mode", "video_quality", "video_bitrate",
        "vbv_maxrate", "vbv_bufsize", "audio_codec", "audio_bitrate", "extra_ffmpeg_options",
        "postprocess_resolution"
    ]

    for k in profile_keys:
        k1 = f"{k}_gpu1"
        if k1 not in merged:
            merged[k1] = merged.get(k)

    # 타입 보정(특히 int/bool)
    try:
        merged["video_quality"] = int(merged.get("video_quality", 33))
    except Exception:
        merged["video_quality"] = 33

    try:
        merged["video_quality_gpu1"] = int(merged.get("video_quality_gpu1", merged["video_quality"]))
    except Exception:
        merged["video_quality_gpu1"] = merged["video_quality"]

    merged["use_bitrate_mode"] = bool(merged.get("use_bitrate_mode", True))
    merged["use_bitrate_mode_gpu1"] = bool(merged.get("use_bitrate_mode_gpu1", merged["use_bitrate_mode"]))

    # 후처리 출력 해상도 정규화
    _allowed_res = ("source", "1080p", "720p", "480p")
    for _k in ("postprocess_resolution", "postprocess_resolution_gpu1"):
        _v = str(merged.get(_k, "source") or "source").strip().lower()
        merged[_k] = _v if _v in _allowed_res else "source"

    # 플러그인/타임시프트 정규화
    raw_plugin = str((merged.get("plugin_type") or "basic")).strip().lower()

    # 허용값만 인정 (오직 basic, timemachine_plus)
    if raw_plugin not in ("basic", "timemachine_plus"):
        raw_plugin = "basic"  # 레거시/이상값은 기본값으로 정리

    merged["plugin_type"] = raw_plugin

    # 플러그인에 따라 시프트 허용범위만 클램프
    try:
        _shift = int(merged.get("timemachine_time_shift", 0) or 0)
    except Exception:
        _shift = 0

    merged["timemachine_time_shift"] = (
        max(0, min(3600, _shift)) if raw_plugin == "timemachine_plus"
        else max(0, min(10, _shift))
    )

    # 분할녹화 오버랩 정규화
    try:
        ov = int(merged.get("splitOverlapSec", 0) or 0)
    except Exception:
        ov = 0
    ov = max(0, min(30, ov))
    if not bool(merged.get("splitRecordingMode", False)):
        ov = 0

    merged["splitOverlapSec"] = ov
    merged["splitPostProcessing"] = bool(merged.get("splitPostProcessing", True))

    # 트레이 옵션 의존성 보정
    enable_tray = bool(merged.get("enableTray", False))
    if not enable_tray:
        merged["minimizeToTrayOnClose"] = False
        merged["minimizeToTrayOnStart"] = False

    # 파일매니저 정규화
    roots = merged.get("fileManagerRoots", [])
    if isinstance(roots, str):
        roots = [roots]
    elif not isinstance(roots, list):
        roots = []
    merged["fileManagerRoots"] = [str(p).strip() for p in roots if str(p).strip()]

    mode = str(merged.get("fileManagerMode", "blacklist")).lower()
    if mode not in ("blacklist", "whitelist"):
        mode = "blacklist"
    merged["fileManagerMode"] = mode

    merged["fileManagerEnabled"] = bool(merged.get("fileManagerEnabled", False))
    merged["fileManagerReadOnly"] = bool(merged.get("fileManagerReadOnly", False))
    merged["trashEnabled"] = bool(merged.get("trashEnabled", False))
    merged["runAtWindowsStartup"] = bool(merged.get("runAtWindowsStartup", False))
    merged["remoteAccessEnabled"] = bool(merged.get("remoteAccessEnabled", False))

    if merged.get("moveAfterProcessing") is None:
        merged["moveAfterProcessing"] = ""

    # 기타 안전 보정
    try:
        merged["recheckInterval"] = int(merged.get("recheckInterval", 60))
    except Exception:
        merged["recheckInterval"] = 60
    try:
        merged["recordingMetadataRefreshInterval"] = parseRecordingMetadataRefreshInterval(merged["recordingMetadataRefreshInterval"])
    except ValueError:
        merged["recordingMetadataRefreshInterval"] = DEFAULT_RECORDING_METADATA_REFRESH_INTERVAL

    try:
        merged["port"] = int(merged.get("port", 5000))
    except Exception:
        merged["port"] = 5000

    merged["telegram_enabled"] = bool(merged.get("telegram_enabled", False))
    merged["diagnosticLogDays"] = normalize_diagnostic_log_days(merged.get("diagnosticLogDays"))

    return merged


# config.json 파일에서 데이터를 저장하는 함수
def saveConfig(data):
    try:
        with _json_write_lock:
            disk = _read_config_data()
            recovering = getConfigLoadStatus() == "safe_mode"
            merged = {**disk, **(data or {})}
            if data and "recordingMetadataRefreshInterval" in data:
                merged["recordingMetadataRefreshInterval"] = parseRecordingMetadataRefreshInterval(data["recordingMetadataRefreshInterval"])
            merged.pop("appUpdateRepository", None)
            merged["config_schema_version"] = 2
            if recovering:
                with contextlib.suppress(FileNotFoundError):
                    shutil.copyfile(CONFIG_PATH, os.fspath(CONFIG_PATH) + ".corrupt.bak")
            changed = writeJsonSafe(CONFIG_PATH, merged, preserve_backup=recovering)
            _set_config_load_status("normal")
        if changed:
            print(f"[DEBUG] {CONFIG_PATH} 저장 완료.")
        return merged
    except Exception as e:
        print(f"[ERROR] {CONFIG_PATH} 저장 오류: {e}")
        raise



# youtube용 최소 CONSENT 쿠키 파일을 저장/보장
def ysaveCookies(path: Optional[str] = None) -> str:
    target = path or yCOOKIE_PATH
    os.makedirs(os.path.dirname(target), exist_ok=True)
    content = (
        "# Netscape HTTP Cookie File\n"
        ".youtube.com\tTRUE\t/\tTRUE\t4102444800\tCONSENT\tYES+cb.202103\n"
    )
    with open(target, "w", encoding="utf-8") as f:
        f.write(content)
    return target


# ycookie.txt 불러오는 함수 
def yloadCookies() -> Optional[str]:
    if not os.path.exists(yCOOKIE_PATH):
        print(f"[INFO] {yCOOKIE_PATH} 파일이 없으므로 새로 생성합니다.")
        with open(yCOOKIE_PATH, 'w', encoding='utf-8') as f:
            f.write("# Netscape HTTP Cookie File\n")
        return None  # 쿠키 파일을 막 생성했으니 내용은 아직 유효하지 않을 수 있음
    
    # 파일이 존재하면, 경로만 반환
    return yCOOKIE_PATH


def detectYtSabrMode(cfg: dict | None = None) -> bool:
    try:
        cfg = cfg or loadConfig() or {}
        if toBool(cfg.get("ytSabrMode", False), default=False):
            return True
    except Exception:
        pass

    try:
        ytdlp = getYtDlp()
        if ytdlp:
            internal = os.path.join(os.path.dirname(ytdlp), "_internal")
            if os.path.isdir(internal):
                return True
    except Exception:
        pass

    return False


def buildYoutubeExtractorArgs(cfg: dict | None = None) -> str:
    cfg = cfg or loadConfig() or {}

    args = ["player-client=default,mweb"]

    if detectYtSabrMode(cfg):
        args.append("formats=duplicate")

    return ";".join(args)


def getYoutubeYtDlpCommonArgs(cfg: dict | None = None) -> list[str]:
    cfg = cfg or loadConfig() or {}
    args: list[str] = []

    deno_path = getDeno()
    if deno_path and os.path.isfile(deno_path):
        args += ["--js-runtimes", f"deno:{deno_path}"]

    ycookie = yloadCookies()
    if ycookie and os.path.isfile(ycookie):
        args += ["--cookies", ycookie]

    ex = buildYoutubeExtractorArgs(cfg)
    if ex:
        args += ["--extractor-args", f"youtube:{ex}"]

    return args


# 암호화 생성 함수
def get_encryption_key():
    account = loadAccount()
    if account and account.get('secret_key'):
        key_bytes = account['secret_key'].encode('utf-8')
        key_bytes = (key_bytes * (32 // len(key_bytes) + 1))[:32]
        return base64.urlsafe_b64encode(key_bytes)
    else:
        return Fernet.generate_key()


def _cleanNotificationEvents(events):
    if not isinstance(events, dict):
        events = {}

    return {
        key: bool(events.get(key, default_value))
        for key, default_value in DEFAULT_NOTIFICATION["events"].items()
    }


def _cleanNotificationLimits(limits):
    if not isinstance(limits, dict):
        limits = {}

    try:
        dedupe_seconds = int(limits.get(
            "dedupe_seconds",
            DEFAULT_NOTIFICATION["limits"]["dedupe_seconds"]
        ) or 0)
    except Exception:
        dedupe_seconds = DEFAULT_NOTIFICATION["limits"]["dedupe_seconds"]
    dedupe_seconds = max(0, min(86400, dedupe_seconds))

    try:
        disk_space_low_gb = int(limits.get(
            "disk_space_low_gb",
            DEFAULT_NOTIFICATION["limits"]["disk_space_low_gb"]
        ) or 10)
    except Exception:
        disk_space_low_gb = DEFAULT_NOTIFICATION["limits"]["disk_space_low_gb"]
    disk_space_low_gb = max(1, min(1024, disk_space_low_gb))

    return {
        "dedupe_seconds": dedupe_seconds,
        "disk_space_low_gb": disk_space_low_gb,
    }


def loadNotification():
    disk = readJsonSafe(NOTIFICATION_PATH, {})
    if not isinstance(disk, dict):
        disk = {}

    merged = {
        **DEFAULT_NOTIFICATION,
        **disk,
    }

    merged["telegram_enabled"] = bool(merged.get("telegram_enabled", False))
    merged["telegram_bot_token"] = str(merged.get("telegram_bot_token", "") or "")
    merged["telegram_chat_id"] = str(merged.get("telegram_chat_id", "") or "")

    merged["discord_enabled"] = bool(merged.get("discord_enabled", False))
    merged["discord_webhook_url"] = str(merged.get("discord_webhook_url", "") or "")

    merged["events"] = _cleanNotificationEvents(disk.get("events"))
    merged["limits"] = _cleanNotificationLimits(disk.get("limits"))

    return merged


def saveNotification(data):
    with _json_write_lock:
        disk = loadNotification()
        incoming = data if isinstance(data, dict) else {}

        merged = {
            **disk,
            **incoming,
        }

        merged["telegram_enabled"] = bool(merged.get("telegram_enabled", False))
        merged["telegram_bot_token"] = str(merged.get("telegram_bot_token", "") or "").strip()
        merged["telegram_chat_id"] = str(merged.get("telegram_chat_id", "") or "").strip()

        merged["discord_enabled"] = bool(merged.get("discord_enabled", False))
        merged["discord_webhook_url"] = str(merged.get("discord_webhook_url", "") or "").strip()

        incoming_events = incoming.get("events") if isinstance(incoming.get("events"), dict) else {}
        merged["events"] = _cleanNotificationEvents({
            **disk.get("events", {}),
            **incoming_events,
        })

        incoming_limits = incoming.get("limits") if isinstance(incoming.get("limits"), dict) else {}
        merged["limits"] = _cleanNotificationLimits({
            **disk.get("limits", {}),
            **incoming_limits,
        })

        changed = writeJsonSafe(NOTIFICATION_PATH, merged)
        if changed:
            print("[DEBUG] notification.json 저장 완료")


def _notify_allowed(cfg: dict, event_type: str, channel_id: str = "") -> bool:
    events = cfg.get("events") if isinstance(cfg.get("events"), dict) else {}
    if not bool(events.get(event_type, False)):
        return False

    try:
        dedupe = int((cfg.get("limits") or {}).get("dedupe_seconds", 300) or 300)
    except Exception:
        dedupe = 300

    key = f"{event_type}:{channel_id or '-'}"
    now = time.time()
    last = float(_notify_last_sent.get(key, 0) or 0)
    if dedupe > 0 and now - last < dedupe:
        return False

    _notify_last_sent[key] = now
    return True


def _plain_text(text: str) -> str:
    return re.sub(r"<[^>]+>", "", str(text or ""))


def _sendTelegramMessage(cfg: dict, message: str) -> bool:
    if not cfg.get("telegram_enabled", False):
        return False

    token = (cfg.get("telegram_bot_token") or "").strip()
    chat_id = (cfg.get("telegram_chat_id") or "").strip()
    if not token or not chat_id:
        print("[NOTIFY][TELEGRAM][WARN] token/chat_id 비어 있음")
        return False

    try:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        r = requests.post(url, data={
            "chat_id": chat_id,
            "text": message,
            "parse_mode": "HTML",
        }, timeout=10)
        if r.status_code != 200:
            print(f"[NOTIFY][TELEGRAM][ERROR] HTTP {r.status_code}")
            return False
        return True
    except Exception as e:
        print(f"[NOTIFY][TELEGRAM][ERROR] {type(e).__name__}")
        return False


def _sendDiscordMessage(cfg: dict, message: str) -> bool:
    if not cfg.get("discord_enabled", False):
        return False

    webhook_url = (cfg.get("discord_webhook_url") or "").strip()
    if not webhook_url:
        print("[NOTIFY][DISCORD][WARN] webhook_url 비어 있음")
        return False

    try:
        r = requests.post(webhook_url, json={
            "content": _plain_text(message)
        }, timeout=10)
        if r.status_code not in (200, 204):
            print(f"[NOTIFY][DISCORD][ERROR] HTTP {r.status_code}")
            return False
        return True
    except Exception as e:
        print(f"[NOTIFY][DISCORD][ERROR] {type(e).__name__}")
        return False


def notifyEvent(event_type: str, title: str, message: str = "",
                channel_id: str = "", channel_name: str = "",
                detail: str = "", severity: str = "info",
                target: str = "", force: bool = False) -> bool:
    cfg = loadNotification()

    if not force and not _notify_allowed(cfg, event_type, channel_id):
        return False

    head = f"<b>{title}</b>"
    body = message or ""
    if channel_name:
        body = f"<b>{channel_name}</b>\n{body}"
    if detail:
        body = f"{body}\n<code>{detail}</code>"

    full = f"{head}\n{body}".strip()

    target = (target or "").strip().lower()

    sent = False
    if target in ("", "telegram"):
        sent = _sendTelegramMessage(cfg, full) or sent
    if target in ("", "discord"):
        sent = _sendDiscordMessage(cfg, full) or sent

    if sent:
        print(f"[NOTIFY] sent event={event_type} target={target or 'all'} channel={channel_name or channel_id}")

    return sent


def checkDiskSpaceLow(path: str, channel_id: str = "", channel_name: str = "") -> bool:
    cfg = loadNotification()
    try:
        limit_gb = float((cfg.get("limits") or {}).get("disk_space_low_gb", 10) or 10)
    except Exception:
        limit_gb = 10

    try:
        target = path or base_directory
        if os.path.isfile(target):
            target = os.path.dirname(target)
        usage = shutil.disk_usage(target)
        free_gb = usage.free / (1024 ** 3)
    except Exception as e:
        print(f"[DISK][WARN] 용량 확인 실패: {e}")
        return False

    if free_gb <= limit_gb:
        notifyEvent(
            event_type="disk_space_low",
            title="디스크 용량 부족",
            message=f"남은 용량이 {free_gb:.1f}GB 입니다. 기준값: {limit_gb:.1f}GB",
            channel_id=channel_id,
            channel_name=channel_name,
            severity="warning",
        )
        return True

    return False


# 파일명 중복 방지 함수
def uniqueFilename(output_dir, filename, add_suffix=True, *, reserved=None):
    output_dir_abs_path = os.path.abspath(output_dir)
    base, ext = os.path.splitext(filename)

    # suffix를 쓰지 않으면 그대로 반환
    if not add_suffix:
        return filename

    candidate = filename
    counter = 1

    while True:
        path = os.path.join(output_dir_abs_path, candidate)
        if not os.path.lexists(path) and (not reserved or os.path.normcase(os.path.realpath(path)) not in reserved):
            return candidate
        candidate = f"{base} ({counter}){ext}"
        counter += 1


# 후처리 후 파일 이동 함수
async def moveDirectory(file_path, destination_directory):
    validateMediaDirectory(destination_directory)
    loop = asyncio.get_running_loop()

    async with move_async_lock:
        def _do_move():
            try:
                if not os.path.exists(file_path):
                    print(f"[WARN] 원본 파일 {file_path}가 존재하지 않습니다. 이동 작업을 건너뜁니다.")
                    return

                if not os.path.exists(destination_directory):
                    os.makedirs(destination_directory)

                base_name = os.path.basename(file_path)
                name, ext = os.path.splitext(base_name)
                destination_path = os.path.join(destination_directory, base_name)

                counter = 1
                # 동일한 파일명이 존재하는지 확인하고, 존재하면 새로운 파일명 생성
                while os.path.exists(destination_path):
                    new_name = f"{name}({counter}){ext}"
                    destination_path = os.path.join(destination_directory, new_name)
                    counter += 1

                shutil.move(file_path, destination_path)
                print(f"파일 {file_path}가 {destination_path}로 이동되었습니다.")
                return destination_path
            except Exception as e:
                print(f"파일 {file_path}를 {destination_directory}로 이동하는 중 오류 발생: {e}")
                raise

        return await loop.run_in_executor(None, _do_move)


def validateMediaDirectory(path):
    if sys.platform == 'linux' and re.match(r'^(?:[A-Za-z]:|\\\\|//)', str(path)):
        raise ValueError('Windows 저장 경로입니다. 채널관리 또는 후처리 설정에서 Linux 경로로 변경하세요.')
    return path


class MediaDirectoryError(OSError):
    pass


def resolveMediaDirectory(path, *, root=None):
    path = os.fsdecode(path)
    if os.name == "nt":
        # Windows Explorer's "Copy as path" includes double quotes.
        path = path.strip()
        if len(path) >= 2 and path.startswith('"') and path.endswith('"'):
            path = path[1:-1]
        drive, _ = os.path.splitdrive(path)
        if drive and not os.path.isabs(path):
            raise ValueError("드라이브 문자 뒤에 \\를 붙여 전체 경로를 입력하세요.")
    if not path.strip():
        raise ValueError("폴더 경로를 입력하세요.")
    validateMediaDirectory(path)
    return os.path.abspath(os.path.join(root, path) if root is not None else path)


def prepareMediaDirectory(path, *, root=None, label="저장"):
    directory = path
    try:
        directory = resolveMediaDirectory(path, root=root)
        os.makedirs(directory, exist_ok=True)
    except (OSError, ValueError, TypeError) as exc:
        raise MediaDirectoryError(f"{label} 폴더를 준비할 수 없습니다. {directory} ({exc})") from exc
    return directory


# ffmpeg 경로를 가져오는 함수
def _get_tool(name, label, log_key=None):
    if os.name == "nt":
        path = os.path.join(base_directory, BUNDLED_TOOL_PATHS[name])
    else:
        path = shutil.which(name)
    key = log_key or name
    if path and os.path.exists(path):
        printOnce(f"dep:{key}:ok", f"[INFO] {label}가 '{path}' 경로에 있습니다.")
        return path
    guidance = "auto_install로 deno를 설치하거나 PATH를 확인해 주세요." if name == "deno" else "설치 후 PATH가 올바른지 확인해 주세요."
    printOnce(f"dep:{key}:err", f"[ERROR] {label}를 찾을 수 없습니다. {guidance}")
    raise FileNotFoundError("필수 실행 파일이 없습니다. 환경 점검과 의존성 복구를 실행하세요.")


def getFFmpeg():
    return _get_tool("ffmpeg", "FFmpeg")


def getFFprobe():
    return _get_tool("ffprobe", "FFprobe")


def getStreamlink():
    return _get_tool("streamlink", "Streamlink")


def getYtDlp():
    return _get_tool("yt-dlp", "yt-dlp", "ytdlp")


def getAria2c():
    return _get_tool("aria2c", "Aria2c")


def getDeno():
    return _get_tool("deno", "deno")


def resolveFFprobe(ffmpeg_path):
    """Find the probe paired with a specific FFmpeg, with a PATH fallback."""
    if ffmpeg_path:
        directory = os.path.dirname(ffmpeg_path)
        names = ("ffprobe.exe", "ffprobe") if os.name == "nt" else ("ffprobe", "ffprobe.exe")
        for name in names:
            path = os.path.join(directory, name)
            if os.path.exists(path):
                return path
    return shutil.which("ffprobe") or "ffprobe"
