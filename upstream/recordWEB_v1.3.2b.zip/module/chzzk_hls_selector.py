"""Streamlink selectors for Chzzk HLS streams."""

import math
import re
from urllib.parse import urljoin


def normalize_video_codec(value):
    name = str(value or "").strip().lower().split(".", 1)[0]
    if name in ("hevc", "h265", "hev1", "hvc1"):
        return "HEVC"
    if name in ("h264", "avc", "avc1", "avc3"):
        return "H264"
    return None


def selected_manifest_codec(text, master_url, stream_url):
    """Use CODECS for the selected media playlist, regardless of variant naming."""
    codecs = set()
    pending = None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#EXT-X-STREAM-INF:"):
            pending = line
        elif line and not line.startswith("#") and pending is not None:
            if urljoin(master_url, line) == stream_url:
                attr = re.search(r'(?:^|[:,])CODECS="([^"]+)"', pending)
                video = set()
                if attr:
                    video = {normalize_video_codec(token) for token in attr[1].split(",")} - {None}
                codecs.add(next(iter(video)) if len(video) == 1 else None)
            pending = None
    return next(iter(codecs)) if len(codecs) == 1 else None


def hls_resolution_selector(quality: str, frame_rate=None) -> str:
    # A name returned by Streamlink, such as 720p60 or 720p_alt, is exact.
    if not re.fullmatch(r"\d+p", quality):
        return quality

    names = []
    try:
        fps = float(frame_rate)
        if fps > 30:
            names.append(f"{quality}{math.ceil(fps)}")
    except (TypeError, ValueError, OverflowError):
        pass
    # Some Chzzk metadata omits FPS even when the playlist provides it.
    names.extend((quality, f"{quality}60", f"{quality}50"))
    return ",".join(dict.fromkeys(names))
