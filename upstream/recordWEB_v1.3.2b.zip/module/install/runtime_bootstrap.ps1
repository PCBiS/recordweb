﻿# recordWEB-owned CPython only. No registry, PATH, launcher or file association changes.
function Get-BootstrapSha256([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $hash = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $hash.Dispose() }
}
function Test-OwnedPython([string]$Directory) {
    $exe = Join-Path $Directory 'python.exe'
    if (-not (Test-Path -LiteralPath $exe)) { return $false }
    try {
        & $exe -I -c "import sys,ssl,ctypes,json,zipfile,venv,ensurepip; assert sys.version_info[:3] == (3,14,10)" 2>$null
        return $LASTEXITCODE -eq 0
    } catch { return $false }
}

function Get-OwnedPython([string]$Root, [switch]$ReadOnly, [switch]$PreserveBackup) {
    if (-not [Environment]::Is64BitOperatingSystem -or [Environment]::OSVersion.Version.Major -lt 10) {
        throw 'recordWEB 1.3.2b requires Windows 10/11 64-bit.'
    }
    $runtimeRoot = Join-Path $Root 'runtime'
    $active = Join-Path $runtimeRoot 'python'
    if (Test-OwnedPython $active) { return (Join-Path $active 'python.exe') }
    if ($ReadOnly) { throw 'recordWEB runtime missing or damaged. Run recordWEB.bat to prepare it automatically.' }
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'recordWEB requires 64-bit Windows.' }
    New-Item -ItemType Directory -Path $runtimeRoot -Force | Out-Null
    $id = [Guid]::NewGuid().ToString('N')
    $stage = Join-Path $runtimeRoot ('python.new-' + $id)
    $backup = Join-Path $runtimeRoot ('python.backup-' + $id)
    $zip = Join-Path $runtimeRoot ('python.download-' + $id + '.zip')
    $extract = Join-Path $runtimeRoot ('python.extract-' + $id)
    $hadActive = Test-Path -LiteralPath $active
    $movedOld = $false
    $activated = $false
    try {
        # Official PSF NuGet CPython distribution includes venv and ensurepip.
        $url = 'https://api.nuget.org/v3-flatcontainer/python/3.14.10/python.3.14.10.nupkg'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Write-Host 'Preparing recordWEB Python 3.14.10 (official PSF package)...'
        Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $zip -TimeoutSec 180
        $expected = 'f54ba67c9951c3d773ea47d2bb095150c037c399f0423a968bcda22809241784'
        if ((Get-BootstrapSha256 $zip) -ne $expected) { throw 'Python package SHA256 mismatch' }
        Expand-Archive -LiteralPath $zip -DestinationPath $extract
        Move-Item -LiteralPath (Join-Path $extract 'tools') -Destination $stage
        if (-not (Test-OwnedPython $stage)) { throw 'Staged Python version or standard-library validation failed' }
        if ($hadActive) {
            Move-Item -LiteralPath $active -Destination $backup
            $movedOld = $true
        }
        Move-Item -LiteralPath $stage -Destination $active
        $activated = $true
        if (-not (Test-OwnedPython $active)) { throw 'Activated Python validation failed' }
        if ($movedOld) {
            if ($PreserveBackup) { $script:OwnedRuntimeBackup = $backup; $script:OwnedRuntimeActive = $active }
            else { Remove-BootstrapTemporary $backup }
        }
        return (Join-Path $active 'python.exe')
    } catch {
        $failure = $_
        if ($activated) { Remove-BootstrapTemporary $active }
        if ($movedOld) {
            if (Test-Path -LiteralPath $active) { throw "Runtime rollback blocked. Original backup: $backup. Cause: $failure" }
            Move-Item -LiteralPath $backup -Destination $active -ErrorAction Stop
        }
        throw "recordWEB Python preparation failed: $failure"
    } finally {
        foreach ($temporary in @($zip, $stage, $extract)) { Remove-BootstrapTemporary $temporary }
    }
}

function Remove-BootstrapTemporary([string]$Path) {
    if (Test-Path -LiteralPath $Path) {
        try { Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop }
        catch { Write-Warning "Temporary cleanup failed: $Path ($($_.Exception.Message))" }
    }
}

function Test-OwnedVenv([string]$Root, [switch]$Headless) {
    $exe = Join-Path $Root '.venv\Scripts\python.exe'
    $base = Join-Path $Root 'runtime\python'
    if (-not (Test-Path -LiteralPath $exe)) { return $false }
    # A legacy venv may redirect into another application's Python. Inspect it
    # before executing its redirector, not after.
    $config = Join-Path $Root '.venv\pyvenv.cfg'
    if (-not (Test-Path -LiteralPath $config)) { return $false }
    $homeLine = Get-Content -LiteralPath $config | Where-Object { $_ -match '^home\s*=' } | Select-Object -First 1
    if (-not $homeLine) { return $false }
    $homePath = ($homeLine -split '=', 2)[1].Trim()
    if ([IO.Path]::GetFullPath($homePath).TrimEnd('\') -ine [IO.Path]::GetFullPath($base).TrimEnd('\')) { return $false }
    try {
        $imports = 'sys,os,fastapi,uvicorn,aiohttp,jinja2,requests,cryptography,httpx,psutil,itsdangerous,werkzeug,python_multipart'
        if (-not $Headless) { $imports += ',webview,pystray,PIL,PyQt6.QtCore,PyQt6.QtWidgets' }
        & $exe -I -c "import $imports; assert sys.version_info[:3] == (3,14,10); assert os.path.normcase(os.path.realpath(sys.base_prefix)) == os.path.normcase(os.path.realpath(sys.argv[1]))" $base 2>$null
        return $LASTEXITCODE -eq 0
    } catch { return $false }
}
