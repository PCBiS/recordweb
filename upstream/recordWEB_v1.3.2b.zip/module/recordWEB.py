import subprocess
import os
import time
import traceback
import json
import logging
import sys
import asyncio
import platform
import threading
import re
import string
import shutil
import secrets
if __name__ == '__main__' and '--backend' not in sys.argv:
    print('recordWEB.bat으로 실행하세요. 이 파일은 내부 백엔드입니다.')
    raise SystemExit(0 if '--help' in sys.argv else 20)
from datetime import datetime
from typing import Optional, Any, List, Dict, Literal

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding='utf-8')

if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from module.runtime_log import (
    normalize_diagnostic_log_days, recordException, set_diagnostic_log_days, setupAppLogging,
    start_diagnostic_log_cleanup,
)

if __name__ == "__main__":
    setupAppLogging("web")

import uvicorn
import requests
import httpx
import psutil


try:
    import cpuinfo
except ImportError:
    cpuinfo = None

from fastapi import FastAPI, Request, Form, HTTPException, BackgroundTasks, Depends, Body, Query, APIRouter
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse, FileResponse, Response
from fastapi.exceptions import RequestValidationError
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from werkzeug.security import generate_password_hash, check_password_hash
from contextlib import asynccontextmanager, contextmanager, suppress

from module.data_manager import (
    RecorderManager, deleteAccount, loadAccount, saveAccount, loadCookies, updatePlatformCookies,
    getCimeCookies,
    loadChannels, loadConfig, saveConfig, getConfigLoadStatus, parseRecordingMetadataRefreshInterval,
    saveNotification, loadNotification, notifyEvent, last_notified_state,
    toBool,
    PROGRAM_NAME, PROGRAM_VERSION, WEB_UI_TITLE
)

from module.meta_cache import (
    ensure as mc_ensure, refreshLoop as mc_refreshLoop, 
    getDisplayCache, getMetadataCached, getThumbnailsCached
)

from module.file_manager import (
    childPath,
    buildAllowedRoots, ensureInRoots, listDir, diskUsageFor, listDisks,
    softDelete, hardDelete, movePath, renamePath, mkdirPath,
    busyFilePaths, deepestAllowedRoot, isLocked, normalizeConfiguredRoots, streamCopyFile
)

from module.recording_adapter import fetchMetadata, startSession
from module.recording_state import recording_page_fields, snapshot as recording_snapshot
from module.channel_fsm import ChannelFsm
from module.cookie_checker import checkChzzkCookie, checkCimeCookie
from module.tray_control import TrayControl
tray_control = TrayControl()
from module.run_mode import resolve_run_mode
from module.cime_recorder import getCimeMetadata
from module.runtime_guard import RuntimeGuard, RuntimeAlreadyRunning
from module.config_validator import checkRequiredPaths, validateRuntimeEnvironment
from module.server_port import ensure_port_available, legacy_port_warning, parse_port

# 현재 파일의 경로
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 정적 파일 경로와 템플릿 디렉토리 설정
static_directory = os.path.join(BASE_DIR, "templates", "static")
from module.runtime_identity import process_identity, freeze_ui
RUNTIME_IDENTITY = process_identity(BASE_DIR, PROGRAM_VERSION)
_runtime_guard = None
templates_directory = str(freeze_ui(BASE_DIR, RUNTIME_IDENTITY['build']))
static_directory = os.path.join(templates_directory, 'static')
templates = Jinja2Templates(directory=templates_directory)
templates.env.globals.update(
    program_name=PROGRAM_NAME,
    program_version=PROGRAM_VERSION,
    web_ui_title=WEB_UI_TITLE,
    runtime_build=RUNTIME_IDENTITY['build'],
    config_load_status=getConfigLoadStatus,
)

# Starlette/FastAPI 최신 버전 TemplateResponse 호출 호환 패치
def patchTemplateResponseCompat(templates_obj):
    original_template_response = templates_obj.TemplateResponse

    def compatibleTemplateResponse(*args, **kwargs):
        if len(args) >= 2 and isinstance(args[0], str) and isinstance(args[1], dict):
            template_name = args[0]
            context = args[1]
            request = context.get('request')
            if request is not None:
                return original_template_response(request, template_name, context, *args[2:], **kwargs)

        return original_template_response(*args, **kwargs)

    templates_obj.TemplateResponse = compatibleTemplateResponse

patchTemplateResponseCompat(templates)

# data_manager.py의 RecorderManager 클래스 인스턴스 생성
recorder_manager = RecorderManager()

# CPU 명칭 조회
_CPU_NAME = None


# 애플리케이션 생애주기 핸들러
@asynccontextmanager
async def lifespan(app: FastAPI):
    from module.performance import watch_loop
    stop_loop_watch = watch_loop(asyncio.get_running_loop())
    from module.process_lifecycle import resume, shutdown
    resume()
    app.state.channels = loadChannels()
    app.state.fsm = ChannelFsm()
    app.state.channels_lock = asyncio.Lock()
    app.state.settings_write_lock = asyncio.Lock()
    app.state.config = loadConfig()
    if sys.platform == 'linux':
        from module.data_manager import validateMediaDirectory
        paths = [('채널 녹화 경로', channel.get('output_dir')) for channel in app.state.channels]
        if app.state.config.get('moveAfterProcessingEnabled'):
            paths.append(('후처리 이동 경로', app.state.config.get('moveAfterProcessing')))
        for label, path in paths:
            try:
                validateMediaDirectory(path)
            except ValueError as error:
                print(f'[WARN] {label}: {error}')
    app.state.run_mode = resolve_run_mode(app.state.config)
    if sys.platform == 'linux' and not os.environ.get('RWEB_LINUX_GUI'):
        app.state.run_mode = 'headless'
    app.state.cookies = loadCookies()
    app.state.bg_tasks = set()
    async def tray_start():
        return await startRecordingForAllChannels(app, is_user_request=True)
    async def tray_stop():
        return await app.state.fsm.stopAll()
    async def tray_quit():
        app.state.server.should_exit = True
    tray_control.bind(asyncio.get_running_loop(), start=tray_start, stop=tray_stop, quit=tray_quit)

    print("[INFO] 채널 데이터 보정 적용 완료.")

    RecorderManager.setChannels(app.state.channels)
    RecorderManager.setChannelsRef(app.state.channels)
    RecorderManager.setChannelsLockRef(app.state.channels_lock)

    meta_task = None

    try:
        from module.postprocess_store import recover_interrupted
        try:
            await asyncio.to_thread(recover_interrupted)
        except OSError as exc:
            print(f"[ERROR] 후처리 복구 저장소 확인 실패 ({exc}) 녹화 감시는 계속합니다.")
        await initChannelStates(app)

        app.state.meta_fetcher = _makeMetaFetcher(app)
        app.state.save_debounced = DebouncedSaver(app, delay=1.2)
        mc_ensure(app)

        meta_task = asyncio.create_task(
            mc_refreshLoop(app, app.state.meta_fetcher, app.state.save_debounced, app.state.channels_lock)
        )

        # 부팅시 한 번만 자동 시작 (Auto ON일 때)
        if app.state.config.get("autoRecordingMode", False):
            print("[DEBUG] 자동 녹화 모드: 부팅시 한 번만 WATCHING 진입")
            await app.state.fsm.startAllWatching()

        from module.tool_usage import monitor, write_snapshot
        await asyncio.to_thread(write_snapshot, BASE_DIR)
        usage_task = asyncio.create_task(monitor(BASE_DIR))
        app.state.bg_tasks.add(usage_task)
        usage_task.add_done_callback(app.state.bg_tasks.discard)
        yield

    finally:
        stop_loop_watch()
        tray_control.close()
        tray_process = getattr(app.state, 'linux_tray_process', None)
        if tray_process is not None:
            with suppress(ProcessLookupError):
                tray_process.terminate()
        icon = getattr(app.state, 'tray_icon', None)
        if icon is not None:
            with suppress(Exception):
                icon.stop()

        # 메타 루프 정리
        if meta_task and not meta_task.done():
            meta_task.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await meta_task

        pending_meta = list(getattr(app.state, 'meta_tasks', set()))
        for task in pending_meta:
            task.cancel()
        if pending_meta:
            await asyncio.gather(*pending_meta, return_exceptions=True)

        # 백그라운드 태스크 모두 취소/대기
        try:
            pending = list(app.state.bg_tasks)
            for t in pending:
                t.cancel()
            for t in pending:
                with suppress(asyncio.CancelledError, Exception):
                    await t
        except Exception as e:
            print(f"[WARN] bg_tasks cleanup error: {e}")

        with suppress(Exception):
            await app.state.fsm.stopAll()
        with suppress(Exception):
            await shutdown()
        with suppress(Exception):
            from module.live_recorder import shutdownPostprocessTasks
            await shutdownPostprocessTasks()

        # 종료 직전 채널 저장 강제 플러시
        try:
            if hasattr(app.state, "save_debounced") and app.state.save_debounced:
                await app.state.save_debounced.flush()
        except Exception as e:
            print(f"[WARN] save_debounced.flush failed: {e}")

        # httpx AsyncClient 정리 
        try:
            from module.live_recorder import closeHttpxClient
            await closeHttpxClient()
        except Exception as e:
            print(f"[WARN] closeHttpxClient 실패(무시): {e}")


app = FastAPI(lifespan=lifespan)
from module.performance import install as install_performance
install_performance(app)
from module.access_control import LOOPBACK, allowed_host, interface_ipv4_addresses, interface_ipv4_display, validate_network

@app.middleware('http')
async def remote_access_gate(request: Request, call_next):
    config = getattr(request.app.state, 'config', {})
    host = request.client.host if request.client else ''
    bound_remote = getattr(request.app.state, 'bound_remote', False)
    actual_port = getattr(request.app.state, 'actual_port', None)
    authority = request.headers.get('host', '')
    local_authority = actual_port is None or allowed_host(authority, actual_port, False)
    if actual_port is not None and (
        len(request.headers.getlist('host')) != 1
        or not (local_authority or allowed_host(authority, actual_port, bound_remote))
    ):
        return JSONResponse({'detail': '허용되지 않는 접속 주소입니다.'}, status_code=400)
    if host not in LOOPBACK or not local_authority:
        if (not config.get('remoteAccessEnabled') or not bound_remote
                or not (await asyncio.to_thread(loadConfig)).get('remoteAccessEnabled')):
            return JSONResponse({'detail':'원격 접속이 비활성화되어 있습니다.'}, status_code=403)
    if request.method not in ('GET', 'HEAD', 'OPTIONS'):
        origins = request.headers.getlist('origin')
        site = request.headers.get('sec-fetch-site')
        expected_origin = f'{request.url.scheme}://{authority.lower()}'
        if (origins and origins != [expected_origin]) or (
            site is not None and site != 'same-origin'
        ) or (not origins and host not in LOOPBACK):
            return JSONResponse({'detail': '다른 사이트의 변경 요청은 허용하지 않습니다.'}, status_code=403)
    return await call_next(request)


if os.path.isdir(static_directory):
    app.mount("/static", StaticFiles(directory=static_directory), name="static")
else:
    print(f"[WARN] Static dir not found: {static_directory}")


# 전역 락 선언
thread_lock = threading.Lock()  # 동기 함수에서 사용할 락


# 메타데이터 가져오는 fetcher를 app에 바인딩하기 위한 팩토리
def _makeMetaFetcher(app: FastAPI):
    async def _fetch(channel: dict):
        platform = (channel.get('platform') or '').lower()
        return await fetchMetadata(channel, platform)
    return _fetch


# 세션을 사용하기 위한 미들웨어
account_data = loadAccount()
if account_data and 'secret_key' in account_data:
    session_secret = account_data['secret_key']
    app.add_middleware(SessionMiddleware, secret_key=account_data['secret_key'],
                       session_cookie="recordweb_session", same_site="lax", https_only=False, max_age=86400)
else:
    # secret_key가 없으면 기본적으로 생성
    new_secret_key = secrets.token_hex(32)
    session_secret = new_secret_key
    saveAccount({'secret_key': new_secret_key})
    app.add_middleware(SessionMiddleware, secret_key=new_secret_key,
                       session_cookie="recordweb_session", same_site="lax", https_only=False, max_age=86400)


# 예외 처리기 정의
@app.exception_handler(PermissionError)
async def path_permission_handler(request: Request, exc: PermissionError):
    return JSONResponse({'detail': '허용된 파일 경로를 확인하세요.'}, status_code=403)


@app.exception_handler(RequestValidationError)
async def request_validation_handler(request: Request, exc: RequestValidationError):
    return JSONResponse({'detail': '요청의 입력값을 확인하세요.'}, status_code=422)


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    if request.method == "GET" and request.url.path in ("/files", "/backup") and exc.status_code in (401, 403):
        return templates.TemplateResponse("access_notice.html", {
            "request": request,
            "title": "파일관리" if request.url.path == "/files" else "백업관리",
            "message": exc.detail,
        }, status_code=exc.status_code, headers={"Cache-Control": "no-store"})
    else:
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
            headers=exc.headers,
        )


# 채널 상태 초기화 함수
async def initChannelStates(app: FastAPI):
    try:
        print("[DEBUG] initChannelStates 시작")
        async with app.state.channels_lock:
            for channel in app.state.channels:
                channel.setdefault('status', '대기 중')
                channel.setdefault('record_enabled', True)
                channel.setdefault('live_title', "불러오는 중...")
                channel.setdefault('category', "불러오는 중...")
                channel.setdefault('thumbnail_url', (
                    '/static/img/cimeclosed_thumbnail.png' if (channel.get('platform') or '').lower() == 'cime'
                    else '/static/img/default_thumbnail.png'
                ))
        print("[DEBUG] initChannelStates 완료")
    except Exception as e:
        print(f"[ERROR] initChannelStates 중 오류 발생: {e}")
        raise


# 로그인 인증 의존성 함수 정의
def account_revision(account):
    import hmac
    return hmac.digest(session_secret.encode(), account['password'].encode(), 'sha256').hex()


def account_session(request, account):
    revision = request.session.get('account_revision', '')
    return bool(account and account.get('password') and revision
                and secrets.compare_digest(revision, account_revision(account)))


def require_account(request: Request):
    if not account_session(request, loadAccount()):
        raise HTTPException(401, "로그인이 필요합니다.")


def require_file_access(request: Request):
    if not request.app.state.config.get('fileManagerEnabled', False):
        raise HTTPException(403, "파일관리 기능이 꺼져 있습니다. 설정관리에서 파일관리를 활성화해 주세요.")
    account = loadAccount() or {}
    if not account.get("password"):
        raise HTTPException(403, "파일관리를 사용하려면 설정관리에서 로그인 계정을 먼저 만들어 주세요.")
    if not account_session(request, account):
        raise HTTPException(401, "현재 로그인 상태가 아니므로 파일관리를 사용할 수 없습니다. 로그인해 주세요.")


def is_local_client(request: Request):
    port = getattr(request.app.state, 'actual_port', None)
    return bool(request.client and request.client.host in LOOPBACK
                and (port is None or allowed_host(request.headers.get('host', ''), port, False)))


def requireLocalClient(request: Request):
    if not is_local_client(request):
        raise HTTPException(403, "로컬 데스크톱에서만 사용할 수 있습니다.")
    return True


def require_backup_access(request: Request):
    requireLocalClient(request)
    account = loadAccount() or {}
    if account.get("password") and not account_session(request, account):
        raise HTTPException(401, "쿠키가 포함된 백업을 관리하려면 먼저 로그인해 주세요.")


def protected_config(request, current, candidate):
    if is_local_client(request):
        return
    for key in (
        'fileManagerRoots', 'fileManagerEnabled', 'fileManagerReadOnly', 'trashEnabled',
        'extra_ffmpeg_options', 'extra_ffmpeg_options_gpu1', 'runAtWindowsStartup',
        'filenamePattern', 'moveAfterProcessing', 'moveAfterProcessingEnabled',
        'video_codec', 'video_codec_gpu1', 'audio_codec', 'audio_codec_gpu1',
        'preset', 'preset_gpu1', 'postprocess_resolution', 'postprocess_resolution_gpu1',
    ):
        if key in candidate and candidate[key] != current.get(key):
            raise HTTPException(403, '파일매니저 권한, 시작프로그램 및 FFmpeg 추가 옵션은 서버 PC에서 변경하세요.')


@app.get("/api/runtime/ping")
async def runtime_ping(request: Request, local: Any = Depends(requireLocalClient)):
    actual_port = getattr(request.app.state, 'actual_port', request.url.port or loadConfig().get('port', 5000))
    return {
        **RUNTIME_IDENTITY,
        "port": int(actual_port),
        "run_mode": getattr(request.app.state, "run_mode", "normal"),
    }


@app.get("/api/config/status")
async def config_status():
    await asyncio.to_thread(loadConfig)
    return {"state": getConfigLoadStatus()}


@app.post("/api/runtime/quit")
async def runtime_quit(request: Request, local: Any = Depends(requireLocalClient)):
    active = []
    manager = RecorderManager()
    for channel in request.app.state.channels:
        cid = channel.get("id", "")
        if manager.get_status_recording(cid) or manager.get_status_reserved(cid):
            active.append(cid)
    body = await request.json()
    if active and not bool(body.get("confirm")):
        raise HTTPException(409, {"message": "감시·녹화 작업이 실행 중입니다.", "active_count": len(active)})
    request.app.state.server.should_exit = True
    return {"status": "종료 요청됨", "active_count": len(active)}


# 자동 녹화 모드 함수
async def autoRecording(app: FastAPI):
    cfg = app.state.config
    if app.state.config.get("autoRecordingMode", False):
        print("[DEBUG] 자동 녹화 모드 활성화 → 모든 채널 WATCHING 진입")
        asyncio.create_task(app.state.fsm.startAllWatching())
    else:
        print("[DEBUG] 자동 녹화 모드가 비활성화되어 있습니다.")


# 특정 채널의 녹화를 시작하는 함수
async def startRecordingForChannel(app, channel_id: str, is_user_request: bool = False):
    async with app.state.channels_lock:
        channels = list(app.state.channels)
    ch = next((c for c in channels if c.get("id") == channel_id), None)
    if not ch:
        return {"status": "error", "message": "unknown channel"}

    try:
        await app.state.fsm.userStart(channel_id, is_user_request=is_user_request)

        return recording_snapshot(recorder_manager, app.state.fsm, ch)
    except Exception as e:
        return {"status": "error", "message": str(e)}



# 특정 채널의 녹화를 중지하는 함수
async def stopRecordingForChannel(app: FastAPI, channel_id: str):
    try:
        return await app.state.fsm.userStop(channel_id)

    except Exception as e:
        print(f"[WARN] stopRecordingForChannel failed for {channel_id}: {e}")
        raise


# 모두 녹화하기 함수
async def startRecordingForAllChannels(app, is_user_request: bool=False):
    async with app.state.channels_lock:
        channels = [dict(c) for c in app.state.channels]

    results = {}
    tasks = []
    for ch in channels:
        cid = ch.get("id")
        if not cid or not bool(ch.get("record_enabled", True)):
            continue
        tasks.append(asyncio.create_task(app.state.fsm.userStart(cid)))
        # 일단 자리만 만들어 두고 나중에 실제 상태로 교정
        results[cid] = {"state": "예약녹화 중", "recording_duration": ""}

    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)

    # 실제 상태로 정정: 녹화 > 예약 > 대기
    for cid in list(results.keys()):
        st  = recorder_manager.get_status_recording(cid)
        rsv = recorder_manager.get_status_reserved(cid)
        fsm = app.state.fsm.getState(cid)
        eff = bool(rsv or (fsm == "WATCHING"))
        results[cid]["state"] = "녹화 중" if st else ("예약녹화 중" if eff else "대기 중")

    return results


# 모든 플랫폼 동시에 모두 녹화 중지하기 함수
async def stopRecordingForAllChannels(app: FastAPI):
    await app.state.fsm.stopAll()
    print("[DEBUG] FSM에게 일괄 STOPPED 전이를 요청했습니다.")



# IP 주소를 가져오는 함수
def getAddresses():
    with thread_lock:  # 전역 락 사용
        internal_ip = "127.0.0.1"
        local_ip = None
        external_ip = None

        if os.name == 'nt':
            # Windows: ipconfig 사용
            try:
                result = subprocess.run(['ipconfig'], capture_output=True, text=True, encoding='cp949')
                ip_address_match = re.search(r'IPv4 주소[^:]*:\s*([\d.]+)', result.stdout)
                if ip_address_match:
                    local_ip = ip_address_match.group(1)
                else:
                    local_ip = "내부 사설 IP 주소를 찾을 수 없습니다."
            except Exception as e:
                local_ip = f"내부 사설 IP 주소를 가져오는 중 오류 발생: {e}"
        else:
            # Linux: ip addr show 사용
            try:
                result = subprocess.run(['ip', 'addr', 'show'], capture_output=True, text=True)
                # 일반적으로 127.0.0.1은 제외하고 첫번째 inet 주소 사용
                ip_address_match = re.search(r'\s+inet\s+(\d+\.\d+\.\d+\.\d+)/', result.stdout)
                if ip_address_match:
                    local_ip = ip_address_match.group(1)
                else:
                    local_ip = "내부 사설 IP 주소를 찾을 수 없습니다."
            except Exception as e:
                local_ip = f"내부 사설 IP 주소를 가져오는 중 오류 발생: {e}"

        try:
            # 외부 공인 IP 주소 가져오기 (httpbin 사용)
            response = requests.get('https://httpbin.org/ip', timeout=5)
            if response.status_code == 200:
                external_ip = response.json()["origin"]
            else:
                external_ip = "공인 IP 주소를 가져오는 데 실패했습니다."
        except Exception as e:
            external_ip = f"공인 IP 주소를 가져오는 중 오류 발생: {e}"

        return internal_ip, local_ip, external_ip


# CPU 모델명 문자열을 반환 함수
def _getCpuName():
    global _CPU_NAME
    if _CPU_NAME:
        return _CPU_NAME

    name = None

    # 1) py-cpuinfo 우선
    try:
        if cpuinfo is not None:
            info = cpuinfo.get_cpu_info() or {}
            name = info.get('brand_raw') or info.get('brand')  # brand_raw 없을 수 있음
    except Exception:
        name = None

    # 2) Linux 전용 간단 폴백(/proc/cpuinfo)
    if not name:
        try:
            if os.path.exists("/proc/cpuinfo"):
                with open("/proc/cpuinfo", "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        if "model name" in line:
                            name = line.split(":", 1)[1].strip()
                            break
        except Exception:
            pass

    # 3) 최후의 폴백
    if not name:
        name = platform.processor() or platform.machine() or "Unknown CPU"

    _CPU_NAME = name
    return _CPU_NAME

# 전역 표시용(1회 평가 후 캐시)
cpu_name = _getCpuName()

# 시스템 모니터링은 짧은 주기로 반복 호출되므로 측정 결과와 디스크 목록을 재사용합니다.
_SYS_METRICS_LOCK = threading.Lock()
_SYS_METRICS_CACHE = {"at": 0.0, "data": None}
_SYS_METRICS_CACHE_TTL = 2.5
psutil.cpu_percent(interval=None)


from module.metrics_cache import MetricsCache, collect_disks
_SYS_DISKS = MetricsCache(collect_disks, ttl=30)


def _collectSysMetrics() -> dict:
    now = time.monotonic()
    with _SYS_METRICS_LOCK:
        cached = _SYS_METRICS_CACHE.get("data")
        if cached is not None and now - float(_SYS_METRICS_CACHE.get("at") or 0.0) < _SYS_METRICS_CACHE_TTL:
            return cached

        cpu_pct = float(psutil.cpu_percent(interval=None))
        vm = psutil.virtual_memory()

        disk_snapshot = _SYS_DISKS.snapshot()

        data = {
            "cpu": {
                "name": cpu_name,
                "percent": cpu_pct,
                "cores": psutil.cpu_count(logical=True),
            },
            "memory": {
                "total": int(vm.total),
                "used": int(vm.used),
                "free": int(vm.available),
                "percent": float(vm.percent),
            },
            **disk_snapshot,
            "sampled_at": time.time(),
        }
        _SYS_METRICS_CACHE["at"] = now
        _SYS_METRICS_CACHE["data"] = data
        return data


# Persistence helpers: 저장 디바운스/비동기 I/O
from module.channel_service import (
    DebouncedSaver, apply_gpu_assignments, mutate_channel, toggle_record_enabled as toggle_channel_recording,
)


# WEB용 메타 시드 동시성 결정


# 녹화 현황 페이지
@app.get("/recording", response_class=HTMLResponse)
async def recording_page(request: Request):
    from module.channel_groups import load_groups, effective_group
    groups = await asyncio.to_thread(load_groups)
    async with request.app.state.channels_lock:
        chs = [dict(c) for c in request.app.state.channels]

    for channel in chs:
        channel['recording_group'] = effective_group(channel.get('recording_group', ''), groups)
        state = recording_snapshot(recorder_manager, request.app.state.fsm, channel)
        channel.update(recording_page_fields(state))
        cached = getattr(request.app.state, 'meta_cache', {}).get(channel['id'], {}).get('data') or {}
        for key in ('live_title', 'category', 'thumbnail_url', 'adult'):
            if cached.get(key) is not None:
                channel[key] = cached[key]
        channel.setdefault('live_title', '불러오는 중...')
        channel.setdefault('category', '불러오는 중...')
        channel.setdefault('thumbnail_url', '/static/img/cimeclosed_thumbnail.png' if channel.get('platform') == 'cime' else '/static/img/default_thumbnail.png')

    return templates.TemplateResponse('recording.html', {
        'recording_groups': groups,
        'request': request,
        'channels': chs,
        'program_version': PROGRAM_VERSION
    })



@app.get("/status")
async def get_status(request: Request):
    async with request.app.state.channels_lock:
        channels = list(request.app.state.channels)
    states = {}
    for ch in channels:
        cid = ch['id']
        state = recording_snapshot(recorder_manager, request.app.state.fsm, ch)
        if state['recording']:
            entry = await getDisplayCache(request.app, cid)
            if entry and entry.get('session') is not None:
                state['metadata_revision'] = entry['revision']
        states[cid] = state
    return states


@app.get("/api/check_status/{channel_id}")
async def api_check_status(request: Request, channel_id: str):
    async with request.app.state.channels_lock:
        channel = next((dict(ch) for ch in request.app.state.channels if ch['id'] == channel_id), None)
    if channel is None:
        raise HTTPException(404, "Channel not found")
    return recording_snapshot(recorder_manager, request.app.state.fsm, channel)


@app.get("/api/runtime/identity")
async def runtime_identity_public():
    return {key: RUNTIME_IDENTITY[key] for key in ('product', 'version', 'build')}


@app.get('/api/performance')
async def performance_snapshot():
    from module.performance import summary
    return summary()


@app.post('/api/performance/client')
async def performance_client(request: Request):
    import math
    from module.performance import pages
    body = await request.json()
    keys = ('cards','first_cards_ms','first_contentful_paint_ms','initial_thumbnails_ms','thumbnail_count','thumbnails_loaded')
    if not isinstance(body, dict) or any(not isinstance(body.get(k),(int,float)) or isinstance(body.get(k),bool)
            or not math.isfinite(body[k]) or not 0 <= body[k] <= 120000 for k in keys):
        raise HTTPException(400, 'Invalid measurement')
    pages.append({k:round(body[k],3) for k in keys})
    return {'ok':True}


# 치지직 및 씨미 메타데이터 통합 API
@app.post("/api/update_metadata/{channel_id}")
async def update_metadata(channel_id: str, request: Request):
    # 1) channel 스냅샷
    async with request.app.state.channels_lock:
        channel = next((c for c in request.app.state.channels if c['id'] == channel_id), None)
    if not channel:
        raise HTTPException(status_code=404, detail="Channel not found")

    platform = (channel.get('platform') or 'unknown').lower()

    # 2) 캐시-우선 응답 (stale면 백그라운드에서 자동 갱신)
    payload, from_cache, fresh = await getMetadataCached(
        request.app,
        channel_id,
        platform,
        request.app.state.meta_fetcher,
        request.app.state.save_debounced,
        request.app.state.channels_lock,
    )

    # 3) 필요 시 ISO 문자열 보정
    if payload and isinstance(payload, dict):
        dt = payload.get('scheduled_start_time_dt')
        if isinstance(dt, datetime):
            payload['scheduled_start_time_str'] = dt.isoformat()
            payload.pop('scheduled_start_time_dt', None)

    return JSONResponse(content={
        'status': 'success',
        'from_cache': from_cache,
        'fresh': fresh,
        'metadata': {key: payload[key] for key in (
            'live_title', 'category', 'status', 'is_live', 'adult', 'scheduled_start_time_str'
        ) if payload and key in payload}
    })


# 썸네일 상태갱신 API
@app.get("/api/thumbnail_status")
async def api_thumbnail_status(request: Request):
    # 캐시-우선 썸네일 목록 (stale이면 백그라운드 갱신 트리거)
    async with request.app.state.channels_lock:
        chs = list(request.app.state.channels)
    items = await getThumbnailsCached(
        request.app, chs, request.app.state.meta_fetcher, request.app.state.save_debounced, request.app.state.channels_lock
    )

    try:
        for it in items:
            cid = str(it.get("id") or "")
            p   = (it.get("platform") or "").lower()

    except Exception:
        pass

    return JSONResponse(content={'channels': items})


# 개별 녹화시작 API 함수
@app.post("/api/start_recording/{channel_id}")
async def api_start_recording(channel_id: str, request: Request):
    try:
        body = await request.json()
    except ValueError:
        body = {}
    result = await startRecordingForChannel(request.app, channel_id, is_user_request=bool(body.get('is_user_request', False)))
    if result.get('status') == 'error':
        raise HTTPException(400, result.get('message', '시작 요청 실패'))
    return result


@app.post("/api/stop_recording/{channel_id}")
async def api_stop_recording(channel_id: str, request: Request):
    async with request.app.state.channels_lock:
        channel = next((dict(ch) for ch in request.app.state.channels if ch['id'] == channel_id), None)
    if channel is None:
        raise HTTPException(404, 'Channel not found')
    await stopRecordingForChannel(request.app, channel_id)
    return recording_snapshot(recorder_manager, request.app.state.fsm, channel)
@app.post("/api/start_all_recording")
async def api_start_all_recording(request: Request):
    try:
        body = await request.json()
        is_user_request = bool(body.get("is_user_request", False))
    except Exception:
        is_user_request = False

    results = await startRecordingForAllChannels(request.app, is_user_request=is_user_request)
    return JSONResponse({'status': 'success', 'message': '일괄 시작 요청 접수', 'channels_status': results})


# 모두 녹화중지 API 함수
@app.post("/api/stop_all_recording")
async def api_stop_all_recording(request: Request):
    await stopRecordingForAllChannels(request.app)
    return JSONResponse({'status': 'success', 'message': '일괄 중지 요청 접수'})


@app.post("/api/channel-groups/{group_id}/recording/{action}")
async def api_group_recording(group_id: str, action: Literal["start", "stop"], request: Request):
    from module.channel_groups import load_groups, effective_group

    app = request.app
    async with app.state.channels_lock:
        try:
            groups = await asyncio.to_thread(load_groups)
        except (OSError, ValueError) as exc:
            raise HTTPException(500, '녹화채널 그룹 설정을 읽지 못했습니다.') from exc
        if not effective_group(group_id, groups):
            raise HTTPException(404, '녹화채널 그룹을 찾을 수 없습니다. 목록을 새로고침하세요.')
        channels = [
            (ch["id"], ch.get("name") or ch["id"])
            for ch in app.state.channels
            if ch.get("id") and ch.get("recording_group") == group_id
            and (action == "stop" or ch.get("record_enabled", True))
        ]
    if not channels:
        return {"status": "empty", "message": "선택한 그룹에 처리할 채널이 없습니다."}

    run_channel = startRecordingForChannel if action == "start" else stopRecordingForChannel
    results = await asyncio.gather(
        *(run_channel(app, cid) for cid, _ in channels), return_exceptions=True
    )
    failed = []
    for (cid, name), result in zip(channels, results):
        if isinstance(result, BaseException):
            print(f"[WARN] 그룹 녹화 요청 실패: action={action} channel={cid} error={type(result).__name__}")
            failed.append(name)
        elif action == "start" and result.get("status") == "error":
            failed.append(f"{name} ({result['message']})")
    if failed:
        status = "partial" if len(failed) < len(channels) else "error"
        return JSONResponse(
            {"status": status, "message": "요청에 실패한 채널: " + ", ".join(failed)},
            status_code=200 if status == "partial" else 500,
        )
    return {"status": "success"}


# 채널별 녹화 활성/비활성 토글 API 
@app.post("/api/toggle_record_enabled/{channel_id}")
async def toggle_record_enabled(channel_id: str, request: Request):
    return await toggle_channel_recording(request.app.state, channel_id)


# 웹 대시보드에 매트릭 API
@app.get("/api/sys_metrics")
async def api_sys_metrics():
    try:
        return JSONResponse(content=await asyncio.to_thread(_collectSysMetrics))
    except Exception as e:
        tb = traceback.format_exc()
        print(f"[SYS_METRICS][ERROR] {e}\n{tb}")
        return JSONResponse(
            content={"status": "error", "message": str(e)},
            status_code=500
        )


# 메인 페이지 라우트
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse('index.html', {'request': request, 'is_linux': sys.platform == 'linux'})


# 로그인 라우트
@app.get('/login', response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse('login.html', {'request': request})


@app.post("/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    try:
        # 계정 정보를 로드합니다.
        account = loadAccount()
        
        # 계정 정보가 존재하고 비밀번호가 일치할 경우
        if account and account['username'] == username and check_password_hash(account['password'], password):
            # 세션에 로그인 상태 저장
            request.session.clear()
            request.session['logged_in'] = True
            request.session['account_revision'] = account_revision(account)
            return JSONResponse(
                content={"status": "success", "message": "로그인 성공", "redirect_url": "/files"},
                status_code=200
            )
        
        else:
            # 로그인 실패 시 JSON 응답을 반환 (리다이렉션 없음)
            return JSONResponse(
                content={"status": "error", "message": "아이디 또는 비밀번호가 올바르지 않습니다."},
                status_code=401,  # 401 Unauthorized 상태 코드
                headers={"Content-Type": "application/json"}
            )
    
    except Exception as e:
        # 예외 처리
        print(f"로그인 중 오류 발생: {e}")
        return JSONResponse(
            content={"status": "error", "message": "로그인 처리 중 오류가 발생했습니다."},
            status_code=500
        )


# 로그아웃 라우트
@app.post("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse(url='/', status_code=303)


# GET 요청을 처리하여 계정 생성 페이지를 렌더링
@app.get("/register")
async def register_page(request: Request, local: Any = Depends(requireLocalClient)):
    account = loadAccount()
    loginMode = request.app.state.config.get('loginMode', False)
    need_account = request.query_params.get('need_account') 

    if account:
        error_message = "이미 계정이 존재합니다. 추가 계정을 만들 수 없습니다."

        return templates.TemplateResponse(
            'register.html',
            {'request': request, 'error_message': error_message, 'loginMode': loginMode, 'program_version': PROGRAM_VERSION},
            status_code=400
        )

    return templates.TemplateResponse(
        'register.html',
        {
            'request': request,
            'loginMode': loginMode,
            'info_message': "로그인 모드를 켰습니다. 먼저 관리자 계정을 생성하세요." if need_account else None,
            'program_version': PROGRAM_VERSION
        }
    )


# 계정 생성 폼을 처리하는 POST 요청
@app.post("/register")
async def register(request: Request, username: str = Form(...), password: str = Form(...), password_confirm: str = Form(...), local: Any = Depends(requireLocalClient)):
    account = loadAccount()
    
    # 계정이 이미 존재하면 계정 생성 금지
    if account:
        error_message = "이미 계정이 존재합니다. 추가 계정을 만들 수 없습니다."
        return templates.TemplateResponse('register.html', {
            'request': request,
            'error_message': error_message,
            'program_version': PROGRAM_VERSION
        }, status_code=400)

    # 비밀번호 확인
    if password != password_confirm:

        return templates.TemplateResponse('register.html', {
            'request': request,
            'error_message': "비밀번호가 일치하지 않습니다.",
            'program_version': PROGRAM_VERSION
        })

    # 비밀번호 해시화 후 계정 저장
    hashed_password = generate_password_hash(password)
    account = {"username": username, "password": hashed_password}
    saveAccount(account)

    # 계정 생성 후 메인 페이지로 리다이렉트
    return RedirectResponse(url='/', status_code=302)


# 계정 수정/삭제 관련 라우트
@app.post("/updateAccount")
async def updateAccount(
    request: Request, 
    username: str = Form(...), 
    current_password: str = Form(...), 
    new_password: str = Form(None), 
    new_password_confirm: str = Form(None), 
    action: str = Form(...),
    login: Any = Depends(require_account)
):
    try:
        account = loadAccount()  # 계정 정보 로드

        # 로그를 추가하여 디버깅
        print(f"Received request for action: {action}")
        print("[INFO] 계정 변경 요청")

        if action == "update":  # 계정 수정
            if account:
                is_password_valid = check_password_hash(account['password'], current_password)
                if not is_password_valid:
                    return JSONResponse(
                        content={"status": "error", "message": "기존 비밀번호가 일치하지 않습니다."},
                        status_code=400
                    )
                if new_password != new_password_confirm:
                    return JSONResponse(
                        content={"status": "error", "message": "새 비밀번호가 일치하지 않습니다."},
                        status_code=400
                    )

                # 비밀번호 해시 업데이트
                hashed_password = generate_password_hash(new_password)
                account['username'] = username
                account['password'] = hashed_password
                saveAccount(account)

                # 세션 정리 및 로그아웃 처리
                request.session.clear()  # 기존 세션 제거
                return JSONResponse(
                    content={"status": "success", "message": "계정이 수정되었습니다. 다시 로그인해 주세요.", "redirect_url": "/login"},
                    status_code=200
                )

        elif action == "delete":  # 계정 삭제
            print(f"Attempting to delete account: {username}")

            # 삭제는 username과 current_password만 필요
            if account and check_password_hash(account['password'], current_password):
                if deleteAccount():
                    request.session.clear()  # 세션 정리
                    return JSONResponse(
                        content={"status": "success", "message": "계정이 삭제되었습니다.", "redirect_url": "/"},
                        status_code=200
                    )
                else:
                    return JSONResponse(
                        content={"status": "error", "message": "삭제할 계정이 없습니다."},
                        status_code=400
                    )
            else:
                return JSONResponse(
                    content={"status": "error", "message": "기존 비밀번호가 일치하지 않습니다."},
                    status_code=400
                )
    except Exception as e:
        print(f"[WARN] 계정 처리 오류: {type(e).__name__}")
        return JSONResponse(
            content={"status": "error", "message": "계정 처리 중 오류가 발생했습니다."},
            status_code=500
        )


@app.post("/api/save_chzzk_cookies")
async def save_chzzk_cookies(request: Request, body: dict = Body(...), login: Any = Depends(requireLocalClient)):
    request.app.state.cookies = updatePlatformCookies(body, replace_chzzk=True)

    return {"status": "ok"}


@app.get("/api/check_chzzk_cookie")
async def api_check_chzzk_cookie(request: Request):
    cookies = loadCookies()
    result = await asyncio.to_thread(checkChzzkCookie, cookies)
    return result


@app.get("/api/check_cime_cookie")
async def api_check_cime_cookie(request: Request):
    return await checkCimeCookie(getCimeCookies(), getCimeMetadata)


async def serialize_settings_write(request: Request):
    state = request.app.state
    lock = getattr(state, "settings_write_lock", None)
    if lock is None:
        lock = state.settings_write_lock = asyncio.Lock()
    async with lock:
        yield


@app.post("/api/save_config", dependencies=[Depends(serialize_settings_write)])
async def save_config_api(request: Request, body: dict = Body(...)):
    current = loadConfig() or {}
    import inspect
    settings = set(inspect.signature(updateConfig).parameters) - {'request', 'fileManagerMode', 'gpuAssignmentsJson'}
    settings -= {key for key in settings if key.startswith(('telegram_', 'discord_', 'notify_'))}
    unsupported = body.keys() - settings - {'loginMode'}
    if unsupported:
        raise HTTPException(400, '지원하지 않는 설정 항목입니다.')
    body.pop('loginMode', None)
    linux_startup = body.pop('runAtLinuxStartup', None)
    try:
        if 'recordingMetadataRefreshInterval' in body:
            body['recordingMetadataRefreshInterval'] = parseRecordingMetadataRefreshInterval(body['recordingMetadataRefreshInterval'])
        candidate = validate_network({**current, **body}, loadAccount())
        candidate['port'] = ensure_port_available(
            candidate['port'],
            "0.0.0.0" if candidate['remoteAccessEnabled'] else "127.0.0.1",
            current_port=getattr(request.app.state, 'actual_port', None),
            previous_port=current.get('port'),
        )
        for key, value in current.items():
            if isinstance(value, bool) and key in body:
                candidate[key] = toBool(body[key], default=value)
        from module.config_validator import validateExtraFfmpegOptions
        for key in ('extra_ffmpeg_options', 'extra_ffmpeg_options_gpu1'):
            validateExtraFfmpegOptions(candidate.get(key, ''))
        candidate['runAtWindowsStartup'] = toBool(candidate.get('runAtWindowsStartup', False))
        candidate['fileManagerEnabled'] = toBool(candidate.get('fileManagerEnabled', False))
        candidate['diagnosticLogDays'] = normalize_diagnostic_log_days(candidate.get('diagnosticLogDays'))
        protected_config(request, current, candidate)
        if candidate['runAtWindowsStartup'] != bool(current.get('runAtWindowsStartup', False)):
            if sys.platform == 'linux':
                raise ValueError('OS 로그인 시 자동 실행은 현재 Windows에서만 지원합니다.')
            from module.windows_startup import set_startup_enabled
            await asyncio.to_thread(set_startup_enabled, BASE_DIR, candidate['runAtWindowsStartup'])
        await apply_linux_startup(request, linux_startup)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    merged = saveConfig(candidate)
    request.app.state.config = merged
    set_diagnostic_log_days(candidate['diagnosticLogDays'])
    restart_required = merged['port'] != getattr(request.app.state, 'actual_port', merged['port'])
    message = "설정을 저장했습니다."
    if restart_required:
        message += " 새 포트는 recordWEB을 완전히 종료한 뒤 다시 실행하면 적용됩니다."
    return {"status": "ok", "config": public_settings(merged), "restart_required": restart_required, "message": message}


# 계정 사용자 정보 전달 
@app.get("/user_info")
async def user_info(request: Request):
    account = loadAccount()
    config = request.app.state.config or {}
    loginMode  = bool(config.get('loginMode', False))
    enableTray = bool(config.get('enableTray', False))

    payload = {
        "config": {
            "loginMode":  loginMode,
            "enableTray": enableTray,   
        }
    }

    if account_session(request, account):
        username = account.get('username', 'Unknown User')
        payload.update({"logged_in": True, "username": username})
    else:
        payload.update({"logged_in": False, "username": None})

    return JSONResponse(content=payload)


@app.get("/channels", response_class=HTMLResponse)
async def channelsPage(request: Request):
    from module.channel_groups import load_groups
    groups = await asyncio.to_thread(load_groups)
    async with request.app.state.channels_lock:
        chs = list(request.app.state.channels)

    return templates.TemplateResponse('channels.html', {
        'recording_groups': groups,
        'can_edit_output_dir': is_local_client(request),
        'request': request,
        'channels': chs,
        'program_version': PROGRAM_VERSION
    })


@app.get('/api/channel-groups')
async def channel_groups_get():
    from module.channel_groups import load_groups
    return {'groups': await asyncio.to_thread(load_groups)}


@app.post('/api/channel-groups')
async def channel_groups_add(request: Request):
    from module.channel_groups import mutate_group
    return await mutate_group(request, 'add')


@app.put('/api/channel-groups/{group_id}')
async def channel_groups_edit(group_id: str, request: Request):
    from module.channel_groups import mutate_group
    return await mutate_group(request, 'edit', group_id)


@app.delete('/api/channel-groups/{group_id}')
async def channel_groups_delete(group_id: str, request: Request):
    from module.channel_groups import mutate_group
    return await mutate_group(request, 'delete', group_id)


# 채널 추가 API 함수
@app.post("/api/channels")
async def addChannel(request: Request):
    return await mutate_channel(request, "add")


# 채널 수정 API 함수
@app.put("/api/channels/{channel_id:path}")
async def editChannel(channel_id: str, request: Request):
    from module.channel_service import decode_channel_path
    channel_id = decode_channel_path(request, channel_id)
    return await mutate_channel(request, "edit", channel_id)


# 채널 삭제 API 함수
@app.delete("/api/channels/{channel_id:path}")
async def deleteChannel(channel_id: str, request: Request):
    from module.channel_service import decode_channel_path
    channel_id = decode_channel_path(request, channel_id)
    return await mutate_channel(request, "delete", channel_id)


@app.get("/cookies", response_class=HTMLResponse)
async def getCookies(request: Request):
    cookies = {
        platform: {key: bool(value) for key, value in values.items()}
        for platform, values in loadCookies().items()
        if isinstance(values, dict)
    }
    cfg = request.app.state.config or {}

    return templates.TemplateResponse('cookies.html', {
        'request': request,
        'cookies': cookies,
        'loginMode': bool(cfg.get("loginMode", False)),
        'program_version': PROGRAM_VERSION
    })


@app.post("/cookies")
async def updateCookies(request: Request, login: Any = Depends(requireLocalClient)):
    try:
        new_cookies = await request.json()
        if not new_cookies:
            return JSONResponse(content={'status': 'error', 'message': '쿠키 데이터가 비어 있습니다.'}, status_code=400)

        request.app.state.cookies = updatePlatformCookies(new_cookies)

        print("[INFO] 쿠키 설정이 저장되었습니다.")
        return JSONResponse(content={'status': 'success'})

    except Exception as e:
        print("쿠키 업데이트 중 오류 발생")
        return JSONResponse(content={'status': 'error', 'message': '쿠키 업데이트 중 오류 발생'}, status_code=500)


# 파일관리 페이지
@app.get("/api/files/access")
async def api_files_access(login: Any = Depends(require_file_access)):
    return JSONResponse({"status": "ok"}, headers={"Cache-Control": "no-store"})


@app.get("/files", response_class=HTMLResponse)
async def filesPage(request: Request, login: Any = Depends(require_file_access)):
    cfg = request.app.state.config
    # roots 존재 여부와 무관하게, 스위치만으로 활성화
    enabled = bool(cfg.get("fileManagerEnabled"))
    roots = cfg.get("fileManagerRoots") or []

    return templates.TemplateResponse(
        "files.html",
        {
            "request": request,
            "loginMode": cfg.get("loginMode", False),
            "fm_enabled": enabled,
            "fm_roots": roots,
            "program_version": PROGRAM_VERSION,
        },
    )


@app.get('/diagnostics', response_class=HTMLResponse)
async def diagnostics_page(request: Request):
    return templates.TemplateResponse('diagnostics.html', {'request': request})


@app.get("/backup", response_class=HTMLResponse, dependencies=[Depends(require_backup_access)])
async def backup_page(request: Request):
    from module.backup_restore import data_dir, restore_status
    last_restore = await asyncio.to_thread(restore_status, data_dir())
    return templates.TemplateResponse("backup.html", {"request": request, "restore": last_restore},
                                      headers={"Cache-Control": "no-store"})


def backup_download(content, filename):
    return Response(content, media_type="application/zip", headers={
        "Content-Disposition": f'attachment; filename="{filename}"',
        "Cache-Control": "no-store",
    })


@app.get("/api/backup/download", dependencies=[Depends(require_backup_access)])
async def create_backup(request: Request):
    from module.backup_restore import capture, data_dir
    try:
        async with request.app.state.settings_write_lock, request.app.state.channels_lock:
            filename, content = await asyncio.to_thread(capture, data_dir())
    except (OSError, ValueError) as exc:
        raise HTTPException(400, "백업 ZIP을 만들 수 없습니다. 파일 권한과 크기를 확인해 주세요.") from exc
    return backup_download(content, filename)


@app.get("/api/backup/before-restore", dependencies=[Depends(require_backup_access)])
async def download_before_restore():
    from module.backup_restore import data_dir, restore_status
    root = data_dir()
    name = (await asyncio.to_thread(restore_status, root)).get("backup")
    if not isinstance(name, str) or not re.fullmatch(r"before_restore_\d{8}_\d{6}_[0-9a-f]{8}\.zip", name):
        raise HTTPException(404, "복원 전 자동 백업을 찾을 수 없습니다.")
    path = root / "backups" / name
    if not path.is_file():
        raise HTTPException(404, "복원 전 자동 백업을 찾을 수 없습니다.")
    return FileResponse(path, filename=name, media_type="application/zip", headers={"Cache-Control": "no-store"})


@app.post("/api/backup/{action}", dependencies=[Depends(require_backup_access)])
async def upload_backup(action: Literal["inspect", "restore"], request: Request, selected: List[str] = Query(default=[])):
    from module.backup_archive import MAX_UPLOAD
    from module.backup_restore import data_dir, prepare, queue_restore
    content = bytearray()
    async for chunk in request.stream():
        if len(content) + len(chunk) > MAX_UPLOAD:
            raise HTTPException(413, "백업 ZIP은 4MB 이하만 사용할 수 있습니다.")
        content.extend(chunk)
    try:
        if action == "inspect":
            _, summary = await asyncio.to_thread(prepare, content)
            return JSONResponse(summary, headers={"Cache-Control": "no-store"})
        names = await asyncio.to_thread(queue_restore, data_dir(), content, selected)
        return {"status": "pending", "included": names,
                "message": "복원을 예약했습니다. recordWEB을 완전히 종료하고 다시 실행하면 적용됩니다."}
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except OSError as exc:
        raise HTTPException(500, "복원 예약을 저장하지 못했습니다. 저장 공간과 권한을 확인해 주세요.") from exc


# 사용량/목록 API
@app.get("/api/files/usage")
async def api_files_usage(request: Request, login: Any = Depends(require_file_access)):
    cfg = request.app.state.config
    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(cfg, request.app.state.channels)
    return {"status": "ok", "volumes": listDisks(roots)}


# 파일 목록
@app.get("/api/files/list")
async def api_files_list(
    request: Request,
    path: str,
    show_hidden: bool = Query(False),
    login: Any = Depends(require_file_access)
):
    cfg = request.app.state.config
    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(cfg, request.app.state.channels)
        busy  = busyFilePaths(recorder_manager, request.app.state.channels)

    rp = ensureInRoots(path, roots)
    items = listDir(rp, show_hidden=show_hidden)
    for it in items:
        it["locked"] = isLocked(it["path"], busy)
    return {"status": "ok", "path": rp, "items": items}


# 루트 목록
@app.get("/api/files/roots")
async def api_files_roots(request: Request, login: Any = Depends(require_file_access)):
    cfg = request.app.state.config
    if not cfg.get("fileManagerEnabled", False):
        raise HTTPException(status_code=403, detail="File manager disabled")

    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(cfg, request.app.state.channels)

    return {"roots": roots, "default": roots[0] if roots else None}


# 파일 목록 호출(프론트가 /api/files/ls 호출)
@app.get("/api/files/ls")
async def api_files_ls(
    request: Request,
    path: str,
    show_hidden: bool = Query(False),
    login: Any = Depends(require_file_access)
):
    cfg = request.app.state.config
    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(cfg, request.app.state.channels)
        busy  = busyFilePaths(recorder_manager, request.app.state.channels)

    # 1) 허용 루트 검사 → 403
    try:
        rp = ensureInRoots(path, roots)
    except PermissionError:
        # 프론트의 보안 안내문 포맷터가 이 문구/상태코드를 잡아줍니다.
        raise HTTPException(status_code=403, detail="outside allowed roots")
    except Exception:
        # 형식이 이상한 path 등은 400
        raise HTTPException(status_code=400, detail="invalid path")

    # 2) 존재/타입 검사 → 404
    if not os.path.isdir(rp):
        raise HTTPException(status_code=404, detail="path not found")

    # 3) 목록 조회(권한 문제 등) → 403
    try:
        items = listDir(rp, show_hidden=show_hidden)
    except PermissionError:
        raise HTTPException(status_code=403, detail="permission denied")
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="path not found")
    except OSError:
        # 접근 금지/장치 오류 등 기타 OS 에러는 보수적으로 403
        raise HTTPException(status_code=403, detail="access denied")

    for it in items:
        it["locked"] = isLocked(it["path"], busy)

    return {"status": "ok", "path": rp, "items": items}


# 디스크 사용량
@app.get("/api/files/disk-usage")
async def api_files_disk_usage(request: Request, paths: List[str] = Query(default=None), login: Any = Depends(require_file_access)):
    cfg = request.app.state.config
    async with request.app.state.channels_lock:
        built = buildAllowedRoots(cfg, request.app.state.channels)
    roots = [ensureInRoots(path, built) for path in paths] if paths else built

    usages = []
    for r in roots:
        try:
            d = diskUsageFor(r)
            # 프론트 표시용 label
            d["label"] = r
            usages.append(d)
        except Exception:
            continue
    return {"status":"ok", "usages": usages}


# 4) 파일 다운로드 
@app.get("/api/files/download")
async def api_files_download(request: Request, path: str, login: Any = Depends(require_file_access)):
    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(request.app.state.config, request.app.state.channels)

    rp = ensureInRoots(path, roots)
    if not os.path.isfile(rp):
        raise HTTPException(status_code=404, detail="File not found")

    filename = os.path.basename(rp)
    return FileResponse(rp, filename=filename, media_type="application/octet-stream")



# 경로 만들기 API
@app.post("/api/files/mkdir")
async def api_files_mkdir(request: Request, body: dict = Body(...), login: Any = Depends(require_file_access)):
    if request.app.state.config.get("fileManagerReadOnly", False):
        raise HTTPException(status_code=403, detail="Read-only mode")
    parent  = body.get("path")
    newName = body.get("new_name")
    if not parent or not newName:
        raise HTTPException(status_code=400, detail="path/new_name required")

    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(request.app.state.config, request.app.state.channels)
    parent = ensureInRoots(parent, roots)
    childPath(parent, newName, roots)
    created = mkdirPath(parent, newName)
    return {"status":"ok", "created": created}


# 경로 수정 API
@app.post("/api/files/rename")
async def api_files_rename(request: Request, body: dict = Body(...), login: Any = Depends(require_file_access)):
    if request.app.state.config.get("fileManagerReadOnly", False):
        raise HTTPException(status_code=403, detail="Read-only mode")
    src = body.get("path"); newName = body.get("new_name")
    if not src or not newName:
        raise HTTPException(status_code=400, detail="path/new_name required")
    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(request.app.state.config, request.app.state.channels)
        busy  = busyFilePaths(recorder_manager, request.app.state.channels)
    src = ensureInRoots(src, roots)
    childPath(os.path.dirname(src), newName, roots)
    if isLocked(src, busy): raise HTTPException(status_code=423, detail="Locked (recording)")
    try:
        dst = renamePath(src, newName)
    except FileExistsError as exc:
        raise HTTPException(409, "같은 이름의 파일이나 폴더가 있습니다.") from exc
    return {"status":"ok", "path": dst}


# 파일 이동 API
@app.post("/api/files/move")
async def api_files_move(request: Request, body: dict = Body(...), login: Any = Depends(require_file_access)):
    if request.app.state.config.get("fileManagerReadOnly", False):
        raise HTTPException(status_code=403, detail="Read-only mode")

    srcs = body.get("srcs") or ([] if not body.get("src") else [body.get("src")])
    dstDir = body.get("dst_dir")
    if not srcs or not dstDir:
        raise HTTPException(status_code=400, detail="src/srcs and dst_dir required")

    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(request.app.state.config, request.app.state.channels)
        busy  = busyFilePaths(recorder_manager, request.app.state.channels)

    dstDir = ensureInRoots(dstDir, roots)
    moved = []
    for s in srcs:
        rp = ensureInRoots(s, roots)
        if isLocked(rp, busy):
            raise HTTPException(status_code=423, detail=f"Locked: {rp}")
        try:
            moved.append(await asyncio.to_thread(movePath, rp, dstDir))
        except FileExistsError as exc:
            raise HTTPException(409, "이동할 위치에 같은 이름의 파일이나 폴더가 있습니다.") from exc
    return {"status":"ok", "moved": moved}


# 파일 삭제 API
@app.post("/api/files/delete")
async def api_files_delete(request: Request, body: dict = Body(...), login: Any = Depends(require_file_access)):
    if request.app.state.config.get("fileManagerReadOnly", False):
        raise HTTPException(status_code=403, detail="Read-only mode")

    paths = body.get("paths") or ([] if not body.get("path") else [body.get("path")])
    hard  = bool(body.get("hard", False))
    if not paths:
        raise HTTPException(status_code=400, detail="paths or path required")

    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(request.app.state.config, request.app.state.channels)
        busy  = busyFilePaths(recorder_manager, request.app.state.channels)

    deleted = []
    for p in paths:
        rp = ensureInRoots(p, roots)
        if isLocked(rp, busy):
            raise HTTPException(status_code=423, detail=f"Locked: {rp}")
        if hard or not request.app.state.config.get("trashEnabled", True):
            hardDelete(rp)
            deleted.append(rp)
        else:
            rootForTrash = deepestAllowedRoot(rp, roots)
            deleted.append(softDelete(rp, rootForTrash))
    return {"status":"ok", "deleted": deleted}


# 파일매니저 스트림복사 API함수
@app.post("/api/files/streamcopy")
async def api_files_streamcopy(
    request: Request,
    body: dict = Body(...),
    login: Any = Depends(require_file_access),
):
    # 읽기전용 모드 차단
    if request.app.state.config.get("fileManagerReadOnly", False):
        raise HTTPException(status_code=403, detail="Read-only mode")

    srcs = body.get("paths") or []
    if not srcs:
        raise HTTPException(status_code=400, detail="paths required")

    async with request.app.state.channels_lock:
        roots = buildAllowedRoots(request.app.state.config, request.app.state.channels)
        busy  = busyFilePaths(recorder_manager, request.app.state.channels)

    results = []

    for s in srcs:
        try:
            rp = ensureInRoots(s, roots)
            if not os.path.isfile(rp):
                raise HTTPException(status_code=400, detail=f"Not a file: {rp}")
            if isLocked(rp, busy):
                raise HTTPException(status_code=423, detail=f"Locked (recording): {rp}")

            dst = await asyncio.to_thread(streamCopyFile, rp)

            results.append({"src": rp, "dst": dst, "ok": True})
        except HTTPException as he:
            results.append({"src": s, "error": he.detail, "ok": False})
        except Exception as e:
            results.append({"src": s, "error": str(e), "ok": False})

    return {"status": "ok", "results": results}


# 텔레그램/디스코드 알림 API 테스트 함수
@app.post("/api/test_notification/{target}")
async def testNotification(target: str, request: Request):
    target = (target or "").strip().lower()
    cfg = loadNotification() or {}

    if target == "telegram":
        if not cfg.get("telegram_enabled"):
            return JSONResponse(content={"status": "error", "message": "텔레그램 알림이 OFF입니다."}, status_code=400)

        ok = notifyEvent(
            "notification_test",
            "recordWEB 테스트",
            "텔레그램 테스트 메시지입니다.",
            severity="info",
            target="telegram",
            force=True
        )

        if not ok:
            return JSONResponse(content={"status": "error", "message": "텔레그램 전송에 실패했습니다."}, status_code=500)

        return JSONResponse(content={"status": "success", "message": "텔레그램 테스트 메시지를 전송했습니다."})

    if target == "discord":
        if not cfg.get("discord_enabled"):
            return JSONResponse(content={"status": "error", "message": "디스코드 알림이 OFF입니다."}, status_code=400)

        ok = notifyEvent(
            "notification_test",
            "recordWEB 테스트",
            "디스코드 테스트 메시지입니다.",
            severity="info",
            target="discord",
            force=True
        )

        if not ok:
            return JSONResponse(content={"status": "error", "message": "디스코드 전송에 실패했습니다."}, status_code=500)

        return JSONResponse(content={"status": "success", "message": "디스코드 테스트 메시지를 전송했습니다."})

    return JSONResponse(content={"status": "error", "message": "지원하지 않는 알림 대상입니다."}, status_code=400)


async def apply_linux_startup(request, value):
    if value is None:
        return
    if sys.platform != 'linux':
        raise ValueError('Linux 부팅 자동 실행은 Linux에서만 지원합니다.')
    requireLocalClient(request)
    from module.linux_startup import set_startup_enabled
    await asyncio.to_thread(set_startup_enabled, BASE_DIR, toBool(value))


# 설정 페이지 라우트
@app.get("/config", response_class=HTMLResponse)
async def configPage(request: Request):
    config_data = loadConfig()           
    account = loadAccount()             
    notification = public_notification(loadNotification())
    linux_startup_enabled = linux_startup_available = False
    if sys.platform == 'linux':
        from module.linux_startup import available, startup_enabled
        linux_startup_available = available() and is_local_client(request)
        linux_startup_enabled = await asyncio.to_thread(startup_enabled, BASE_DIR)

    # 채널 분배 UI를 위해 channels 전달
    async with request.app.state.channels_lock:
        channels = [dict(c) for c in request.app.state.channels]

    return templates.TemplateResponse('config.html', {
        'request': request,
        'config': public_settings(config_data),
        'resolved_run_mode': resolve_run_mode(config_data),
        'is_linux': sys.platform == 'linux',
        'linux_startup_available': linux_startup_available,
        'linux_startup_enabled': linux_startup_enabled,
        'local_access_port': (
            getattr(request.app.state, 'actual_port', None)
            if not (getattr(request.app.state, 'bound_remote', False)
                    and config_data.get('remoteAccessEnabled'))
            else None
        ),
        'current_lan_port': (
            getattr(request.app.state, 'actual_port', None)
            if getattr(request.app.state, 'bound_remote', False) and config_data.get('remoteAccessEnabled')
            else None
        ),
        'current_access_addresses': (
            interface_ipv4_display() if getattr(request.app.state, 'bound_remote', False)
            and config_data.get('remoteAccessEnabled')
            else {}
        ),
        'account': {'username': account['username']} if account_session(request, account) else None,
        'account_exists': bool(account),
        'notification': notification,
        'channels': channels,           
        'program_version': PROGRAM_VERSION
    })


@app.get("/api/config")
async def get_config_api():
    return public_settings(loadConfig())


def public_settings(config):
    if isinstance(config, dict):
        return {key: public_settings(value) for key, value in config.items()
                if not any(word in key.lower() for word in
                           ('password', 'secret', 'token', 'cookie', 'webhook', 'authorization', 'api_key', 'apikey'))}
    if isinstance(config, list):
        return [public_settings(value) for value in config]
    return config


def public_notification(notification):
    result = public_settings(notification)
    for key in ('telegram_bot_token', 'telegram_chat_id', 'discord_webhook_url'):
        result[key + '_configured'] = bool(notification.get(key))
        result.pop(key, None)
    return result


@app.post("/config", dependencies=[Depends(serialize_settings_write)])
async def updateConfig(
    request: Request,
    autoRecordingMode: Optional[str] = Form(None),
    runMode: Optional[str] = Form(None),
    runAtWindowsStartup: Optional[str] = Form(None),
    runAtLinuxStartup: Optional[str] = Form(None),
    remoteAccessEnabled: Optional[str] = Form(None),
    port: Optional[int] = Form(None),
    enableTray: Optional[str] = Form(None),
    minimizeToTrayOnClose: Optional[str] = Form(None),
    minimizeToTrayOnStart: Optional[str] = Form(None),
    plugin_type: Optional[str] = Form(None),
    timemachine_time_shift: Optional[int] = Form(None),
    autoPostProcessing: Optional[str] = Form(None),
    deleteAfterPostProcessing: Optional[str] = Form(None),
    removeFixedPrefix: Optional[str] = Form(None),
    moveAfterProcessingEnabled: Optional[str] = Form(None),
    moveAfterProcessing: Optional[str] = Form(None),
    postNewWindow: Optional[str] = Form(None),
    recheckInterval: Optional[int] = Form(None),
    recordingMetadataRefreshInterval: Optional[str] = Form(None),
    filenamePattern: Optional[str] = Form(None),
    splitRecordingMode: Optional[str] = Form(None),
    splitPostProcessing: Optional[str] = Form(None),
    autoStopInterval: Optional[int] = Form(None),
    splitOverlapSec: Optional[int] = Form(None),
    stream_copy: Optional[str] = Form(None),
    video_codec: Optional[str] = Form(None),
    preset: Optional[str] = Form(None),
    postprocess_resolution: Optional[str] = Form(None),
    use_bitrate_mode: Optional[str] = Form(None),
    video_quality: Optional[int] = Form(None),
    video_bitrate: Optional[str] = Form(None),
    vbv_maxrate: Optional[str] = Form(None),
    vbv_bufsize: Optional[str] = Form(None),
    extra_ffmpeg_options: Optional[str] = Form(None),
    audio_codec: Optional[str] = Form(None),
    audio_bitrate: Optional[str] = Form(None),
    gpuCount: Optional[int] = Form(None),
    singleGpuIndex: Optional[int] = Form(None),
    video_codec_gpu1: Optional[str] = Form(None),
    preset_gpu1: Optional[str] = Form(None),
    postprocess_resolution_gpu1: Optional[str] = Form(None),
    use_bitrate_mode_gpu1: Optional[str] = Form(None),
    video_quality_gpu1: Optional[int] = Form(None),
    video_bitrate_gpu1: Optional[str] = Form(None),
    vbv_maxrate_gpu1: Optional[str] = Form(None),
    vbv_bufsize_gpu1: Optional[str] = Form(None),
    extra_ffmpeg_options_gpu1: Optional[str] = Form(None),
    audio_codec_gpu1: Optional[str] = Form(None),
    audio_bitrate_gpu1: Optional[str] = Form(None),
    gpuAssignmentsJson: Optional[str] = Form(None),
    fileManagerEnabled: Optional[str] = Form(None),
    fileManagerRoots: List[str] = Form([]),
    fileManagerMode: str = Form("blacklist"),
    fileManagerReadOnly: Optional[str] = Form(None),
    trashEnabled: Optional[str] = Form(None),

    telegram_enabled: str = Form("off"),
    telegram_bot_token: str = Form(""),
    telegram_chat_id: str = Form(""),
    discord_enabled: str = Form("off"),
    discord_webhook_url: str = Form(""),

    notify_record_started: str = Form("off"),
    notify_record_finished: str = Form("off"),
    notify_record_start_failed: str = Form("on"),
    notify_record_abnormally_stopped: str = Form("on"),
    notify_record_user_stopped: str = Form("off"),
    notify_postprocess_finished: str = Form("on"),
    notify_postprocess_failed: str = Form("on"),
    notify_cookie_auth_failed: str = Form("on"),
    notify_watchparty_skipped: str = Form("off"),
    notify_disk_space_low: str = Form("on"),
    notify_dedupe_seconds: int = Form(300),
    notify_disk_space_low_gb: int = Form(10),
    diagnosticLogDays: Optional[str] = Form(None),
):
    try:
        # 1) 기존 설정 로드
        current_config = loadConfig() or {}
        if runMode is not None and runMode not in ('normal', 'lite', 'headless'):
            raise ValueError('실행 모드를 확인해 주세요.')
        requested_port = port if port is not None else current_config.get('port', 5000)
        normalized_port = parse_port(
            requested_port,
            allow_legacy=int(requested_port) == int(current_config.get('port', 5000)),
        )

        # 2) 플러그인/시프트
        posted_plugin = (plugin_type or "").strip().lower() if plugin_type is not None else None
        if posted_plugin in ("basic", "timemachine_plus"):
            normalized_plugin = posted_plugin
        else:
            normalized_plugin = (current_config.get("plugin_type") or "basic")

        try:
            if timemachine_time_shift is None:
                _shift = int(current_config.get("timemachine_time_shift", 0) or 0)
            else:
                _shift = int(timemachine_time_shift or 0)
        except Exception:
            _shift = int(current_config.get("timemachine_time_shift", 0) or 0)

        normalized_shift = (
            max(0, min(10, _shift)) if normalized_plugin == "basic"
            else max(0, min(3600, _shift))
        )

        # 3) 파일매니저(웹 전용)
        normalized_roots = normalizeConfiguredRoots(fileManagerRoots)
        effective_fm_enabled = toBool(fileManagerEnabled)

        # 4) 분할/오버랩/오토스탑
        _split_on = toBool(splitRecordingMode) if splitRecordingMode is not None else bool(current_config.get("splitRecordingMode", False))
        try:
            if splitOverlapSec is None:
                ov = int(current_config.get("splitOverlapSec", 0) or 0)
            else:
                ov = int(splitOverlapSec or 0)
        except Exception:
            ov = int(current_config.get("splitOverlapSec", 0) or 0)
        if ov < 0: ov = 0
        if ov > 30: ov = 30
        if not _split_on:
            ov = 0

        # autoStopInterval: 분할 ON일 때만, 누락 시 기존값 유지
        try:
            if _split_on:
                _auto_stop = int(autoStopInterval) if autoStopInterval is not None else int(current_config.get("autoStopInterval", 0) or 0)
            else:
                _auto_stop = 0
        except Exception:
            _auto_stop = 0 if not _split_on else int(current_config.get("autoStopInterval", 0) or 0)

        # 5) 트레이
        _enable_tray   = toBool(enableTray) if enableTray is not None else bool(current_config.get("enableTray", False))
        _tray_on_close = toBool(minimizeToTrayOnClose) if minimizeToTrayOnClose is not None else bool(current_config.get("minimizeToTrayOnClose", False))
        _tray_on_start = toBool(minimizeToTrayOnStart) if minimizeToTrayOnStart is not None else bool(current_config.get("minimizeToTrayOnStart", False))
        if not _enable_tray:
            _tray_on_close = False
            _tray_on_start = False

        # 6) 재탐색/파일명
        try:
            _recheck = int(recheckInterval) if recheckInterval is not None else int(current_config.get("recheckInterval", 60))
        except Exception:
            _recheck = int(current_config.get("recheckInterval", 60))
        if recordingMetadataRefreshInterval is None:
            recordingMetadataRefreshInterval = (await request.form()).get(
                "recordingMetadataRefreshInterval", current_config["recordingMetadataRefreshInterval"])
        metadata_interval = parseRecordingMetadataRefreshInterval(recordingMetadataRefreshInterval)
        _pattern = filenamePattern if (filenamePattern not in (None, "")) else current_config.get("filenamePattern", "[{start_time}] {safe_live_title}")

        # 7) 이동경로: 누락 시 기존값 유지(빈 문자열은 None)
        _move_path = (
            current_config.get("moveAfterProcessing")
            if moveAfterProcessing is None
            else (moveAfterProcessing or None)
        )

        # gpuCount 정규화
        try:
            _gc = int(gpuCount) if gpuCount is not None else int(current_config.get("gpuCount", 1) or 1)
        except Exception:
            _gc = int(current_config.get("gpuCount", 1) or 1)
        _gc = 2 if _gc == 2 else 1         

        # 후처리 옵션(GPU0): 폼 누락(None)일 때 기존값 유지
        _stream_copy0 = toBool(stream_copy) if stream_copy is not None else bool(current_config.get("stream_copy", True))

        # 영상 출력 해상도 정규화
        _allowed_res = ("source", "1080p", "720p", "480p")
        _pp0_raw = postprocess_resolution if postprocess_resolution is not None else current_config.get("postprocess_resolution", "source")
        _pp0 = str(_pp0_raw or "source").strip().lower()
        if _pp0 not in _allowed_res:
            _pp0 = "source"

        _video_codec0 = video_codec if (video_codec not in (None, "")) else current_config.get("video_codec", "libx264")
        _preset0      = preset      if (preset      not in (None, "")) else current_config.get("preset", "medium")

        _use_bitrate_mode0 = toBool(use_bitrate_mode) if use_bitrate_mode is not None else bool(current_config.get("use_bitrate_mode", False))

        try:
            _video_quality0 = int(video_quality) if video_quality is not None else int(current_config.get("video_quality", 23) or 23)
        except Exception:
            _video_quality0 = int(current_config.get("video_quality", 23) or 23)

        _video_bitrate0 = video_bitrate if video_bitrate is not None else current_config.get("video_bitrate", "1000k")
        _vbv_maxrate0   = vbv_maxrate   if vbv_maxrate   is not None else current_config.get("vbv_maxrate", "")
        _vbv_bufsize0   = vbv_bufsize   if vbv_bufsize   is not None else current_config.get("vbv_bufsize", "")
        _extra_opts0    = extra_ffmpeg_options if extra_ffmpeg_options is not None else current_config.get("extra_ffmpeg_options", "")

        _audio_codec0   = audio_codec   if (audio_codec   not in (None, "")) else current_config.get("audio_codec", "aac")
        _audio_bitrate0 = audio_bitrate if audio_bitrate is not None else current_config.get("audio_bitrate", "copy")

        # 폼 누락으로 기존값 유지된 경우 확인용 디버그
        if (video_codec is None or preset is None or video_quality is None):
            print(f"[DEBUG][CFG] GPU0 폼 누락 → 기존값 유지: codec={_video_codec0}, preset={_preset0}, q={_video_quality0}")

        # GPU1 옵션 누락(None)이면 기존값/또는 GPU0 값으로 fallback
        _vc1 = video_codec_gpu1 if (video_codec_gpu1 not in (None, "")) else current_config.get("video_codec_gpu1", _video_codec0)
        _pr1 = preset_gpu1      if (preset_gpu1      not in (None, "")) else current_config.get("preset_gpu1", _preset0)

        _pp1_raw = postprocess_resolution_gpu1 if postprocess_resolution_gpu1 is not None else current_config.get("postprocess_resolution_gpu1", _pp0)
        _pp1 = str(_pp1_raw or _pp0).strip().lower()
        if _pp1 not in _allowed_res:
            _pp1 = _pp0

        _ubm1 = toBool(use_bitrate_mode_gpu1) if use_bitrate_mode_gpu1 is not None else bool(current_config.get("use_bitrate_mode_gpu1", _use_bitrate_mode0))

        try:
            _vq1 = int(video_quality_gpu1) if video_quality_gpu1 is not None else int(current_config.get("video_quality_gpu1", _video_quality0) or _video_quality0)
        except Exception:
            _vq1 = int(current_config.get("video_quality_gpu1", _video_quality0) or _video_quality0)

        _vb1 = video_bitrate_gpu1 if video_bitrate_gpu1 is not None else current_config.get("video_bitrate_gpu1", _video_bitrate0)

        # GPU1의 vbv/extra는 None이면 기존값 유지, 누락이면 사용자가 비운 값으로 반영
        _vbv_maxrate1 = vbv_maxrate_gpu1 if vbv_maxrate_gpu1 is not None else current_config.get("vbv_maxrate_gpu1", "")
        _vbv_bufsize1 = vbv_bufsize_gpu1 if vbv_bufsize_gpu1 is not None else current_config.get("vbv_bufsize_gpu1", "")
        _extra_opts1  = extra_ffmpeg_options_gpu1 if extra_ffmpeg_options_gpu1 is not None else current_config.get("extra_ffmpeg_options_gpu1", "")
        _ac1 = audio_codec_gpu1   if (audio_codec_gpu1   not in (None, "")) else current_config.get("audio_codec_gpu1", _audio_codec0)
        _ab1 = audio_bitrate_gpu1 if audio_bitrate_gpu1 is not None else current_config.get("audio_bitrate_gpu1", _audio_bitrate0)


        # 8) 새 설정 구성(없으면 기존값 유지 원칙)
        new_config = {
            **current_config,
            "runMode":                      runMode or resolve_run_mode(current_config),
            "autoRecordingMode":            toBool(autoRecordingMode),
            "runAtWindowsStartup":          (toBool(runAtWindowsStartup) if runAtWindowsStartup is not None
                                             else current_config.get('runAtWindowsStartup', False)),
            "remoteAccessEnabled":          toBool(remoteAccessEnabled),
            "port":                         normalized_port,
            "enableTray":                   _enable_tray,
            "minimizeToTrayOnClose":        _tray_on_close,
            "minimizeToTrayOnStart":        _tray_on_start,
            "plugin_type":                  normalized_plugin,
            "timemachine_time_shift":       normalized_shift,
            "autoPostProcessing":           toBool(autoPostProcessing),
            "deleteAfterPostProcessing":    toBool(deleteAfterPostProcessing),
            "removeFixedPrefix":            toBool(removeFixedPrefix),
            "moveAfterProcessingEnabled":   toBool(moveAfterProcessingEnabled),
            "moveAfterProcessing":          _move_path,
            "postNewWindow":                toBool(postNewWindow),
            "recheckInterval":              _recheck,
            "recordingMetadataRefreshInterval": metadata_interval,
            "filenamePattern":              _pattern,
            "splitRecordingMode":           _split_on,
            "splitPostProcessing":          toBool(splitPostProcessing),
            "autoStopInterval":             _auto_stop,
            "splitOverlapSec":              ov,
            "stream_copy":                  _stream_copy0,
            "video_codec":                  _video_codec0,
            "preset":                       _preset0,
            "use_bitrate_mode":             _use_bitrate_mode0,
            "postprocess_resolution":      _pp0,
            "video_quality":                _video_quality0,
            "video_bitrate":                _video_bitrate0,
            "vbv_maxrate":                  _vbv_maxrate0,
            "vbv_bufsize":                  _vbv_bufsize0,
            "extra_ffmpeg_options":         _extra_opts0,
            "audio_codec":                  _audio_codec0,
            "audio_bitrate":                _audio_bitrate0,
            "gpuCount":                     _gc,
            "singleGpuIndex":               singleGpuIndex if singleGpuIndex in (0, 1) else current_config.get('singleGpuIndex', 0),
            "video_codec_gpu1":             _vc1,
            "preset_gpu1":                  _pr1,
            "postprocess_resolution_gpu1": _pp1,
            "use_bitrate_mode_gpu1":        _ubm1,
            "video_quality_gpu1":           _vq1,
            "video_bitrate_gpu1":           _vb1,
            "vbv_maxrate_gpu1":             _vbv_maxrate1,
            "vbv_bufsize_gpu1":             _vbv_bufsize1,
            "extra_ffmpeg_options_gpu1":    _extra_opts1,
            "audio_codec_gpu1":             _ac1,
            "audio_bitrate_gpu1":           _ab1, 
            "fileManagerEnabled":           effective_fm_enabled,
            "fileManagerRoots":             normalized_roots,
            "fileManagerMode":              fileManagerMode if fileManagerMode in ("blacklist","whitelist") else "blacklist",
            "fileManagerReadOnly":          toBool(fileManagerReadOnly),
            "trashEnabled":                 toBool(trashEnabled),
        }

        previous_notification = loadNotification() or {}
        notification_data = {
            "telegram_enabled": toBool(telegram_enabled),
            "telegram_bot_token": telegram_bot_token.strip() or previous_notification.get("telegram_bot_token", ""),
            "telegram_chat_id": telegram_chat_id.strip() or previous_notification.get("telegram_chat_id", ""),

            "discord_enabled": toBool(discord_enabled),
            "discord_webhook_url": discord_webhook_url.strip() or previous_notification.get("discord_webhook_url", ""),

            "events": {
                "record_started": toBool(notify_record_started),
                "record_finished": toBool(notify_record_finished),
                "record_start_failed": toBool(notify_record_start_failed),
                "record_abnormally_stopped": toBool(notify_record_abnormally_stopped),
                "record_user_stopped": toBool(notify_record_user_stopped),
                "postprocess_finished": toBool(notify_postprocess_finished),
                "postprocess_failed": toBool(notify_postprocess_failed),
                "cookie_auth_failed": toBool(notify_cookie_auth_failed),
                "watchparty_skipped": toBool(notify_watchparty_skipped),
                "disk_space_low": toBool(notify_disk_space_low),
            },

            "limits": {
                "dedupe_seconds": notify_dedupe_seconds,
                "disk_space_low_gb": notify_disk_space_low_gb,
            },
        }
        new_config["diagnosticLogDays"] = normalize_diagnostic_log_days(
            diagnosticLogDays if diagnosticLogDays is not None else current_config.get("diagnosticLogDays")
        )
        protected_config(request, current_config, new_config)
        if not is_local_client(request) and any(
            value.strip() for value in (telegram_bot_token, telegram_chat_id, discord_webhook_url)
        ):
            raise HTTPException(403, '알림 인증값은 서버 PC에서 변경하세요.')

        # 9) 알림 필수값 체크
        error_message = ""

        if notification_data["telegram_enabled"]:
            if not notification_data["telegram_bot_token"] or not notification_data["telegram_chat_id"]:
                error_message = "텔레그램 알림 사용 시 봇 토큰과 채팅방 ID를 모두 입력해야 합니다."

        if not error_message and notification_data["discord_enabled"]:
            if not notification_data["discord_webhook_url"]:
                error_message = "디스코드 알림 사용 시 웹훅 URL을 입력해야 합니다."

        if error_message:
            raise ValueError(error_message)

        new_config = validate_network(new_config, loadAccount())
        new_config['port'] = ensure_port_available(
            new_config['port'],
            "0.0.0.0" if new_config['remoteAccessEnabled'] else "127.0.0.1",
            current_port=getattr(request.app.state, 'actual_port', None),
            previous_port=current_config.get('port'),
        )
        from module.config_validator import validateExtraFfmpegOptions
        for key in ('extra_ffmpeg_options', 'extra_ffmpeg_options_gpu1'):
            validateExtraFfmpegOptions(new_config.get(key, ''))

        # 시작프로그램 반영이 실패하면 설정도 성공으로 저장하지 않습니다.
        if new_config["runAtWindowsStartup"] != bool(current_config.get("runAtWindowsStartup", False)):
            if sys.platform == 'linux':
                raise ValueError('OS 로그인 시 자동 실행은 현재 Windows에서만 지원합니다.')
            from module.windows_startup import set_startup_enabled
            await asyncio.to_thread(set_startup_enabled, BASE_DIR, new_config["runAtWindowsStartup"])
        await apply_linux_startup(request, runAtLinuxStartup)

        print("[DEBUG] 설정 저장 중...")
        merged = saveConfig(new_config)
        request.app.state.config = merged
        set_diagnostic_log_days(merged["diagnosticLogDays"])
        try:
            saveNotification(notification_data)
        except Exception as exc:
            print(f"[ERROR] 알림 설정 저장 실패: {type(exc).__name__}")
            return JSONResponse(
                {"status": "error", "message": "일반 설정은 저장했지만 알림 설정을 저장하지 못했습니다."},
                status_code=500,
            )
        print("[DEBUG] 설정 저장 완료")

        if _gc == 2 and gpuAssignmentsJson:
            try:
                await apply_gpu_assignments(request.app.state, json.loads(gpuAssignmentsJson))
            except Exception as e:
                print(f"[WARN] gpuAssignmentsJson parse/apply failed: {e}")

        restart_required = new_config['port'] != getattr(request.app.state, 'actual_port', new_config['port'])
        message = "설정을 저장했습니다."
        if restart_required:
            message += " 새 포트는 recordWEB을 완전히 종료한 뒤 다시 실행하면 적용됩니다."
        if request.headers.get('x-recordweb-client') == 'settings':
            return JSONResponse({"status": "ok", "message": message, "restart_required": restart_required,
                                 "recordingMetadataRefreshInterval": metadata_interval})
        return RedirectResponse(url="/config", status_code=303)

    except ValueError as e:
        return JSONResponse(content={"status": "error", "message": str(e)}, status_code=400)
    except HTTPException as e:
        return JSONResponse(content={"status": "error", "message": e.detail}, status_code=e.status_code)
    except Exception as e:
        print(f"[ERROR] 설정 저장 중 오류 발생: {type(e).__name__}")
        return JSONResponse(
            content={"status": "error", "message": "설정을 저장하지 못했습니다."},
            status_code=500
        )


@app.get("/get_config")
async def get_config(request: Request):
    try:
        return {"status": "success", "config": public_settings(request.app.state.config)}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.post("/api/channels/batch")
async def batch_channels_api(request: Request):
    from module.channel_service import batch_channels
    return await batch_channels(request)


@app.post("/api/channel-cleanup/{channel_id:path}")
async def channel_cleanup_api(channel_id: str, request: Request):
    from module.channel_service import cleanup_channel
    if channel_id not in getattr(request.app.state, "pending_channel_cleanup", {}):
        raise HTTPException(404, "정리 대기 작업이 없습니다.")
    await cleanup_channel(request.app.state, channel_id)
    return {"status": "success"}


@app.get("/api/channel-cleanups")
async def channel_cleanups_api(request: Request):
    return [{"id": cid, **entry} for cid, entry in getattr(request.app.state, "pending_channel_cleanup", {}).items()]


@app.get("/api/diagnostics")
async def diagnostics_api(request: Request):
    from module.diagnostics import channel_diagnostics
    return channel_diagnostics(request.app.state)


@app.get("/api/environment")
async def environment_api(force: bool = False):
    from module.diagnostics import environment_check
    return await environment_check(force=force)


@app.get("/api/postprocess-failures")
async def postprocess_failures_api():
    from module.postprocess_recovery import list_failures
    return await asyncio.to_thread(list_failures)


@app.get("/api/postprocess-history")
async def postprocess_history_api():
    from module.postprocess_recovery import list_history
    return await asyncio.to_thread(list_history)


@app.post("/api/postprocess-retry/{job_id}")
async def postprocess_retry_api(job_id: str, request: Request):
    from module.postprocess_recovery import retry
    return await retry(request, job_id)


@app.delete("/api/postprocess-records/{job_id}")
async def delete_postprocess_record_api(job_id: str):
    from module.postprocess_store import delete_record
    await asyncio.to_thread(delete_record, job_id)
    return {"message": "후처리 기록을 삭제했습니다."}


# 상태 조회 성공 로그 생략
def keep_access_log(record):
    args = record.args
    return not (
        isinstance(args, tuple) and len(args) == 5
        and args[1:3] == ('GET', '/status') and args[4] == 200
    )


# Uvicorn 서버 실행
class RecordWebServer(uvicorn.Server):
    @contextmanager
    def capture_signals(self):
        if sys.platform != 'linux' or threading.current_thread() is not threading.main_thread():
            with super().capture_signals():
                yield
            return

        import signal
        def stop(signum, frame):
            self.should_exit = True
        handlers = {sig: signal.signal(sig, stop) for sig in (signal.SIGINT, signal.SIGTERM)}
        try:
            yield
        finally:
            for sig, handler in handlers.items():
                signal.signal(sig, handler)

    async def startup(self, sockets=None):
        await super().startup(sockets)
        if self.started and not self.should_exit:
            if _runtime_guard is not None:
                _runtime_guard.update_port(app.state.actual_port)
            if sys.platform == 'linux':
                port = app.state.actual_port
                print(f'[recordWEB] 현재 PC: http://127.0.0.1:{port}')
                if app.state.bound_remote:
                    for address in interface_ipv4_addresses():
                        print(f'[recordWEB] 인터페이스 접속 주소: http://{address}:{port}')
                if app.state.run_mode in ('normal', 'lite'):
                    threading.Thread(target=startWebTray, daemon=True, name='recordWEB tray').start()
            else:
                startWebTray()


async def runUvicorn(config_data=None):
    try:
        if config_data is None:
            config_data = loadConfig()
        port = config_data.get('port', 5000)  # port 값 불러오고, 없으면 기본값 5000 사용

        # Uvicorn 서버를 비동기적으로 실행
        config_data = validate_network(config_data, loadAccount())
        remote = config_data['remoteAccessEnabled']
        port = config_data['port']
        app.state.bound_remote = remote
        app.state.actual_port = port
        RUNTIME_IDENTITY['port'] = port
        host = "0.0.0.0" if remote else "127.0.0.1"
        config = uvicorn.Config(app, host=host, port=port, log_level="info", use_colors=False, proxy_headers=False)
        logging.getLogger('uvicorn.access').addFilter(keep_access_log)
        server = RecordWebServer(config)
        app.state.server = server
        if os.name == 'nt' and os.environ.get('RWEB_SHUTDOWN_EVENT'):
            from module.session_owner import watch_shutdown
            threading.Thread(target=watch_shutdown, args=(server,), daemon=True).start()
        print(f"[DEBUG] Uvicorn 서버 시작 - 포트 {port}")
        await server.serve()
    except Exception as e:
        print(f"[ERROR] runUvicorn 중 오류 발생: {e}")
        raise e


# 비동기로 서버 실행 함수 
async def runAutomodeServer():
    try:
        # 자동녹화는 lifespan에서 시작하므로 여기서는 서버만 띄움
        print("[DEBUG] runUvicorn 호출")
        await runUvicorn()

    except Exception as e:
        print(f"[ERROR] 서버 실행 중 오류 발생: {e}")
        try:
            recordException("recordWEB.runAutomodeServer", e)
        except Exception:
            pass


# 트레이 아이콘 기동 함수 (수정본)
def startWebTray():
    try:
        if getattr(app.state, 'run_mode', None) not in ("normal", "lite"):
            return
        linux = sys.platform == 'linux'
        if linux:
            from module.linux_desktop import run_tray
            run_tray(app, tray_control, BASE_DIR)
            return
        if os.name != 'nt':
            return
        import pystray
        from PIL import Image

        # 모듈 네임스페이스 별칭 (함수 내부 re-import 불필요)
        Menu     = pystray.Menu
        MenuItem = pystray.MenuItem
        Icon     = pystray.Icon

        icon_path = os.path.join(BASE_DIR, "templates", "static", "img", "recordweb.ico")

        try:
            with Image.open(icon_path) as source:
                img = source.copy()
        except Exception:
            # 못 열면 투명 64x64 placeholder
            img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
            print(f"[WARN] tray icon open failed: {icon_path}")

        def _open_desktop():
            try:
                executable = os.path.join(os.path.dirname(sys.executable), 'pythonw.exe')
                subprocess.Popen([executable, os.path.join(BASE_DIR, "module", "recordWEB_launcher.py"), "--open-ui"], cwd=BASE_DIR,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except OSError as error:
                print(f"[WARN] 전용 창 열기 실패: {error}")

        def _open_browser():
            try:
                import webbrowser
                webbrowser.open(f"http://127.0.0.1:{int(app.state.actual_port)}/")
            except Exception as error:
                print(f"[WARN] 브라우저 열기 실패: {error}")

        def _start_all():
            tray_control.submit("start")

        def _stop_all():
            tray_control.submit("stop")

        def _on_quit(icon, item):
            if tray_control.submit("quit") is not None:
                icon.stop()

        menu = Menu(
            MenuItem("recordWEB 창 열기", _open_desktop),
            MenuItem("브라우저에서 열기", _open_browser),
            Menu.SEPARATOR,
            MenuItem("모두 녹화 시작", _start_all),
            MenuItem("모두 녹화 중지", _stop_all),
            Menu.SEPARATOR,
            MenuItem("recordWEB 완전 종료", _on_quit),
        )

        # 현재 스레드 블록하지 않음
        icon = Icon("recordWEB", img, "recordWEB", menu)
        app.state.tray_icon = icon
        tray_control.notify = lambda message: icon.notify(message, "recordWEB")
        icon.run_detached()
        print("[DEBUG] Web tray icon started (detached).")

    except Exception as e:
        print(f"[WARN] 트레이 초기화 중 예외: {e}")



if __name__ == "__main__":
    config_data = None
    try:
        _runtime_guard = RuntimeGuard("recordWEB", identity=RUNTIME_IDENTITY).acquire()
        from module.backup_restore import apply_pending, data_dir
        try:
            apply_pending(data_dir(), loadConfig(restore_backup=False))
        except Exception as error:
            print(f"[FATAL] 복원 기록을 안전하게 정리하지 못했습니다. json/backups의 자동 백업을 확인하세요. ({type(error).__name__})")
            sys.exit(22)
        config_data = validate_network(loadConfig(), loadAccount())
        port = config_data['port']
        _runtime_guard.update_port(port)
        warning = legacy_port_warning(port)
        if warning:
            print(f"[WARN] {warning}")
        if sys.platform != 'linux':
            ensure_port_available(
                port,
                "0.0.0.0" if config_data['remoteAccessEnabled'] else "127.0.0.1",
                previous_port=port,
            )
        validateRuntimeEnvironment("recordWEB")
    except RuntimeAlreadyRunning as e:
        if sys.platform == 'linux':
            from module.recordWEB_launcher import RuntimeUnavailable, runtime_port_hint, runtime_status
            deadline = time.monotonic() + 15
            while time.monotonic() < deadline:
                try:
                    status = runtime_status(timeout=1) if runtime_port_hint() is not None else None
                except RuntimeUnavailable:
                    status = None
                except RuntimeError as error:
                    sys.exit(str(error))
                if status:
                    print(f"[recordWEB] 기존 서버 실행 중 (PID {status['pid']}, 포트 {status['port']}).")
                    if os.environ.get('RWEB_LINUX_GUI') and status['run_mode'] in ('normal', 'lite'):
                        from module.linux_desktop import open_window
                        open_window(BASE_DIR)
                    sys.exit(0)
                time.sleep(.25)
            sys.exit('[recordWEB] 기존 서버가 시작 중이거나 응답하지 않습니다. 로그를 확인하세요.')
        print(f"[FATAL] {e}")
        sys.exit(1)
    except ValueError as e:
        print(f"[FATAL] 서버 포트 사용 오류: {e}")
        sys.exit(21)
    except Exception as e:
        if sys.platform == 'linux' or config_data is None:
            sys.exit(f'[recordWEB] 시작 점검 실패: {e}')
        print(f"[WARN] 시작 전 안정성 점검 실패(계속 진행): {e}")
        try:
            recordException("recordWEB.startup", e)
        except Exception:
            pass

    set_diagnostic_log_days(config_data["diagnosticLogDays"])
    start_diagnostic_log_cleanup()

    if sys.platform == 'linux':
        try:
            asyncio.run(runUvicorn(config_data))
            if not app.state.server.started:
                sys.exit(21)
        finally:
            if _runtime_guard is not None:
                _runtime_guard.release()
        sys.exit(0)

    internal_ip, local_ip, external_ip = getAddresses()

    # 프로그램 이름과 버전 출력
    print(f"Starting {PROGRAM_NAME} version {PROGRAM_VERSION}")

    # 프로그램 첫 실행 시 FFmpeg와 Streamlink 경로 확인
    checkRequiredPaths()

    if internal_ip and "오류" not in internal_ip:
        print(f"* 로컬호스트 주소로 접속 http://{internal_ip}:{port}")

    if local_ip and "오류" not in local_ip:
        print(f"* 내부 사설 IP 주소로 접속 http://{local_ip}:{port}")

    if external_ip and "오류" not in external_ip:
        print(f"* 공인 IP 주소로 접속 http://{external_ip}:{port}")

    asyncio.run(runAutomodeServer())
