"""Read and write the bounded recordWEB settings archive."""
from datetime import datetime
from io import BytesIO
import json
import stat
from zlib import error as ZlibError
from zipfile import BadZipFile, ZIP_DEFLATED, ZipFile

from module import data_manager as dm


ITEMS = {
    "channels": ("channels.json", "channel_groups.json"),
    "config": ("config.json",),
    "platform_cookies": ("cookie.json",),
    "youtube_cookies": ("ycookie.txt",),
}
FILES = tuple(name for names in ITEMS.values() for name in names)
MANIFEST = "backup_manifest.json"
MAX_UPLOAD = 4 * 1024 * 1024
MAX_CONTENT = 8 * 1024 * 1024


def json_data(raw):
    def invalid_constant(_):
        raise ValueError("JSON에 허용되지 않는 숫자가 있습니다.")

    return json.loads(raw.decode("utf-8-sig"), parse_constant=invalid_constant)


def create_archive(files):
    if sum(map(len, files.values())) > MAX_CONTENT - 4096:
        raise ValueError("설정 파일의 전체 크기가 백업 한도를 초과합니다.")
    created = datetime.now().astimezone()
    manifest = {
        "backup_format": 1,
        "recordweb_version": dm.PROGRAM_VERSION,
        "created_at": created.isoformat(timespec="seconds"),
        "included_files": list(files),
    }
    archive = BytesIO()
    with ZipFile(archive, "w", compression=ZIP_DEFLATED) as target:
        target.writestr(MANIFEST, json.dumps(manifest, ensure_ascii=False, indent=2))
        for name, content in files.items():
            target.writestr(name, content)
    content = archive.getvalue()
    if len(content) > MAX_UPLOAD:
        raise ValueError("백업 ZIP이 크기 한도를 초과합니다.")
    return f"recordWEB_backup_{created:%Y%m%d_%H%M%S}.zip", content


def read_archive(content, *, allow_empty=False):
    if len(content) > MAX_UPLOAD:
        raise ValueError("백업 ZIP은 4MB 이하만 사용할 수 있습니다.")
    files = {}
    manifest = None
    try:
        with ZipFile(BytesIO(content)) as source:
            entries = source.infolist()
            if len(entries) > len(FILES) + 2 or sum(i.file_size for i in entries) > MAX_CONTENT:
                raise ValueError("ZIP의 항목 수 또는 압축 해제 크기가 한도를 초과합니다.")
            for entry in entries:
                if entry.filename == "json/" and entry.is_dir():
                    continue
                name = entry.filename.removeprefix("json/")
                if (entry.orig_filename != entry.filename or name not in (*FILES, MANIFEST)
                        or name in files or (name == MANIFEST and manifest is not None)
                        or entry.flag_bits & 1 or stat.S_ISLNK(entry.external_attr >> 16)):
                    raise ValueError("지원하지 않거나 중복된 항목이 ZIP에 들어 있습니다.")
                with source.open(entry) as source_file:
                    data = source_file.read(entry.file_size + 1)
                if len(data) != entry.file_size:
                    raise ValueError("ZIP 내부 파일 크기가 기록과 다릅니다.")
                if name == MANIFEST:
                    manifest = json_data(data)
                    if not isinstance(manifest, dict):
                        raise ValueError("백업 정보 파일의 형식이 올바르지 않습니다.")
                else:
                    files[name] = data
    except (BadZipFile, RuntimeError, NotImplementedError, OSError, UnicodeError, RecursionError, ZlibError) as exc:
        raise ValueError("백업 ZIP의 압축 또는 백업 정보를 읽을 수 없습니다.") from exc
    if not files and not allow_empty:
        raise ValueError("ZIP에 복원할 설정 파일이 없습니다.")
    if manifest is not None:
        names = manifest.get("included_files")
        if (type(manifest.get("backup_format")) is not int or manifest["backup_format"] != 1
                or not isinstance(names, list) or any(not isinstance(name, str) for name in names)
                or sorted(files) != sorted(names)
                or not isinstance(manifest.get("recordweb_version"), str)
                or not isinstance(manifest.get("created_at"), str)):
            raise ValueError("백업 형식 버전이 지원되지 않거나 ZIP 내용이 백업 정보와 다릅니다.")
        try:
            datetime.fromisoformat(manifest["created_at"])
        except ValueError as exc:
            raise ValueError("백업 생성 시각을 읽을 수 없습니다.") from exc
    return files, manifest
